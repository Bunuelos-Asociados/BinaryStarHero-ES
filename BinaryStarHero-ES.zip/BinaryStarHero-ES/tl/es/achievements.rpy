
# game/achievements.rpyc:148
translate es demonizer_e21a5ae1:

    # "The day has been slow..."
    "El día ha sido lento..."

# game/achievements.rpyc:150
translate es demonizer_3af860d8:

    # "Not many people coming or going, I can't help but to space out."
    "No mucha gente entra o sale, no puedo evitar distraerme."

# game/achievements.rpyc:152
translate es demonizer_2cdee4fd:

    # "My eyes blur as I fight to keep focus and stay alert."
    "Mi vista se nubla mientras lucho por mantenerme firme y alerta."

# game/achievements.rpyc:154
translate es demonizer_6f165b9f:

    # "{i}Maybe I can use some coffee myself...{/i}"
    "{i}Tal vez yo necesite un poco de café...{/i}"

# game/achievements.rpyc:156
translate es demonizer_079bfede:

    # "My eyes trace the subtle grooves and crevices of the counter top as I space out."
    "Mis ojos siguen los sutiles surcos y grietas del mostrador mientras me pierdo en mis pensamientos."

# game/achievements.rpyc:162
translate es demonizer_32c54207:

    # "I glance upwards, my eyes meeting the strange customer's form."
    "Levanto la mirada, mis ojos se encuentran con la figura del extraño cliente."

# game/achievements.rpyc:170
translate es demonizer_86376840:

    # "They smile, their mouth full of sharp teeth."
    "Sonríe, su boca llena de dientes afilados."

# game/achievements.rpyc:172
translate es demonizer_328ce478:

    # "They sport some sharp horns and a peculiar tail."
    "Tiene unos cuernos puntiagudos y una cola peculiar."

# game/achievements.rpyc:180
translate es demonizer_6c5958fe:

    # mc2 "Oh...sorry..."
    mc2 "Oh... perdón..."

# game/achievements.rpyc:188
translate es demonizer_ac64d845:

    # "I clear my throat and shift on my feet, uncomfortable."
    "Aclaro mi garganta y cambio el peso en mis pies, con incomodidad."

# game/achievements.rpyc:190
translate es demonizer_2fde643f:

    # "His sharp teeth gleamed in the light."
    "Sus dientes afilados brillan bajo la luz."

# game/achievements.rpyc:199
translate es demonizer_61a55c01:

    # mc2 "Well, it depends what you are feeling."
    mc2 "Bueno, depende de lo que estés sintiendo."

# game/achievements.rpyc:209
translate es demonizer_b758d8a1:

    # mc2 "Oh yeah? What do I get if I guess right?"
    mc2 "¿Ah sí? ¿Y qué obtengo si adivino bien?"

# game/achievements.rpyc:211
translate es demonizer_ee89372e:

    # "The customer looks amused, he leans in."
    "El cliente parece divertido, se inclina hacia adelante."

# game/achievements.rpyc:229
translate es demonizer_ae283dd0:

    # "I laugh at the bold proclamation."
    "Me río ante su audaz proclamación."

# game/achievements.rpyc:233
translate es demonizer_4ac3d8e8:

    # mc2 "You will give me... whatever I want?"
    mc2 "¿Me darás... lo que yo quiera?"

# game/achievements.rpyc:250
translate es demonizer_c0209843:

    # "I knot my eyebrows. Their tone seemed friendly, but something screamed in me that danger slithered under the surface."
    "Frunzo el ceño. Su tono parecía amistoso, pero algo dentro de mí gritaba que había peligro reptando bajo la superficie."

# game/achievements.rpyc:254
translate es demonizer_5c9eeb03:

    # mc2 "Well then...what will you take?"
    mc2 "Bueno entonces... ¿qué tomarás?"

# game/achievements.rpyc:256
translate es demonizer_5cfedb46:

    # "They just smile."
    "Solo sonríe."

# game/achievements.rpyc:266
translate es demonizer_0ab6b5ea:

    # mc2 "I...I'm not sure."
    mc2 "Yo... no se."

# game/achievements.rpyc:268
translate es demonizer_430dcf25:

    # "The customer leans back."
    "El cliente se reclina hacia atrás."

# game/achievements.rpyc:287
translate es demonizer_ec4fb474:

    # z "..."
    z "..."

# game/achievements.rpyc:289
translate es demonizer_2594be06:

    # "A blank expression crosses their face."
    "Una expresión vacía cruza su rostro."

# game/achievements.rpyc:298
translate es demonizer_32da4d5a:

    # "They tilt their head quizzically."
    "Inclinan la cabeza, curiosos."

# game/achievements.rpyc:321
translate es demonizer_9f03aa55:

    # mc2 "Well I guess I lost then."
    mc2 "Supongo que entonces perdí."

# game/achievements.rpyc:331
translate es demonizer_0cd55675:

    # mc2 "I feel like you somehow rigged this...."
    mc2 "Siento que de alguna manera hiciste trampa..."

# game/achievements.rpyc:333
translate es demonizer_031f1540:

    # "They smile innocently."
    "Sonríe inocentemente."

# game/achievements.rpyc:349
translate es demonizer_271baa90:

    # "The customer openly mocks me, cackling loudly."
    "El cliente se burla abiertamente de mí, riendo a carcajadas."

# game/achievements.rpyc:353
translate es demonizer_f3563d79:

    # mc2 "You are such an asshole."
    mc2 "Eres un idiota."

# game/achievements.rpyc:377
translate es demonizer_01c689a4:

    # mc2 "What? No, I don't. I don't even know you..."
    mc2 "¿Qué? No, no lo soy. Ni siquiera te conozco..."

# game/achievements.rpyc:392
translate es demonizer_8c03df90:

    # mc2 "No, I...I-"
    mc2 "No, yo... yo—"

# game/achievements.rpyc:394
translate es demonizer_7e6c1ad4:

    # mc2 "I..I don't-"
    mc2 "Yo... yo no—"

# game/achievements.rpyc:400
translate es demonizer_dc9e2551:

    # "My head begins to reel, my surroundings feel {i}wrong.{/i}"
    "Mi cabeza empieza a dar vueltas, mi entorno se siente {i}mal.{/i}"

# game/achievements.rpyc:422
translate es demonizer_52783d93:

    # "The customer leans on the counter looking down at me."
    "El cliente se apoya en el mostrador mirándome desde arriba."

# game/achievements.rpyc:424
translate es demonizer_1b3f3963:

    # "I back up a bit, frazzled by the sudden closeness."
    "Retrocedo un poco, desconcertada por la repentina cercanía."

# game/achievements.rpyc:428
translate es demonizer_fba541ef:

    # mc2 "Ask...ask what...?"
    mc2 "¿Preguntar... qué...?"

# game/achievements.rpyc:430
translate es demonizer_edd561fc:

    # "I start to feel dizzy."
    "Empiezo a sentir mareo."

# game/achievements.rpyc:452
translate es demonizer_446b1e02:

    # mc2 "We should stop playing around."
    mc2 "Deberíamos dejar de jugar."

# game/achievements.rpyc:461
translate es demonizer_a9f0f768:

    # "The customer..."
    "El cliente..."

# game/achievements.rpyc:463
translate es demonizer_d8488db6:

    # "Z leans in close."
    "Z se inclina cerca."

# game/achievements.rpyc:480
translate es demonizer_4724f115:

    # "My jaw drops."
    "Mi mandíbula cae."

# game/achievements.rpyc:484
translate es demonizer_7df4a84a:

    # mc2 "Wh..what?!"
    mc2 "¿Q-qué?!"

# game/achievements.rpyc:505
translate es demonizer_f9d3aa0a:

    # mc2 "...?!"
    mc2 "...?!"

# game/achievements.rpyc:512
translate es demonizer_debbb714:

    # "Z leans in closer. They whisper to me."
    "Z se inclina aún más cerca. Me susurra."


# game/game/achievements.rpy:148
translate es demonizer_e21a5ae1_1:

    # "The day has been slow..."
    "El día ha sido lento..."

# game/game/achievements.rpy:150
translate es demonizer_3af860d8_1:

    # "Not many people coming or going, I can't help but to space out."
    "No mucha gente entra o sale, no puedo evitar distraerme."

# game/game/achievements.rpy:152
translate es demonizer_2cdee4fd_1:

    # "My eyes blur as I fight to keep focus and stay alert."
    "Mi vista se nubla mientras lucho por mantenerme firme y alerta."

# game/game/achievements.rpy:154
translate es demonizer_6f165b9f_1:

    # "{i}Maybe I can use some coffee myself...{/i}"
    "{i}Tal vez yo necesite un poco de café...{/i}"

# game/game/achievements.rpy:156
translate es demonizer_079bfede_1:

    # "My eyes trace the subtle grooves and crevices of the counter top as I space out."
    "Mis ojos siguen los sutiles surcos y grietas del mostrador mientras me pierdo en mis pensamientos."

# game/game/achievements.rpy:162
translate es demonizer_32c54207_1:

    # "I glance upwards, my eyes meeting the strange customer's form."
    "Levanto la mirada, mis ojos se encuentran con la figura del extraño cliente."

# game/game/achievements.rpy:170
translate es demonizer_86376840_1:

    # "They smile, their mouth full of sharp teeth."
    "Sonríe, su boca llena de dientes afilados."

# game/game/achievements.rpy:172
translate es demonizer_328ce478_1:

    # "They sport some sharp horns and a peculiar tail."
    "Tiene unos cuernos puntiagudos y una cola peculiar."

# game/game/achievements.rpy:180
translate es demonizer_6c5958fe_1:

    # mc2 "Oh...sorry..."
    mc2 "Oh... perdón..."

# game/game/achievements.rpy:188
translate es demonizer_ac64d845_1:

    # "I clear my throat and shift on my feet, uncomfortable."
    "Aclaro mi garganta y cambio el peso en mis pies, con incomodidad."

# game/game/achievements.rpy:190
translate es demonizer_2fde643f_1:

    # "His sharp teeth gleamed in the light."
    "Sus dientes afilados brillan bajo la luz."

# game/game/achievements.rpy:199
translate es demonizer_61a55c01_1:

    # mc2 "Well, it depends what you are feeling."
    mc2 "Bueno, depende de lo que estés sintiendo."

# game/game/achievements.rpy:209
translate es demonizer_b758d8a1_1:

    # mc2 "Oh yeah? What do I get if I guess right?"
    mc2 "¿Ah sí? ¿Y qué obtengo si adivino bien?"

# game/game/achievements.rpy:211
translate es demonizer_ee89372e_1:

    # "The customer looks amused, he leans in."
    "El cliente parece divertido, se inclina hacia adelante."

# game/game/achievements.rpy:229
translate es demonizer_ae283dd0_1:

    # "I laugh at the bold proclamation."
    "Me río ante su audaz proclamación."

# game/game/achievements.rpy:233
translate es demonizer_4ac3d8e8_1:

    # mc2 "You will give me... whatever I want?"
    mc2 "¿Me darás... lo que yo quiera?"

# game/game/achievements.rpy:250
translate es demonizer_c0209843_1:

    # "I knot my eyebrows. Their tone seemed friendly, but something screamed in me that danger slithered under the surface."
    "Frunzo el ceño. Su tono parecía amistoso, pero algo dentro de mí gritaba que había peligro reptando bajo la superficie."

# game/game/achievements.rpy:254
translate es demonizer_5c9eeb03_1:

    # mc2 "Well then...what will you take?"
    mc2 "Bueno entonces... ¿qué tomarás?"

# game/game/achievements.rpy:256
translate es demonizer_5cfedb46_1:

    # "They just smile."
    "Solo sonríe."

# game/game/achievements.rpy:266
translate es demonizer_0ab6b5ea_1:

    # mc2 "I...I'm not sure."
    mc2 "Yo... no se."

# game/game/achievements.rpy:268
translate es demonizer_430dcf25_1:

    # "The customer leans back."
    "El cliente se reclina hacia atrás."

# game/game/achievements.rpy:287
translate es demonizer_ec4fb474_1:

    # z "..."
    z "..."

# game/game/achievements.rpy:289
translate es demonizer_2594be06_1:

    # "A blank expression crosses their face."
    "Una expresión vacía cruza su rostro."

# game/game/achievements.rpy:298
translate es demonizer_32da4d5a_1:

    # "They tilt their head quizzically."
    "Inclinan la cabeza, curiosos."

# game/game/achievements.rpy:321
translate es demonizer_9f03aa55_1:

    # mc2 "Well I guess I lost then."
    mc2 "Supongo que entonces perdí."

# game/game/achievements.rpy:331
translate es demonizer_0cd55675_1:

    # mc2 "I feel like you somehow rigged this...."
    mc2 "Siento que de alguna manera hiciste trampa..."

# game/game/achievements.rpy:333
translate es demonizer_031f1540_1:

    # "They smile innocently."
    "Sonríe inocentemente."

# game/game/achievements.rpy:349
translate es demonizer_271baa90_1:

    # "The customer openly mocks me, cackling loudly."
    "El cliente se burla abiertamente de mí, riendo a carcajadas."

# game/game/achievements.rpy:353
translate es demonizer_f3563d79_1:

    # mc2 "You are such an asshole."
    mc2 "Eres un idiota."

# game/game/achievements.rpy:377
translate es demonizer_01c689a4_1:

    # mc2 "What? No, I don't. I don't even know you..."
    mc2 "¿Qué? No, no lo soy. Ni siquiera te conozco..."

# game/game/achievements.rpy:392
translate es demonizer_8c03df90_1:

    # mc2 "No, I...I-"
    mc2 "No, yo... yo—"

# game/game/achievements.rpy:394
translate es demonizer_7e6c1ad4_1:

    # mc2 "I..I don't-"
    mc2 "Yo... yo no—"

# game/game/achievements.rpy:400
translate es demonizer_dc9e2551_1:

    # "My head begins to reel, my surroundings feel {i}wrong.{/i}"
    "Mi cabeza empieza a dar vueltas, mi entorno se siente {i}mal.{/i}"

# game/game/achievements.rpy:422
translate es demonizer_52783d93_1:

    # "The customer leans on the counter looking down at me."
    "El cliente se apoya en el mostrador mirándome desde arriba."

# game/game/achievements.rpy:424
translate es demonizer_1b3f3963_1:

    # "I back up a bit, frazzled by the sudden closeness."
    "Retrocedo un poco, desconcertada por la repentina cercanía."

# game/game/achievements.rpy:428
translate es demonizer_fba541ef_1:

    # mc2 "Ask...ask what...?"
    mc2 "¿Preguntar... qué...?"

# game/game/achievements.rpy:430
translate es demonizer_edd561fc_1:

    # "I start to feel dizzy."
    "Empiezo a sentir mareo."

# game/game/achievements.rpy:452
translate es demonizer_446b1e02_1:

    # mc2 "We should stop playing around."
    mc2 "Deberíamos dejar de jugar."

# game/game/achievements.rpy:461
translate es demonizer_a9f0f768_1:

    # "The customer..."
    "El cliente..."

# game/game/achievements.rpy:463
translate es demonizer_d8488db6_1:

    # "Z leans in close."
    "Z se inclina cerca."

# game/game/achievements.rpy:480
translate es demonizer_4724f115_1:

    # "My jaw drops."
    "Mi mandíbula cae."

# game/game/achievements.rpy:484
translate es demonizer_7df4a84a_1:

    # mc2 "Wh..what?!"
    mc2 "¿Q-qué?!"

# game/game/achievements.rpy:505
translate es demonizer_f9d3aa0a_1:

    # mc2 "...?!"
    mc2 "...?!"

# game/game/achievements.rpy:512
translate es demonizer_debbb714_1:

    # "Z leans in closer. They whisper to me."
    "Z se inclina aún más cerca. Me susurra."

translate es strings:

    old "'Decaf Coffee'"
    new "'Café descafeinado'"

    old "'Black coffee'"
    new "'Café negro'"

    old "'Caramel latte'"
    new "'Latte de caramelo'"
