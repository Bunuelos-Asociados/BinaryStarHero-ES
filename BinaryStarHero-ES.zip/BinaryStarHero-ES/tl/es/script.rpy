
# game/game/script.rpy:55
translate es prologue_1ecc5182:

    # n "In the modern era of superheroes and super villains I.... was just a regular villain."
    n "En la era moderna de los superhéroes y supervillanos yo... hacia parte de los comunes villanos."

# game/game/script.rpy:57
translate es prologue_f4678561:

    # n "And I say {i}'was'{/i} very intentionally here."
    n "Y digo {i}'era'{/i} muy intencionalmente aquí."

# game/game/script.rpy:59
translate es prologue_7fb58161:

    # n "My days of crime are officially over."
    n "Mis días de crimen han terminado oficialmente."

# game/game/script.rpy:61
translate es prologue_b0776188:

    # n "I didn't go out in a large daring stunt, or in insane wealth like most may assume that a villain would."
    n "No salí con una gran y atrevida hazaña, ni con una riqueza insana como muchos podrían suponer que lo haría un villano."

# game/game/script.rpy:63
translate es prologue_51a26fc0:

    # n "Most may assume that villains finally retire when nature makes an end of our perpetual greed and selfishness."
    n "La mayoría podría suponer que los villanos finalmente se retiran cuando la naturaleza pone fin a nuestra perpetua codicia y egoísmo."

# game/game/script.rpy:65
translate es prologue_83beccde:

    # n "Eventually spiraling into self sabotage, becoming our own undoing."
    n "Eventualmente cayendo en la auto sabotaje, convirtiéndonos en nuestra propia perdición."

# game/game/script.rpy:67
translate es prologue_d0a6cac5:

    # n "But that was not me..."
    n "Pero ese no era mi caso..."

# game/game/script.rpy:69
translate es prologue_0a716fb2:

    # n "I had loans to pay off, medications to afford, a family to support."
    n "Tenía préstamos que pagar, medicamentos que costear, una familia que mantener."

# game/game/script.rpy:71
translate es prologue_89655a9f:

    # n "I was not looking for a beautiful life full of luxury, or Gatsby level grandeur."
    n "No buscaba una vida hermosa llena de lujos, ni una grandeza al estilo Gatsby."

# game/game/script.rpy:73
translate es prologue_8f587d38:

    # n "I only wanted to survive."
    n "Solo quería sobrevivir."

# game/game/script.rpy:75
translate es prologue_82003dfa:

    # n "And sometimes we can only survive in the best way we know how."
    n "Y a veces solo podemos sobrevivir de la mejor manera que sabemos."

# game/game/script.rpy:77
translate es prologue_bafd2702:

    # n "For me, that was stealing from others."
    n "Para mí, eso era robar a otros."

# game/game/script.rpy:79
translate es prologue_79b2637e:

    # n "I didn't take from the average joe."
    n "No tomaba del ciudadano promedio."

# game/game/script.rpy:81
translate es prologue_52aa9aca:

    # n "My targets were specifically 7 figures and above."
    n "Mis objetivos eran específicamente de siete cifras en adelante."

# game/game/script.rpy:83
translate es prologue_c651ebeb:

    # n "Well, sometimes I would stoop...but they always deserved it."
    n "Bueno, a veces bajaba el nivel... pero siempre lo merecían."

# game/game/script.rpy:85
translate es prologue_8e2dc5b9:

    # n "But now, it's over."
    n "Pero ahora, se acabó."

# game/game/script.rpy:87
translate es prologue_687973f7:

    # n "I went out nameless."
    n "Me fui sin nombre."

# game/game/script.rpy:89
translate es prologue_2eaf3228:

    # n "As long as you know {i} what {/i} to take, what they can afford to lose, they will never search you out."
    n "Mientras sepas {i}qué{/i} tomar, y qué pueden permitirse perder, nunca te buscarán."

# game/game/script.rpy:91
translate es prologue_6bf3c2f0:

    # n "I'm not proud of what I have done...."
    n "No siento orgullo por lo que hice...."

# game/game/script.rpy:93
translate es prologue_0cd95f45:

    # n "Okay, that's a lie, I'm a {i}little{/i} proud."
    n "Bueno, eso es mentira, siento un {i}poco{/i} de orgullo."

# game/game/script.rpy:95
translate es prologue_a91bd559:

    # n "But not many knew of me."
    n "Pero no muchos sabían de mí."

# game/game/script.rpy:97
translate es prologue_77c80353:

    # n "I was never infamous enough to attract the attention of the heroes."
    n "Nunca fui lo bastante infame para atraer la atención de los héroes."

# game/game/script.rpy:99
translate es prologue_a21fe9cb:

    # n "But the underground crime world sure knew me..."
    n "Pero el mundo del crimen subterráneo sí me conocían..."

# game/game/script.rpy:101
translate es prologue_b12faf40:

    # n "They referred to me as..."
    n "Me llamaban..."

# game/game/script.rpy:115
translate es prologue_f0edd72f:

    # n "{color=#fffb00}[criminalname]{/color}"
    n "{color=#fffb00}[criminalname]{/color}"

# game/game/script.rpy:117
translate es prologue_ab851b70:

    # n "In infamy I even gained a small fan following of fellow criminals."
    n "En la infamia incluso gané una pequeña base de admiradores entre otros criminales."

# game/game/script.rpy:119
translate es prologue_58a4e022:

    # n "But that doesn't change the fact that those days are over for me."
    n "Pero eso no cambia el hecho de que esos días se acabaron para mí."

# game/game/script.rpy:121
translate es prologue_b33f80eb:

    # n "My loans are payed off, my family has a proper safety net, I can afford my medication (for a while at least)...."
    n "Mis préstamos están pagados, mi familia tiene una red de seguridad adecuada, puedo pagar mis medicamentos (al menos por un tiempo)...."

# game/game/script.rpy:123
translate es prologue_8fa61767:

    # n "It was a means to an end."
    n "Fue un medio para un fin."

# game/game/script.rpy:125
translate es prologue_41649405:

    # n "And now, the present day me..."
    n "Y ahora, el yo del presente..."

# game/game/script.rpy:132
translate es prologue_c5a58042:

    # m "Ayo, Newbie, pass me some napkins! Some old fart dropped his coffee."
    m "¡Ey, Principiante, pásame unas servilletas! Un viejo dejó caer su café."

# game/game/script.rpy:134
translate es prologue_e083a00e:

    # "I groan looking at the clock."
    "Gimo mirando el reloj."

# game/game/script.rpy:136
translate es prologue_ec699a76:

    # "{i}Only 9am...{/i}."
    "{i}Solo las 9 a. m...{/i}."

# game/game/script.rpy:138
translate es prologue_5f3c55e0:

    # "I sigh heavily, my coworker's voice grating on my ears."
    "Suspiro pesadamente, la voz de mi compañero me taladra los oídos."

# game/game/script.rpy:140
translate es prologue_517d4d01:

    # "I pass my 9am annoyance some napkins."
    "Le paso unas servilletas a mi molestia de las 9 a. m."

# game/game/script.rpy:147
translate es prologue_9f1b4449:

    # m "If you sigh like that you will only bring yourself bad luck Newbie."
    m "Si suspiras así solo te traerás mala suerte, Principiante."

# game/game/script.rpy:149
translate es prologue_d3851ee0:

    # m "Uhh...yeah, I'm going to need more napkins than this."
    m "Uhh... sí, voy a necesitar más servilletas que estas."

# game/game/script.rpy:151
translate es prologue_db5f82e9:

    # m "Gramps spilled like his {i}whole{/i} coffee."
    m "El abuelo derramó como {i}todo{/i} el café."

# game/game/script.rpy:157
translate es prologue_a4b48621:

    # m "Whole {i}bean{/i} coffee ....heh heh..."
    m "Café de {i}grano entero{/i}... je je..."

# game/game/script.rpy:159
translate es prologue_19aa3e60:

    # "I glance a glare at my coworker Miles."
    "Lanzo una mirada fulminante a mi compañero Miles."

# game/game/script.rpy:161
translate es prologue_0daca320:

    # "I am about to ask if he is high at 9 in the morning when he cuts me off."
    "Estoy a punto de preguntarle si está drogado a las nueve de la mañana cuando me interrumpe."

# game/game/script.rpy:165
translate es prologue_3b801e06:

    # m "Hey, uh by the way, what's your name again? If I ask Hals they'll explode at me."
    m "Oye, eh, por cierto, ¿cómo era tu nombre otra vez? Si le pregunto a Hals me van a explotar."

# game/game/script.rpy:169
translate es prologue_6aa58914:

    # "He laughs sheepishly scratching his head."
    "Ríe con torpeza mientras se rasca la cabeza."

# game/game/script.rpy:181
translate es playername_e7297468:

    # mc "My name is %(player_name)s. We have been working here together for over a month Miles."
    mc "Mi nombre es %(player_name)s. Hemos trabajado aquí juntos por más de un mes, Miles."

# game/game/script.rpy:186
translate es playername_6b87f74e:

    # m "Oh right, %(player_name)s....."
    m "Ah, cierto, %(player_name)s....."

# game/game/script.rpy:188
translate es playername_6c4acbbd:

    # m "Don't be mad, I promise I'll remember next time!"
    m "No te enojes, ¡prometo recordarlo la próxima vez!"

# game/game/script.rpy:192
translate es playername_09e75ba8:

    # "Miles walks towards the spill with an incredible amount of napkins in hand."
    "Miles camina hacia el derrame con una cantidad ridícula de servilletas en la mano."

# game/game/script.rpy:194
translate es playername_1c41d693:

    # mc "Miles, you know we have a cleaning supplies closet right?"
    mc "Miles, sabes que tenemos un armario de limpieza, ¿verdad?"

# game/game/script.rpy:196
translate es playername_c7844956:

    # mc "If you just wipe it up with napkins it's going to be sticky."
    mc "Si solo lo limpias con servilletas va a quedar pegajoso."

# game/game/script.rpy:200
translate es playername_cf81516d:

    # m "Sheesh newbie, I don't tell you how to live your life."
    m "Ay, principiante, yo no te digo cómo vivir tu vida."

# game/game/script.rpy:202
translate es playername_f95d5e47:

    # "I shoot a glare at Miles."
    "Le lanzo otra mirada a Miles."

# game/game/script.rpy:204
translate es playername_2f32395d:

    # mc "Please stop calling me Newbie."
    mc "Por favor, deja de llamarme Principiante."

# game/game/script.rpy:208
translate es playername_b66ef6a0:

    # m "Ahaha, okay, okay. I get it, sure."
    m "Ajaja, está bien, está bien. Lo entiendo, seguro."

# game/game/script.rpy:210
translate es playername_eeb03fd1:

    # m "My legs are like super sore from stock this morning though."
    m "Pero mis piernas están súper adoloridas por reponer mercancía esta mañana."

# game/game/script.rpy:212
translate es playername_ae33d949:

    # m "Do you mind cleaning it up and I'll man the register?"
    m "¿Te importa limpiarlo y yo atiendo la caja?"

# game/game/script.rpy:214
translate es playername_52755230:

    # mc "Hals said you aren't allowed on the register anymore after charging a customer $20 extra..."
    mc "Hals dijo que ya no tienes permitido tocar la caja después de cobrarle $20 de más a un cliente..."

# game/game/script.rpy:216
translate es playername_30b8c38f:

    # m "That was only one-"
    m "Eso fue solo una—"

# game/game/script.rpy:218
translate es playername_fcf0ac2a:

    # mc "For the third time. {i}In one day Miles{/i}."
    mc "Por tercera vez. {i}En un solo día, Miles{/i}."

# game/game/script.rpy:220
translate es playername_ed99ef90:

    # m "Just be chill, Hals only take your side because-"
    m "Tranquilízate, Hals solo toma tu lado porque—"

# game/game/script.rpy:224
translate es playername_a369abf9:

    # h "Because {i}what{/i} Miles?"
    h "¿Porque {i}qué{/i}, Miles?"

# game/game/script.rpy:229
translate es playername_c0159446:

    # "Haley's tall unimpressed stare gazes at Miles."
    "La alta y poco impresionada mirada de Haley se fija en Miles."

# game/game/script.rpy:234
translate es playername_1c3a1830:

    # m "AH!"
    m "¡AH!"

# game/game/script.rpy:238
translate es playername_61b6e134:

    # m "Haley! How are you so quiet?!"
    m "¡Haley! ¿Cómo puedes ser tan silenciose?!"

# game/game/script.rpy:242
translate es playername_362d7e6d:

    # h "Miles."
    h "Miles."

# game/game/script.rpy:248
translate es playername_1dbbfbd1:

    # m "Yeah."
    m "Sí."

# game/game/script.rpy:252
translate es playername_bb5285f5:

    # h "Go clean up the mess."
    h "Ve a limpiar el desastre."

# game/game/script.rpy:254
translate es playername_d6729445:

    # "Haley hands Miles a mop and a bucket."
    "Haley le entrega a Miles un trapeador y un balde."

# game/game/script.rpy:256
translate es playername_ebff90eb:

    # "Miles hangs his head walking towards the spill while dragging the mop and bucket behind him."
    "Miles baja la cabeza caminando hacia el derrame mientras arrastra el trapeador y el balde detrás de él."

# game/game/script.rpy:262
translate es playername_c9929bf6:

    # m "Yeah yeah yeah...."
    m "Sí, sí, sí...."

# game/game/script.rpy:264
translate es playername_8d57fdcc:

    # "Miles grumbles sulking back to the spill."
    "Miles refunfuña mientras vuelve cabizbajo al derrame."

# game/game/script.rpy:268
translate es playername_eaf59ab2:

    # "Haley sighs deeply, leaning on the counter next to me."
    "Haley suspira profundamente, apoyándose en el mostrador a mi lado."

# game/game/script.rpy:270
translate es playername_4eeafbf5:

    # "They grab a slightly burnt croissant from the discards pile and pick at it."
    "Toma un croissant ligeramente quemado del montón de descartes y lo desmenuza."

# game/game/script.rpy:276
translate es playername_591c5d21:

    # h "I swear I have never seen Miles do things the right way, even if only one-percent more effort is required."
    h "Juro que nunca he visto a Miles hacer las cosas bien, incluso si solo se requiere un uno por ciento más de esfuerzo."

# game/game/script.rpy:278
translate es playername_6f4520ea:

    # "Haley's stare lingers on Mile's sneakers."
    "La mirada de Haley se posa en los tenis de Miles."

# game/game/script.rpy:280
translate es playername_4762d9e7:

    # h "Damn if those Layon's aren't cool though."
    h "Maldita sea, aunque esos Layon sí que son geniales."

# game/game/script.rpy:282
translate es playername_7f0328e9:

    # "I look at the flashy black and green shoes Miles is sporting."
    "Miro los llamativos zapatos negros y verdes que Miles lleva puestos."

# game/game/script.rpy:284
translate es playername_6f4a60c1:

    # h "I can't resist a good sneaker, even if it's being sported on the least deserving person possible."
    h "No puedo resistirme a unas buenas zapatillas, aunque las lleve la persona menos merecedora posible."

# game/game/script.rpy:286
translate es playername_97e38806:

    # mc "Aren't those things like... a couple hundred at least?"
    mc "¿Esos no cuestan como... un par de cientos al menos?"

# game/game/script.rpy:288
translate es playername_e0cb3642:

    # h "Yep."
    h "Sí."

# game/game/script.rpy:290
translate es playername_f8a171e0:

    # "Haley sighs."
    "Haley suspira."

# game/game/script.rpy:295
translate es playername_9af7c93a:

    # h "Maybe I should just steal them when he takes his afternoon nap in the storage room."
    h "Tal vez debería robárselos cuando se eche su siesta de la tarde en el almacén."

# game/game/script.rpy:297
translate es playername_0fb9fc89:

    # h "How about it? Want to be my partner in crime?"
    h "¿Qué dices? ¿Quieres ser mi cómplice en el crimen?"

# game/game/script.rpy:299
translate es playername_70109390:

    # mc "I don't think I'm quite cut out for a life of villainy."
    mc "No creo estar hecho para una vida de villanía."

# game/game/script.rpy:301
translate es playername_ce96d9bd:

    # mc "Sorry to disappoint Hal."
    mc "Lamento decepcionarte, Hal."

# game/game/script.rpy:303
translate es playername_da40260f:

    # "Haley drops a casual pat on my shoulder."
    "Haley me da una palmada casual en el hombro."

# game/game/script.rpy:305
translate es playername_3298ca24:

    # h "Don't worry about it %(player_name)s. Just keep being a kickass barista and we are cool."
    h "No te preocupes, %(player_name)s. Solo sigue siendo un barista increíble y estamos bien."

# game/game/script.rpy:307
translate es playername_11c45fd4:

    # "Haley and I sat in in the Ambience of the cafe. I wiped down the counter tops as Haley picked at the scone."
    "Haley y yo nos sentamos en la tranquilidad del café. Yo limpiaba los mostradores mientras Haley picoteaba el panecillo."

# game/game/script.rpy:309
translate es playername_c499f9e7:

    # "The position in which Haley was standing gave them direct line of sight onto Miles's activities."
    "La posición en la que Haley estaba le daba una línea directa de visión hacia las actividades de Miles."

# game/game/script.rpy:313
translate es playername_f2e0a555:

    # "Miles's current demeanor of a hardworking cafe employee indicated that he felt their hawk-like stare."
    "La actitud actual de Miles, de un empleado de cafetería trabajador, indicaba que sentía su mirada de halcón."

# game/game/script.rpy:315
translate es playername_eacaa846:

    # "I sigh again glancing upward at the clock."
    "Suspiro de nuevo mirando hacia el reloj."

# game/game/script.rpy:317
translate es playername_d8d9b37e:

    # h "Don't get too impatient. You still have a full 5 left to go."
    h "No te impacientes. Aún te faltan cinco horas completas."

# game/game/script.rpy:319
translate es playername_0ef6abfb:

    # mc "...feels like forever."
    mc "...se siente como una eternidad."

# game/game/script.rpy:323
translate es playername_0f734037:

    # h "Hmm? Maybe you should pick up a more exciting job then?"
    h "¿Hmm? Tal vez deberías buscar un trabajo más emocionante entonces."

# game/game/script.rpy:329
translate es playername_79da62b0:

    # "Hal cracks a smile, tossing their napkin at me playfully."
    "Hal suelta una sonrisa y me lanza su servilleta de forma juguetona."

# game/game/script.rpy:331
translate es playername_729febce:

    # "I snatch it out of the air."
    "La atrapo al vuelo."

# game/game/script.rpy:333
translate es playername_cceed430:

    # h "You're such a little shit, you know that?"
    h "Eres una mierdecilla, ¿lo sabías?"

# game/game/script.rpy:335
translate es playername_d1ce09ac:

    # mc "Wow, Hal, language! I think in the onboarding videos they refereed to this as a {i}'toxic workplace environment'{/i}."
    mc "Vaya, Hal, ¡lenguaje! Creo que en los videos de inducción se referían a esto como un {i}'entorno laboral tóxico'{/i}."

# game/game/script.rpy:337
translate es playername_f8858472:

    # h "To be fair, any place that has Miles and I working together is {i}technically{/i} a toxic workplace environment."
    h "Siendo juste, cualquier lugar que tenga a Miles y a mí trabajando juntos es {i}técnicamente{/i} un entorno laboral tóxico."

# game/game/script.rpy:339
translate es playername_995a442e:

    # mc "Well as the middleman, I would like to formally request popcorn as an official mainstay break-room snack."
    mc "Bueno, como intermediario, me gustaría solicitar formalmente las palomitas como refrigerio oficial en la sala de descanso."

# game/game/script.rpy:341
translate es playername_22d6c934:

    # h "Maybe if you don't charge a customer $20 extra multiple times in a day, I'll see what I can do."
    h "Tal vez si no le cobras $20 de más a un cliente varias veces en un día, vea qué puedo hacer."

# game/game/script.rpy:343
translate es playername_0b68a2f4:

    # mc "Excuse me, I have never done that."
    mc "Disculpa, nunca he hecho eso."

# game/game/script.rpy:345
translate es playername_45ac3ff9:

    # h "Sorry my standards were beaten low by previous experiences, previous...{i}people{/i}."
    h "Perdón, mis estándares fueron rebajados por experiencias anteriores, personas anteriores...{i}personas{/i}."

# game/game/script.rpy:347
translate es playername_600957d1:

    # h "I've been hurt before~"
    h "Me han lastimado antes~"

# game/game/script.rpy:349
translate es playername_c67ac253:

    # mc "Well you can trust in me."
    mc "Bueno, puedes confiar en mí."

# game/game/script.rpy:351
translate es playername_89b89046:

    # mc "I'll serve my time well as a proper middle-man."
    mc "Cumpliré bien mi tiempo como un intermediario adecuado."

# game/game/script.rpy:353
translate es playername_6d4a32fa:

    # mc "If you and Miles end up legitimately brawling and destroy the place..."
    mc "Si tú y Miles terminan peleando de verdad y destruyen el lugar..."

# game/game/script.rpy:355
translate es playername_ab2a8fa6:

    # mc "Then I probably will have to find a new job."
    mc "Entonces probablemente tendré que buscar un nuevo trabajo."

# game/game/script.rpy:357
translate es playername_66559d0d:

    # h "Eh, it won't get to that."
    h "Eh, no llegará a eso."

# game/game/script.rpy:359
translate es playername_86e43507:

    # h "And even if it did, I could totally kick Mile's ass in 2 minutes flat."
    h "E incluso si pasara, podría patearle el trasero a Miles en 2 minutos exactos."

# game/game/script.rpy:361
translate es playername_fd761446:

    # h "And 2 minutes isn't a ton of time to do a whole lot of damage here."
    h "Y 2 minutos no es mucho tiempo para causar tanto daño aquí."

# game/game/script.rpy:363
translate es playername_49dfc46f:

    # "My eyes narrow."
    "Entrecierro los ojos."

# game/game/script.rpy:365
translate es playername_bc83fddb:

    # mc "In all seriousness, I prefer not to find a new job...."
    mc "Hablando en serio, prefiero no tener que buscar un nuevo trabajo..."

# game/game/script.rpy:367
translate es playername_678c065b:

    # h "Say you had to though."
    h "Supón que tuvieras que hacerlo."

# game/game/script.rpy:369
translate es playername_8faf1aee:

    # h "What would you choose?"
    h "¿Qué elegirías?"

# game/game/script.rpy:371
translate es playername_392af8d7:

    # mc "I'm not sure..."
    mc "No se con seguridad... "

# game/game/script.rpy:373
translate es playername_ff43147f:

    # mc "What do you think I'd be good at?"
    mc "¿Qué crees que se me daría bien?"

# game/game/script.rpy:375
translate es playername_464ef46d:

    # h "Well, you are a really good at wrangling Miles and myself...so maybe..."
    h "Bueno, se te da bien controlar a Miles y a mí... así que tal vez..."

# game/game/script.rpy:379
translate es playername_442e4c9b:

    # mc "I prefer a boring life."
    mc "Prefiero una vida aburrida."

# game/game/script.rpy:381
translate es playername_7f7e9260:

    # mc "Excitement usually means trouble."
    mc "La emoción normalmente significa problemas."

# game/game/script.rpy:383
translate es playername_3af85a66:

    # h "You look like you are speaking from experience..."
    h "Parece que hablas por experiencia..."

# game/game/script.rpy:385
translate es playername_4366a711:

    # "Hal leans in close, their long hair trickling over their shoulder."
    "Hal se inclina cerca, su largo cabello deslizándose sobre su hombro."

# game/game/script.rpy:397
translate es playername_5a19fa6d:

    # h "What secrets are you hiding %(player_name)s ~ "
    h "¿Qué secretos escondes %(player_name)s ~"

# game/game/script.rpy:399
translate es playername_ff138be6:

    # mc "I should be more concerned about {i}your{/i} secrets Hal."
    mc "Debería preocuparme más por {i}tus{/i} secretos, Hal."

# game/game/script.rpy:401
translate es playername_82432a05:

    # "Haley raises an eyebrow curiously."
    "Haley arquea una ceja con curiosidad."

# game/game/script.rpy:403
translate es playername_0ee30965:

    # mc "I mean, if you happen get arrested for something crazy like... insurance fraud, I'd be out of a job."
    mc "Digo, si llegaras a ser arrestade por algo loco como... fraude de seguros, me quedaría sin trabajo."

# game/game/script.rpy:407
translate es playername_af0a2be3:

    # h "{i}Insurance Fraud?!{/i}"
    h "{i}¿¡Fraude de seguros?!{/i}"

# game/game/script.rpy:409
translate es playername_8c672158:

    # h "Do I look that shady to you?"
    h "¿Te parezco tan sospechose?"

# game/game/script.rpy:411
translate es playername_3f95aaeb:

    # "Haley huffs jokingly."
    "Haley resopla en tono de broma."

# game/game/script.rpy:415
translate es playername_9fec6a2c:

    # h "Then you could finally leave me to rot in prison, and get your dream job."
    h "Entonces finalmente podrías dejarme pudrirme en prisión, y conseguir tu trabajo soñado."

# game/game/script.rpy:417
translate es playername_e8842189:

    # mc "Yeah? And what's my dream job?"
    mc "¿Ah sí? ¿Y cuál sería mi trabajo soñado?"

# game/game/script.rpy:419
translate es playername_9a917d02:

    # "I cross my arms and tilt my head curiously."
    "Cruzo los brazos y ladeo la cabeza con curiosidad."

# game/game/script.rpy:425
translate es playername_e26aaa37:

    # "Hal levels their gaze at me."
    "Hal fija su mirada en mí."

# game/game/script.rpy:427
translate es playername_8d65c803:

    # h "Hmmm I don't know, maybe like..."
    h "Hmmm no lo sé, tal vez como..."

# game/game/script.rpy:430
translate es playername_0c423b2a:

    # h "Like ...a super hero?"
    h "¿Como... un superhéroe?"

# game/game/script.rpy:432
translate es playername_7e391be3:

    # "Haley was more monotone than ever, but I could tell it was an obvious joke."
    "Haley estaba más monótone que nunca, pero podía notar que era una broma obvia."

# game/game/script.rpy:434
translate es playername_1831c29e:

    # mc "Yeah, I really look the type huh?"
    mc "Sí, realmente tengo toda la pinta, ¿eh?"

# game/game/script.rpy:436
translate es playername_9dbea47a:

    # "I drawl out sarcastically."
    "Digo con sarcasmo."

# game/game/script.rpy:438
translate es playername_42efb20b:

    # h "Maybe your superhero name could be like...{i}The Pessimist{/i} or something."
    h "Tal vez tu nombre de superhéroe podría ser algo como... {i}Pesimista{/i} o algo así."

# game/game/script.rpy:440
translate es playername_d6c23114:

    # "I laugh, a small twinkle shines behind Haley's eye."
    "Río, un pequeño destello brilla en los ojos de Haley."

# game/game/script.rpy:442
translate es playername_21fa7802:

    # mc "Oh yeah? And what will I do? Bum the villains out so much they decide to go home?"
    mc "¿Ah sí? ¿Y qué haré? ¿Deprimir tanto a los villanos que decidan irse a casa?"

# game/game/script.rpy:444
translate es playername_878b54cd:

    # "I mock a superhero pose."
    "Imito una pose de superhéroe."

# game/game/script.rpy:446
translate es playername_399951ba:

    # mc "You there, disgusting villain! Don't you have any idea about the money you are stealing?"
    mc "¡Tú, villano repugnante! ¿No tienes idea del dinero que estás robando?"

# game/game/script.rpy:448
translate es playername_9358d115:

    # mc "Inflation is on the rise! That money will be worth next to nothing in 2 years!"
    mc "¡La inflación está aumentando! ¡Ese dinero no valdrá casi nada en 2 años!"

# game/game/script.rpy:452
translate es playername_214b6efa:

    # h "Pfttt!"
    h "¡Pfttt!"

# game/game/script.rpy:454
translate es playername_750d1b05:

    # "Haley covers their face and turns their back."
    "Haley se cubre la cara y se da la vuelta."

# game/game/script.rpy:456
translate es playername_4194e3fa:

    # "They attempted to regain composure, but I felt a little disappointed I wasn't able to see their expression."
    "Intentó recuperar la compostura, pero sentí un poco de decepción por no poder ver su expresión."

# game/game/script.rpy:460
translate es playername_19b7a373:

    # h "Wow you could totally go for it, you are even bumming {i}me{/i} out!"
    h "Vaya, podrías hacerlo perfectamente, ¡hasta me estás deprimiendo {i}a mí{/i}!"

# game/game/script.rpy:462
translate es playername_2f8ca877:

    # "I smile wide and laugh a bit at the ridiculousness of it."
    "Sonrío ampliamente y río un poco ante lo ridículo de la situación."

# game/game/script.rpy:464
translate es playername_47a41e09:

    # h "That's what I like about you %(player_name)s."
    h "Eso es lo que me gusta de ti, %(player_name)s."

# game/game/script.rpy:466
translate es playername_92a70081:

    # h "You feel like the only other person that truly couldn't give a shit about the heroes."
    h "Siento que eres la única otra persona que realmente no le importa una mierda los héroes."

# game/game/script.rpy:468
translate es playername_02776c05:

    # h "Even villains tend to have favorite heroes."
    h "Incluso los villanos suelen tener héroes favoritos."

# game/game/script.rpy:470
translate es playername_321114f8:

    # h "But you? You truly couldn't care less."
    h "¿Pero tú? A ti realmente te da igual."

# game/game/script.rpy:472
translate es playername_71bd67c9:

    # h "Why is that?"
    h "¿Por qué es eso?"

# game/game/script.rpy:474
translate es playername_cd4fe599:

    # "I shrug and mumble out some random reason."
    "Me encojo de hombros y murmuro alguna razón al azar."

# game/game/script.rpy:476
translate es playername_41ef1a97:

    # mc "Taxpayer money and all that..."
    mc "El dinero de los impuestos y todo eso..."

# game/game/script.rpy:480
translate es playername_4d36c33b:

    # c "Uhh...can I order?"
    c "Eh... ¿puedo pedir?"

# game/game/script.rpy:486
translate es playername_ad2a420c:

    # "My head springs up at the customer on the other side of the counter."
    "Levanto la cabeza ante el cliente al otro lado del mostrador."

# game/game/script.rpy:488
translate es playername_f7d4b934:

    # "They rubbed their arm awkwardly."
    "Se frotó el brazo con incomodidad."

# game/game/script.rpy:490
translate es playername_9492a7c0:

    # "{i}Fuck how long were they standing there?{/i}"
    "{i}Joder, ¿cuánto tiempo llevaba ahí parado?{/i}"

# game/game/script.rpy:492
translate es playername_1d090336:

    # "I wanted to die of embarrassment."
    "Quise morirme de vergüenza."

# game/game/script.rpy:494
translate es playername_d465cb39:

    # "My head whizzed over to Haley, but they already took advantage of the moment and trotted off to some other part of the cafe."
    "Giré la cabeza hacia Haley, pero ya había aprovechado el momento y se había alejado hacia otra parte del café."

# game/game/script.rpy:496
translate es playername_5cdbefca:

    # "My cheeks felt hot as I glanced up at the man."
    "Sentí las mejillas arder mientras miraba al hombre."

# game/game/script.rpy:501
translate es playername_a8918195:

    # mc "Hello, uh- I'm sorry about that."
    mc "Hola, eh... lo siento por eso."

# game/game/script.rpy:503
translate es playername_2f5a36d0:

    # mc "I didn't see you there."
    mc "No te vi ahí."

# game/game/script.rpy:505
translate es playername_5ef75ea4:

    # c "No problem, I prefer it that way."
    c "No hay problema, lo prefiero así."

# game/game/script.rpy:507
translate es playername_11455b53:

    # mc "What?"
    mc "¿Qué?"

# game/game/script.rpy:509
translate es playername_0673fb2e:

    # c "...never mind lets just ...stop talking."
    c "...no importa, mejor... dejemos de hablar."

# game/game/script.rpy:511
translate es playername_2751c501:

    # "He cringed at himself looking up at the menu."
    "Hizo una mueca mientras miraba el menú."

# game/game/script.rpy:513
translate es playername_b75727ec:

    # c "Can I get a black coffee to-go?"
    c "¿Puedo pedir un café negro para llevar?"

# game/game/script.rpy:515
translate es playername_5e6ef29b:

    # mc "Yeah sure, nothing else?"
    mc "Sí, claro, ¿nada más?"

# game/game/script.rpy:520
translate es playername_77bdf7bc:

    # "He pauses for a second, as if he is trying to determine if it is a trick question."
    "Hace una pausa por un segundo, como si intentara determinar si era una pregunta trampa."

# game/game/script.rpy:524
translate es playername_658bb62c:

    # c "Uh, no...thank you."
    c "Eh, no... gracias."

# game/game/script.rpy:526
translate es playername_218ccabc:

    # mc "Okay...that will be $3.00 flat."
    mc "De acuerdo... serán $3.00 exactos."

# game/game/script.rpy:528
translate es playername_d89472a6:

    # "He hands over a five bill."
    "Entrega un billete de cinco."

# game/game/script.rpy:530
translate es playername_c5d3d6b2:

    # mc "Here is your change sir."
    mc "Aquí tiene su cambio, señor."

# game/game/script.rpy:533
translate es playername_0836557c:

    # c "Keep it."
    c "Quédatelo."

# game/game/script.rpy:535
translate es playername_84700a5b:

    # "He moves away before I can give him his receipt."
    "Se aleja antes de que pueda darle el recibo."

# game/game/script.rpy:537
translate es playername_183d4b2a:

    # "{i}Not very talkative...{/i}"
    "{i}No muy hablador...{/i}"

# game/game/script.rpy:539
translate es playername_22df75bb:

    # "I put together a fresh black coffee in a to-go cup."
    "Preparo un café negro fresco en un vaso para llevar."

# game/game/script.rpy:541
translate es playername_f7ef6fb4:

    # "He stands at the counter ready to grab it. Right before I hand the coffee over, I quickly pull it back towards myself."
    "Él se queda en el mostrador listo para tomarlo. Justo antes de entregárselo, lo retiro rápidamente hacia mí."

# game/game/script.rpy:543
translate es playername_f38759fb:

    # mc "Ah, I almost forgot this!"
    mc "Ah, ¡casi olvido esto!"

# game/game/script.rpy:547
translate es playername_f2457ad5:

    # "I slip a coffee sleeve onto the cup."
    "Coloco una funda de cartón en el vaso."

# game/game/script.rpy:549
translate es playername_ed26cf05:

    # mc "Careful, it's hot. You don't want to burn your hands... "
    mc "Cuidado, está caliente. No vas a querer quemarte las manos..."

# game/game/script.rpy:551
translate es playername_4ff00d93:

    # "{i}Why does everything I say feel so... awkward with this guy.{/i}"
    "{i}¿Por qué todo lo que digo se siente tan... incómodo con este tipo?{/i}"

# game/game/script.rpy:553
translate es playername_755ad96d:

    # "He flashes a wry smile."
    "Él esboza una sonrisa torcida."

# game/game/script.rpy:558
translate es playername_702b1872:

    # c "Thanks...uh.."
    c "Gracias... eh..."

# game/game/script.rpy:563
translate es playername_c2fafe24:

    # "He glances down at my name tag."
    "Baja la mirada hacia mi placa con el nombre."

# game/game/script.rpy:567
translate es playername_e36d75ab:

    # c "%(player_name)s..."
    c "%(player_name)s..."

# game/game/script.rpy:569
translate es playername_74720dec:

    # c "Have a good day..."
    c "Que tengas un buen día..."

# game/game/script.rpy:571
translate es playername_307983eb:

    # "He takes the coffee from my hand. His fingertips brush over mine during the exchange making me jump a bit."
    "Toma el café de mi mano. La punta de sus dedos roza los míos durante el intercambio, haciéndome sobresaltar un poco."

# game/game/script.rpy:573
translate es playername_829b7969:

    # "The man walks out the door sipping his hot coffee."
    "El hombre sale por la puerta sorbiendo su café caliente."

# game/game/script.rpy:577
translate es playername_0ee70635:

    # "He glances at me while passing the glass window. When our eyes make contact, he shifts his glance away."
    "Me mira al pasar frente a la ventana de vidrio. Cuando nuestros ojos se cruzan, aparta la mirada."

# game/game/script.rpy:581
translate es playername_70edc9b8:

    # "I continue to work the register, ringing customers up and preparing drinks."
    "Sigo atendiendo la caja, cobrando a los clientes y preparando bebidas."

# game/game/script.rpy:583
translate es playername_b7b282f4:

    # "When customers peter out later in the day, I pass the time by watching the TV with no sound hanging in the corner."
    "Cuando los clientes empiezan a escasear más tarde ese día, paso el tiempo mirando la televisión sin sonido que cuelga en la esquina."

# game/game/script.rpy:585
translate es playername_b9238af3:

    # "A special about Hero origin's flashes across the screen."
    "Un especial sobre el origen de los héroes aparece en la pantalla."

# game/game/script.rpy:592
translate es playername_7bdc6b9e:

    # "I mute the TV as Binary Star's red, blue, white and yellow stand out amongst the news interview."
    "Subo el volumen mientras el rojo, azul, blanco y amarillo de Binary Star destacan en la entrevista de noticias."

# game/game/script.rpy:594
translate es playername_4312fb30:

    # mc "A child from the stars huh...."
    mc "Un niño de las estrellas, ¿eh...?"

# game/game/script.rpy:596
translate es playername_4b5f41fb:

    # "I murmur to myself."
    "Murmuro para mí."

# game/game/script.rpy:598
translate es playername_17b03c63:

    # "As unbelievable as it was, Binary's red eyes were chillingly unhuman."
    "Por increíble que fuera, los ojos rojos de Binary eran inquietantemente inhumanos."

# game/game/script.rpy:600
translate es playername_54ac4772:

    # "To the general public he glimmered like starlight...."
    "Para el público en general, brillaba como la luz de las estrellas..."

# game/game/script.rpy:602
translate es playername_b7da9469:

    # "But to the villains his name was only uttered in whispers."
    "Pero para los villanos su nombre solo se pronunciaba en susurros."

# game/game/script.rpy:607
translate es playername_5d873b1d:

    # "The rest of the day passes pretty normally."
    "El resto del día transcurre con bastante normalidad."

# game/game/script.rpy:609
translate es playername_33d9fce0:

    # "Soon I'll finally be off the clock and can head home."
    "Pronto terminará mi turno y podré irme a casa."

# game/game/script.rpy:627
translate es playername_acaed3d8:

    # "I yawn while looking through some boxes under the counter for more sleeves."
    "Bostezo mientras reviso unas cajas bajo el mostrador buscando más fundas."

# game/game/script.rpy:629
translate es playername_baf5eba7:

    # "The morning shift is brutal."
    "El turno de la mañana es brutal."

# game/game/script.rpy:631
translate es playername_52cef98d:

    # "I probably shouldn't have stayed up so late doom scrolling."
    "Probablemente no debería haberme quedado en vela hasta tan tarde scrolleando sin sentido."

# game/game/script.rpy:635
translate es playername_7e06c1c3:

    # h "Hey!"
    h "¡Eh!"

# game/game/script.rpy:639
translate es playername_b37cc3f9:

    # "THUD"
    "¡PUM!"

# game/game/script.rpy:641
translate es playername_bc898f0f:

    # mc "Ow!"
    mc "¡Ay!"

# game/game/script.rpy:643
translate es playername_5a3bee5f:

    # "I rub the back of my head where it hit the counter."
    "Me froto la parte posterior de la cabeza donde golpeó el mostrador."

# game/game/script.rpy:645
translate es playername_e5c4fbb1:

    # "Ducking my head out from under the counter, I see Haley standing there with their usual expression."
    "Asomándome desde debajo del mostrador, veo a Haley de pie con su expresión habitual."

# game/game/script.rpy:651
translate es playername_ce7ae87b:

    # mc "Hal, you really have to make your presence more known..."
    mc "Hal, realmente tienes que hacer notar tu presencia..."

# game/game/script.rpy:653
translate es playername_ce1a1962:

    # "Haley shrugs."
    "Haley se encoge de hombros."

# game/game/script.rpy:655
translate es playername_975685fb:

    # h "Do you mind bussing some tables?"
    h "¿Te importaría recoger algunas mesas?"

# game/game/script.rpy:657
translate es playername_e878ee24:

    # mc "Sure, but where's Miles?"
    mc "Claro, pero ¿dónde está Miles?"

# game/game/script.rpy:663
translate es playername_58a418a4:

    # h "Probably pretending to do work in the storage room while browsing auction sites for hero action figures."
    h "Probablemente fingiendo trabajar en el almacén mientras navega por sitios de subastas buscando figuras de acción de héroes."

# game/game/script.rpy:665
translate es playername_d077738a:

    # "I start to laugh assuming it's a joke, but Haley's unamused expression never shifted."
    "Empiezo a reír creyendo que es una broma, pero la expresión impasible de Haley no cambia."

# game/game/script.rpy:667
translate es playername_de1b5683:

    # "Haley sighs, rubbing their temples."
    "Haley suspira, frotándose las sienes."

# game/game/script.rpy:669
translate es playername_191f359e:

    # h "Sometimes I wonder if firing him would be easier."
    h "A veces me pregunto si despedirlo sería más fácil."

# game/game/script.rpy:671
translate es playername_fc5fcc38:

    # h "But it would make my life way more complicated if I did..."
    h "Pero complicaría mucho más mi vida si lo hiciera..."

# game/game/script.rpy:673
translate es playername_d2ca169f:

    # "Haley glances up at me quickly."
    "Haley me mira rápidamente."

# game/game/script.rpy:675
translate es playername_fc963d8f:

    # h "It's tough to find anyone willing to work a normal job recently."
    h "Es difícil encontrar a alguien dispuesto a trabajar un trabajo normal últimamente."

# game/game/script.rpy:677
translate es playername_c5977fcb:

    # mc "All Miles talks about how he is going to quit some day out and be a hero."
    mc "Todo lo que Miles habla es de cómo algún día renunciará y será un héroe."

# game/game/script.rpy:679
translate es playername_4f9537b4:

    # "Haley barks a humorless laugh."
    "Haley suelta una risa sin humor."

# game/game/script.rpy:681
translate es playername_a82ed3b0:

    # h "Yeah?"
    h "¿Sí?"

# game/game/script.rpy:683
translate es playername_0999f574:

    # h "The guy can barely tell a coarse grind from a fine grind!"
    h "¡El tipo apenas puede distinguir un molido grueso de uno fino!"

# game/game/script.rpy:685
translate es playername_c4be216e:

    # h "And don't even get me started about how many times he has-"
    h "Y ni me hagas empezar con las veces que ha—"

# game/game/script.rpy:689
translate es playername_a2fce97f:

    # m "Yo! Check out this side-kick era Blaze figure I found!"
    m "¡Oye! ¡Mira esta figura de Blaze de la era de los sidekicks que encontré!"

# game/game/script.rpy:693
translate es playername_22f68c54:

    # m "It's only at eight-ks and has an hour left!"
    m "¡Solo va por ocho-miles y le queda una hora!"

# game/game/script.rpy:695
translate es playername_b20cbbc2:

    # mc "$8,000 for an... action figure?"
    mc "¿$8,000 por una... figura de acción?"

# game/game/script.rpy:697
translate es playername_60bea00a:

    # "{i} With spending habits like that, it's no wonder Miles is trying to always borrow money.{/i}"
    "{i}Con hábitos de gasto como esos, no es de extrañar que Miles siempre esté pidiendo prestado.{/i}"

# game/game/script.rpy:699
translate es playername_28ea1af1:

    # "As Haley starts in on a lecture I quietly dip out."
    "Mientras Haley comienza una reprimenda, me escabullo en silencio."

# game/game/script.rpy:703
translate es playername_f87374c8:

    # "I hum to myself while gathering the left behind plates, mugs, and cups off of the tables and placing them into the bus tub."
    "Canto para mí mientras recojo los platos, tazas y vasos dejados en las mesas y los coloco en el contenedor."

# game/game/script.rpy:709
translate es playername_fed03ca2:

    # mc "Ah!"
    mc "¡Ah!"

# game/game/script.rpy:726
translate es playername_4f10d05c:

    # "I walked into someone, almost dropping the bus tub."
    "Choqué con alguien, casi dejo caer el contenedor."

# game/game/script.rpy:729
translate es playername_9d1a4728:

    # "The stranger's hand grasps the container from the other side keeping it steady."
    "La mano del desconocido agarra el recipiente por el otro lado manteniéndolo firme."

# game/game/script.rpy:731
translate es playername_4bbcac30:

    # mc "Whoa, nice reflexes!"
    mc "¡Vaya, buenos reflejos!"

# game/game/script.rpy:736
translate es playername_9ccc845b:

    # "I look up and see the same stranger from yesterday."
    "Levanto la vista y veo al mismo desconocido de ayer."

# game/game/script.rpy:738
translate es playername_085bcc70:

    # "I feel a bit frazzled, my face heating up remembering the caught glances and graze of our fingertips...."
    "Siento un poco de desconcierto, la cara se me enrojece al recordar las miradas atrapadas y el roce de nuestros dedos...."

# game/game/script.rpy:740
translate es playername_644ed392:

    # "{i} Oh my god get it together you whore!{/i}"
    "{i}¡Dios mío, contrólate, puta!{/i}"

# game/game/script.rpy:742
translate es playername_cb765978:

    # c "Pftt..."
    c "Pftt..."

# game/game/script.rpy:747
translate es playername_d93f5a93:

    # "My eyes shoot up to his. I could swear he was laughing at me. Instead he coolly shifts his gaze in another direction."
    "Mis ojos se elevan hacia los suyos. Juraría que se estaba riendo de mí. En cambio, desvía la mirada con frialdad hacia otra dirección."

# game/game/script.rpy:749
translate es playername_fd8de381:

    # "{i}He is a little attractive though...{/i}"
    "{i}Aunque es un poco atractivo...{/i}"

# game/game/script.rpy:751
translate es playername_3079022a:

    # c "You think so?"
    c "¿Tú crees?"

# game/game/script.rpy:753
translate es playername_a047b2a5:

    # mc "I-i!..What??"
    mc "¡Y-yo!.. ¿¿Qué??"

# game/game/script.rpy:757
translate es playername_332e2dfc:

    # "He smirks down at me."
    "Él me sonríe con suficiencia."

# game/game/script.rpy:761
translate es playername_f1c0ef48:

    # c "My reflexes."
    c "Mis reflejos."

# game/game/script.rpy:763
translate es playername_d8773e8e:

    # mc "Ah, right! Yeah."
    mc "¡Ah, claro! Sí."

# game/game/script.rpy:765
translate es playername_bf9e091e:

    # "My eyes go wide noticing the customer's hand still holding the bus tub."
    "Abro mucho los ojos al notar que la mano del cliente aún sostiene el contenedor."

# game/game/script.rpy:767
translate es playername_9f0292c3:

    # mc "Ah! Sorry!"
    mc "¡Ah! ¡Perdón!"

# game/game/script.rpy:781
translate es playername_7550bef7:

    # "I place the bus tub down on a nearby table."
    "Coloco el contenedor en una mesa cercana."

# game/game/script.rpy:783
translate es playername_0719cbd8:

    # "The man stands there with a curious look on his face."
    "El hombre se queda allí con una expresión curiosa en el rostro."

# game/game/script.rpy:785
translate es playername_386d5202:

    # mc "I didn't get anything on you, did I?"
    mc "No te manché con nada, ¿verdad?"

# game/game/script.rpy:810
translate es playername_cafc9417:

    # "I flutter around him, making sure that no stains were on his shirt."
    "Mientras me muevo a su alrededor, compruebo que no haya manchas en su camisa."

# game/game/script.rpy:814
translate es playername_e94ee709:

    # "He didn't move, staring down at me intensely."
    "No se mueve, me mira fijamente con intensidad."

# game/game/script.rpy:816
translate es playername_503a7967:

    # "I verified that there weren't any spills on him and backed up a little."
    "Verifiqué que no hubiera derrames en él y retrocedí un poco."

# game/game/script.rpy:831
translate es playername_2ab06998:

    # mc "Um, I think you are good.."
    mc "Eh, creo que estás bien.."

# game/game/script.rpy:833
translate es playername_4442dcbf:

    # "I look down and notice a coffee at his table."
    "Miro hacia abajo y noto un café en su mesa."

# game/game/script.rpy:835
translate es playername_534d0c2b:

    # mc "Black coffee again? You know we have ...other things too."
    mc "¿Otra vez café negro? Sabes que tenemos... otras cosas también."

# game/game/script.rpy:837
translate es playername_60019831:

    # "{i}I hope that didn't come off as judgemental...{/i}"
    "{i}Espero que eso no sonara a juicio...{/i}"

# game/game/script.rpy:841
translate es playername_3c415826:

    # c "I like this."
    c "Me gusta esto."

# game/game/script.rpy:843
translate es playername_3d108241:

    # "After a second of awkward silence he continues."
    "Tras un segundo de silencio incómodo continúa."

# game/game/script.rpy:845
translate es playername_745ef4b1:

    # c "Well, I'm usually in a rush to...get to work."
    c "Bueno, normalmente tengo prisa para... llegar al trabajo."

# game/game/script.rpy:847
translate es playername_5270bead:

    # c "So Black coffee is just the fastest to get."
    c "Asì que el café negro es lo más rápido de conseguir."

# game/game/script.rpy:849
translate es playername_8c053254:

    # mc "Ah okay I see."
    mc "Ah, ya veo."

# game/game/script.rpy:853
translate es playername_a07d3ae4:

    # mc "Well, if you ever want to try something new I can make something else for you!"
    mc "Bueno, si alguna vez quieres probar algo nuevo puedo prepararte otra cosa."

# game/game/script.rpy:857
translate es playername_da67de7e:

    # c "Sounds tempting."
    c "Suena tentador."

# game/game/script.rpy:861
translate es playername_d00e7660:

    # mc "I promise it will be {i} really {/i} good~ You won't ever want to buy coffee anywhere else - or your money back!"
    mc "Te prometo que será {i}realmente{/i} bueno~ ¡No vas a querer comprar café en ningún otro lado — o te devuelvo tu dinero!"

# game/game/script.rpy:866
translate es playername_2ac91d95:

    # c "Okay, can I get that in writing?"
    c "Está bien, ¿puedes poner eso por escrito?"

# game/game/script.rpy:868
translate es playername_8e93208d:

    # "{i}Cheeky bastard...{/i}"
    "{i}Maldito descarado...{/i}"

# game/game/script.rpy:870
translate es playername_723a10a7:

    # mc "You don't seem to be in a rush today?"
    mc "No pareces tener prisa hoy."

# game/game/script.rpy:872
translate es playername_a81a7cbf:

    # c "No, work doesn't need me quite yet."
    c "No, el trabajo aún no me necesita del todo."

# game/game/script.rpy:874
translate es playername_c0977270:

    # mc "What do you do for work?"
    mc "¿En qué trabajas?"

# game/game/script.rpy:878
translate es playername_f756d51c:

    # c "You are asking what I do for work when you don't even know my name yet..?"
    c "¿Me preguntas a qué me dedico cuando ni siquiera sabes mi nombre..?"

# game/game/script.rpy:880
translate es playername_0058d302:

    # c "I'm disappointed in you %(player_name)s."
    c "Estoy decepcionado contigo %(player_name)s."

# game/game/script.rpy:882
translate es playername_a338770f:

    # mc "How do you know my name?!"
    mc "¿Cómo sabes mi nombre?!"

# game/game/script.rpy:886
translate es playername_b16f1725:

    # "He gazes down at me."
    "Él me mira."

# game/game/script.rpy:888
translate es playername_bb64608f:

    # "His intense dark eyes scan my form."
    "Sus intensos ojos oscuros recorren mi figura."

# game/game/script.rpy:890
translate es playername_56bf8e3b:

    # "They linger as they move across me slowly."
    "Se detienen mientras se deslizan lentamente sobre mí."

# game/game/script.rpy:892
translate es playername_f6e6bef5:

    # "I end up feeling frazzled all over again."
    "Vuelvo a desconcertarme por completo."

# game/game/script.rpy:894
translate es playername_8a2cbc5c:

    # "Is he...staring at my chest?"
    "¿Está... mirando mi pecho?"

# game/game/script.rpy:896
translate es playername_d2efbb77:

    # "I glance down seeing my name tag."
    "Echo un vistazo hacia abajo y veo mi placa con el nombre."

# game/game/script.rpy:898
translate es playername_11dbd7c2:

    # "{i}Oh my god you idiot %(player_name)s!{/i}"
    "{i}¡Dios mío, %(player_name)s idiota!{/i}"

# game/game/script.rpy:900
translate es playername_a7919327:

    # mc "Oh haha right...perks of being an employee."
    mc "Ah jaja cierto... privilegios de ser empleado."

# game/game/script.rpy:902
translate es playername_ca4239aa:

    # "{i}Why did I just say that!?{/i}"
    "{i}¿!Por qué dije eso!?{/i}"

# game/game/script.rpy:904
translate es playername_2777e4b6:

    # c "Is me.... getting to know your name a perk of the job for you?"
    c "¿Es que... conocer tu nombre es un privilegio del trabajo para ti?"

# game/game/script.rpy:906
translate es playername_bebc9a8e:

    # "The man smirks darkly, his eyes scanning my face."
    "El hombre sonríe con malicia, sus ojos recorren mi rostro."

# game/game/script.rpy:908
translate es playername_05bf3aab:

    # c "{i}I'm flattered{/i}."
    c "{i}Me halagas{/i}."

# game/game/script.rpy:910
translate es playername_87e777ee:

    # c "I don't have to pay extra for flattery right?"
    c "No tengo que pagar extra por los halagos, ¿verdad?"

# game/game/script.rpy:912
translate es playername_d6b7063a:

    # "I'm pretty sure my face is as red as a tomato at this point."
    "Bastante seguro que mi cara está tan roja como un tomate en este punto."

# game/game/script.rpy:914
translate es playername_b9b4aa57:

    # mc "No, that's uh... on the house."
    mc "No, eso es... por cuenta de la casa."

# game/game/script.rpy:916
translate es playername_324f5471:

    # "I gather the bus tub into my arms a little too quickly, splashing a bit of water onto myself."
    "Agarro el contenedor con demasiada rapidez, salpicándome un poco de agua."

# game/game/script.rpy:918
translate es playername_12db99f0:

    # mc "Sorry, I gotta go- uh, work- do some work!"
    mc "Lo siento, tengo que ir— eh, trabajar— ¡hacer algo de trabajo!"

# game/game/script.rpy:920
translate es playername_60f5df32:

    # "As I turned around to escape I could swear I heard a deep chuckle."
    "Al darme la vuelta para escapar juraría que escuché una risa profunda."

# game/game/script.rpy:924
translate es playername_85d28c62:

    # "When I returned from the back, the man was already gone."
    "Cuando regresé desde la parte de atrás, el hombre ya se había ido."

# game/game/script.rpy:926
translate es playername_a90db925:

    # "{i}I wonder if he will come back tomorrow...{/i}"
    "{i}Me pregunto si volverá mañana...{/i}"

# game/game/script.rpy:948
translate es playername_501b4e5e:

    # "A week goes by, and the customer hasn't come back."
    "Pasa una semana y el cliente no ha regresado."

# game/game/script.rpy:950
translate es playername_e2f8a8a0:

    # "Some part of me felt a little disappointed."
    "Una parte de mí se siente un poco decepcionada."

# game/game/script.rpy:952
translate es playername_0c9e6ef4:

    # "Another part of me chastised myself for how ridiculous that is when I don't even know the man's name."
    "Otra parte de mí se recrimina por lo ridículo que es, cuando ni siquiera sé el nombre del hombre."

# game/game/script.rpy:954
translate es playername_b8423706:

    # "{i}He's a stranger, he could be like... a murderer or something.{/i}"
    "{i}Es un extraño, podría ser... un asesino o algo así.{/i}"

# game/game/script.rpy:956
translate es playername_c7398cca:

    # "{i}Or married!{/i}"
    "{i}¡O casado!{/i}"

# game/game/script.rpy:958
translate es playername_dba1c890:

    # "{i}Why am I even thinking about this? It's so stupid...{/i}"
    "{i}¿Por qué siquiera estoy pensando en esto? Es tan estúpido...{/i}"

# game/game/script.rpy:960
translate es playername_889924be:

    # "I groan into my hands."
    "Gimo entre mis manos."

# game/game/script.rpy:966
translate es playername_b929c5d2:

    # h "Yeah same."
    h "Sí, igual."

# game/game/script.rpy:968
translate es playername_282e5851:

    # mc "What...?"
    mc "¿Qué...?"

# game/game/script.rpy:970
translate es playername_27b66f24:

    # "I drag my head up to see Hal standing next to me."
    "Levanto la cabeza y veo a Hal de pie junto a mí."

# game/game/script.rpy:972
translate es playername_0a72d0ea:

    # "I follow their line of vision and land on the muted TV in the corner."
    "Sigo su línea de visión y me detengo en el televisor silenciado en la esquina."

# game/game/script.rpy:978
translate es playername_42cc189c:

    # "Shown on the screen was the most notable super hero {i}Binary Star{/i}."
    "En la pantalla se mostraba al superhéroe más notable, {i}Binary Star{/i}."

# game/game/script.rpy:980
translate es playername_7b35aca8:

    # "There truly wasn't a household that hasn't heard of that name."
    "No existía un solo hogar que no hubiera oído ese nombre."

# game/game/script.rpy:982
translate es playername_8c0ba86c:

    # h "Let's see what they are saying about this prick"
    h "Veamos qué dicen sobre este imbécil."

# game/game/script.rpy:984
translate es playername_5566ee2d:

    # "Haley grabs the remote turning up the sound."
    "Haley toma el control remoto y sube el volumen."

# game/game/script.rpy:994
translate es playername_2dce4e92:

    # tv "-The Hero that will shine against ANY darkness!"
    tv "—¡El héroe que brillará contra CUALQUIER oscuridad!"

# game/game/script.rpy:996
translate es playername_f299127d:

    # tv "How do you feel about that title Mr. Binary Star?"
    tv "¿Cómo se siente con ese título, señor Binary Star?"

# game/game/script.rpy:999
translate es playername_cb49823d:

    # bs "Well I gotta say, I'm flattered..."
    bs "Bueno, debo decir que me siento halagado..."

# game/game/script.rpy:1001
translate es playername_e4a1a884:

    # bs "But Steve, they are not wrong...!"
    bs "¡Pero Steve, no están equivocados...!"

# game/game/script.rpy:1003
translate es playername_897853be:

    # "The hero tilts his head giving an animated wink to the interviewer."
    "El héroe inclina la cabeza y guiña un ojo de forma exagerada al entrevistador."

# game/game/script.rpy:1005
translate es playername_b8851fe6:

    # "He then turns to the camera pointing directly towards the audience."
    "Luego se gira hacia la cámara apuntando directamente al público."

# game/game/script.rpy:1007
translate es playername_a002c301:

    # bs "No villain can hide under the thick veil of darkness. Not while I'm around!"
    bs "Ningún villano puede esconderse bajo el espeso velo de la oscuridad. ¡No mientras yo esté cerca!"

# game/game/script.rpy:1009
translate es playername_95941bbc:

    # bs "Against the dusk of their crimes, the shining light will always prevail, bringing them to justice!"
    bs "Contra el ocaso de sus crímenes, la luz resplandeciente siempre prevalecerá, llevándolos ante la justicia."

# game/game/script.rpy:1011
translate es playername_bff42dd8:

    # "The hero turns his point into a thumbs-up, his smile so wide it instinctively made me rub my own jaw."
    "El héroe transforma su gesto en un pulgar arriba, su sonrisa tan amplia que instintivamente me hizo frotarme la mandíbula."

# game/game/script.rpy:1013
translate es playername_4be328dc:

    # tv "You are known to have numerous abilities, but none as iconic as the {i}'Diamond Melting Eyes'{/i}!"
    tv "Es conocido por tener numerosas habilidades, pero ninguna tan icónica como los {i}'Ojos que Derriten Diamantes'{/i}."

# game/game/script.rpy:1015
translate es playername_2597ee9d:

    # tv "It is said that you were born with this special talent, indicating from birth that you were an ability holder."
    tv "Se dice que nació con este talento especial, lo cual indicaba desde su nacimiento que era un portador de habilidades."

# game/game/script.rpy:1017
translate es playername_b327fdcb:

    # bs "Yes, that's right! When I first opened my eyes and they were red, it really gave the nurses a scare!"
    bs "¡Así es! Cuando abrí los ojos por primera vez y eran rojos, realmente asusté a las enfermeras."

# game/game/script.rpy:1019
translate es playername_cdf764dc:

    # bs "Despite the shock, my dear mother never once faltered in loving me. God rest her soul."
    bs "A pesar del impacto, mi querida madre nunca dejó de amarme. Que Dios la tenga en su gloria."

# game/game/script.rpy:1021
translate es playername_41d73be3:

    # "The interviewer extends his condolences."
    "El entrevistador le ofrece sus condolencias."

# game/game/script.rpy:1023
translate es playername_f441eb18:

    # bs "As I grew older, my other abilities manifested and now-"
    bs "A medida que fui creciendo, se manifestaron mis otras habilidades y ahora—"

# game/game/script.rpy:1038
translate es playername_d337db5c:

    # h "Ugh!"
    h "¡Ugh!"

# game/game/script.rpy:1040
translate es playername_c61bc525:

    # "Haley turns off the TV."
    "Haley apaga el televisor."

# game/game/script.rpy:1043
translate es playername_cfeb5198:

    # h "GOD! I fucking hate that guy."
    h "¡DIOS! Odio a ese tipo con toda mi alma."

# game/game/script.rpy:1045
translate es playername_2ac3b6cd:

    # "I glance towards Haley. It was odd she disliked the hero so much."
    "Miro a Haley. Era extraño que detestara tanto al héroe."

# game/game/script.rpy:1047
translate es playername_20156f81:

    # "Most people love heroes..."
    "La mayoría de la gente ama a los héroes..."

# game/game/script.rpy:1049
translate es playername_3cd2b930:

    # "And even if they aren't interested, they will at least feign interest in order to be liked by people around them."
    "E incluso si no les interesa, al menos fingen hacerlo para agradar a los demás."

# game/game/script.rpy:1051
translate es playername_14c1528d:

    # "Heroes are seen as a paragon of justice, so to openly dislike them is seen as odd at best, suspicious at worst."
    "Los héroes son vistos como un paradigma de la justicia, así que expresar abiertamente rechazo hacia ellos se considera raro como mínimo, sospechoso como máximo."

# game/game/script.rpy:1053
translate es playername_07a94909:

    # mc "Why so much hate?"
    mc "¿Por qué tanto odio?"

# game/game/script.rpy:1055
translate es playername_0b2c84f3:

    # "Haley turns to me a bit shocked."
    "Haley me mira un poco sorprendide."

# game/game/script.rpy:1057
translate es playername_0508b00b:

    # h "What?! I thought you didn't like him either?"
    h "¡¿Qué?! Pensé que tú tampoco lo soportabas."

# game/game/script.rpy:1059
translate es playername_01afa3c3:

    # mc "I don't...I'm just surprised you are so....{i}passionate{/i} about hating him."
    mc "No lo hago... solo me sorprende que seas tan... {i}apasionade{/i} al odiarlo."

# game/game/script.rpy:1061
translate es playername_3e88f7be:

    # "Haley rolls their eyes."
    "Haley pone los ojos en blanco."

# game/game/script.rpy:1063
translate es playername_df74df5e:

    # h "It's just all so fake honestly."
    h "Es que todo es tan falso, sinceramente."

# game/game/script.rpy:1065
translate es playername_517cea09:

    # h "All this show boating, bull-shittery, just for heroes to go out and mercilessly slaughter anyone they deem as 'villains'."
    h "Toda esta fanfarronería y palabrería, solo para que los héroes salgan y masacren sin piedad a cualquiera que consideren 'villano'."

# game/game/script.rpy:1067
translate es playername_271217a2:

    # h "It's honestly disgusting. Does anyone even remember when we tried to {i}reform{/i} criminals."
    h "Es francamente repugnante. ¿Alguien siquiera recuerda cuando intentábamos {i}reformar{/i} a los criminales?"

# game/game/script.rpy:1069
translate es playername_056becb7:

    # h "Now they just get slaughtered because that is easier than reformation."
    h "Ahora solo los matan porque es más fácil que reformarlos."

# game/game/script.rpy:1071
translate es playername_27244982:

    # h "And the only group that seems to care even a goddamn smidgen is the {i}fucking prison industry{/i}...!"
    h "Y el único grupo que parece preocuparse un maldito poco es la {i}maldita industria carcelaria{/i}..."

# game/game/script.rpy:1073
translate es playername_a5bfcbd9:

    # h "because {i} ohhhh god forbid{/i} they lose out on 25-cent an hour labor!"
    h "porque {i}ohhh Dios nos libre{/i} de que pierdan su mano de obra a 25 centavos la hora."

# game/game/script.rpy:1075
translate es playername_a87992bb:

    # h "Like, is this world going crazy or is it just me?!"
    h "¿Acaso el mundo se ha vuelto loco o soy solo yo?!"

# game/game/script.rpy:1078
translate es playername_a3f217f5:

    # "I notice some of the customers are glancing over at Haley as their voice continues to get louder alongside their building passion."
    "Noto que algunos clientes miran hacia Haley mientras su voz se eleva junto con su creciente vehemencia."

# game/game/script.rpy:1080
translate es playername_774a9010:

    # "I agree with Haley to an extent."
    "Concuerdo con Haley en cierta medida."

# game/game/script.rpy:1082
translate es playername_b34252a4:

    # "Heroes do have too much power..."
    "Los héroes sí tienen demasiado poder..."

# game/game/script.rpy:1084
translate es playername_99bfc23b:

    # "But the idea that they go around slaughtering villains...?"
    "Pero la idea de que anden masacrando villanos... ¿?"

# game/game/script.rpy:1086
translate es playername_83fb0713:

    # "They must be getting these ideas from some borderline extremist, or at least villain-sympathetic internet forum or something."
    "Debe estar sacando esas ideas de algún foro extremista o al menos simpatizante de villanos."

# game/game/script.rpy:1088
translate es playername_d79192cd:

    # "It's common knowledge after all; Heroes don't kill."
    "Después de todo, es conocimiento general: los héroes no matan."

# game/game/script.rpy:1095
translate es playername_a579092d:

    # mc "Haley..."
    mc "Haley..."

# game/game/script.rpy:1097
translate es playername_25d08467:

    # "I touch their arm grabbing their attention."
    "Toco su brazo para captar su atención."

# game/game/script.rpy:1104
translate es playername_2d6d72c4:

    # "They pause, noticing me look around the cafe at the customers who are peering curiously."
    "Hace una pausa, notando que miro alrededor del café a los clientes que observan con curiosidad."

# game/game/script.rpy:1106
translate es playername_2918b508:

    # h "Yeah, yeah you're right, I'll shut up now."
    h "Sí, sí, tienes razón, me callo ya."

# game/game/script.rpy:1108
translate es playername_fa8101c5:

    # "Haley sighs pushing their hair over their shoulder."
    "Haley suspira, echando su cabello sobre el hombro."

# game/game/script.rpy:1112
translate es playername_26614bd4:

    # h "{size=-10}....I'm right though...{/size}"
    h "{size=-10}...Pero tengo razón...{/size}"

# game/game/script.rpy:1116
translate es playername_1b59d72f:

    # h "{size=-10}Back when I was a teen people still protested heroes...{/size}"
    h "{size=-10}Cuando era adolescente, la gente todavía protestaba contra los héroes...{/size}"

# game/game/script.rpy:1118
translate es playername_7b50fc14:

    # "They grumble while walking away."
    "Murmura mientras se aleja."

# game/game/script.rpy:1124
translate es playername_bb543d74:

    # mc "Okay grandy, we know, the world was different back in your day."
    mc "Está bien, abuele, ya sabemos, el mundo era diferente en tus tiempos."

# game/game/script.rpy:1128
translate es playername_8bab2066:

    # "Haley shoots a glare in my direction, but is unable to keep a completely straight face."
    "Haley me lanza una mirada fulminante, pero no logra mantener una cara completamente seria."

# game/game/script.rpy:1130
translate es playername_153ec668:

    # "They laugh while continuing to walk to the storage room."
    "Ríe mientras sigue caminando hacia el almacén."

# game/game/script.rpy:1134
translate es playername_19b541a5:

    # h "I'm going to go sort out some inventory in the back."
    h "Voy a ordenar algo de inventario atrás."

# game/game/script.rpy:1136
translate es playername_6d45811f:

    # h "If my old person back can hang in there...."
    h "Si mi vieja espalda aguanta..."

# game/game/script.rpy:1138
translate es playername_c3cf49af:

    # h "Maybe I'll have to ask for help from the younglings with more energy."
    h "Tal vez tenga que pedir ayuda a los jovencitos con más energía."

# game/game/script.rpy:1140
translate es playername_e806cad2:

    # "I point to the register."
    "Señalo la caja registradora."

# game/game/script.rpy:1144
translate es playername_e3e4b075:

    # mc "Yeah I don't mind helping out..."
    mc "No me importa ayudar..."

# game/game/script.rpy:1146
translate es playername_529d45a8:

    # mc "...As long as you are cool with the till being run by a certain employee with sticky fingers and a fascination for hero collectibles."
    mc "...Mientras estés de acuerdo con que la caja quede a cargo de cierto empleado con dedos pegajosos y fascinación por las figuras de héroes."

# game/game/script.rpy:1150
translate es playername_0ea67c8a:

    # h "Never mind! I feel {i} years {/i} younger."
    h "¡Olvídalo! Me siento {i}años{/i} más joven."

# game/game/script.rpy:1152
translate es playername_767df8e7:

    # "Haley walks off in their wide stride. Although their boots have heels, I can never seem to hear them click against the hard floor."
    "Haley se aleja con su característico paso largo. Aunque sus botas tienen tacones, nunca logro escuchar cómo golpean el suelo duro."

# game/game/script.rpy:1156
translate es playername_45872033:

    # "I lean back on the counter watching Haley as they continue to rant."
    "Me recuesto en el mostrador observando a Haley mientras sigue despotricando."

# game/game/script.rpy:1158
translate es playername_db28876e:

    # h "What world do we live in where murderers get praised and have...fucking {i} tv shows and interviews {/i}?!"
    h "¿En qué clase de mundo vivimos donde los asesinos son alabados y tienen... malditos {i}programas de televisión e entrevistas{/i}?"

# game/game/script.rpy:1160
translate es playername_d19d224a:

    # h "I swear to god all of these {i} heroes {/i} are just full on psychopaths."
    h "Juro por Dios que todos estos {i}héroes{/i} son psicópatas totales."

# game/game/script.rpy:1162
translate es playername_339acf9f:

    # h "They can do whatever they want and literally nobody will stop them! {i} Nobody! {/i}"
    h "¡Pueden hacer lo que quieran y literalmente nadie los detiene! ¡{i}Nadie{/i}!"

# game/game/script.rpy:1164
translate es playername_5a361058:

    # h "What kind of fucked up, piss poor, definition of 'justice' is that?!"
    h "¿Qué clase de jodida y pésima definición de 'justicia' es esa?!"

# game/game/script.rpy:1166
translate es playername_e10ddf4d:

    # h "And what do we do?! We make edited montages of them! Commercial goods! Paste their goddamn faces on every surface imaginable!"
    h "¿Y qué hacemos nosotros?! ¡Hacemos montajes editados de ellos! ¡Productos comerciales! ¡Pegamos sus malditas caras en cada superficie imaginable!"

# game/game/script.rpy:1168
translate es playername_ee3792eb:

    # h "Fuck! It pisses me off !"
    h "¡Mierda! ¡Me pone furiose!"

# game/game/script.rpy:1170
translate es playername_e23b2b4b:

    # "Haley unable to contain their anger any longer storms off."
    "Incapaz de contener más su ira, Haley se marcha furiosa."

# game/game/script.rpy:1172
translate es playername_23b5106e:

    # "Despite their stormy disposition, their angry heeled steps are almost silent."
    "A pesar de su temperamento tormentoso, sus pasos con tacones son casi inaudibles."

# game/game/script.rpy:1174
translate es playername_2edd7afa:

    # "{i}Truly the definition of light footed.{/i}"
    "{i}Verdaderamente la definición de pies ligeros.{/i}"

# game/game/script.rpy:1179
translate es playername_43f9ad6f:

    # "I sigh, turning back on the TV."
    "Suspiro y vuelvo a encender el televisor."

# game/game/script.rpy:1184
translate es playername_cd3d4176:

    # "{i}It's getting later on in the day, so customers are petering out.{/i}"
    "{i}Está cayendo la tarde, así que los clientes van disminuyendo.{/i}"

# game/game/script.rpy:1186
translate es playername_861b3c01:

    # "{i}And I'll be damned if I don't have some form of entertainment for my last working hour.{/i}"
    "{i}Y que me parta un rayo si no tengo algún tipo de entretenimiento para mi última hora de trabajo.{/i}"

# game/game/script.rpy:1188
translate es playername_2fcd2c39:

    # "The Hero's face lights up the screen as he saves women and children from imminent danger."
    "El rostro del héroe ilumina la pantalla mientras salva mujeres y niños del peligro inminente."

# game/game/script.rpy:1190
translate es playername_04648fc8:

    # "Apparently he has only been in this city for about 3 weeks and the people have already fallen in love with him."
    "Aparentemente solo lleva unas tres semanas en esta ciudad y la gente ya está enamorada de él."

# game/game/script.rpy:1192
translate es playername_8e0e0ec6:

    # "They even claim that he alone reduced villain and criminal attacks by 60 percent in the last month."
    "Incluso afirman que él solo redujo los ataques de villanos y criminales en un 60 por ciento el mes pasado."

# game/game/script.rpy:1194
translate es playername_aa88d140:

    # "Watching him do his thing on screen, the fall in villainy wasn't much of a surprise to me."
    "Viéndolo actuar en pantalla, la caída de la delincuencia no me sorprende mucho."

# game/game/script.rpy:1196
translate es playername_9e30ba52:

    # "It was almost impressive seeing him fly around, battling against monsters and villains."
    "Era casi impresionante verlo volar por ahí, luchando contra monstruos y villanos."

# game/game/script.rpy:1198
translate es playername_1b22c123:

    # "His red eyes glow, cutting down everything in their path."
    "Sus ojos rojos brillan, cortando todo a su paso."

# game/game/script.rpy:1200
translate es playername_b929d20b:

    # "Apparently he has trained many sidekicks to become successful heroes."
    "Aparentemente ha entrenado a muchos ayudantes para convertirlos en héroes exitosos."

# game/game/script.rpy:1202
translate es playername_a2912a02:

    # "I can't help but to wonder how hectic his life is."
    "No puedo evitar preguntarme cuán caótica debe ser su vida."

# game/game/script.rpy:1204
translate es playername_683e4517:

    # "The hero, after saving a child, smiles and waves at the camera. Citizens on clap and cheer for him in the back ground."
    "El héroe, después de salvar a un niño, sonríe y saluda a la cámara. Los ciudadanos aplauden y vitorean detrás de él."

# game/game/script.rpy:1206
translate es playername_bd28c148:

    # "Edited highlight shots of the hero plays. He gloriously flashes across the screen as terrified citizens scream for help, soon to be picked up and saved."
    "Se reproducen clips destacados del héroe. Cruza la pantalla gloriosamente mientras los aterrados ciudadanos gritan pidiendo ayuda, para ser rescatados enseguida."

# game/game/script.rpy:1208
translate es playername_e7a6d091:

    # "Some part of me felt ...gross watching it."
    "Una parte de mí sintió... asco al verlo."

# game/game/script.rpy:1210
translate es playername_af555c51:

    # "Imagine almost dying and immediately getting edited into....a hero montage."
    "Imagina casi morir y que inmediatamente te editen en... un montaje de héroes."

# game/game/script.rpy:1212
translate es playername_416acb1e:

    # mc "Ugh...."
    mc "Ugh...."

# game/game/script.rpy:1214
translate es playername_2405649a:

    # c "Not a fan huh?"
    c "¿No eres fan, eh?"

# game/game/script.rpy:1218
translate es playername_e232d0b3:

    # mc "!!!"
    mc "¡¡¡!!!"

# game/game/script.rpy:1220
translate es playername_a0bfde9e:

    # "I almost jump out of my skin at the sound of the voice in front of me."
    "Casi salto del susto al oír la voz frente a mí."

# game/game/script.rpy:1222
translate es playername_8f22562d:

    # "I look up and see the customer from about a week ago."
    "Levanto la mirada y veo al cliente de hace una semana."

# game/game/script.rpy:1230
translate es playername_c29b19fc:

    # mc "Oh sorry, I didn't see you there!"
    mc "¡Oh, perdón, no te vi ahí!"

# game/game/script.rpy:1232
translate es playername_8750cb21:

    # c "Yeah, I noticed."
    c "Sí, me di cuenta."

# game/game/script.rpy:1234
translate es playername_ff32f570:

    # "He glances up at the screen."
    "Él levanta la vista hacia la pantalla."

# game/game/script.rpy:1236
translate es playername_6cceb7ed:

    # c "It's okay, I'd rather look at Binary Star than myself too."
    c "Está bien, yo también preferiría mirar a Binary Star antes que a mí mismo."

# game/game/script.rpy:1238
translate es playername_af2e9b87:

    # "I smile sheepishly."
    "Sonrío con timidez."

# game/game/script.rpy:1240
translate es playername_a20cc073:

    # mc "I don't really like him or anything..."
    mc "No es que me guste ni nada..."

# game/game/script.rpy:1244
translate es playername_c085ee2d:

    # "{i}Why do I feel need to specify that...{/i}"
    "{i}¿Por qué siento la necesidad de aclarar eso...?{/i}"

# game/game/script.rpy:1246
translate es playername_c7a34e37:

    # "I cringe internally."
    "Me estremezco internamente."

# game/game/script.rpy:1248
translate es playername_d1d46ca0:

    # c "Yeah I kinda... noticed that too."
    c "Sí, como que... también me di cuenta."

# game/game/script.rpy:1250
translate es playername_15d4a291:

    # mc "You did?"
    mc "¿De verdad?"

# game/game/script.rpy:1252
translate es playername_e50dab2c:

    # c "Mhmm, your facial expression kinda looked like you smelled soiled milk or something."
    c "Ajá, tu expresión parecía como si olieras leche podrida o algo así."

# game/game/script.rpy:1254
translate es playername_f2f0f78b:

    # "My jaw hangs, I'm at a loss for words."
    "Mi mandíbula cae, sin saber qué decir."

# game/game/script.rpy:1256
translate es playername_40f408b9:

    # c "But like, four month old spoiled milk, not a week old spoiled milk."
    c "Pero como... leche podrida de cuatro meses, no de una semana."

# game/game/script.rpy:1258
translate es playername_43f5bc29:

    # c "It was intense."
    c "Fue intenso."

# game/game/script.rpy:1260
translate es playername_887bfaf3:

    # c "I almost even felt hurt for that guy..."
    c "Casi hasta me sentí mal por ese tipo..."

# game/game/script.rpy:1262
translate es playername_3a6150a3:

    # c "Nobody wants to get that kind of look from a cute barista."
    c "Nadie quiere recibir esa mirada de un barista adorable."

# game/game/script.rpy:1264
translate es playername_fff6bdf1:

    # mc "Cute?!"
    mc "¿¡Adorable?!"

# game/game/script.rpy:1268
translate es playername_7a648b0c:

    # "The man smirks quirking an eyebrow."
    "El hombre sonríe ladeando una ceja."

# game/game/script.rpy:1270
translate es playername_6fec0add:

    # c "Do you want me... to repeat myself?"
    c "¿Quieres que... lo repita?"

# game/game/script.rpy:1272
translate es playername_b0f0da4d:

    # mc "No, no, it's okay!"
    mc "¡No, no, está bien!"

# game/game/script.rpy:1274
translate es playername_6da3f13a:

    # "I feel like if I heard him say it again my face would simply combust."
    "Siento que si lo escucho decirlo otra vez mi cara simplemente explotará."

# game/game/script.rpy:1276
translate es playername_d4bca2d7:

    # "I already know it's probably bright red."
    "Ya sé que probablemente está completamente roja."

# game/game/script.rpy:1278
translate es playername_aa3246f8:

    # "{i}While this guy just stands there with the same smirk....what a bastard.{/i}"
    "{i}Mientras este tipo se queda ahí con la misma sonrisa... qué bastardo.{/i}"

# game/game/script.rpy:1280
translate es playername_ffabb40a:

    # "His smirk seemed to get wider."
    "Su sonrisa parece ensancharse más."

# game/game/script.rpy:1284
translate es playername_8a7b080a:

    # c "Why don't you like him?"
    c "¿Por qué no te gusta?"

# game/game/script.rpy:1286
translate es playername_fabba7e6:

    # "He motions his head toward the TV."
    "Hace un gesto con la cabeza hacia el televisor."

# game/game/script.rpy:1291
translate es playername_13fd6757:

    # "I decide to go with a safe, non-committal answer."
    "Decido irme por una respuesta segura y poco comprometida."

# game/game/script.rpy:1293
translate es playername_f5acbe80:

    # mc "I just never had any real interest in them, I guess."
    mc "Supongo que nunca tuve mucho interés en ellos."

# game/game/script.rpy:1295
translate es playername_9058779e:

    # mc "Call me crazy, but I think the whole hero thing is kinda ostentatious..."
    mc "Llámame demente, pero creo que todo ese asunto de los héroes es un poco ostentoso..."

# game/game/script.rpy:1297
translate es playername_025bd333:

    # mc "I can't help but to think that there are better ways to spend that money and time."
    mc "No puedo evitar pensar que hay mejores formas de gastar ese dinero y tiempo."

# game/game/script.rpy:1299
translate es playername_1dea13dd:

    # c "It just feels like a new category of asshole at the end of the day?"
    c "Al final del día, solo parecen otra categoría de idiotas, ¿no?"

# game/game/script.rpy:1301
translate es playername_8ce61eb8:

    # "I nod."
    "Asiento."

# game/game/script.rpy:1303
translate es playername_f36e5aec:

    # mc "Exactly."
    mc "Exactamente."

# game/game/script.rpy:1305
translate es playername_d14ad9e8:

    # mc "I think I'd rather my heroes be everyday people."
    mc "Creo que prefiero que mis héroes sean personas comunes."

# game/game/script.rpy:1307
translate es playername_6fabfd95:

    # mc "Humans that have their own lives and issues to worry about."
    mc "Humanos con sus propias vidas y problemas de los que preocuparse."

# game/game/script.rpy:1309
translate es playername_0da0af1f:

    # mc "Without fame and special abilities, but they take the time and effort to care for others around them."
    mc "Sin fama ni habilidades especiales, pero que se tomen el tiempo y esfuerzo de cuidar a los demás."

# game/game/script.rpy:1311
translate es playername_97d2e71b:

    # mc "Not celebrities that fly around in some gaudy outfit with homes that cost millions of dollars."
    mc "No celebridades que vuelan por ahí en trajes llamativos con casas que valen millones de dólares."

# game/game/script.rpy:1319
translate es playername_c3f6b7b3:

    # "I bite my lip trying to decide how honest I want to be."
    "Me muerdo el labio, decidiendo qué tan honesto quiero ser."

# game/game/script.rpy:1321
translate es playername_a2329d5a:

    # mc "To be honest..."
    mc "Para ser sincero..."

# game/game/script.rpy:1323
translate es playername_02a19bf6:

    # mc "Something about heroes kinda make me...uncomfortable."
    mc "Algo en los héroes me hace sentir... incomodidad."

# game/game/script.rpy:1325
translate es playername_be8b7287:

    # c "How so?"
    c "¿Cómo así?"

# game/game/script.rpy:1327
translate es playername_cc782a75:

    # mc "Something about them feel somewhat.... uncanny valley."
    mc "Hay algo en ellos que se siente un poco... fuera del límite de lo humano."

# game/game/script.rpy:1329
translate es playername_b2eef6a0:

    # c "Like a robot?"
    c "¿Como un robot?"

# game/game/script.rpy:1331
translate es playername_a29347ad:

    # mc "Yeah! Almost if Binary Star smiles any harder his face will just crack and fall to pieces."
    mc "¡Sí! Si Binary Star sonríe un poco más, su cara se romperá y se hará pedazos."

# game/game/script.rpy:1333
translate es playername_3869f58b:

    # mc "Heroes are always saying what the public wants them to say too."
    mc "Además, los héroes siempre dicen lo que el público quiere escuchar."

# game/game/script.rpy:1335
translate es playername_c2919600:

    # mc "Like they know exactly what to say."
    mc "Como si supieran exactamente qué decir."

# game/game/script.rpy:1337
translate es playername_e23f1de9:

    # c "I think most of them probably have PR writers."
    c "Apuesto a que la mayoría tiene escritores de relaciones públicas."

# game/game/script.rpy:1339
translate es playername_1b2ac705:

    # mc "After all of that media grooming, the heroes don't even feel human anymore."
    mc "Después de todo ese entrenamiento mediático, los héroes ya ni siquiera parecen humanos."

# game/game/script.rpy:1341
translate es playername_5e228d56:

    # mc "I mean, I guess Binary Star {i} isn't {/i} technically human... but you understand what I'm saying right?"
    mc "Quiero decir, supongo que técnicamente Binary Star {i}no es{/i} humano... pero entiendes lo que digo, ¿verdad?"

# game/game/script.rpy:1345
translate es playername_6c291d8e:

    # "The man grimaces, but nods."
    "El hombre hace una mueca, pero asiente."

# game/game/script.rpy:1347
translate es playername_10e1347a:

    # c "The child from the stars...Binary Star that poor bastard."
    c "El niño de las estrellas... Binary Star, ese pobre desgraciado."

# game/game/script.rpy:1349
translate es playername_fd1d2800:

    # c "I bet you're right."
    c "Apuesto a que tienes razón."

# game/game/script.rpy:1351
translate es playername_6bf18f8d:

    # c "If his face did smile any harder it would just fall off."
    c "Si su sonrisa se estira un poco más, se le caería la cara."

# game/game/script.rpy:1353
translate es playername_a8da03d3:

    # c "And underneath it would be an endless pit."
    c "Y debajo de ella habría un pozo sin fin."

# game/game/script.rpy:1357
translate es playername_6fbaaf80:

    # "The man chuckles."
    "El hombre se ríe."

# game/game/script.rpy:1359
translate es playername_2d6ab123:

    # c "Or something like that right?"
    c "¿O algo así, verdad?"

# game/game/script.rpy:1361
translate es playername_beb1f114:

    # mc "Nah, I'm betting it's just a robot war machine underneath the human looking face."
    mc "Nah, apuesto a que debajo solo hay una máquina de guerra robótica."

# game/game/script.rpy:1363
translate es playername_6f38bf25:

    # c "The military getting in on the hero game with the latest tech huh?"
    c "¿El ejército metiéndose en el negocio de los héroes con su última tecnología, eh?"

# game/game/script.rpy:1365
translate es playername_b7fd02df:

    # "I can't help but laugh."
    "No puedo evitar reírme."

# game/game/script.rpy:1367
translate es playername_ad8f90f6:

    # mc "Yeah! They always want the fame and fortune after all..."
    mc "¡Sí! Siempre quieren la fama y la fortuna, después de todo..."

# game/game/script.rpy:1371
translate es playername_b9a29de0:

    # "A momentary look of softness travels across the man's face."
    "Una expresión suave cruza momentáneamente el rostro del hombre."

# game/game/script.rpy:1375
translate es playername_88844731:

    # mc "But either way, I should probably take your order."
    mc "Pero de cualquier manera, probablemente debería tomar tu orden."

# game/game/script.rpy:1377
translate es playername_5d26792a:

    # mc "Considering you have been standing here for like 5 minutes..."
    mc "Considerando que llevas como cinco minutos parado ahí..."

# game/game/script.rpy:1379
translate es playername_067b8491:

    # "The man smiles."
    "El hombre sonríe."

# game/game/script.rpy:1381
translate es playername_5101fbef:

    # c "Don't worry about it."
    c "No te preocupes por eso."

# game/game/script.rpy:1383
translate es playername_d79976e1:

    # c "I think I enjoy our little interactions."
    c "Creo que disfruto de nuestras pequeñas interacciones."

# game/game/script.rpy:1385
translate es playername_65768fdc:

    # "I grab a medium sized cup, the size he has ordered the last two times he came here."
    "Tomo un vaso mediano, el tamaño que ha pedido las últimas dos veces que vino."

# game/game/script.rpy:1387
translate es playername_8be189c7:

    # mc "Black coffee again?"
    mc "¿Café negro otra vez?"

# game/game/script.rpy:1391
translate es playername_c38760af:

    # c "Oh, you remembered..."
    c "Oh, lo recordaste..."

# game/game/script.rpy:1393
translate es playername_827b8f5f:

    # mc "I try to remember our regular's orders."
    mc "Intento memorizar los pedidos de los clientes habituales."

# game/game/script.rpy:1397
translate es playername_cc3f0b18:

    # c "I think with this being my third time here, I hardly count as a regular."
    c "Creo que siendo apenas mi tercera vez aquí, no cuento como cliente habitual."

# game/game/script.rpy:1399
translate es playername_049da538:

    # c "But I'll take the expedited honor anyways."
    c "Pero aceptaré el honor de todos modos."

# game/game/script.rpy:1401
translate es playername_9379223c:

    # mc "Can I get your name for the order?"
    mc "¿Puedo saber tu nombre para la orden?"

# game/game/script.rpy:1403
translate es playername_b4530796:

    # "In all honesty, I didn't really need his name. We tend to just call out the type of drink rather than the name of the customer."
    "En realidad, no necesitaba su nombre. Generalmente solo anunciamos el tipo de bebida, no el nombre del cliente."

# game/game/script.rpy:1407
translate es playername_61deec81:

    # "{i}But maybe I want to be a little selfish for once...{/i}"
    "{i}Pero tal vez quiera ser un poco egoísta por una vez...{/i}"

# game/game/script.rpy:1411
translate es playername_35ba903f:

    # c "Can I try your special?"
    c "¿Puedo probar tu especial?"

# game/game/script.rpy:1413
translate es playername_eac157c1:

    # "I give a blank look."
    "Pongo una cara en blanco."

# game/game/script.rpy:1415
translate es playername_65bdbc82:

    # c "...The one guaranteed not to be found anywhere else, or I get my money back."
    c "...El que está garantizado que no se encuentra en ningún otro lugar, o me devuelves el dinero."

# game/game/script.rpy:1417
translate es playername_1b51a367:

    # mc "Ah, of course!"
    mc "Ah, por supuesto."

# game/game/script.rpy:1419
translate es playername_309ee2dd:

    # mc "And if you don't like it, I'll make you something else!"
    mc "Y si no te gusta, te preparo otra cosa."

# game/game/script.rpy:1421
translate es playername_a04fb3f0:

    # c "I thought you said I could get my money back? Am I about to be scammed?"
    c "¿No dijiste que me devolverías el dinero? ¿Acabo de caer en una estafa?"

# game/game/script.rpy:1423
translate es playername_fbc73198:

    # mc "Fine, {i}and{/i} your money back."
    mc "Está bien, {i}y{/i} te devuelvo el dinero."

# game/game/script.rpy:1425
translate es playername_b87bbc1c:

    # "He smirks as if he already won."
    "Él sonríe como si ya hubiera ganado."

# game/game/script.rpy:1427
translate es playername_ad6c595b:

    # "{i}I'll make the best damn coffee he has ever had{/i}."
    "{i}Le haré el mejor maldito café que haya probado.{/i}"

# game/game/script.rpy:1429
translate es playername_59851022:

    # c "Somehow I feel like you are challenging me."
    c "De alguna forma siento que me estás desafiando."

# game/game/script.rpy:1431
translate es playername_fb5dcb42:

    # mc "Go take a seat, I'll bring it to you when it's ready."
    mc "Ve a sentarte, te lo llevo cuando esté listo."

# game/game/script.rpy:1433
translate es playername_34757527:

    # c "You don't want me to pay?"
    c "¿No quieres que pague?"

# game/game/script.rpy:1435
translate es playername_218ac5e1:

    # mc "I'll take your money {i} after {/i} I rob you of your pride."
    mc "Tomaré tu dinero {i}después{/i} de robarte el orgullo."

# game/game/script.rpy:1437
translate es playername_76583bc2:

    # "He cracks a smile."
    "Él suelta una sonrisa."

# game/game/script.rpy:1441
translate es playername_d41e840b:

    # c "Cheeky thing..."
    c "Cuanto descaro... "

# game/game/script.rpy:1443
translate es playername_08af3c45:

    # "The man saunters off to lean against the far wall."
    "El hombre se aleja con calma para apoyarse en la pared del fondo."

# game/game/script.rpy:1449
translate es playername_6cbbc50b:

    # "I feel his eyes follow me as I move back and forth while making the coffee."
    "Siento su mirada siguiéndome mientras me muevo preparando el café."

# game/game/script.rpy:1451
translate es playername_404cc780:

    # "After a couple of minutes, it's finally done."
    "Después de unos minutos, finalmente está listo."

# game/game/script.rpy:1453
translate es playername_5f755259:

    # "I bring out the most beautiful mint latte I have ever made."
    "Traigo el latte de menta más hermoso que he hecho."

# game/game/script.rpy:1459
translate es playername_28339ad9:

    # "The man looks down at it slightly grimacing."
    "El hombre lo mira con una ligera mueca."

# game/game/script.rpy:1461
translate es playername_bd4b62fd:

    # c "It's kinda....green...?"
    c "Es como... ¿verde...?"

# game/game/script.rpy:1463
translate es playername_9e124f7b:

    # mc "What, you don't know any other color than black?"
    mc "¿Qué? ¿No conoces otro color que no sea el negro?"

# game/game/script.rpy:1465
translate es playername_adc802ef:

    # "The man eyes it up suspiciously."
    "El hombre lo observa con suspicacia."

# game/game/script.rpy:1467
translate es playername_5251db75:

    # c "If I die from this..."
    c "Si muero por esto..."

# game/game/script.rpy:1469
translate es playername_724b9c35:

    # mc "Oh my god, you are more likely to die from ingesting black coffee everyday."
    mc "Dios mío, es más probable que mueras por tomar café negro todos los días."

# game/game/script.rpy:1471
translate es playername_f77e9a4e:

    # mc "Stir it a bit first, and give it a try."
    mc "Revuelve un poco primero y pruébalo."

# game/game/script.rpy:1475
translate es playername_cd1d88ff:

    # mc "You can also start to take out your wallet if you want."
    mc "También puedes ir sacando la billetera si quieres."

# game/game/script.rpy:1480
translate es playername_8f01d2c2:

    # c "Wow, the barista won't stir it for me? Service is really lacking here."
    c "Vaya, ¿el barista no lo va a revolver por mí? Qué mal servicio hay aquí."

# game/game/script.rpy:1482
translate es playername_72f475cf:

    # mc "I am NOT going to stir it for you, {i}Sir{/i}."
    mc "NO voy a revolvértelo, {i}señor{/i}."

# game/game/script.rpy:1486
translate es playername_2b36ad4b:

    # "The man chuckles a bit and stirs the drink."
    "El hombre suelta una pequeña risa y revuelve la bebida."

# game/game/script.rpy:1488
translate es playername_8a2d9de7:

    # "He bring it up to take a drink."
    "La acerca para dar un sorbo."

# game/game/script.rpy:1490
translate es playername_171a6e3e:

    # "He takes a good amount in at once, swallowing deeply."
    "Toma una buena cantidad de una vez, tragando profundamente."

# game/game/script.rpy:1492
translate es playername_52ca5dd3:

    # "He pauses looking at me."
    "Hace una pausa y me mira."

# game/game/script.rpy:1494
translate es playername_3bee3db9:

    # "The man places down the drink and takes out his wallet."
    "El hombre deja la bebida sobre la mesa y saca su billetera."

# game/game/script.rpy:1496
translate es playername_2393c365:

    # c "So what do I owe you?"
    c "Entonces, ¿cuánto te debo?"

# game/game/script.rpy:1498
translate es playername_14099f23:

    # "I can't help but to smile."
    "No puedo evitar sonreír."

# game/game/script.rpy:1500
translate es playername_10713ad5:

    # mc "You haven't even told me how good it is yet!"
    mc "¡Ni siquiera me has dicho qué tan bueno está!"

# game/game/script.rpy:1502
translate es playername_c7009ae1:

    # c "It's......good."
    c "Está... bueno."

# game/game/script.rpy:1504
translate es playername_37ddf2a6:

    # mc "That's it? Nothing else?"
    mc "¿Eso es todo? ¿Nada más?"

# game/game/script.rpy:1506
translate es playername_57bff59c:

    # mc "Maybe the word you were thinking of was 'delicious', 'heavenly', maybe 'awe-inspiring'...?"
    mc "¿Tal vez la palabra que buscabas era 'delicioso', 'celestial', tal vez 'inspirador'?"

# game/game/script.rpy:1510
translate es playername_fba7cc1d:

    # c "Don't push your luck kid, I got my pride too."
    c "No tientes tu suerte, chico, yo también tengo mi orgullo."

# game/game/script.rpy:1514
translate es playername_2c19db29:

    # "He smirks rifling in his wallet for bills."
    "Sonríe mientras busca billetes en su billetera."

# game/game/script.rpy:1516
translate es playername_f7d8d093:

    # mc "Don't worry about the money..."
    mc "No te preocupes por el dinero..."

# game/game/script.rpy:1518
translate es playername_47679710:

    # mc "The satisfaction of your loss is payment enough."
    mc "La satisfacción de tu derrota es pago suficiente."

# game/game/script.rpy:1520
translate es playername_9484e5e2:

    # c "No, I lost fair and square. I have to pay up."
    c "No, perdí justamente. Tengo que pagar."

# game/game/script.rpy:1522
translate es playername_21421402:

    # mc "No seriously, my treat!"
    mc "No, en serio, ¡invita la casa!"

# game/game/script.rpy:1524
translate es playername_a8b7d36e:

    # "He looks at me for what felt like a solid minute before putting his wallet away."
    "Me mira durante lo que pareció un minuto entero antes de guardar la billetera."

# game/game/script.rpy:1526
translate es playername_c1bfa14d:

    # c "If you say so..."
    c "Si tú lo dices..."

# game/game/script.rpy:1528
translate es playername_6b7b82dc:

    # "He looks at the drink which is beautifully displayed in a glass mug."
    "Mira la bebida, bellamente servida en una taza de vidrio."

# game/game/script.rpy:1532
translate es playername_004e1c12:

    # "He then checks the time on his phone and grimaces."
    "Luego revisa la hora en su teléfono y hace una mueca."

# game/game/script.rpy:1534
translate es playername_bb53285b:

    # "Before he can even open his mouth I present a to-go cup and lid."
    "Antes de que pueda abrir la boca, le presento una taza para llevar con tapa."

# game/game/script.rpy:1536
translate es playername_ad734f6f:

    # mc "I figured you wouldn't be able to stick around for long."
    mc "Imaginé que no podrías quedarte mucho tiempo."

# game/game/script.rpy:1540
translate es playername_d3fb85b1:

    # "He seems a bit surprised as he takes the cup, his face eventually falling back into his usual expression."
    "Parece algo sorprendido al tomar la taza, aunque su rostro vuelve pronto a su expresión habitual."

# game/game/script.rpy:1544
translate es playername_675cfae0:

    # c "You didn't have to go to all the effort to-"
    c "No tenías que molestarte tanto en—"

# game/game/script.rpy:1546
translate es playername_0ade978b:

    # "I swiftly cut him off."
    "Lo interrumpo con rapidez."

# game/game/script.rpy:1548
translate es playername_211bc8c5:

    # mc "It tastes better when it's presented well."
    mc "Sabe mejor cuando se presenta bien."

# game/game/script.rpy:1552
translate es playername_d0ae06d2:

    # c "Is that so?"
    c "¿Ah, sí?"

# game/game/script.rpy:1554
translate es playername_ea69d82f:

    # mc "Mmhm!"
    mc "¡Ajá!"

# game/game/script.rpy:1556
translate es playername_cfcf1217:

    # "I nod enthusiastically."
    "Asiento con entusiasmo."

# game/game/script.rpy:1558
translate es playername_e403404c:

    # "He pours the drink into the to-go cup careful not to spill."
    "Vierte la bebida en la taza para llevar, con cuidado de no derramar."

# game/game/script.rpy:1560
translate es playername_ecb257ca:

    # c "Thanks a lot for this."
    c "Gracias por esto."

# game/game/script.rpy:1564
translate es playername_32f3f6fd:

    # "He leans in close."
    "Se inclina hacia mí."

# game/game/script.rpy:1577
translate es playername_81f640e4:

    # "My heart starts to beat faster."
    "Mi corazón empieza a latir más rápido."

# game/game/script.rpy:1579
translate es playername_103e750c:

    # "{i}What is he doing...?{/i}"
    "{i}¿Qué está haciendo...?{/i}"

# game/game/script.rpy:1581
translate es playername_babf5ae7:

    # "He pauses, snatching the permanent marker out of my apron pocket."
    "Hace una pausa, sacando el marcador permanente de mi bolsillo del delantal."

# game/game/script.rpy:1585
translate es playername_44d5ec2a:

    # "I gape as he scribbles something on the to-go cup."
    "Me quedo inmovil mientras garabatea algo en la taza."

# game/game/script.rpy:1587
translate es playername_748412b8:

    # "He turns the cup towards me, the word 'Ray' scrawled on the side."
    "Gira la taza hacia mí, mostrando la palabra 'Ray' escrita a un lado."

# game/game/script.rpy:1589
translate es playername_4c2bdbd4:

    # r "It's my name."
    r "Es mi nombre."

# game/game/script.rpy:1591
translate es playername_6a1ab6cb:

    # mc "Oh! Cool, nice to meet you Ray."
    mc "¡Oh! Genial, un gusto conocerte, Ray."

# game/game/script.rpy:1593
translate es playername_67ea59d4:

    # r "Nice to meet you too, %(player_name)s."
    r "El gusto es mío, %(player_name)s."

# game/game/script.rpy:1595
translate es playername_2dc4987e:

    # mc "Have a good day at work, if that's where you are going."
    mc "Que tengas un buen día en el trabajo, si es a donde vas."

# game/game/script.rpy:1597
translate es playername_99b04a79:

    # "It occurred to me that it was nearly 4pm on a Tuesday. Was he going back to work..?"
    "Se me ocurre que ya casi son las 4 p. m. de un martes. ¿Volvería al trabajo...?"

# game/game/script.rpy:1599
translate es playername_ba5b8ada:

    # "Or maybe he was done for the day?"
    "¿O quizá ya había terminado por hoy?"

# game/game/script.rpy:1601
translate es playername_5a6f95fa:

    # "{i}But he never comes in at the same times for coffee.{/i}"
    "{i}Aunque nunca viene a la misma hora por su café.{/i}"

# game/game/script.rpy:1603
translate es playername_2a1fccb2:

    # "{i}He must have a job with very odd hours.{/i}"
    "{i}Debe tener un trabajo con horarios muy raros.{/i}"

# game/game/script.rpy:1605
translate es playername_4faf1ed2:

    # "As I walk away something catches on my shoe causing me to stumble."
    "Mientras me alejo, algo se engancha en mi zapato y tropiezo."

# game/game/script.rpy:1626
translate es playername_84d88380:

    # r "Whoa!"
    r "¡Whoa!"

# game/game/script.rpy:1628
translate es playername_3b4f1423:

    # "Ray reaches out with one arm and catches me swiftly by the waist before I completely face plant."
    "Ray extiende un brazo y me sostiene rápidamente por la cintura antes de que me estrelle contra el suelo."

# game/game/script.rpy:1630
translate es playername_e137ae28:

    # "The catch pulled up his sleeve, and his arm was marked with scars..."
    "El movimiento levanta su manga, y su brazo está cubierto de cicatrices..."

# game/game/script.rpy:1632
translate es playername_28c33f4f:

    # r "Try not to space out too much when you walk."
    r "Trata de no distraerte tanto cuando camines."

# game/game/script.rpy:1648
translate es playername_79cb613b:

    # "Ray pulls me up back to my feet and releases me gently. His arms were.... surprisingly strong...considering how sleep deprived he always looks."
    "Ray me levanta y me ayuda a ponerme de pie con suavidad. Sus brazos eran... sorprendentemente fuertes... considerando lo agotado que siempre parece."

# game/game/script.rpy:1650
translate es playername_8a59aa48:

    # "I can't help to think about how surprisingly marked up his arm was."
    "No puedo evitar pensar en lo marcados que estaban sus brazos."

# game/game/script.rpy:1652
translate es playername_b15359a4:

    # "Cuts, holes, slices, both old and new."
    "Cortes, agujeros, rasguños, tanto viejos como nuevos."

# game/game/script.rpy:1654
translate es playername_06fad9cb:

    # "{i}Maybe his job is some hard manual labor or something.{/i}"
    "{i}Tal vez su trabajo requiere mucho esfuerzo físico o algo así.{/i}"

# game/game/script.rpy:1656
translate es playername_3cdda399:

    # "{i}That would explain why he is so tired all of the time.{/i}"
    "{i}Eso explicaría por qué siempre está tan cansado.{/i}"

# game/game/script.rpy:1658
translate es playername_45ef5692:

    # "{i}And he smelled nice too...I wonder what cologne he uses{/i}."
    "{i}Y además olía bien... me pregunto qué colonia usa.{/i}"

# game/game/script.rpy:1663
translate es playername_1ade0c25:

    # "I get back behind the counter and watch Ray as he gives me a short wave before leaving."
    "Vuelvo detrás del mostrador y observo a Ray mientras me saluda con un leve gesto antes de irse."

# game/game/script.rpy:1667
translate es playername_41236e71:

    # "Some part of me hoped he would be back tomorrow."
    "Una parte de mí esperaba que volviera mañana."

# game/game/script.rpy:1669
translate es playername_d83f445f:

    # "I stick my hands in my apron pockets and sigh."
    "Meto las manos en los bolsillos del delantal y suspiro."

# game/game/script.rpy:1671
translate es playername_2564af7c:

    # "My fingertips nudge a hard object in my pocket."
    "Mis dedos tocan un objeto duro dentro del bolsillo."

# game/game/script.rpy:1673
translate es playername_05500ff6:

    # mc "Huh?"
    mc "¿Eh?"

# game/game/script.rpy:1675
translate es playername_d08c4603:

    # "I pull out the foreign object that was in my pocket."
    "Saco el objeto extraño que había dentro."

# game/game/script.rpy:1677
translate es playername_fbbaab52:

    # "{i}A small wad of money...?{/i}"
    "{i}¿Un pequeño fajo de dinero...?{/i}"

# game/game/script.rpy:1679
translate es playername_bd769f72:

    # "I felt a harder object with them."
    "Siento algo más duro junto con él."

# game/game/script.rpy:1681
translate es playername_88a85ac3:

    # "I pull out part of a coffee sleeve scrawled with a small message in permanent marker."
    "Saco parte de una funda de cartón de café con un pequeño mensaje escrito con marcador permanente."

# game/game/script.rpy:1683
translate es playername_01b44923:

    # "{i}Thanks for the coffee, the extra is tip - R{/i}"
    "{i}Gracias por el café, lo extra es propina – R{/i}"

# game/game/script.rpy:1685
translate es playername_757815ee:

    # "There is a phone number scrawled at the bottom."
    "Hay un número de teléfono escrito al final."

# game/game/script.rpy:1687
translate es playername_c79dc45c:

    # "I look at the bills."
    "Miro los billetes."

# game/game/script.rpy:1689
translate es playername_eb58a505:

    # mc "$50..?"
    mc "¿$50...?"

# game/game/script.rpy:1691
translate es playername_87b40c04:

    # "After carrying out the transaction, I stuff the rest of the cash in the tip jar."
    "Después de cerrar la transacción, guardo el resto del dinero en el frasco de propinas."

# game/game/script.rpy:1706
translate es playername_b214d7a8:

    # "A couple more days passed without any appearance from Ray..."
    "Pasaron un par de días más sin señales de Ray..."

# game/game/script.rpy:1708
translate es playername_0213b4b2:

    # "{i}Finally off of work.{/i}"
    "{i}Por fin libre del trabajo.{/i}"

# game/game/script.rpy:1714
translate es playername_776afb21:

    # "Despite my desperate desire to just go home, face plant on the couch, and binge shows for the rest of the day..."
    "A pesar de mi desesperado deseo de ir a casa, tirarme en el sofá y ver series todo el día..."

# game/game/script.rpy:1716
translate es playername_f1b03469:

    # "{i}I should probably get some groceries.{/i}"
    "{i}Probablemente debería comprar algo de comida.{/i}"

# game/game/script.rpy:1718
translate es playername_b8977982:

    # "{i}I can't live off of mac and cheese for the next two weeks after all...{/i}"
    "{i}No puedo vivir solo de macarrones con queso las próximas dos semanas...{/i}"

# game/game/script.rpy:1720
translate es playername_edc2dd3c:

    # "{i}Or rather, I probably shouldn't...{/i}"
    "{i}O más bien, probablemente no debería...{/i}"

# game/game/script.rpy:1728
translate es playername_b915885a:

    # "I do a bit of grocery shopping and grab some essentials for the next couple of days."
    "Hago algunas compras y tomo lo esencial para los próximos días."

# game/game/script.rpy:1730
translate es playername_6324588a:

    # "But not too much that I am unable to carry all of them back to the apartment."
    "Pero no demasiado, para poder cargar todo de regreso al apartamento."

# game/game/script.rpy:1734
translate es playername_7ca06f67:

    # "Partway through the trip back home, my phone buzzes."
    "A mitad del camino de regreso, mi teléfono vibra."

# game/game/script.rpy:1738
translate es playername_222592e4:

    # "I heft a bag onto my other arm and check the call."
    "Cambio una bolsa de brazo y reviso la llamada."

# game/game/script.rpy:1744
translate es playername_0ba44906:

    # "{i}Unknown Caller{/i}"
    "{i}Número desconocido{/i}"

# game/game/script.rpy:1750
translate es playername_36f3545c:

    # "The sinking feeling in my stomach gave me an idea of who it could be."
    "La sensación en el estómago me da una idea de quién podría ser."

# game/game/script.rpy:1754
translate es playername_e074a45a:

    # "I take a breath and pickup the call."
    "Respiro hondo y contesto la llamada."

# game/game/script.rpy:1760
translate es playername_883694a4:

    # dvp "[criminalname]"
    dvp "[criminalname]"

# game/game/script.rpy:1762
translate es playername_2b35b6fe:

    # mc "..."
    mc "..."

# game/game/script.rpy:1764
translate es playername_84d9991b:

    # mc "Yes..."
    mc "Sí..."

# game/game/script.rpy:1766
translate es playername_f5dee544:

    # "I could tell by the voice. It was my old partner in crime Double Vision. "
    "Pude reconocer la voz. Era mi antiguo compañero de crimen, Double Vision."

# game/game/script.rpy:1768
translate es playername_87d18d7e:

    # "Double Vision, myself, and the rest of the Night Crew used to hit houses and make quite a bit of money."
    "Double Vision, yo y el resto del Night Crew solíamos asaltar casas y ganar bastante dinero."

# game/game/script.rpy:1770
translate es playername_d55950a2:

    # "We would even lift cars on occasion."
    "Incluso robábamos autos de vez en cuando."

# game/game/script.rpy:1772
translate es playername_789c62cc:

    # "{i}Though, I can't say we split on good terms.{/i}"
    "{i}Aunque no puedo decir que terminamos en buenos términos.{/i}"

# game/game/script.rpy:1774
translate es playername_06227863:

    # dvp "You moved."
    dvp "Te mudaste."

# game/game/script.rpy:1776
translate es playername_d6fcb3c2:

    # mc "Yeah, away from you."
    mc "Sí, lejos de ti."

# game/game/script.rpy:1778
translate es playername_09af9967:

    # dvp "You wound me [criminalname]."
    dvp "Me hieres, [criminalname]."

# game/game/script.rpy:1780
translate es playername_1ddd0a52:

    # dvp "We had a good thing."
    dvp "Teníamos algo bueno."

# game/game/script.rpy:1782
translate es playername_8d3e9be3:

    # "I could hear the thick malice in his voice."
    "Podía escuchar la densa malicia en su voz."

# game/game/script.rpy:1784
translate es playername_2b35b6fe_1:

    # mc "..."
    mc "..."

# game/game/script.rpy:1786
translate es playername_70da99ae:

    # dvp "Don't be so cold honey."
    dvp "Cuanta frialdad, cariño. "

# game/game/script.rpy:1788
translate es playername_eb19c945:

    # dvp "Going to the lengths of running away while I was out of town?"
    dvp "¿Llegaste al punto de huir mientras yo estaba fuera de la ciudad?"

# game/game/script.rpy:1790
translate es playername_07da348c:

    # dvp "You wound me, truly."
    dvp "Me heriste, de verdad."

# game/game/script.rpy:1792
translate es playername_46a872e3:

    # dvp "When you left, I did some things I'm not so proud of...."
    dvp "Cuando te fuiste, hice cosas de las que no estoy tan orgulloso...."

# game/game/script.rpy:1794
translate es playername_c66c5e4f:

    # dvp "But the honest truth is that I saw red."
    dvp "Pero la verdad honesta es que vi rojo."

# game/game/script.rpy:1796
translate es playername_4954751b:

    # dvp "You remember Ripley right?"
    dvp "¿Recuerdas a Ripley, verdad?"

# game/game/script.rpy:1798
translate es playername_4637d62f:

    # "I swallowed hard. My hand shook, but I was unable to hang up."
    "Tragué saliva con fuerza. Mi mano tembló, pero no pude colgar."

# game/game/script.rpy:1800
translate es playername_5c908930:

    # dvp "I can't guarantee that you will be able to recognize him anymore."
    dvp "No puedo garantizar que puedas reconocerlo ya."

# game/game/script.rpy:1802
translate es playername_7b5f5a73:

    # "He lets out a cold curt laugh."
    "Él deja escapar una risa fría y cortante."

# game/game/script.rpy:1804
translate es playername_c73d3d84:

    # "He then transitions into a soft coo-ing voice."
    "Luego cambia a una voz suave y arrulladora."

# game/game/script.rpy:1806
translate es playername_b17f8e30:

    # dvp "You should have told me you were upset honey."
    dvp "Deberías haberme dicho que estabas mal, cariño."

# game/game/script.rpy:1808
translate es playername_0beaae90:

    # dvp "You can't just leave me like that."
    dvp "No puedes simplemente dejarme así."

# game/game/script.rpy:1810
translate es playername_d16b48f9:

    # dvp "You know what that does to a guy..."
    dvp "¿Sabes lo que le hace eso a un tipo...?"

# game/game/script.rpy:1812
translate es playername_684088f3:

    # dvp "I get so worked up over you, I know I shouldn't..."
    dvp "Me altero tanto por ti, sé que no debería..."

# game/game/script.rpy:1814
translate es playername_85a4a200:

    # dvp "But I keep thinking about you, and I don't think I can just let you go."
    dvp "Pero sigo pensando en ti, y no creo que pueda simplemente dejarte ir."

# game/game/script.rpy:1816
translate es playername_25e5509b:

    # dvp "So I'm asking {i}nicely{/i}..."
    dvp "Así que te pido {i}amablemente{/i}..."

# game/game/script.rpy:1818
translate es playername_fd171cc6:

    # dvp "Please come back."
    dvp "Por favor vuelve."

# game/game/script.rpy:1820
translate es playername_79ed985e:

    # dvp "I'll buy you the same flat, the same car, everything."
    dvp "Te compraré el mismo piso, el mismo auto, todo."

# game/game/script.rpy:1822
translate es playername_5ba3d487:

    # dvp "And we can pretend your silly little lapse in judgement never even happened."
    dvp "Y podemos fingir que tu pequeño lapsus de juicio nunca siquiera ocurrió."

# game/game/script.rpy:1824
translate es playername_072f3787:

    # dvp "Come back to the crew... {i}to me{/i}."
    dvp "Vuelve a la banda... {i}a mí{/i}."

# game/game/script.rpy:1826
translate es playername_bc97f75c:

    # "I gather any courage I can, breathing in a shaky breath."
    "Reúno todo el coraje que puedo, respirando con un aliento tembloroso."

# game/game/script.rpy:1831
translate es playername_44c94da5:

    # "You know... I can't do that Double."
    "Sabes... No puedo hacer eso, Double."

# game/game/script.rpy:1837
translate es playername_1b38a821:

    # "I take all of the spite I can muster."
    "Tomo todo el despecho que puedo reunir."

# game/game/script.rpy:1839
translate es playername_feb2ae1a:

    # mc "{i}Go fuck yourself Double.{/i}"
    mc "{i}Vete a la mierda, Double.{/i}"

# game/game/script.rpy:1841
translate es playername_347a13ca:

    # "I spit out in rage."
    "Lo escupo con rabia."

# game/game/script.rpy:1843
translate es playername_5042a523:

    # "Double lets out a loud barking laugh."
    "Double deja escapar una carcajada fuerte y ladrante."

# game/game/script.rpy:1845
translate es playername_7148d720:

    # dvp "Oh, %(player_name)s! You never cease to surprise me~"
    dvp "Oh, %(player_name)s! Nunca dejas de sorprenderme~"

# game/game/script.rpy:1847
translate es playername_d78e7c80:

    # dvp "Listen to this close:"
    dvp "Escucha esto atentamente:"

# game/game/script.rpy:1849
translate es playername_68ced6d8:

    # dvp "If you really want to be free..."
    dvp "Si realmente quieres ser libre..."

# game/game/script.rpy:1851
translate es playername_4ea654c5:

    # dvp "{i}Then don't let me find you honey.{/i}"
    dvp "{i}Entonces no me dejes encontrarte, cariño.{/i}"

# game/game/script.rpy:1853
translate es playername_4dcbcb25:

    # dvp "Because when I do-"
    dvp "Porque cuando lo haga-"

# game/game/script.rpy:1855
translate es playername_6b7eaa90:

    # dvp "...."
    dvp "...."

# game/game/script.rpy:1857
translate es playername_b6bdfd68:

    # "A heavy silence blankets the call like mist."
    "Un silencio pesado cubre la llamada como niebla."

# game/game/script.rpy:1859
translate es playername_84b5dd2b:

    # "I could hear my own heart beat echo through my ears."
    "Puedo oír los latidos de mi propio corazón resonar en mis oídos."

# game/game/script.rpy:1861
translate es playername_68de8adf:

    # "Double finally talks in a slow and serious whisper."
    "Double finalmente habla en un susurro lento y serio."

# game/game/script.rpy:1863
translate es playername_0d1867de:

    # dvp "{i}{b}I'll fucking kill you.{/b}{/i}"
    dvp "{i}{b}Te voy a matar, maldita sea.{/b}{/i}"

# game/game/script.rpy:1865
translate es playername_5455e0d4:

    # "He hangs up and the line beeps."
    "Cuelga y la línea emite un pitido."

# game/game/script.rpy:1872
translate es playername_fb694c2c:

    # "I collapse to the ground, my legs not quite feeling up to the task of standing."
    "Me desplomo en el suelo, mis piernas no se sienten del todo capaces de sostenerme."

# game/game/script.rpy:1880
translate es playername_8ca3cca6:

    # n "Closer than I'd like to admit honestly."
    n "Más cerca de lo que me gustaría admitir, honestamente."

# game/game/script.rpy:1882
translate es playername_21113ce5:

    # n "For a while it was peaceful, even fun."
    n "Por un tiempo fue pacífico, incluso divertido."

# game/game/script.rpy:1884
translate es playername_c777798c:

    # n "Then slowly, things started to change."
    n "Luego, poco a poco, las cosas empezaron a cambiar."

# game/game/script.rpy:1886
translate es playername_c2053250:

    # n "Every time I gave an inch, he started to take two inches..."
    n "Cada vez que cedía una pulgada, él empezaba a tomar dos pulgadas..."

# game/game/script.rpy:1888
translate es playername_8890cdf5:

    # n "Then he would take a foot..."
    n "Luego tomaría un pie..."

# game/game/script.rpy:1890
translate es playername_a883e6a5:

    # n "Eventually, he wasn't even satisfied with a mile."
    n "Eventualmente, ni siquiera se conformaba con una milla."

# game/game/script.rpy:1892
translate es playername_970e76ee:

    # n "That was the type of guy Double was."
    n "Ese era el tipo de hombre que era Double."

# game/game/script.rpy:1894
translate es playername_c69cdca9:

    # n "For a while I wondered if he started to change..."
    n "Por un tiempo me pregunté si él empezó a cambiar..."

# game/game/script.rpy:1896
translate es playername_f9568caa:

    # n "Or if this was him all along, prowling under the cracking mask."
    n "O si este había sido él desde siempre, merodeando bajo la máscara que se agrietaba."

# game/game/script.rpy:1898
translate es playername_614d7f42:

    # n "But at some point the egg or the chicken hardly mattered."
    n "Pero en algún punto, el huevo o la gallina apenas importaban."

# game/game/script.rpy:1904
translate es playername_bb53ca0a:

    # n "Compliments turned into obsessions."
    n "Los halagos se convirtieron en obsesiones."

# game/game/script.rpy:1906
translate es playername_18f1eee4:

    # n "Warnings turned into threats."
    n "Las advertencias se convirtieron en amenazas."

# game/game/script.rpy:1908
translate es playername_656b11ff:

    # n "Once I had enough money, enough of a safety net, I had to get out."
    n "Una vez que tuve suficiente dinero, suficiente red de seguridad, tuve que salir."

# game/game/script.rpy:1910
translate es playername_4f510d59:

    # n "Maybe Double, in some way, kept me from becoming too greedy..."
    n "Quizá Double, de alguna manera, me evitó tener demasiada codicia..."

# game/game/script.rpy:1912
translate es playername_edd91a40:

    # n "Kept me from becoming too used to the lucrative villain lifestyle."
    n "Me alejo de acostumbrarme demasiado al lucrativo estilo de vida de villano."

# game/game/script.rpy:1914
translate es playername_f88e9df6:

    # n "When I asked to leave he said no."
    n "Cuando pedí irme, él dijo que no."

# game/game/script.rpy:1916
translate es playername_8b1cb37c:

    # n "When the soft spoken Marsh stood up for me, telling Double to 'just let me go'..."
    n "Cuando el de voz suave Marsh se levantó en mi defensa, diciéndole a Double que 'solo me dejara ir'..."

# game/game/script.rpy:1918
translate es playername_bb2cf764:

    # n "..."
    n "..."

# game/game/script.rpy:1920
translate es playername_97470523:

    # n "Double beat Marsh's face into a lump of unrecognizable flesh."
    n "Double golpeó la cara de Marsh hasta convertirla en un bulto de carne irreconocible."

# game/game/script.rpy:1922
translate es playername_fe904e05:

    # n "From that point it guaranteed Double into god-hood for the more violent members of the crew."
    n "A partir de ese momento garantizó la divinización de Double para los miembros más violentos de la banda."

# game/game/script.rpy:1924
translate es playername_bafd2b9b:

    # n "The non-violent members became too fearful to ever speak up against Double again."
    n "Los miembros no violentos se volvieron demasiado temerosos para hablar contra Double de nuevo."

# game/game/script.rpy:1926
translate es playername_740be278:

    # n "And so, I left the crew, alone."
    n "Y así, dejé la banda, sin acompañantes."

# game/game/script.rpy:1928
translate es playername_e1a07caf:

    # n "I fled in the darkness of night, taking my family with me."
    n "Hui en la oscuridad de la noche, llevando a mi familia conmigo."

# game/game/script.rpy:1930
translate es playername_6a707266:

    # n "I moved my family into a different town, with different names, far far away."
    n "Mudé a mi familia a un pueblo distinto, con nombres distintos, muy muy lejos."

# game/game/script.rpy:1932
translate es playername_9b6712f7:

    # n "And as for myself..."
    n "Y en cuanto a mí..."

# game/game/script.rpy:1934
translate es playername_882f8c44:

    # n "I became anonymous in a different city."
    n "Me envolví en el anonimato en otra ciudad. "

# game/game/script.rpy:1936
translate es playername_f253c3ae:

    # n "Far enough away from my family so that they could live in peace without me."
    n "Lo suficientemente lejos de mi familia para que pudieran vivir en paz sin mí."

# game/game/script.rpy:1938
translate es playername_db87e6ad:

    # n "So the question is..."
    n "Así que la pregunta es..."

# game/game/script.rpy:1940
translate es playername_840c296e:

    # n "{i}Has he already found me...?{/i}"
    n "{i}¿Ya me ha encontrado...?{/i}"

# game/game/script.rpy:1942
translate es playername_ad25e07e:

    # n "{i}After all...{/i}"
    n "{i}Después de todo...{/i}"

# game/game/script.rpy:1944
translate es playername_366f947a:

    # n "{i}{b}Double always enjoyed playing with his food.{/b}{/i}"
    n "{i}{b}A Double siempre le gustó jugar con su comida.{/b}{/i}"

# game/game/script.rpy:1952
translate es playername_a6fa181b:

    # "My legs shook."
    "Mis piernas temblaron."

# game/game/script.rpy:1954
translate es playername_0749283f:

    # "I felt nauseated with the thought."
    "Me sentí náuseas con la idea."

# game/game/script.rpy:1956
translate es playername_43867fb5:

    # "I desperately scanned the area. I didn't see or feel anything off."
    "Escaneé desesperadamente el área. No vi ni sentí nada extraño."

# game/game/script.rpy:1958
translate es playername_18a801ba:

    # "Locals walked along casually carrying out their lives."
    "Los lugareños caminaban con naturalidad llevando a cabo sus vidas."

# game/game/script.rpy:1960
translate es playername_f0766a12:

    # "I quickly gather up my bags. In my haste my phone falls out of my hand."
    "Recojo rápidamente mis bolsas. En mi prisa el teléfono se me cae de la mano."

# game/game/script.rpy:1966
translate es playername_036729cf:

    # "It tumbles to a stop against the shoes of a stranger."
    "Rueda hasta detenerse contra los zapatos de un desconocido."

# game/game/script.rpy:1968
translate es playername_e4f2e532:

    # "They pick it up and hold it out towards me."
    "Lo recogen y me lo extienden."

# game/game/script.rpy:1978
translate es playername_e48bc95d:

    # mc ".....Ray...?"
    mc "¿.....Ray...?"

# game/game/script.rpy:1980
translate es playername_6716070c:

    # r "Here."
    r "Toma."

# game/game/script.rpy:1982
translate es playername_2307b3f5:

    # "He hands me my phone."
    "Me entrega mi teléfono."

# game/game/script.rpy:1984
translate es playername_bb5a2c84:

    # r "You look like you've seen better days %(player_name)s..."
    r "Pareces haber visto días mejores %(player_name)s..."

# game/game/script.rpy:1986
translate es playername_402110d8:

    # r "Is everything alright..?"
    r "¿Está todo bien..?"

# game/game/script.rpy:1988
translate es playername_71c50ec9:

    # "I get up from the ground, setting the groceries onto the ground to straighten out my clothes."
    "Me levanto del suelo, colocando las compras en el suelo para arreglarme la ropa."

# game/game/script.rpy:1990
translate es playername_514ece4e:

    # "{i}I have to get it together. I probably look crazy right now.{/i}"
    "{i}Tengo que recomponerme. Probablemente me veo demente ahora mismo.{/i}"

# game/game/script.rpy:1992
translate es playername_d6da961f:

    # "I mentally chastise myself, looking up at Ray's concerned eyes."
    "Me reprendo mentalmente, mirando los ojos preocupados de Ray."

# game/game/script.rpy:1997
translate es playername_66f54e2c:

    # "I force a grin and pray it is convincing."
    "Fuerzo una sonrisa y rezo porque sea convincente."

# game/game/script.rpy:1999
translate es playername_ac4ff163:

    # mc "Ah yeah...I was just, taking a break."
    mc "Ah sí... solo estaba, tomando un descanso."

# game/game/script.rpy:2001
translate es playername_80dc5c29:

    # "Ray raises an eyebrow."
    "Ray arquea una ceja."

# game/game/script.rpy:2003
translate es playername_2b2b2029:

    # "I motion towards the groceries."
    "Hago un gesto hacia las compras."

# game/game/script.rpy:2005
translate es playername_da90d9f9:

    # mc "I think I purchased too much, they are pretty heavy."
    mc "Creo que compré demasiado, están bastante pesadas."

# game/game/script.rpy:2007
translate es playername_38975662:

    # "I lie through my teeth."
    "Miento descaradamente."

# game/game/script.rpy:2009
translate es playername_f8588dd4:

    # r "So you took a break....in the middle of the street?"
    r "¿Así que tomaste un descanso....en medio de la calle?"

# game/game/script.rpy:2011
translate es playername_0febe1f9:

    # "I laugh awkwardly, unable to find a good excuse."
    "Me río incómodamente, incapaz de encontrar una buena excusa."

# game/game/script.rpy:2015
translate es playername_a1fa7a56:

    # r "Are you heading in this direction?"
    r "¿Te diriges en esta dirección?"

# game/game/script.rpy:2017
translate es playername_a8c5638b:

    # "He points to where I was facing."
    "Señala hacia donde yo estaba mirando."

# game/game/script.rpy:2021
translate es playername_4be65a8d:

    # mc "Ah, yeah-"
    mc "Ah, sí-"

# game/game/script.rpy:2023
translate es playername_e68e6055:

    # r "I'm going that way too."
    r "Yo también voy para allá."

# game/game/script.rpy:2025
translate es playername_4a3d2023:

    # r "Need some help?"
    r "¿Necesitas ayuda?"

# game/game/script.rpy:2029
translate es playername_d5697803:

    # "Before I can say no, he picks up a grocery bag..."
    "Antes de que pueda decir que no, él levanta una bolsa de la compra..."

# game/game/script.rpy:2034
translate es playername_8cdc8986:

    # "A grocery bag that was incredibly light."
    "Una bolsa de la compra que era increíblemente ligera."

# game/game/script.rpy:2038
translate es playername_7952d115:

    # "Ray pauses, turning to look at me. He gives me a look of suspicion and confusion."
    "Ray se detiene y se gira para mirarme. Me lanza una mirada de sospecha y confusión."

# game/game/script.rpy:2040
translate es playername_ec00ff1c:

    # "He opens his mouth as if he was about to say something, he then seemingly decides against it."
    "Abre la boca como si fuera a decir algo, pero luego parece decidir lo contrario."

# game/game/script.rpy:2044
translate es playername_ab2803ce:

    # "He then silently picks up the other grocery bag too."
    "Luego levanta en silencio la otra bolsa de compras también."

# game/game/script.rpy:2046
translate es playername_ffde9045:

    # "I stare embarrassed, unsure of what to do."
    "Me quedo mirando, con pena, sin saber qué hacer."

# game/game/script.rpy:2048
translate es playername_f11fa861:

    # "Luckily for me, Ray reads the room and decides not to press me further."
    "Por suerte para mí, Ray capta la situación y decide no presionarme más."

# game/game/script.rpy:2052
translate es playername_34b5239b:

    # r "Are we going? Or do you want me to carry you too?"
    r "¿Vamos? ¿O quieres que te cargue también?"

# game/game/script.rpy:2054
translate es playername_ef0d583c:

    # "I hurry to catch up with his tired stride."
    "Apuro el paso para alcanzarlo con su andar cansado."

# game/game/script.rpy:2058
translate es playername_60773d91:

    # r "These bags are pretty light...do you have any food of substance in here...?"
    r "Estas bolsas son bastante ligeras... ¿tienes algo de comida de verdad aquí...?"

# game/game/script.rpy:2060
translate es playername_0014b25e:

    # mc "I don't want to hear about dietary habits from a guy who regularly consumes black coffee in the middle of the day."
    mc "No quiero oír sobre hábitos alimenticios de un tipo que bebe café negro a media tarde."

# game/game/script.rpy:2062
translate es playername_d39baac0:

    # r "I recently took up mint lattes {i}thank you very much{/i}."
    r "Recientemente empecé con los lattes de menta {i}muchas gracias{/i}."

# game/game/script.rpy:2064
translate es playername_00534074:

    # mc "Oh yeah? What made you decide to do that?"
    mc "¿Ah sí? ¿Qué te hizo decidir eso?"

# game/game/script.rpy:2066
translate es playername_39641a2f:

    # r "When a cute barista asks you to try something, you can hardly say 'no'."
    r "Cuando un barista adorable te pide que pruebes algo, apenas puedes decir 'no'."

# game/game/script.rpy:2070
translate es playername_799cb3d5:

    # r "Someone like me has weaknesses too you know?"
    r "Alguien como yo también tiene debilidades, ¿sabes?"

# game/game/script.rpy:2072
translate es playername_a2618d79:

    # mc "Someone like you?"
    mc "¿Alguien como tú?"

# game/game/script.rpy:2076
translate es playername_768c354d:

    # r "How far do you live from here?"
    r "¿Qué tan lejos vives de aquí?"

# game/game/script.rpy:2078
translate es playername_9b877a1c:

    # mc "Not too far, are you already getting tired?"
    mc "No muy lejos, ¿ya te estás cansando?"

# game/game/script.rpy:2082
translate es playername_ff1fd024:

    # "Ray looks down at me with a wry smile."
    "Ray me mira hacia abajo con una sonrisa irónica."

# game/game/script.rpy:2084
translate es playername_b873d29c:

    # r "Not on your life, barista."
    r "Ni en tus sueños, barista."

# game/game/script.rpy:2086
translate es playername_f1264db4:

    # mc "I have a name you know."
    mc "Tengo nombre, ¿sabes?"

# game/game/script.rpy:2088
translate es playername_36b42926:

    # r "{i}%(player_name)s.{/i}"
    r "{i}%(player_name)s.{/i}"

# game/game/script.rpy:2090
translate es playername_d0ce8e9c:

    # mc "I...honestly didn't expect you to remember my name."
    mc "Yo... honestamente no esperaba que recordaras mi nombre."

# game/game/script.rpy:2092
translate es playername_23fca6e0:

    # "Ray is about to say something when his phone buzzes."
    "Ray está a punto de decir algo cuando su teléfono vibra."

# game/game/script.rpy:2098
translate es playername_2f081262:

    # "He pauses to look at it and cancels the call, stuffing his phone back into his pocket."
    "Se detiene para mirarlo y cancela la llamada, guardando el teléfono de nuevo en el bolsillo."

# game/game/script.rpy:2100
translate es playername_2ffd642b:

    # "After only a couple of moments, his phone begins to buzz again and he once again cancels it."
    "Después de unos pocos momentos, su teléfono vuelve a vibrar y vuelve a cancelarlo."

# game/game/script.rpy:2102
translate es playername_4b20327d:

    # r "Sorry about that..."
    r "Perdón por eso..."

# game/game/script.rpy:2104
translate es playername_86fffea1:

    # r "I've got some....needy juniors at work."
    r "Tengo unos... subordinados necesitados en el trabajo."

# game/game/script.rpy:2106
translate es playername_62b58aa3:

    # r "Hopefully they will get the hint and leave me alone."
    r "Con suerte entenderán la indirecta y me dejarán en paz."

# game/game/script.rpy:2110
translate es playername_4d17d027:

    # "As we stroll Ray and I chat about a variety of topics."
    "Mientras caminamos, Ray y yo conversamos sobre varios temas."

# game/game/script.rpy:2112
translate es playername_f57c3568:

    # "I discover that he likes cats, but due to his work he is unable to own one."
    "Descubro que le gustan los gatos, pero debido a su trabajo no puede tener uno."

# game/game/script.rpy:2114
translate es playername_bade51a4:

    # "He also recently took up coffee a few months ago. Before then he never even drank it."
    "También comenzó a tomar café hace unos meses. Antes de eso, ni siquiera lo bebía."

# game/game/script.rpy:2116
translate es playername_5587e8a7:

    # "Soon enough we made it to the front door of my apartment building."
    "Pronto llegamos a la puerta de mi edificio de apartamentos."

# game/game/script.rpy:2127
translate es playername_029590f8:

    # "{i}'Bzzzzzz'{/i}"
    "{i}'Bzzzzzz'{/i}"

# game/game/script.rpy:2133
translate es playername_40dadfbe:

    # "His phone vibrates again and he fumbles to reject the call."
    "Su teléfono vibra otra vez y él lucha por rechazar la llamada."

# game/game/script.rpy:2135
translate es playername_f7afb2a0:

    # r "Sorry.."
    r "Perdón..."

# game/game/script.rpy:2137
translate es playername_1e2cd5c3:

    # "He mumbles."
    "Murmura."

# game/game/script.rpy:2139
translate es playername_f9ea60f3:

    # r "Work forces me to use a phone that has the silence feature blocked."
    r "El trabajo me obliga a usar un teléfono sin opción de silencio."

# game/game/script.rpy:2141
translate es playername_b9824dde:

    # mc "That's sounds like a ... unhealthy work environment..?"
    mc "¿Eso suena como un... entorno laboral poco saludable...?"

# game/game/script.rpy:2143
translate es playername_0bd6cceb:

    # "Ray gives a chuckle that sounded more tired than humorous."
    "Ray suelta una risa que sonó más cansada que divertida."

# game/game/script.rpy:2145
translate es playername_a0266332:

    # r "Yeah 'suppose so. Unfortunately I'm somewhat grandfathered into the position."
    r "Sí, supongo que sí. Desafortunadamente, estoy algo atado al puesto."

# game/game/script.rpy:2147
translate es playername_07f4a5cd:

    # mc "You can't just quit?"
    mc "¿No puedes simplemente renunciar?"

# game/game/script.rpy:2149
translate es playername_a7aba515:

    # r "Not really..."
    r "No realmente..."

# game/game/script.rpy:2151
translate es playername_5684a75e:

    # mc "That sounds... illegal."
    mc "Eso suena... ilegal."

# game/game/script.rpy:2153
translate es playername_c26bf66d:

    # "Ray just grimaces."
    "Ray solo hace una mueca."

# game/game/script.rpy:2155
translate es playername_09de8172:

    # "He doesn't seem very chatty about work, he must be in a stressful career ..."
    "No parece muy hablador sobre su trabajo, debe ser una carrera estresante..."

# game/game/script.rpy:2157
translate es playername_41523734:

    # mc "Well either way, this is me."
    mc "Bueno, de cualquier forma, aquí estoy."

# game/game/script.rpy:2159
translate es playername_bbd696da:

    # "I motion up to the apartment building."
    "Señalo hacia el edificio de apartamentos."

# game/game/script.rpy:2165
translate es playername_28e061c0:

    # mc "Um, if you have time... do you want to come up for some tea?"
    mc "Um, si tienes tiempo... ¿quieres subir a tomar un té?"

# game/game/script.rpy:2169
translate es playername_6eea1224:

    # mc "As a thankyou for the help, of course."
    mc "Como agradecimiento por la ayuda, por supuesto."

# game/game/script.rpy:2171
translate es playername_7e18f2b7:

    # "My heart was beating and I was sure that my face was getting increasingly red."
    "Mi corazón latía y estaba segura de que mi rostro se ponía cada vez más rojo."

# game/game/script.rpy:2173
translate es playername_59278e97:

    # "I genuinely didn't mean the invitation with any unholy intentions..."
    "Sinceramente no tenía intenciones indebidas con la invitación..."

# game/game/script.rpy:2175
translate es playername_fc2542cf:

    # "But it was still such an awkward question to ask because of the {i}implication{/i}."
    "Pero seguía siendo una pregunta incómoda por la {i}implicación{/i}."

# game/game/script.rpy:2177
translate es playername_df8cef53:

    # "Ray looks genuinely surprised, almost dropping his phone."
    "Ray parece genuinamente sorprendido, casi deja caer su teléfono."

# game/game/script.rpy:2181
translate es playername_b2b1ab62:

    # r "Uh yeah, Of course. I'd love to."
    r "Eh sí, por supuesto. Me encantaría."

# game/game/script.rpy:2185
translate es playername_8120e6c6:

    # "{i}'Bzzzzzzz'{/i}"
    "{i}'Bzzzzzzz'{/i}"

# game/game/script.rpy:2189
translate es playername_0e139484:

    # "Ray's phone begins to buzz again."
    "El teléfono de Ray comienza a vibrar de nuevo."

# game/game/script.rpy:2197
translate es playername_6243e6af:

    # "Ray looks visibly annoyed by the buzzing of his phone."
    "Ray se muestra visiblemente molesto por el zumbido de su teléfono."

# game/game/script.rpy:2199
translate es playername_e5a7b0ae:

    # r "Let me just... take this real quick."
    r "Déjame... atender esto rápido."

# game/game/script.rpy:2201
translate es playername_ad9e7c7c:

    # "He puts the phone up to his ear."
    "Se lleva el teléfono al oído."

# game/game/script.rpy:2203
translate es playername_3c46b32b:

    # r "Yes?"
    r "¿Sí?"

# game/game/script.rpy:2205
translate es playername_b9b755e5:

    # r "..."
    r "..."

# game/game/script.rpy:2207
translate es playername_1791270f:

    # r "Absolutely not, no. It is my day off."
    r "Absolutamente no, no. Es mi día libre."

# game/game/script.rpy:2209
translate es playername_3cad14fb:

    # r "What? Do you have no one else? Am I really your only-"
    r "¿Qué? ¿No tienen a nadie más? ¿De verdad soy su única-"

# game/game/script.rpy:2211
translate es playername_cbe316b5:

    # "He shoots a quick side glance at me."
    "Lanza una rápida mirada de reojo hacia mí."

# game/game/script.rpy:2215
translate es playername_8fb589c8:

    # r "{i} Option {/i} or something?"
    r "¿{i}Opción{/i} o algo así?"

# game/game/script.rpy:2219
translate es playername_dd159719:

    # r "I in fact {i} do {/i} have a life."
    r "De hecho {i}sí{/i} tengo una vida."

# game/game/script.rpy:2221
translate es playername_e4d7c289:

    # r "Is it so hard to believe that I have {i} plans{/i}?"
    r "¿Tan difícil es creer que tengo {i}planes{/i}?"

# game/game/script.rpy:2223
translate es playername_b9b755e5_1:

    # r "..."
    r "..."

# game/game/script.rpy:2225
translate es playername_b9b755e5_2:

    # r "..."
    r "..."

# game/game/script.rpy:2227
translate es playername_a385d35e:

    # r "Well that's too bad isn't it? You will just have to find someone else to take it on."
    r "Bueno, qué mal, ¿no? Tendrán que encontrar a alguien más que lo haga."

# game/game/script.rpy:2229
translate es playername_b9b755e5_3:

    # r "..."
    r "..."

# game/game/script.rpy:2231
translate es playername_e017438a:

    # r "I'm not."
    r "No lo haré."

# game/game/script.rpy:2233
translate es playername_b6e19d3e:

    # r "...."
    r "...."

# game/game/script.rpy:2235
translate es playername_2e6e34dc:

    # r "Anyways, I'm hanging up now. If you call me again this phone is getting a hole burnt into it. {i} I'm serious.{/i}"
    r "En fin, voy a colgar ahora. Si vuelven a llamarme, a este teléfono le haré un agujero. {i}Lo digo en serio.{/i}"

# game/game/script.rpy:2237
translate es playername_70e0ad16:

    # "Ray hangs up and places his phone back in his pocket."
    "Ray cuelga y guarda el teléfono en su bolsillo."

# game/game/script.rpy:2239
translate es playername_00ddbe1f:

    # "He turns to me, smiling kindly."
    "Se gira hacia mí, sonriendo amablemente."

# game/game/script.rpy:2243
translate es playername_939a8b04:

    # r "Sorry about that, should we head up?"
    r "Perdón por eso, ¿subimos?"

# game/game/script.rpy:2245
translate es playername_45ef7fc9:

    # "He picks up the bags again before I am able to."
    "Vuelve a levantar las bolsas antes de que pueda hacerlo yo."

# game/game/script.rpy:2247
translate es playername_3caa632a:

    # "As he takes his first step..."
    "Cuando da su primer paso..."

# game/game/script.rpy:2261
translate es playername_a451551d:

    # "The sound of a large explosion is heard in the distance."
    "Se escucha el sonido de una gran explosión a lo lejos."

# game/game/script.rpy:2265
translate es playername_a0e19ae5:

    # "The ground shakes with the force of the blow."
    "El suelo tiembla con la fuerza del impacto."

# game/game/script.rpy:2267
translate es playername_6e2ee2fd:

    # "Ray sighs in a frustrated manner."
    "Ray suspira con frustración."

# game/game/script.rpy:2271
translate es playername_8541db1a:

    # r "{size=-10}....goddammit.{/size}"
    r "{size=-10}....maldita sea.{/size}"

# game/game/script.rpy:2273
translate es playername_f48dd053:

    # "Ray's phone buzzes once more and he picks it up."
    "El teléfono de Ray vuelve a vibrar y él lo contesta."

# game/game/script.rpy:2275
translate es playername_52195e54:

    # r "Just two?"
    r "¿Solo dos?"

# game/game/script.rpy:2277
translate es playername_4c40ce1f:

    # r "Fine, I'm on my way, but you owe me."
    r "Bien, voy para allá, pero me lo debes."

# game/game/script.rpy:2279
translate es playername_a7f40b00:

    # "After hanging up Ray turns to me."
    "Después de colgar, Ray se vuelve hacia mí."

# game/game/script.rpy:2283
translate es playername_deaa392c:

    # r "Sorry %(player_name)s, looks like I just can't escape work today..."
    r "Perdón %(player_name)s, parece que hoy no puedo escapar del trabajo..."

# game/game/script.rpy:2287
translate es playername_c2158a01:

    # "He gives a smile so disappointed that I can't help but to feel bad for him."
    "Sonríe con tanta decepción que no puedo evitar sentir lástima por él."

# game/game/script.rpy:2289
translate es playername_a920b727:

    # mc "It's okay, maybe next time?"
    mc "Está bien, ¿quizás la próxima vez?"

# game/game/script.rpy:2291
translate es playername_1d1e6b7f:

    # r "Definitely next time."
    r "Definitivamente la próxima vez."

# game/game/script.rpy:2293
translate es playername_9e2c00f7:

    # "He picks up the grocery bags again."
    "Vuelve a levantar las bolsas de la compra."

# game/game/script.rpy:2295
translate es playername_b04104b4:

    # mc "Ah, don't worry about it."
    mc "Ah, no te preocupes por eso."

# game/game/script.rpy:2297
translate es playername_b82ce030:

    # mc "If your work is about that..."
    mc "Si tu trabajo tiene que ver con eso..."

# game/game/script.rpy:2301
translate es playername_46ccffed:

    # "I point to the giant cloud of black smoke in the distance."
    "Señalo la enorme nube de humo negro en la distancia."

# game/game/script.rpy:2305
translate es playername_112c9379:

    # mc "It's probably more important than my dumb groceries."
    mc "Probablemente sea más importante que mis tontas compras."

# game/game/script.rpy:2312
translate es playername_069eabeb:

    # "Ray gives a slow smile handing me the grocery bag."
    "Ray sonríe lentamente y me entrega la bolsa de la compra."

# game/game/script.rpy:2314
translate es playername_28e1e4a1:

    # "His eyes linger on my face as his hands brush mine slowly."
    "Sus ojos se detienen en mi rostro mientras sus manos rozan las mías lentamente."

# game/game/script.rpy:2316
translate es playername_1cbdfe27:

    # r "Nothing's more important than {i}your{/i} dumb groceries."
    r "Nada es más importante que {i}tus{/i} tontas compras."

# game/game/script.rpy:2318
translate es playername_500b056d:

    # r "I'll pay you back next time, okay?"
    r "Te lo compensaré la próxima vez, ¿de acuerdo?"

# game/game/script.rpy:2320
translate es playername_b091af72:

    # "He runs his hand over mine before pulling back."
    "Pasa su mano sobre la mía antes de retirarla."

# game/game/script.rpy:2322
translate es playername_dc2d86ee:

    # "The small motion makes my heart flutter something fierce."
    "El pequeño movimiento hace que mi corazón se agite con fuerza."

# game/game/script.rpy:2324
translate es playername_88dc170e:

    # mc "Okay, thanks again for your help Ray."
    mc "Está bien, gracias otra vez por tu ayuda, Ray."

# game/game/script.rpy:2326
translate es playername_6765210c:

    # "He smiles"
    "Él sonríe."

# game/game/script.rpy:2328
translate es playername_bbd00d39:

    # r "Anytime Star."
    r "Cuando quieras, Estrella."

# game/game/script.rpy:2330
translate es playername_5d4fe08e:

    # "{i}...Star?{/i}"
    "{i}...¿Estrella?{/i}"

# game/game/script.rpy:2332
translate es playername_04e367ee:

    # "He turns and walks away giving a short wave as he goes."
    "Se da vuelta y se aleja, levantando una mano en un breve saludo."

# game/game/script.rpy:2336
translate es playername_2cab4d6a:

    # mc "Hey thanks for helping-"
    mc "Hey, gracias por ayudar—"

# game/game/script.rpy:2350
translate es playername_a451551d_1:

    # "The sound of a large explosion is heard in the distance."
    "Se escucha el sonido de una gran explosión a lo lejos."

# game/game/script.rpy:2354
translate es playername_a0e19ae5_1:

    # "The ground shakes with the force of the blow."
    "El suelo tiembla con la fuerza del impacto."

# game/game/script.rpy:2356
translate es playername_b3b87e8d:

    # "Ray sighs, frustration seeping from his tone."
    "Ray suspira, con frustración en su tono."

# game/game/script.rpy:2362
translate es playername_8541db1a_1:

    # r "{size=-10}....goddammit.{/size}"
    r "{size=-10}....maldita sea.{/size}"

# game/game/script.rpy:2366
translate es playername_f48dd053_1:

    # "Ray's phone buzzes once more and he picks it up."
    "El teléfono de Ray vuelve a vibrar y él lo contesta."

# game/game/script.rpy:2368
translate es playername_52195e54_1:

    # r "Just two?"
    r "¿Solo dos?"

# game/game/script.rpy:2370
translate es playername_e2d61742:

    # r "Fine, I'm on my way. You owe me."
    r "Bien, voy para allá. Me lo debes."

# game/game/script.rpy:2372
translate es playername_64ff64ff:

    # "After hanging up, Ray turns to me."
    "Después de colgar, Ray se gira hacia mí."

# game/game/script.rpy:2376
translate es playername_13498ba9:

    # r "Looks like I gotta clock in some overtime."
    r "Parece que tendré que hacer horas extra."

# game/game/script.rpy:2378
translate es playername_360df6a6:

    # mc "Sorry to hear that, I hope you don't have to work too hard."
    mc "Lamento oír eso, espero que no tengas que trabajar demasiado."

# game/game/script.rpy:2382
translate es playername_2792a694:

    # r "I donno...might work so late that I'll just have to pick up some of my favorite coffee tomorrow morning."
    r "No sé... puede que trabaje tan tarde que mañana tenga que pasar por mi café favorito."

# game/game/script.rpy:2384
translate es playername_07596be6:

    # mc "I don't work tomorrow."
    mc "Yo no trabajo mañana."

# game/game/script.rpy:2386
translate es playername_849dea1a:

    # "Ray takes on a teasing tone."
    "Ray adopta un tono burlón."

# game/game/script.rpy:2388
translate es playername_fcd447b1:

    # r "Wow, assuming I only come to Cafe Waning Crescent for you?"
    r "Vaya, ¿asumiendo que solo voy a Café Waning Crescent por ti?"

# game/game/script.rpy:2390
translate es playername_4b36c259:

    # r "Pretty bold of you..."
    r "Bastante atrevido de tu parte..."

# game/game/script.rpy:2392
translate es playername_3adf6d8b:

    # mc "I've tasted our black coffee Ray..."
    mc "He probado nuestro café negro, Ray..."

# game/game/script.rpy:2394
translate es playername_7c526cad:

    # mc "Calling it 'good' is an awful stretch of the imagination."
    mc "Llamarlo 'bueno' es un enorme esfuerzo de imaginación."

# game/game/script.rpy:2396
translate es playername_68aa0985:

    # "He laughs genuinely."
    "Él se ríe genuinamente."

# game/game/script.rpy:2400
translate es playername_efdcb58c:

    # r "Okay, fair enough. An attractive barista is a nice bonus to a pretty average black coffee."
    r "Está bien, justo. Un barista de gran atractivo es un buen extra para un café negro bastante promedio."

# game/game/script.rpy:2402
translate es playername_e669e485:

    # "Ray looks toward the large black plumage staining the sky."
    "Ray mira hacia la gran pluma negra que mancha el cielo."

# game/game/script.rpy:2406
translate es playername_f46338fb:

    # r "I should probably get going though."
    r "Aunque probablemente debería irme ya."

# game/game/script.rpy:2408
translate es playername_3b0d76f5:

    # mc "Thanks for your help Ray."
    mc "Gracias por tu ayuda, Ray."

# game/game/script.rpy:2412
translate es playername_38ff4bc4:

    # r "Anything for my favorite barista."
    r "Cualquier cosa por mi barista favorito."

# game/game/script.rpy:2414
translate es playername_a2188053:

    # "He walks off giving a short wave goodbye."
    "Se aleja levantando una mano en señal de despedida."

# game/game/script.rpy:2425
translate es playername_51f2bf07:

    # "I put the groceries away and collapse on my bed."
    "Guardo las compras y me desplomo en la cama."

# game/game/script.rpy:2427
translate es playername_33c23e01:

    # "It was only around 4pm but it felt like it was such a long day already."
    "Apenas eran las 4 de la tarde, pero ya sentía que había sido un día larguísimo."

# game/game/script.rpy:2429
translate es playername_60d732e7:

    # "I can't help but to drift away into a short nap."
    "No puedo evitar dormir una breve siesta."

# game/game/script.rpy:2433
translate es playername_a20cefa7:

    # "..."
    "..."

# game/game/script.rpy:2435
translate es playername_632a4e28:

    # "I'm awakened with a start."
    "Me despierto de un sobresalto."

# game/game/script.rpy:2437
translate es playername_7a2b399e:

    # "A light draft makes me shiver."
    "Una ligera corriente de aire me hace estremecer."

# game/game/script.rpy:2439
translate es playername_d50b8997:

    # "I see that the window is cracked open."
    "Veo que la ventana está entreabierta."

# game/game/script.rpy:2441
translate es playername_85a53b34:

    # "{i}How do I keep forgetting to close this...?{/i}"
    "{i}¿Cómo sigo olvidando cerrarla...?{/i}"

# game/game/script.rpy:2445
translate es playername_2b2eaa5c:

    # "I shut it once again."
    "La cierro nuevamente."

# game/game/script.rpy:2455
translate es playername_8d5a7786:

    # "I sigh looking up at the clock."
    "Suspiro mirando el reloj."

# game/game/script.rpy:2457
translate es playername_52a1e488:

    # "{i}Only 10 more minutes before work ends...{/i}"
    "{i}Solo 10 minutos más para que termine el trabajo...{/i}"

# game/game/script.rpy:2459
translate es playername_e57d8072:

    # "It was almost 5pm, the usual crowd had completely died off at this point."
    "Ya casi eran las 5 p. m., la clientela habitual se había ido por completo a esta hora."

# game/game/script.rpy:2461
translate es playername_93a3a677:

    # "{i}8 more minutes.{/i}"
    "{i}8 minutos más.{/i}"

# game/game/script.rpy:2463
translate es playername_0f74c59a:

    # un2 "Excuse me, Helloooo."
    un2 "Disculpa, ¿Holaaaa?"

# game/game/script.rpy:2465
translate es playername_6402fd69:

    # "I look up."
    "Levanto la vista."

# game/game/script.rpy:2469
translate es playername_e08d2519:

    # "{i} Why does someone always appear literally right before the end of my shift....{/i}"
    "{i}¿Por qué siempre aparece alguien justo antes de que termine mi turno....?{/i}"

# game/game/script.rpy:2471
translate es playername_23c4c5cd:

    # "I groan internally."
    "Gimo internamente."

# game/game/script.rpy:2473
translate es playername_28549037:

    # mc "Hi, what can I get you today?"
    mc "Hola, ¿qué puedo ofrecerte hoy?"

# game/game/script.rpy:2475
translate es playername_eb0c8cd5:

    # bl "Yeah uh...sorry-"
    bl "Sí, eh... lo siento—"

# game/game/script.rpy:2477
translate es playername_80c5d886:

    # "The customer gives a short incredulous laugh."
    "El cliente suelta una pequeña risa incrédula."

# game/game/script.rpy:2479
translate es playername_05986b53:

    # bl "Do you not recognize me?"
    bl "¿No me reconoces?"

# game/game/script.rpy:2481
translate es playername_5f168573:

    # mc "... I'm sorry?"
    mc "... Lo siento, ¿qué?"

# game/game/script.rpy:2483
translate es playername_5689b457:

    # bl "..."
    bl "..."

# game/game/script.rpy:2485
translate es playername_e9df0596:

    # mc "I don't understand..."
    mc "No entiendo..."

# game/game/script.rpy:2487
translate es playername_6bc6aeb3:

    # bl "The hero of fire {i}'BLAZE' {/i} is right in front of you."
    bl "El héroe del fuego {i}'BLAZE'{/i} está justo frente a ti."

# game/game/script.rpy:2489
translate es playername_0c5fb789:

    # bl "And you don't recognize him?!"
    bl "¿Y no lo reconoces?!"

# game/game/script.rpy:2491
translate es playername_8e635b30:

    # "I blink, unsure of what to say."
    "Parpadeo, sin saber qué decir."

# game/game/script.rpy:2493
translate es playername_84182155:

    # bl "Ohhh, of course!"
    bl "Ohhh, claro."

# game/game/script.rpy:2495
translate es playername_b803d519:

    # bl "You are playing {i}cool and mysterious {/i} to get me all interested in you right?"
    bl "Estás actuando con {i}frialdad y misterio{/i} para que me interese más en ti, ¿verdad?"

# game/game/script.rpy:2497
translate es playername_c60d3ece:

    # "He brushes his hair with his hand giving a laugh."
    "Se pasa la mano por el cabello, soltando una risa."

# game/game/script.rpy:2499
translate es playername_04339e93:

    # bl "Well don't worry sweetheart, I'm already there~"
    bl "Bueno, no te preocupes, cariño, ya lo lograste~"

# game/game/script.rpy:2503
translate es playername_6b58e2be:

    # "He points a finger between myself and him winking at me."
    "Señala con un dedo entre nosotros, guiñándome un ojo."

# game/game/script.rpy:2505
translate es playername_ec043d54:

    # un2 "Same page."
    un2 "En la misma sintonía."

# game/game/script.rpy:2507
translate es playername_e61ed2a2:

    # mc "Uh, okay, so do you want coffee or what?"
    mc "Eh, bueno, ¿quieres café o qué?"

# game/game/script.rpy:2512
translate es playername_d1e46525:

    # "The man waves a hand dismissively."
    "El hombre hace un gesto con la mano, restándole importancia."

# game/game/script.rpy:2514
translate es playername_5f1e3ae4:

    # bl "We will get to that in a moment, but first..."
    bl "Llegaremos a eso en un momento, pero primero..."

# game/game/script.rpy:2516
translate es playername_d828097e:

    # bl "Does a blonde, tired looking man come in here often?"
    bl "¿Un hombre rubio, con aspecto cansado, viene seguido por aquí?"

# game/game/script.rpy:2518
translate es playername_6416aae6:

    # "I give a confused look."
    "Le pongo una mirada confundida."

# game/game/script.rpy:2520
translate es playername_101c6a60:

    # mc "There are a lot of tired people that come in here..."
    mc "Vienen muchas personas cansadas aquí..."

# game/game/script.rpy:2522
translate es playername_84d11421:

    # mc "It's a cafe."
    mc "Es una cafetería."

# game/game/script.rpy:2524
translate es playername_ad958d2c:

    # bl "He has hair about to here-"
    bl "Tiene el cabello más o menos hasta aquí—"

# game/game/script.rpy:2526
translate es playername_c7356411:

    # "the man waves his hand around his neckline."
    "el hombre mueve la mano alrededor de su cuello."

# game/game/script.rpy:2528
translate es playername_26a3a43e:

    # bl "And his eyes are really dead, like a thousand yard stare most of the time."
    bl "Y sus ojos se ven muertos, como una mirada vacía la mayor parte del tiempo."

# game/game/script.rpy:2530
translate es playername_ab07f0f4:

    # mc "Are you talking about Ray...?"
    mc "¿Estás hablando de Ray...?"

# game/game/script.rpy:2532
translate es playername_b5402bf5:

    # bl "Yeah, wow, first name basis huh? Lucky guy~"
    bl "Sí, wow, ¿te sabes su nombre y todo, eh? Chico con suerte~"

# game/game/script.rpy:2534
translate es playername_367f5694:

    # "I glance at the clock. I should have been off of work 5 minutes ago at this point..."
    "Miro el reloj. A esta hora ya debería haber terminado mi turno hace 5 minutos..."

# game/game/script.rpy:2536
translate es playername_7619f164:

    # "I attempt to speed things up."
    "Intento acelerar las cosas."

# game/game/script.rpy:2538
translate es playername_bdae9b02:

    # mc "Sooo... no coffee then?"
    mc "Así que... ¿no vas a pedir café entonces?"

# game/game/script.rpy:2540
translate es playername_9c5caf59:

    # bl "I don't blame you for going for {i} all that {/i} but..."
    bl "No te culpo por fijarte en {i}todo eso{/i} pero..."

# game/game/script.rpy:2542
translate es playername_994b12eb:

    # "He smiles."
    "Él sonríe."

# game/game/script.rpy:2544
translate es playername_edfea746:

    # bl "I feel like {i} I {/i} could give you better."
    bl "Siento que {i}yo{/i} podría ofrecerte algo mejor."

# game/game/script.rpy:2546
translate es playername_3fcf9093:

    # "At this point I am utterly confused."
    "A estas alturas estoy completamente confundida."

# game/game/script.rpy:2548
translate es playername_511d610e:

    # mc "Look {i} sir {/i} I don't even know your name-"
    mc "Mira, {i}señor{/i}, ni siquiera sé tu nombre—"

# game/game/script.rpy:2550
translate es playername_27636f81:

    # bl "Blaze."
    bl "Blaze."

# game/game/script.rpy:2552
translate es playername_2e6f6b8f:

    # mc "I meant your {i} real {/i} name."
    mc "Me refería a tu nombre {i}real{/i}."

# game/game/script.rpy:2554
translate es playername_abe73f3e:

    # bl "It's Luke, nice to meet you."
    bl "Luke, un placer conocerte."

# game/game/script.rpy:2556
translate es playername_b0bbaaa4:

    # bl "So as I was saying, I'm parked out front. It's the convertible."
    bl "Como decía, estoy estacionado afuera. Es el convertible."

# game/game/script.rpy:2558
translate es playername_ccf01e7d:

    # "He points to a flashy red car sitting diagonally across two disabled parking spots."
    "Señala un auto rojo llamativo que ocupa diagonalmente dos lugares de discapacitados."

# game/game/script.rpy:2560
translate es playername_e4b53117:

    # bl "How about we get out of here, just us... "
    bl "¿Qué tal si nos vamos de aquí, solo tú y yo...?"

# game/game/script.rpy:2564
translate es playername_627172ff:

    # "He winks and I smile harder to keep my face from cringing."
    "Me guiña un ojo y yo sonrío con esfuerzo para evitar que mi cara se contraiga."

# game/game/script.rpy:2566
translate es playername_b0889b60:

    # "{i}This guy is really laying it on thick.{/i}"
    "{i}Este tipo está realmente exagerando.{/i}"

# game/game/script.rpy:2572
translate es playername_b7cd860d:

    # bl "Not to sound too full of myself, but you would be lucky to be with a guy like me."
    bl "No quiero sonar arrogante, pero tendrías suerte de estar con un tipo como yo."

# game/game/script.rpy:2574
translate es playername_cd0fc1ec:

    # bl "Not sure if you noticed, but I'm a {i}hero{/i}."
    bl "Por si no lo notaste, soy un {i}héroe{/i}."

# game/game/script.rpy:2576
translate es playername_b23639f4:

    # "He starts to look upset, most likely due to his passes not being received with the enthusiasm that he expected."
    "Empieza a parecer molesto, probablemente porque sus insinuaciones no están siendo recibidas con el entusiasmo que esperaba."

# game/game/script.rpy:2578
translate es playername_f030c8d6:

    # mc "I need to clock out, so...do you want to order anything?"
    mc "Necesito registrar mi salida, así que... ¿vas a pedir algo?"

# game/game/script.rpy:2580
translate es playername_03b72608:

    # "The man sucks his teeth leaning up against the counter."
    "El hombre chasquea los dientes, apoyándose en el mostrador."

# game/game/script.rpy:2584
translate es playername_77c1850b:

    # bl "Look, you seem a bit dense. So I'll spell it out for you."
    bl "Mira, pareces no captarlo. Así que te lo voy a deletrear."

# game/game/script.rpy:2586
translate es playername_bd5adf41:

    # "Luke leans in, his cologne enveloping me."
    "Luke se inclina, su colonia envolviéndome."

# game/game/script.rpy:2588
translate es playername_1f080804:

    # bl "This may be hard to believe, but I'm the hero {i}Blaze{/i}."
    bl "Puede que sea difícil de creer, pero soy el héroe {i}Blaze{/i}."

# game/game/script.rpy:2590
translate es playername_90ec56d1:

    # mc "Yes, you mentioned that a few times now {i}Blaze{/i}."
    mc "Sí, ya lo mencionaste varias veces {i}Blaze{/i}."

# game/game/script.rpy:2592
translate es playername_49fd9a41:

    # "I could feel the customer service politeness leaving my body."
    "Podía sentir cómo la cortesía del servicio al cliente abandonaba mi cuerpo."

# game/game/script.rpy:2596
translate es playername_515e66e3:

    # "He gives a leering smile."
    "Él muestra una sonrisa lasciva."

# game/game/script.rpy:2598
translate es playername_a6b1e09f:

    # bl "Now, don't start freaking out when I say this. I don't want the whole world to know I'm here."
    bl "Ahora, no empieces a entrar en pánico cuando diga esto. No quiero que todo el mundo sepa que estoy aquí."

# game/game/script.rpy:2600
translate es playername_ff21a1db:

    # bl "But let's just say.... I'm interested."
    bl "Pero digamos que... estoy interesado."

# game/game/script.rpy:2602
translate es playername_a6498c42:

    # "I blink, unable to stop the words from spilling from my mouth."
    "Parpadeo, incapaz de evitar que las palabras salgan de mi boca."

# game/game/script.rpy:2609
translate es playername_64752e1c:

    # mc "Whatever you are trying to do...I'm not interested."
    mc "Sea lo que sea que estés intentando hacer... me interesa."

# game/game/script.rpy:2611
translate es playername_ccb2d227:

    # mc "Luke, I am just trying to {i}work my job{/i}. I have to clock out as of-"
    mc "Luke, solo estoy tratando de {i}hacer mi trabajo{/i}. Tengo que marcar mi salida desde—"

# game/game/script.rpy:2613
translate es playername_45781f0d:

    # "I glance at the clock."
    "Miro el reloj."

# game/game/script.rpy:2615
translate es playername_ab7dd842:

    # mc "10 minutes ago."
    mc "Hace 10 minutos."

# game/game/script.rpy:2617
translate es playername_8fd2bfa1:

    # bl "Okay, so go clock out and we can head out together."
    bl "Bien, entonces ve a marcar y podemos irnos juntos."

# game/game/script.rpy:2619
translate es playername_36454751:

    # mc "Uh, that's not happening."
    mc "Eh, eso no va a pasar."

# game/game/script.rpy:2621
translate es playername_20195d44:

    # bl "Sorry, you don't want to leave with me?"
    bl "¿Perdón, no quieres irte conmigo?"

# game/game/script.rpy:2623
translate es playername_8639e5a3:

    # bl "Oh, don't worry darling, I'll take you to dinner first."
    bl "Oh, no te preocupes cariño, te invitaré a cenar primero."

# game/game/script.rpy:2625
translate es playername_aa4f1cc1:

    # "He eyes me up and down."
    "Me mira de arriba abajo."

# game/game/script.rpy:2627
translate es playername_e26f5f20:

    # bl "You look starving~"
    bl "Te ves con hambre~"

# game/game/script.rpy:2629
translate es playername_08dcbc96:

    # "{i}The fuck...?{/i}"
    "{i}¿Qué carajos...?{/i}"

# game/game/script.rpy:2631
translate es playername_c05e2f2e:

    # mc "Absolutely not."
    mc "Absolutamente no."

# game/game/script.rpy:2638
translate es playername_02c8bb02:

    # "I flash my sweetest smile."
    "Le dedico mi sonrisa más dulce."

# game/game/script.rpy:2640
translate es playername_7d2857ed:

    # mc "Do you mind waiting for a minute?"
    mc "¿Te importa esperar un minuto?"

# game/game/script.rpy:2642
translate es playername_7a43067d:

    # bl "I supposed I could donate a minute of my time to a citizen in need."
    bl "Supongo que podría donar un minuto de mi tiempo a un ciudadano necesitado."

# game/game/script.rpy:2646
translate es playername_f2b13734:

    # "I log out of the register and walk to the back."
    "Cierro sesión en la caja registradora y camino hacia la parte trasera."

# game/game/script.rpy:2648
translate es playername_cc8a7f12:

    # "I then take off my apron in the back of the store and clock out of my shift."
    "Luego me quito el delantal en la parte de atrás de la tienda y marco la salida de mi turno."

# game/game/script.rpy:2652
translate es playername_81bf933f:

    # "I see Luke leaning against the wall when I come out."
    "Veo a Luke recostado contra la pared cuando salgo."

# game/game/script.rpy:2654
translate es playername_65b4d885:

    # bl "Are we going now?"
    bl "¿Nos vamos ahora?"

# game/game/script.rpy:2656
translate es playername_4182f231:

    # mc "{i} 'We?' {/i} Yeah, I don't think so."
    mc "{i}¿'Nosotros'?{/i} Sí, no lo creo."

# game/game/script.rpy:2658
translate es playername_5635bfa0:

    # mc "Do you get off on harassing minimum wage employees or something?"
    mc "¿Te excitas molestando empleados de salario mínimo o algo así?"

# game/game/script.rpy:2662
translate es playername_16792059:

    # mc "Because frankly, it's tiring and old."
    mc "Porque francamente, es agotador y viejo."

# game/game/script.rpy:2664
translate es playername_784f0af9:

    # mc "I don't know what your angle is, but you can kindly fuck off."
    mc "No sé cuál es tu objetivo, pero puedes irte a la mierda amablemente."

# game/game/script.rpy:2666
translate es playername_b50d276b:

    # mc "Nobody gets paid enough to deal with that kind of bullshit."
    mc "Nadie gana lo suficiente como para soportar esa clase de estupideces."

# game/game/script.rpy:2670
translate es playername_a2f68504:

    # "Luke looks visibly irritated."
    "Luke parece visiblemente irritado."

# game/game/script.rpy:2672
translate es playername_5e78d21b:

    # bl "Fine."
    bl "Bien."

# game/game/script.rpy:2674
translate es playername_bdfddb00:

    # bl "You just lost the chance that every civilian wants."
    bl "Acabas de perder la oportunidad que todo ciudadano desea."

# game/game/script.rpy:2676
translate es playername_735085bc:

    # bl "I was going to light your life on fire."
    bl "Iba a incendiar tu vida."

# game/game/script.rpy:2680
translate es playername_69a40751:

    # bl "Have fun with your {i}'golden boy'{/i}."
    bl "Diviértete con tu {i}'niño dorado'{/i}."

# game/game/script.rpy:2682
translate es playername_a8a4cc6c:

    # bl "A Hero from the stars? Yeah, right."
    bl "¿Un héroe de las estrellas? Sí, claro."

# game/game/script.rpy:2684
translate es playername_cbe98a88:

    # bl "Ask Ray how he got his abilities~"
    bl "Pregúntale a Ray cómo obtuvo sus habilidades~"

# game/game/script.rpy:2686
translate es playername_fda6a98c:

    # "Luke grins a smile full of malice."
    "Luke sonríe con malicia."

# game/game/script.rpy:2688
translate es playername_2ac9e04b:

    # bl "Hope you know what you're getting yourself into %(player_name)s."
    bl "Espero que sepas en lo que te estás metiendo %(player_name)s."

# game/game/script.rpy:2690
translate es playername_b72b82cf:

    # "He gives a cold laugh."
    "Suelta una risa fría."

# game/game/script.rpy:2694
translate es playername_90ee7771:

    # bl "That guy is no hero."
    bl "Ese tipo no es ningún héroe."

# game/game/script.rpy:2696
translate es playername_81f243a0:

    # "Luke angrily takes his leave muttering some words under his breath on his way out."
    "Luke se marcha enfadado, murmurando algunas palabras entre dientes mientras se aleja."

# game/game/script.rpy:2700
translate es playername_cbd7292e:

    # "I sigh, exhausted."
    "Suspiro, con cansancio. "

# game/game/script.rpy:2705
translate es playername_038a1580:

    # h "Wow, the fuck was that about...?"
    h "Wow, ¿Qué carajos fue eso...?"

# game/game/script.rpy:2707
translate es playername_b12093eb:

    # "I look over my shoulder at Hals who appeared behind me with croissant in hand."
    "Miro por encima del hombro a Hals, que aparece detrás de mí con un croissant en la mano."

# game/game/script.rpy:2709
translate es playername_7fccf63a:

    # mc "Honestly, I have no idea. He said he was a hero and accused that new regular Ray of some ridiculous stuff."
    mc "Honestamente, no tengo idea. Dijo que era un héroe y acusó a ese nuevo cliente regular, Ray, de cosas ridículas."

# game/game/script.rpy:2722
translate es playername_6a8480aa:

    # h "What kind of stuff?"
    h "¿De qué tipo de cosas?"

# game/game/script.rpy:2724
translate es playername_5aa5b186:

    # mc "Of him being a hero or something."
    mc "De ser un héroe o algo así."

# game/game/script.rpy:2726
translate es playername_bab70bb1:

    # h "Which one?"
    h "¿Cuál?"

# game/game/script.rpy:2728
translate es playername_9dcd8020:

    # mc "Uh, ...the Star one?"
    mc "Eh... ¿el de las estrellas?"

# game/game/script.rpy:2730
translate es playername_b0714b24:

    # h "Binary Star...?"
    h "¿Binary Star...?"

# game/game/script.rpy:2732
translate es playername_cf1adef2:

    # mc "Yeah."
    mc "Sí."

# game/game/script.rpy:2734
translate es playername_90223a0b:

    # "Hal chews on their croissant in thought.."
    "Hal mastica su croissant pensative."

# game/game/script.rpy:2736
translate es playername_66fe1586:

    # h "Hmm....weird..."
    h "Hmm... raro..."

# game/game/script.rpy:2738
translate es playername_64b66f08:

    # h "That guy seemed like a total dick."
    h "Ese tipo parecía un completo idiota."

# game/game/script.rpy:2742
translate es playername_79f17ca9:

    # h "Maybe he was hopped up on some new designer drugs or something."
    h "Tal vez estaba drogado con alguna nueva sustancia de diseño o algo así."

# game/game/script.rpy:2744
translate es playername_1fac4387:

    # mc "Unfortunately I got the vibe that it was just his default personality."
    mc "Desafortunadamente, tuve la sensación de que esa era solo su personalidad por defecto."

# game/game/script.rpy:2746
translate es playername_588fad8b:

    # h "He was really laying it on you though."
    h "Aunque realmente estaba encima de ti."

# game/game/script.rpy:2748
translate es playername_765dd370:

    # h "Good thing Miles wasn't around, he would have flipped out."
    h "Menos mal que Miles no estaba cerca, se habría vuelto loco."

# game/game/script.rpy:2750
translate es playername_ec65cdcd:

    # mc "Probably would have scared 'Blaze' away with his enthusiasm."
    mc "Probablemente habría espantado a 'Blaze' con su entusiasmo."

# game/game/script.rpy:2752
translate es playername_da9a4075:

    # mc "Damn....Miles could have saved the day."
    mc "Maldita sea... Miles pudo haber salvado el día."

# game/game/script.rpy:2754
translate es playername_28a42b69:

    # h "Could you imagine! Miles cornering Blaze to show him hundreds of pictures of his collectibles."
    h "¿Te imaginas? Miles acorralando a Blaze para mostrarle cientos de fotos de sus coleccionables."

# game/game/script.rpy:2758
translate es playername_e1045df3:

    # h "That hero would be so creeped out."
    h "Ese héroe habría estado totalmente asustado."

# game/game/script.rpy:2760
translate es playername_51cb8442:

    # mc "Who knows, he seemed self obsessed enough to probably enjoy it. I'm sure he has his own collection too."
    mc "Quién sabe, parecía lo bastante egocéntrico como para disfrutarlo. Seguro que tiene su propia colección también."

# game/game/script.rpy:2762
translate es playername_5a866bbc:

    # h "I could totally see that!"
    h "¡Totalmente puedo imaginarlo!"

# game/game/script.rpy:2764
translate es playername_106e21ad:

    # mc "I know, we should implement a 'no weirdos' policy."
    mc "Lo sé, deberíamos implementar una política de 'no raros'."

# game/game/script.rpy:2789
translate es playername_d735977e:

    # cg "Haley leans up against the counter next to me. They laugh. It is a refreshing sound, like bells in the summer."
    cg "Haley se apoya en el mostrador junto a mí. Ríe. Es un sonido refrescante, como campanas en verano."

# game/game/script.rpy:2791
translate es playername_d3c9c60c:

    # cg "{color=#1A5F38} 'Yeah, but then Miles wouldn't be able to work.'{/color}"
    cg "{color=#1A5F38} 'Sí, pero entonces Miles no podría trabajar.'{/color}"

# game/game/script.rpy:2793
translate es playername_bbbe6052:

    # cg "{color=#61170f} 'Hey I heard that!' {/color}"
    cg "{color=#61170f} '¡Oye, te escuché!' {/color}"

# game/game/script.rpy:2795
translate es playername_61ab9b51:

    # cg "Haley and I chuckle at the far off sound of Mile's voice."
    cg "Haley y yo reímos al oír la voz lejana de Miles."

# game/game/script.rpy:2805
translate es playername_f9222d02:

    # cg "{color=#1A5F38} 'You are allowed to turn away customers, you know.'{/color}"
    cg "{color=#1A5F38} 'Sabes que puedes rechazar clientes, ¿verdad?'{/color}"

# game/game/script.rpy:2807
translate es playername_cd4e9bbd:

    # cg "{color=#510f80} 'I {i}tried{/i}.' {/color}"
    cg "{color=#510f80} 'Lo {i}intenté{/i}.' {/color}"

# game/game/script.rpy:2809
translate es playername_52299a1e:

    # cg "They give me a reassuring pat on the shoulder."
    cg "Me da una palmada tranquilizadora en el hombro."

# game/game/script.rpy:2811
translate es playername_b356bc45:

    # cg "{color=#1A5F38} 'Just call me next time, I'll kick his ass outta here.'{/color}"
    cg "{color=#1A5F38} 'Solo llámame la próxima vez, yo lo sacaré a patadas de aquí.'{/color}"

# game/game/script.rpy:2813
translate es playername_843dc1ba:

    # cg "I gasp in a fake shock."
    cg "Finjo una exclamación de sorpresa."

# game/game/script.rpy:2815
translate es playername_d194a38a:

    # cg "{color=#510f80} 'To a {i} Hero {/i}? Isn't that like, a crime or something?' {/color}"
    cg "{color=#510f80} '¿A un {i}Héroe{/i}? ¿Eso no es un crimen o algo así?' {/color}"

# game/game/script.rpy:2817
translate es playername_e6455f51:

    # cg "Haley smiles deviously."
    cg "Haley sonríe con picardía."

# game/game/script.rpy:2819
translate es playername_10542a81:

    # cg "{color=#1A5F38} 'Maybe I'll key his car for good measure, they say two crimes are better than one.' {/color}"
    cg "{color=#1A5F38} 'Tal vez le raye el coche por si acaso, dicen que dos crímenes son mejor que uno.' {/color}"

# game/game/script.rpy:2821
translate es playername_ce1d1053:

    # cg "{color=#510f80} 'Wow Hals, loving the determination. If only that was reflected in your management style.'{/color}"
    cg "{color=#510f80} 'Wow Hals, me encanta tu determinación. Si tan solo eso se reflejara en tu estilo de gestión.'{/color}"

# game/game/script.rpy:2829
translate es playername_e58b9957:

    # cg "We laugh a bit between the two of us."
    cg "Nos reímos un poco."

# game/game/script.rpy:2831
translate es playername_9d06dce7:

    # cg "I have only known Hals for around 3 months now, but we have become so close."
    cg "Solo conozco a Hals desde hace unos tres meses, pero nos hemos vuelto muy inseparables. "

# game/game/script.rpy:2833
translate es playername_69df1d94:

    # cg "They always know the right thing to say to cheer me up."
    cg "Siempre sabe qué decir para animarme."

# game/game/script.rpy:2835
translate es playername_1a30a9b1:

    # cg "{color=#510f80} 'Anyways, I should probably head out.' {/color}"
    cg "{color=#510f80} 'De todos modos, probablemente debería irme ya.' {/color}"

# game/game/script.rpy:2848
translate es playername_b721e26b:

    # h "Hey uh, before you go..."
    h "Oye, eh, antes de que te vayas..."

# game/game/script.rpy:2852
translate es playername_aa8adc70:

    # "Haley bites their lip, debating."
    "Haley se muerde el labio, dudando."

# game/game/script.rpy:2856
translate es playername_0b58fc92:

    # "After a couple of seconds pass, they speak up."
    "Después de unos segundos, habla."

# game/game/script.rpy:2858
translate es playername_7e8eb87f:

    # h "Um, that guy...you said his name was Ray...?"
    h "¿Um, ese tipo... dijiste que se llamaba Ray...?"

# game/game/script.rpy:2860
translate es playername_3dbc75bd:

    # mc "Yeah, I actually ran into him the other day and he helped me carry my groceries home."
    mc "Sí, de hecho me lo encontré el otro día y me ayudó a llevar mis compras a casa."

# game/game/script.rpy:2862
translate es playername_1699602b:

    # h "Well, uh-"
    h "Bueno, eh..."

# game/game/script.rpy:2866
translate es playername_20c9134e:

    # h "Look, I kinda of get a bad feeling from the guy..."
    h "Mira, tengo una mala sensación con ese tipo..."

# game/game/script.rpy:2873
translate es playername_bc2f23a7:

    # mc "What about him?"
    mc "¿Qué pasa con él?"

# game/game/script.rpy:2877
translate es playername_debd5cce:

    # "Hal rubs their neck looking away."
    "Hal se frota el cuello, mirando a otro lado."

# game/game/script.rpy:2879
translate es playername_c6d9a7ee:

    # h "Ah, I.. It's....uh, I guess a feeling-"
    h "Ah, yo... es... eh, supongo que es una sensación—"

# game/game/script.rpy:2883
translate es playername_e7ca684f:

    # h "Like kinda a bad one..."
    h "Como una mala..."

# game/game/script.rpy:2885
translate es playername_792859a2:

    # h "Something doesn't feel genuine with him."
    h "Algo no se siente genuino en él."

# game/game/script.rpy:2891
translate es playername_c845a3b7:

    # mc "Really..?"
    mc "¿En serio...?"

# game/game/script.rpy:2893
translate es playername_ee00279f:

    # mc "I don't really see it...."
    mc "No lo noto mucho..."

# game/game/script.rpy:2895
translate es playername_93a3319c:

    # mc "But things are harder to see with rose tinted glasses I guess."
    mc "Pero supongo que las cosas son más difíciles de ver con lentes color rosa."

# game/game/script.rpy:2899
translate es playername_a81a0c01:

    # "Haley gives an awkward laugh."
    "Haley suelta una risa incómoda."

# game/game/script.rpy:2901
translate es playername_6af3582b:

    # h "Yeah that's probably true."
    h "Sí, probablemente tengas razón."

# game/game/script.rpy:2903
translate es playername_2af75412:

    # mc "Hmm okay, well thanks for letting me know."
    mc "Hmm, está bien, gracias por avisarme."

# game/game/script.rpy:2905
translate es playername_60f45c75:

    # h "Maybe just keep an eye out for anything that's ...off."
    h "Tal vez solo mantente atento a cualquier cosa que parezca... rara."

# game/game/script.rpy:2909
translate es playername_7a4508c3:

    # mc "I haven't seen anything weird yet-"
    mc "Aún no he visto nada extraño–"

# game/game/script.rpy:2929
translate es playername_7a2795f9:

    # r "What's weird?"
    r "¿Qué es raro?"

# game/game/script.rpy:2930
translate es playername_3daff334:

    # "{i}!!!{/i}"
    "{i}¡¡¡!!!{/i}"

# game/game/script.rpy:2934
translate es playername_7bf3b8e4:

    # "I feel like I almost had a heart attack."
    "Siento que casi me da un infarto."

# game/game/script.rpy:2936
translate es playername_d32cf9e2:

    # "Ray somehow walked up without me even noticing."
    "Ray de alguna manera se acercó sin que yo siquiera lo notara."

# game/game/script.rpy:2938
translate es playername_9940d58d:

    # mc "Ah! Nothing weird! We just had some uh,...."
    mc "¡Ah! ¡Nada raro! Solo que, eh..."

# game/game/script.rpy:2940
translate es playername_7a63fe5a:

    # mc "Coffee lids go missing recently!"
    mc "¡Últimamente se han estado perdiendo tapas de café!"

# game/game/script.rpy:2942
translate es playername_135280c4:

    # r "Hmm, is that right...?"
    r "Hmm, ¿es así...?"

# game/game/script.rpy:2944
translate es playername_9e79300e:

    # "Ray stares directly at Haley who levels a glare right back at him."
    "Ray mira directamente a Haley, quien le devuelve una mirada desafiante."

# game/game/script.rpy:2946
translate es playername_96dc3e37:

    # "He shoots me a quick smile."
    "Él me lanza una sonrisa rápida."

# game/game/script.rpy:2950
translate es playername_261ed110:

    # r "Sorry I don't think I've met your...friend yet."
    r "Perdón, no creo que haya conocido a...esa persona aún."

# game/game/script.rpy:2952
translate es playername_8094bc3a:

    # mc "Oh, this is Haley."
    mc "Oh, este es Haley."

# game/game/script.rpy:2954
translate es playername_640bdd00:

    # r "Oh, {i}coworker{/i}?"
    r "Oh, ¿{i}compañere de trabajo{/i}?"

# game/game/script.rpy:2960
translate es playername_e5a6623f:

    # h "{i}Friend{/i}."
    h "{i}Amigue{/i}."

# game/game/script.rpy:2962
translate es playername_ae018537:

    # "Haley cuts in quickly."
    "Haley interrumpe rápidamente."

# game/game/script.rpy:2966
translate es playername_b4bb5a76:

    # r "Sorry for interrupting the conversation."
    r "Perdón por interrumpir la conversación."

# game/game/script.rpy:2968
translate es playername_62a870ff:

    # r "I'm just looking to get the usual before heading to work."
    r "Solo busco pedir lo de siempre antes de ir a trabajar."

# game/game/script.rpy:2970
translate es playername_83d2f2ac:

    # mc "It's almost 5pm and you're just starting work for the day?"
    mc "¿Ya casi son las 5 p.m. y apenas vas a empezar a trabajar?"

# game/game/script.rpy:2976
translate es playername_2a293bba:

    # h "Yeah that's strange, what {i} DO {/i} you do for work?"
    h "Sí, eso es raro, ¿en qué {i}trabajas{/i}?"

# game/game/script.rpy:2982
translate es playername_c93886d8:

    # r "Law enforcement."
    r "Fuerzas del orden."

# game/game/script.rpy:2984
translate es playername_c269f90c:

    # "Ray responds without missing a beat."
    "Ray responde sin titubear."

# game/game/script.rpy:2986
translate es playername_5f9b772e:

    # "...."
    "...."

# game/game/script.rpy:2988
translate es playername_1db83fc9:

    # "A tense silence falls between the 3 of us."
    "Cae un silencio tenso entre los tres."

# game/game/script.rpy:2990
translate es playername_f610bc71:

    # "I don't quite understand what is going on but I feel uncomfortable..."
    "No entiendo del todo lo que está pasando, pero me incómoda..."

# game/game/script.rpy:2992
translate es playername_56dd42ec:

    # r "Haley, what do {i} YOU {/i} do for work?"
    r "Haley, ¿en qué {i}trabajas{/i} tú?"

# game/game/script.rpy:2998
translate es playername_b16eb413:

    # h "What do you mean? I'm obviously at work right now."
    h "¿Qué quieres decir? Obviamente estoy trabajando ahora mismo."

# game/game/script.rpy:3004
translate es playername_c798ceed:

    # r "This is your only job?"
    r "¿Este es tu único trabajo?"

# game/game/script.rpy:3012
translate es playername_633012c7:

    # h "Last time I checked, yeah."
    h "La última vez que revisé, sí."

# game/game/script.rpy:3018
translate es playername_a645de81:

    # r "Hmm sorry. You just look {i}so {/i} familiar...."
    r "Hmm, perdón. Es que te ves {i}tan{/i} familiar..."

# game/game/script.rpy:3022
translate es playername_cf21d4b7:

    # r "I just can't put my finger on it."
    r "No logro identificar por qué."

# game/game/script.rpy:3024
translate es playername_9846ea20:

    # "Haley looks genuinely annoyed. I could see them bite their cheek....probably to keep themselves from saying anything too unprofessional."
    "Haley parece genuinamente moleste. Puedo ver cómo se muerde la mejilla... probablemente para evitar decir algo poco profesional."

# game/game/script.rpy:3030
translate es playername_a66b79d9:

    # h "You must be thinking of someone else."
    h "Debes estar confundiendo con otra persona."

# game/game/script.rpy:3032
translate es playername_7613d6a1:

    # "Haley strains out."
    "Dice Haley con esfuerzo."

# game/game/script.rpy:3040
translate es playername_26875833:

    # "Ray smiles, but there was no friendliness to it."
    "Ray sonríe, pero no había nada de amabilidad en su gesto."

# game/game/script.rpy:3042
translate es playername_838680dc:

    # r "Hm, maybe you're right."
    r "Hm, tal vez tienes razón."

# game/game/script.rpy:3048
translate es playername_cc5ec49c:

    # "Haley smiles back with an equal amount of spite."
    "Haley le devuelve la sonrisa con la misma dosis de desdén."

# game/game/script.rpy:3050
translate es playername_05e4dfb3:

    # h "You know, we had a celebrity visit. You {i} just {/i} missed it."
    h "¿Sabes?, tuvimos la visita de una celebridad. La {i}acabaste{/i} de perder."

# game/game/script.rpy:3052
translate es playername_5663cc4a:

    # h "He was a hero too. This place is quite popular lately~"
    h "También era un héroe. Este lugar se ha vuelto bastante popular últimamente~"

# game/game/script.rpy:3054
translate es playername_ffe5dfd8:

    # "Ray's face falls into a frown."
    "El rostro de Ray se ensombrece en una mueca."

# game/game/script.rpy:3059
translate es playername_17a5432d:

    # "Haley looks at me for a second."
    "Haley me mira por un segundo."

# game/game/script.rpy:3063
translate es playername_efd130d8:

    # h "I can't imagine why."
    h "No imagino por qué."

# game/game/script.rpy:3065
translate es playername_d81f31e0:

    # h "It's not like we have some kind of {i} hero discount {/i} or something."
    h "No es que tengamos algún tipo de {i}descuento para héroes{/i} o algo así."

# game/game/script.rpy:3071
translate es playername_6f8c7c8b:

    # "Ray's lips pull tight and he narrows his eyes."
    "Los labios de Ray se tensan y entrecierra los ojos."

# game/game/script.rpy:3073
translate es playername_9850ed5f:

    # r "...Is that right...?"
    r "...¿Es así...?"

# game/game/script.rpy:3077
translate es playername_cd8ff936:

    # "Haley picks at their nails seeming uninterested."
    "Haley se limpia las uñas con indiferencia."

# game/game/script.rpy:3081
translate es playername_e6df8ae1:

    # h "Yeah, what was his name again...Flame? Blade?"
    h "Sí, ¿cómo era su nombre...? ¿Flame? ¿Blade?"

# game/game/script.rpy:3087
translate es playername_096cd6f0:

    # r "{size=-10}Blaze....{/size}"
    r "{size=-10}Blaze...{/size}"

# game/game/script.rpy:3089
translate es playername_a826d430:

    # "Ray mumbles under his breath."
    "Murmura Ray por lo bajo."

# game/game/script.rpy:3095
translate es playername_218e690e:

    # h "Right, that was it!"
    h "¡Cierto, ese era!"

# game/game/script.rpy:3099
translate es playername_d9074683:

    # "He sudden looks at me and gives a smile."
    "De pronto me mira y sonríe."

# game/game/script.rpy:3103
translate es playername_75827ba8:

    # r "Looks like I overstayed my welcome."
    r "Parece que ya me quedé más de la cuenta."

# game/game/script.rpy:3105
translate es playername_3dfe5b6f:

    # r "I should probably head to work before my new phone blows up."
    r "Probablemente debería irme a trabajar antes de que mi nuevo teléfono explote."

# game/game/script.rpy:3107
translate es playername_83d305ca:

    # "Ray glances at Haley."
    "Ray lanza una mirada a Haley."

# game/game/script.rpy:3111
translate es playername_affc52c4:

    # r "Thanks."
    r "Gracias."

# game/game/script.rpy:3117
translate es playername_cf86fed6:

    # "Ray already begins to leave."
    "Ray ya empieza a marcharse."

# game/game/script.rpy:3119
translate es playername_fee9efbe:

    # "{i}I should grab him some coffee before he goes!{/i}"
    "{i}¡Debería prepararle un café antes de que se vaya!{/i}"

# game/game/script.rpy:3121
translate es playername_30e51061:

    # mc "Oh, Ray!"
    mc "¡Oh, Ray!"

# game/game/script.rpy:3123
translate es playername_12b47978:

    # "I jog past Haley in a rush and grab onto his sleeve."
    "Paso corriendo junto a Haley y agarro la manga de su abrigo."

# game/game/script.rpy:3145
translate es playername_6dea591c:

    # "He turns to me looking a bit surprised."
    "Él se gira sorprendido."

# game/game/script.rpy:3149
translate es playername_148c5f98:

    # r "...Uh yeah?"
    r "...¿Eh, sí?"

# game/game/script.rpy:3151
translate es playername_d7fc9c48:

    # "I smile at him."
    "Le sonrío."

# game/game/script.rpy:3153
translate es playername_72762468:

    # mc "Wait for one more second."
    mc "Espera un segundo más."

# game/game/script.rpy:3155
translate es playername_6e296feb:

    # "I jog off to the coffee grabbing him a fresh cup of black coffee."
    "Corro a la barra y tomo una taza de café negro recién hecho para él."

# game/game/script.rpy:3158
translate es playername_f7c3a230:

    # mc "I hope work goes by quickly for you."
    mc "Espero que el trabajo se te pase rápido."

# game/game/script.rpy:3162
translate es playername_b3733cf5:

    # "I hand him the cup."
    "Le entrego la taza."

# game/game/script.rpy:3166
translate es playername_7a59714d:

    # "Ray smiles softly."
    "Ray sonríe suavemente."

# game/game/script.rpy:3168
translate es playername_425f506a:

    # r "Thanks Star..."
    r "Gracias, Estrella..."

# game/game/script.rpy:3181
translate es playername_91ddd707:

    # "He reaches his hand out as if he wanted to touch my head but then he pauses and pulls back."
    "Extiende la mano como si quisiera tocarme la cabeza, pero luego se detiene y la retira."

# game/game/script.rpy:3183
translate es playername_3f06003e:

    # r "I'll catch ya around."
    r "Nos veremos luego."

# game/game/script.rpy:3185
translate es playername_b936767b:

    # mc "Come back soon."
    mc "Vuelve pronto."

# game/game/script.rpy:3187
translate es playername_d705fb5b:

    # r "Of course."
    r "Por supuesto."

# game/game/script.rpy:3189
translate es playername_e02146dc:

    # "He gives a little wink before turning and heading out."
    "Me lanza un guiño antes de girarse y salir."

# game/game/script.rpy:3194
translate es playername_b9b991e1:

    # mc "Have a good day at work Ray."
    mc "Que tengas un buen día en el trabajo, Ray."

# game/game/script.rpy:3196
translate es playername_664a3b98:

    # "Ray gives a small smile."
    "Ray muestra una pequeña sonrisa."

# game/game/script.rpy:3200
translate es playername_eb980aa2:

    # "He looks so tired, to just be starting work for the day must be rough."
    "Se ve tan cansado... empezar a trabajar a esta hora debe ser duro."

# game/game/script.rpy:3202
translate es playername_e3f044a2:

    # r "I can't guarantee that I will."
    r "No puedo garantizarlo."

# game/game/script.rpy:3204
translate es playername_da6ec24f:

    # r "But I'll try my best."
    r "Pero haré lo mejor que pueda."

# game/game/script.rpy:3206
translate es playername_fafe4ad6:

    # "Sometimes when he smiled, the dark circles under his eyes seemed to only get worse."
    "A veces, cuando sonreía, las ojeras bajo sus ojos parecían volverse aún más marcadas."

# game/game/script.rpy:3208
translate es playername_0635afe8:

    # "I wave goodbye to Ray as he walks out the door."
    "Le hago un gesto de despedida a Ray mientras sale por la puerta."

# game/game/script.rpy:3212
translate es playername_aae5bc2e:

    # "Haley gives me a long look from beside the coffee bar counter."
    "Haley me lanza una larga mirada desde el otro lado del mostrador."

# game/game/script.rpy:3218
translate es playername_56e8300e:

    # mc "Is there something wrong?"
    mc "¿Pasa algo?"

# game/game/script.rpy:3220
translate es playername_66fb7b1f:

    # "Haley opens their mouth about to say something but settles on a shake of the head."
    "Haley abre la boca como para decir algo, pero termina negando con la cabeza."

# game/game/script.rpy:3222
translate es playername_21391e0d:

    # h "Nah..."
    h "Nah..."

# game/game/script.rpy:3226
translate es playername_668f2888:

    # "Haley sensing my skepticism, gives a reassuring smile."
    "Al notar mi escepticismo, Haley me dedica una sonrisa tranquilizadora."

# game/game/script.rpy:3228
translate es playername_4a36ac44:

    # h "Oh did I tell you! Remember that action figure that Miles was trying to get?"
    h "¡Oh, te conté! ¿Recuerdas esa figura de acción que Miles estaba tratando de conseguir?"

# game/game/script.rpy:3230
translate es playername_c3b402b8:

    # mc "The eight-thousand dollar one?"
    mc "¿La de ocho mil dólares?"

# game/game/script.rpy:3232
translate es playername_c8b80021:

    # h "Yeah so, apparently he went and cried for money from each of his friends but still was $20 short."
    h "Sí, pues aparentemente fue a llorarle dinero a todos sus amigos y aun así le faltaban 20 dólares."

# game/game/script.rpy:3234
translate es playername_cd7d04f9:

    # h "Long story short...guess who shares the same shoe size as Miles~"
    h "En resumen... adivina quién tiene la misma talla de zapato que Miles~"

# game/game/script.rpy:3236
translate es playername_c0a83a15:

    # "Haley gives a triumphant look, placing one of their long legs forward."
    "Haley pone una expresión triunfante, adelantando una de sus largas piernas."

# game/game/script.rpy:3238
translate es playername_8cea4a36:

    # "Sitting on their feet were a used-like-new pair of Layon sneakers."
    "En sus pies lleva un par de zapatillas Layon, usadas pero como nuevas."

# game/game/script.rpy:3240
translate es playername_9fdf20bb:

    # h "Worth {i}every penny{/i}."
    h "Valieron {i}cada centavo{/i}."

# game/game/script.rpy:3242
translate es playername_0ad8880e:

    # h "Can you believe Miles and I are the exact same shoe size?!"
    h "¿Puedes creer que Miles y yo tenemos exactamente la misma talla?"

# game/game/script.rpy:3244
translate es playername_c25f67e2:

    # mc "Didn't Miles come in wearing those shoes today?"
    mc "¿No entró Miles hoy usando esos zapatos?"

# game/game/script.rpy:3246
translate es playername_2805928b:

    # mc "Where are your shoes?"
    mc "¿Dónde están los tuyos?"

# game/game/script.rpy:3248
translate es playername_2fded262:

    # h "..."
    h "..."

# game/game/script.rpy:3250
translate es playername_1d8c4606:

    # mc "Is Miles...?"
    mc "¿Miles...?"

# game/game/script.rpy:3252
translate es playername_d715e015:

    # h "Miles can rock a black heeled boot. I think it's giving him more confidence."
    h "Miles puede lucir unas botas negras con tacón. Creo que le dan más confianza."

# game/game/script.rpy:3256
translate es playername_1d3db3cc:

    # "A loud crash can be heard from the storage room."
    "Se escucha un fuerte estruendo proveniente del almacén."

# game/game/script.rpy:3260
translate es playername_6eba8db8:

    # h "....He's still getting the hang of it though."
    h "...Aunque todavía está acostumbrándose a eso."

# game/game/script.rpy:3264
translate es playername_ca6d7f67:

    # "After chatting with Haley for a bit longer I finally take my leave and head home."
    "Después de charlar un poco más con Haley, finalmente me despido y regreso a casa."

# game/game/script.rpy:3276
translate es playername_7c407038:

    # "The next day I get to work at 9am for a later shift."
    "Al día siguiente llego al trabajo a las 9 a.m. para el turno más tarde."

# game/game/script.rpy:3278
translate es playername_fc774193:

    # "After clocking in I start restocking some pastries."
    "Después de registrar mi entrada, empiezo a reabastecer algunos pasteles."

# game/game/script.rpy:3287
translate es playername_1b712e57:

    # m "No dude, I'm {i} telling you {/i} Blaze is going rogue or something!"
    m "No, amigo, te {i}digo{/i} que Blaze se está volviendo rebelde o algo así."

# game/game/script.rpy:3289
translate es playername_30d024b1:

    # m "Why else would Binary do that?!"
    m "¿Si no, por qué más Binary haría eso?"

# game/game/script.rpy:3291
translate es playername_077d0651:

    # m "Blaze totally is going full anti-hero!"
    m "¡Blaze definitivamente se está volviendo un anti-héroe total!"

# game/game/script.rpy:3293
translate es playername_3ed0bbfb:

    # "Haley groans as they approach with Miles in tow as he chats their ear off."
    "Haley gime mientras se acerca con Miles a cuestas, que no deja de hablarle al oído."

# game/game/script.rpy:3311
translate es playername_6eed2468:

    # h "Miles for the last time {i} anti-heros don't exist{/i}."
    h "Miles, por última vez, {i}los anti-héroes no existen{/i}."

# game/game/script.rpy:3317
translate es playername_f1ae7d25:

    # m "They could though!"
    m "¡Pero podrían existir!"

# game/game/script.rpy:3323
translate es playername_bb16cdac:

    # h "No they can't, it is illegal to be doing any hero activities without proper government approval."
    h "No, no pueden, es ilegal realizar actividades heroicas sin la aprobación gubernamental adecuada."

# game/game/script.rpy:3325
translate es playername_09fe1a48:

    # h "And that is especially so for some rogue 'anti-hero' type of activities."
    h "Y eso aplica especialmente para actividades 'anti-héroe' de algún rebelde."

# game/game/script.rpy:3329
translate es playername_e235ec23:

    # "Miles turns to me next."
    "Miles se gira hacia mí."

# game/game/script.rpy:3335
translate es playername_0a534c1a:

    # m "Okay %(player_name)s! so listen to this-!"
    m "¡Bien, %(player_name)s! ¡Escucha esto!"

# game/game/script.rpy:3341
translate es playername_5b80d8c5:

    # h "%(player_name)s doesn't want to listen Miles."
    h "%(player_name)s no quiere escucharte, Miles."

# game/game/script.rpy:3343
translate es playername_8c26cb31:

    # mc "What's going on?"
    mc "¿Qué pasa?"

# game/game/script.rpy:3350
translate es playername_775c0459:

    # m "Looks like %(player_name)s {i} does {/i} want to listen~"
    m "Parece que %(player_name)s {i}sí{/i} quiere escuchar~"

# game/game/script.rpy:3352
translate es playername_c16d9554:

    # "Miles smirks smugly at Haley who just rolls their eyes at him."
    "Miles sonríe con autosuficiencia mientras Haley solo pone los ojos en blanco."

# game/game/script.rpy:3357
translate es playername_ba10641d:

    # h "You didn't see the news...? Or like, go on {i} any {/i} social media yesterday or today?"
    h "¿No viste las noticias...? ¿O no entraste a {i}ninguna{/i} red social ayer o hoy?"

# game/game/script.rpy:3359
translate es playername_9046db5b:

    # mc "Uh, not really."
    mc "Eh, no mucho."

# game/game/script.rpy:3360
translate es playername_50c6f943:

    # mc "I accidentally slept in and was in a rush this morning. I practically ran here."
    mc "Me dormí por accidente y esta mañana iba con prisa. Prácticamente corrí hasta aquí."

# game/game/script.rpy:3365
translate es playername_a45f7b05:

    # m "Dude, you {i} got {/i} to check this out!"
    m "¡Tienes que ver esto!"

# game/game/script.rpy:3367
translate es playername_950d203d:

    # "Miles is already tapping on his phone."
    "Miles ya está tecleando en su teléfono."

# game/game/script.rpy:3369
translate es playername_0beb1f9f:

    # "He suddenly turns the screen towards me and I look closely."
    "De repente gira la pantalla hacia mí y miro de cerca."

# game/game/script.rpy:3371
translate es playername_867cdd4e:

    # "At first it's kind of hard to understand what is going on..."
    "Al principio es un poco difícil entender qué está pasando..."

# game/game/script.rpy:3373
translate es playername_803a070d:

    # "But on closer inspection it seems as if a hero is.... throwing another hero off of a building?"
    "Pero al observar mejor, parece que un héroe está... ¿lanzando a otro héroe desde un edificio?"

# game/game/script.rpy:3375
translate es playername_93dce540:

    # mc "Is it a joke..? I don't really get it."
    mc "¿Es una broma...? No lo entiendo muy bien."

# game/game/script.rpy:3377
translate es playername_824f0795:

    # "Miles fast forwards the video a bit."
    "Miles adelanta un poco el video."

# game/game/script.rpy:3379
translate es playername_7e9e18e3:

    # m "Okay look there is a close up here."
    m "Bien, mira, aquí hay un acercamiento."

# game/game/script.rpy:3383
translate es playername_799aaef4:

    # "The video shows two heroes talking and suddenly one tries to kick the other."
    "El video muestra a dos héroes hablando y de repente uno intenta patear al otro."

# game/game/script.rpy:3385
translate es playername_c3acf06a:

    # "The hero who was on the receiving end of the kick grabs the other hero by the ankle and holds them over the ledge of the tall building."
    "El héroe que recibe la patada agarra al otro por el tobillo y lo sostiene sobre el borde del edificio alto."

# game/game/script.rpy:3387
translate es playername_01b0cad0:

    # "The hero lets go, but the other hero stays suspended in the air. They continue to converse."
    "El héroe lo suelta, pero el otro permanece suspendido en el aire. Siguen conversando."

# game/game/script.rpy:3389
translate es playername_36d6afc4:

    # mc "How are they floating like that...?"
    mc "¿Cómo están flotando así...?"

# game/game/script.rpy:3391
translate es playername_ffa50e8c:

    # m "Uh, one of Binary's abilities is telekinesis. You didn't know that..?"
    m "Eh, una de las habilidades de Binary es la telequinesis. ¿No lo sabías?"

# game/game/script.rpy:3393
translate es playername_e101064d:

    # "Miles scoffs as if it's the most obvious thing in the world."
    "Miles resopla como si fuera lo más obvio del mundo."

# game/game/script.rpy:3395
translate es playername_e0ce9e5b:

    # "After a minute or so, the heroes seem finished talking. 'Binary Star' turns and starts to walk away..."
    "Después de un minuto o algo así, los héroes parecen terminar de hablar. 'Binary Star' se da vuelta y empieza a alejarse..."

# game/game/script.rpy:3397
translate es playername_dcb48e42:

    # "And the other Hero plummets towards the ground."
    "Y el otro héroe cae al vacío."

# game/game/script.rpy:3400
translate es playername_cb1ade31:

    # "Miles shuts off the video."
    "Miles apaga el video."

# game/game/script.rpy:3403
translate es playername_59c180e5:

    # mc "Oh my god."
    mc "Oh, Dios mío."

# game/game/script.rpy:3408
translate es playername_fffb1060:

    # h "Don't worry too much, that guy is fine..."
    h "No te preocupes tanto, ese tipo está bien..."

# game/game/script.rpy:3413
translate es playername_f7e708d9:

    # m "Yeah and get this-!"
    m "¡Sí, y escucha esto!"

# game/game/script.rpy:3415
translate es playername_bd0a0715:

    # m "Before Binary grabbed his leg, Blaze said...{i}'What are you going to do? Stop me?'{/i}"
    m "Antes de que Binary le agarrara la pierna, Blaze dijo... {i}'¿Qué vas a hacer? ¿Detenerme?'{/i}"

# game/game/script.rpy:3417
translate es playername_4b7a8aa5:

    # m "And then Binary grabbed him and just dropped him off the side of the fuckin' building!"
    m "¡Y entonces Binary lo tomó y simplemente lo dejó caer por el costado del maldito edificio!"

# game/game/script.rpy:3420
translate es playername_075971be:

    # m "{i}Sooo badass!{/i}"
    m "{i}¡Tan rudo!{/i}"

# game/game/script.rpy:3424
translate es playername_bddbe0fa:

    # mc "That was the only audio that was caught..?"
    mc "¿Ese fue el único audio que se captó...?"

# game/game/script.rpy:3426
translate es playername_03c5865e:

    # m "Yup! So netizens are going crazy trying to figure out what it was {i} all about {/i}."
    m "¡Sí! Así que los internautas están enloqueciendo tratando de descubrir de qué {i}se trató{/i}."

# game/game/script.rpy:3428
translate es playername_859a128c:

    # m "Binary Star is squeaky clean. He has never done anything like this!"
    m "Binary Star tiene una reputación impecable. ¡Nunca ha hecho algo así!"

# game/game/script.rpy:3430
translate es playername_c64437e5:

    # m "So it {i} has {/i} to be something about Blaze going rogue!"
    m "¡Así que {i}tiene{/i} que ser por culpa de Blaze yéndose por el mal camino!"

# game/game/script.rpy:3432
translate es playername_eee78279:

    # m "Why else would Binary Star do that to Blaze, a hero that was previously his sidekick for three years?!"
    m "¿Por qué más Binary Star haría eso a Blaze, un héroe que antes fue su compañero durante tres años?"

# game/game/script.rpy:3438
translate es playername_d8131b50:

    # h "I doubt that 'going rogue' thing...."
    h "Dudo eso de que se 'rebeló'..."

# game/game/script.rpy:3440
translate es playername_440641fb:

    # h "I think the more 'squeaky clean' a hero seems, the more skeletons they are probably hiding in their closet..."
    h "Creo que mientras más 'perfecto' parece un héroe, más esqueletos debe tener escondidos en su armario..."

# game/game/script.rpy:3445
translate es playername_752b66f4:

    # m "Don't be so envious Hal, it looks bad on you."
    m "No seas tan envidiose, Hal, no te queda bien."

# game/game/script.rpy:3450
translate es playername_ed63e3be:

    # h "Miles..."
    h "Miles..."

# game/game/script.rpy:3452
translate es playername_7a65ef64:

    # "Miles just laughs despite Hal's potent glare."
    "Miles simplemente se ríe a pesar de la intensa mirada de Hal."

# game/game/script.rpy:3457
translate es playername_f98fb576:

    # m "What do you think %(player_name)s?"
    m "¿Qué piensas, %(player_name)s?"

# game/game/script.rpy:3466
translate es playername_7b30e33e:

    # mc "Yeah, I mean, every human has {i}some{/i} skeletons in their closet, so I can't be surprised if Binary is any different."
    mc "Sí, digo, todo ser humano tiene {i}algunos{/i} esqueletos en su armario, así que no me sorprendería que Binary no fuera diferente."

# game/game/script.rpy:3471
translate es playername_481e735a:

    # h "Yeah... I just wonder how many skeletons ya know?"
    h "Sí... Solo me pregunto cuántos esqueletos tendrá, ya sabes."

# game/game/script.rpy:3473
translate es playername_9b8eb4ce:

    # "Haley bites their lip in thought."
    "Haley se muerde el labio, pensative."

# game/game/script.rpy:3475
translate es playername_0c0630b9:

    # h "I just don't think heros can be moral..."
    h "Simplemente no creo que los héroes puedan ser morales..."

# game/game/script.rpy:3477
translate es playername_1b20724f:

    # h "And that is pretty dangerous when you have the powers that heros do."
    h "Y eso es bastante peligroso cuando tienes los poderes que ellos tienen."

# game/game/script.rpy:3482
translate es playername_f916d86e:

    # m "You think too much Hals! Heros are just like you and me."
    m "¡Piensas demasiado, Hals! Los héroes son como tú y como yo."

# game/game/script.rpy:3486
translate es playername_97590061:

    # "Haley levels a glance at miles"
    "Haley le lanza una mirada a Miles."

# game/game/script.rpy:3490
translate es playername_729db56e:

    # h "I really doubt that..."
    h "Realmente lo dudo..."

# game/game/script.rpy:3495
translate es playername_db6a29da:

    # m "What'd you say?"
    m "¿Qué dijiste?"

# game/game/script.rpy:3500
translate es playername_be87bca8:

    # h "Nothing Miles."
    h "Nada, Miles."

# game/game/script.rpy:3502
translate es playername_9d95bb2a:

    # mc "When you put it like that...it's hard not to feel a little weary."
    mc "Cuando lo pones así... es difícil no sentirse un poco inquieto."

# game/game/script.rpy:3504
translate es playername_58721f77:

    # mc "I just hope there aren't too many skeletons."
    mc "Solo espero que no haya demasiados esqueletos."

# game/game/script.rpy:3510
translate es playername_56e8899e:

    # mc "To be honest, I just can't be bothered to care that much..."
    mc "Para ser sincero, simplemente no me interesa tanto..."

# game/game/script.rpy:3512
translate es playername_a14b114f:

    # mc "Heroes can do whatever they want. It's not like any of us can influence that, skeletons or not."
    mc "Los héroes pueden hacer lo que quieran. No es como si alguno de nosotros pudiera influir en eso, tengan secretos o no."

# game/game/script.rpy:3514
translate es playername_8c9516b7:

    # mc "If Blaze does go rogue anti-hero or whatever, the government will definitely crack down on it."
    mc "Si Blaze se vuelve un anti-héroe o lo que sea, el gobierno definitivamente tomará cartas en el asunto."

# game/game/script.rpy:3516
translate es playername_475fe20a:

    # mc "So I guess this doesn't really pertain to me in anyway, I'm just one civilian. So I don't care much."
    mc "Así que supongo que esto no tiene mucho que ver conmigo; solo soy un civil, así que no me importa demasiado."

# game/game/script.rpy:3521
translate es playername_7a226bdb:

    # h "You're wrong %(player_name)s, it {i} does {/i} pertain to you."
    h "Te equivocas, %(player_name)s, sí {i}tiene{/i} que ver contigo."

# game/game/script.rpy:3523
translate es playername_69f9d1ba:

    # h "You might not think that heroes affect you, but that's wrong. They affect all of us whether we like it, or not."
    h "Puede que pienses que los héroes no te afectan, pero eso es falso. Nos afectan a todos, nos guste o no."

# game/game/script.rpy:3525
translate es playername_eead18eb:

    # "I open my mouth to retort but I can't find a proper response."
    "Abro la boca para responder, pero no encuentro las palabras adecuadas."

# game/game/script.rpy:3527
translate es playername_33f97d01:

    # "Haley had a point. No matter where you look, posters of heroes are around, watching."
    "Haley tenía razón. No importa a dónde mires, hay carteles de héroes por todas partes, observando."

# game/game/script.rpy:3529
translate es playername_09727873:

    # "People strive and work within this binary of 'good' and 'evil' that has been permeated by the concept of heroes and villains."
    "La gente vive y trabaja dentro de este binario de 'bien' y 'mal' que ha sido moldeado por el concepto de héroes y villanos."

# game/game/script.rpy:3531
translate es playername_91b43cfd:

    # "Heroes are so engrained in our society at this point, I don't think any of us can even imagine a word without them, even if we want to."
    "Los héroes están tan arraigados en nuestra sociedad que ya no creo que nadie pueda imaginar un mundo sin ellos, incluso si quisiera."

# game/game/script.rpy:3533
translate es playername_3b0f6146:

    # mc "I don't see how the whole heroes thing affects me personally...but I can understand what you mean."
    mc "No veo cómo todo esto de los héroes me afecta personalmente... pero entiendo lo que quieres decir."

# game/game/script.rpy:3535
translate es playername_51926e58:

    # mc "I guess... I mean to say that, I just wish it {i} didn't {/i} pertain to me."
    mc "Supongo... quiero decir que ojalá no {i}tuviera{/i} que ver conmigo."

# game/game/script.rpy:3537
translate es playername_b929c5d2_1:

    # h "Yeah same."
    h "Sí, igual."

# game/game/script.rpy:3541
translate es playername_c42ed956:

    # h "You just gotta watchout for yourself first and foremost."
    h "Solo tienes que cuidarte a ti primero, ante todo."

# game/game/script.rpy:3543
translate es playername_3ddf812b:

    # "I chuckle."
    "Me río."

# game/game/script.rpy:3545
translate es playername_ee0a7e5c:

    # mc "I know Hal, I think better than anyone."
    mc "Lo sé, Hal, creo que mejor que nadie."

# game/game/script.rpy:3547
translate es playername_574f4c36:

    # "Haley quirks an eyebrow."
    "Haley arquea una ceja."

# game/game/script.rpy:3549
translate es playername_bb31a93c:

    # "Before they can talk, I cut them off."
    "Antes de que pueda hablar, le interrumpo."

# game/game/script.rpy:3551
translate es playername_0b15d407:

    # mc "Don't worry about it."
    mc "No te preocupes por eso."

# game/game/script.rpy:3553
translate es playername_fd48560c:

    # "I laugh awkwardly changing the subject."
    "Me río con torpeza, cambiando de tema."

# game/game/script.rpy:3555
translate es playername_897d55b1:

    # mc "So, I think we are running low on straws again."
    mc "Así que creo que nos estamos quedando sin pitillos otra vez."

# game/game/script.rpy:3560
translate es playername_633a704f:

    # m "Good! save the turtles baby!"
    m "¡Bien! ¡Salva a las tortugas, bebé!"

# game/game/script.rpy:3562
translate es playername_46fd5797:

    # mc "They are made of cardboard Miles."
    mc "Son de cartón, Miles."

# game/game/script.rpy:3566
translate es playername_8e62db32:

    # m "Oh."
    m "Oh."

# game/game/script.rpy:3570
translate es playername_5529063e:

    # m "Then save the trees bay-!"
    m "Entonces salva a los árboles, beb–"

# game/game/script.rpy:3575
translate es playername_348305d6:

    # h "Ugh, I've had enough of you people!"
    h "¡Ugh, ya tuve suficiente de ustedes!"

# game/game/script.rpy:3577
translate es playername_935c9533:

    # "Haley jokingly exclaims walking off towards the back door."
    "Exclama Haley en tono de broma mientras se aleja hacia la puerta trasera."

# game/game/script.rpy:3596
translate es playername_db50c690:

    # "I glance up at the clock. It's about time for Hal's smoke break so I can't say I'm surprised they took this opportunity to ditch us."
    "Levanto la vista al reloj. Es más o menos la hora del descanso para fumar de Hal, así que no me sorprende que haya aprovechado para huir."

# game/game/script.rpy:3598
translate es playername_9d8d9c72:

    # mc "Killing your lungs!"
    mc "¡Estás matando tus pulmones!"

# game/game/script.rpy:3600
translate es playername_b5734534:

    # "I shout to Haley's retreating form."
    "Le grito a la figura de Haley que se aleja."

# game/game/script.rpy:3602
translate es playername_13ec2629:

    # h "We are all dying anyways!"
    h "¡De todos modos todos estamos muriendo!"

# game/game/script.rpy:3604
translate es playername_a040b034:

    # "Haley waves their cigarette of choice disappearing into the back."
    "Haley agita su cigarrillo favorito mientras desaparece por la parte trasera."

# game/game/script.rpy:3608
translate es playername_11e7a2a8:

    # "A couple of hours drift by."
    "Pasan un par de horas."

# game/game/script.rpy:3610
translate es playername_dcee31b8:

    # "The sound of clanking mugs and patrons quietly conversing amongst themselves could be almost comforting."
    "El sonido de las tazas chocando y los clientes conversando en voz baja entre sí podría resultar casi reconfortante."

# game/game/script.rpy:3612
translate es playername_0827d207:

    # "{i}....if I wasn't so damn tired.{/i}"
    "{i}...si no tuviera tan condenado cansío.{/i}"

# game/game/script.rpy:3614
translate es playername_1f35c1f4:

    # "Haley walks up to the register."
    "Haley se acerca a la caja registradora."

# game/game/script.rpy:3623
translate es playername_d9b53515:

    # h "So, I have to head out early are you cool to close by yourself?"
    h "Así que tengo que irme temprano, ¿te parece bien cerrar tú sin nadie?"

# game/game/script.rpy:3625
translate es playername_abb54b79:

    # mc "Yeah, no problem. I feel like I've done it a billion times at this point."
    mc "Sí, no hay problema. Siento que lo he hecho un billón de veces a estas alturas."

# game/game/script.rpy:3627
translate es playername_3b32d4a2:

    # "Haley shoots a slightly worried look but covers it with a smile."
    "Haley me lanza una mirada ligeramente preocupada, pero la disfraza con una sonrisa."

# game/game/script.rpy:3629
translate es playername_538db5d5:

    # h "Make sure to call me if anything weird is happening kay?"
    h "Asegúrate de llamarme si pasa algo raro, ¿de acuerdo?"

# game/game/script.rpy:3631
translate es playername_2f6f1e60:

    # mc "I'll be fine, stop worrying Hals!"
    mc "Estaré bien, ¡deja de preocuparte, Hals!"

# game/game/script.rpy:3633
translate es playername_f8a171e0_1:

    # "Haley sighs."
    "Haley suspira."

# game/game/script.rpy:3635
translate es playername_c91b8e39:

    # h "I'm never {i} not {/i} going to be worried about you %(player_name)s....."
    h "Nunca voy a {i}dejar{/i} de preocuparme por ti, %(player_name)s..."

# game/game/script.rpy:3637
translate es playername_47797461:

    # mc "I'm not as helpless as you think I am Hal."
    mc "No soy tan debil como crees, Hal."

# game/game/script.rpy:3639
translate es playername_5dd0f0de:

    # "Haley smiles."
    "Haley sonríe."

# game/game/script.rpy:3641
translate es playername_a0d82e2d:

    # h "I know it. I'm always going to worry no matter what though."
    h "Lo sé. Pero aun así, siempre me preocuparé, pase lo que pase."

# game/game/script.rpy:3643
translate es playername_165c7dc5:

    # mc "Yeah, yeah, now go clock out."
    mc "Sí, sí, ahora ve a registrar tu salida."

# game/game/script.rpy:3645
translate es playername_63259ed6:

    # h "I'll take Miles with me."
    h "Me llevaré a Miles conmigo."

# game/game/script.rpy:3647
translate es playername_dcf94a89:

    # mc "Huh? Miles already left."
    mc "¿Eh? Miles ya se fue."

# game/game/script.rpy:3651
translate es playername_57f54a9b:

    # "Haley groans."
    "Haley gime."

# game/game/script.rpy:3653
translate es playername_68725c13:

    # h "let me guess...did he say it was time for his Grandma's physical therapy...?"
    h "Déjame adivinar... ¿dijo que era hora de la fisioterapia de su abuela...?"

# game/game/script.rpy:3655
translate es playername_ff2dabc9:

    # "I can't help but to cringe which makes Haley rub their temple."
    "No puedo evitar hacer una mueca, lo que hace que Haley se frote la sien."

# game/game/script.rpy:3657
translate es playername_169d2939:

    # h "Miles doesn't {i}have {/i} a grandmother."
    h "Miles no {i}tiene{/i} abuela."

# game/game/script.rpy:3659
translate es playername_4440fbf0:

    # mc "I honestly...should have seen that coming."
    mc "Honestamente... debí haberlo imaginado."

# game/game/script.rpy:3661
translate es playername_f8a171e0_2:

    # "Haley sighs."
    "Haley suspira."

# game/game/script.rpy:3665
translate es playername_083f8a2b:

    # h "It's not your fault %(player_name)s."
    h "No es tu culpa, %(player_name)s."

# game/game/script.rpy:3667
translate es playername_4bbe5891:

    # mc "Sorry..."
    mc "Perdón..."

# game/game/script.rpy:3670
translate es playername_7a907cc6:

    # h "No, no don't worry about it."
    h "No, no, no te preocupes por eso."

# game/game/script.rpy:3674
translate es playername_e8e1bdd4:

    # h "Miles will be hearing from me tomorrow."
    h "Miles sabrá de mí mañana."

# game/game/script.rpy:3676
translate es playername_cd938aab:

    # "I grimace."
    "Hago una mueca."

# game/game/script.rpy:3678
translate es playername_0ed30591:

    # "I feel a little bad for Miles considering how much Haley is glowering up a storm currently."
    "Siento un poco de lástima por Miles, considerando lo furiose que se ve Haley ahora mismo."

# game/game/script.rpy:3680
translate es playername_4a386c81:

    # "Haley takes their leave."
    "Haley se marcha."

# game/game/script.rpy:3684
translate es playername_ee29cacc:

    # "After an hour I start to close up the store."
    "Después de una hora empiezo a cerrar la tienda."

# game/game/script.rpy:3692
translate es playername_d3dad16e:

    # "Noticing that we are a bit low on cups, I grab some from the back to restock."
    "Al notar que estamos un poco escasos de vasos, voy por algunos al almacén para reabastecer."

# game/game/script.rpy:3696
translate es playername_cf7e79d2:

    # "While I am restocking the coffee bar shelves I hear the door chime."
    "Mientras estoy reponiendo los estantes de la barra de café, escucho el timbre de la puerta."

# game/game/script.rpy:3698
translate es playername_bd404ea1:

    # mc "Sorry we are closed!"
    mc "¡Perdón, estamos cerrados!"

# game/game/script.rpy:3700
translate es playername_059d42ea:

    # "I turn to towards the sound of the door."
    "Me giro hacia el sonido de la puerta."

# game/game/script.rpy:3702
translate es playername_9d191314:

    # dv "Aww, don't be like that {i}honey{/i}."
    dv "Aww, no seas así, {i}cariño{/i}."

# game/game/script.rpy:3712
translate es playername_0ceadbb2:

    # "My blood runs cold."
    "La sangre se me hiela."

# game/game/script.rpy:3714
translate es playername_bf1eb59e:

    # "I whip around....and {i}he{/i} comes into view."
    "Me doy la vuelta... y {i}él{/i} aparece ante mi vista."

# game/game/script.rpy:3721
translate es playername_75a56ada:

    # "I start to sweat, my heart pounds."
    "Empiezo a sudar, mi corazón se acelera."

# game/game/script.rpy:3725
translate es playername_ea0e120f:

    # dv "I thought this place treated their customers like family."
    dv "Pensé que este lugar trataba a sus clientes como familia."

# game/game/script.rpy:3729
translate es playername_c5ed5fa1:

    # dv "I would say we are closer than family though...wouldn't you agree {i}[criminalname]{/i}?"
    dv "Aunque diría que nosotros somos más que una familia... ¿no estás de acuerdo, {i}[criminalname]{/i}?"

# game/game/script.rpy:3733
translate es playername_1e1f8b7c:

    # "He leans on the counter, I take a step back instinctively."
    "Se apoya en el mostrador; instintivamente doy un paso atrás."

# game/game/script.rpy:3736
translate es playername_794f5269:

    # dv "Maybe you could make me a cappuccino, y'know, {i}for old times sake{/i}."
    dv "Quizás podrías prepararme un capuchino, ya sabes, {i}por los viejos tiempos{/i}."

# game/game/script.rpy:3738
translate es playername_42a85c56:

    # "My hands shook and I couldn't seem to get a grip."
    "Mis manos tiemblan y no logro mantener el control."

# game/game/script.rpy:3740
translate es playername_c05a213d:

    # mc "How did you find me...?"
    mc "¿Cómo me encontraste...?"

# game/game/script.rpy:3745
translate es playername_85b81a49:

    # dv "Ohh dear [criminalname], you think you could hide from me?"
    dv "Oh, querido [criminalname], ¿creías que podías esconderte de mí?"

# game/game/script.rpy:3746
translate es playername_b144bfeb:

    # "He laughs brushing a hand through his hair."
    "Se ríe, pasándose una mano por el cabello."

# game/game/script.rpy:3747
translate es playername_3e173228:

    # dv "I didn't think you were so {i}stupid{/i}."
    dv "No pensé que fueras tan {i}idiota{/i}."

# game/game/script.rpy:3752
translate es playername_c86330e4:

    # dv "I came to get you."
    dv "Vine a buscarte."

# game/game/script.rpy:3757
translate es playername_798f8752:

    # "I instinctively backed up."
    "Retrocedo instintivamente."

# game/game/script.rpy:3759
translate es playername_d08c79d6:

    # dv "To bring you back."
    dv "Para llevarte de vuelta."

# game/game/script.rpy:3761
translate es playername_2a6bad91:

    # "My eyes shot around scanning for anything I could use as a weapon."
    "Mis ojos recorren el lugar buscando cualquier cosa que pudiera usar como arma."

# game/game/script.rpy:3765
translate es playername_a969da8c:

    # "Double stares down at me. His eyes emptier than ever."
    "Double me mira fijamente. Sus ojos, más vacíos que nunca."

# game/game/script.rpy:3767
translate es playername_3b1fa936:

    # "He watches me like a possessed man. No emotion to be found. Like a shell."
    "Me observa como un hombre poseído. Sin emoción alguna. Como una cáscara."

# game/game/script.rpy:3771
translate es playername_71225a07:

    # dv "{i}You look scared [criminalname]{/i}."
    dv "{i}Veo que tienes miedo, [criminalname]{/i}."

# game/game/script.rpy:3773
translate es playername_2df210ed:

    # "I am unable to answer."
    "Soy incapaz de responder."

# game/game/script.rpy:3777
translate es playername_b603f114:

    # dv "Don't worry, for now I'm just here to see you."
    dv "No te preocupes, por ahora solo estoy aquí para verte."

# game/game/script.rpy:3779
translate es playername_7709465d:

    # "Double walks behind the counter and makes himself a cup of coffee."
    "Double pasa detrás del mostrador y se prepara una taza de café."

# game/game/script.rpy:3784
translate es playername_56bba1c7:

    # "Every now and then he shoots a glance at my direction. I am unable to make eye contact with him."
    "De vez en cuando me lanza una mirada. No puedo sostenerle la vista."

# game/game/script.rpy:3786
translate es playername_228f1c52:

    # "I can't run, my legs feeling stuck in place."
    "No puedo correr; mis piernas parecen clavadas al suelo."

# game/game/script.rpy:3792
translate es playername_a45a453f:

    # mc "Why are you doing this Double...?"
    mc "¿Por qué haces esto, Double...?"

# game/game/script.rpy:3798
translate es playername_7a514cfd:

    # "He approaches quickly, making me back up into the counter."
    "Se aproxima rápidamente, obligándome a retroceder hasta topar con el mostrador."

# game/game/script.rpy:3800
translate es playername_3d10699d:

    # mc "{size=-7}What have I done to deserve this?{/size}"
    mc "{size=-7}¿Qué hice para merecer esto?{/size}"

# game/game/script.rpy:3802
translate es playername_27a17079:

    # "My once courageous voice ends with a squeak."
    "Mi voz, antes valiente, termina en un chillido."

# game/game/script.rpy:3804
translate es playername_3d351d70:

    # dv "Tsk."
    dv "Tsk."

# game/game/script.rpy:3806
translate es playername_4b2250ac:

    # dv "You, you, {i} {b} you {/b}{/i}, everything is always about YOU isn't it %(player_name)s?"
    dv "Tú, tú, {i}{b}tú{/b}{/i}, todo siempre se trata de TI, ¿no es así, %(player_name)s?"

# game/game/script.rpy:3808
translate es playername_8333bd4e:

    # dv "It's no wonder our relationship went to shit."
    dv "No es de extrañar que nuestra relación se fuera al demonio."

# game/game/script.rpy:3810
translate es playername_53d5a07d:

    # dv "Has it ever occurred to you that WHY I'm doing this is simply because {i} I want to {/i}?"
    dv "¿Se te ocurrió alguna vez que la razón por la que hago esto es simplemente porque {i}quiero{/i}?"

# game/game/script.rpy:3812
translate es playername_e17a57ab:

    # dv "No?"
    dv "¿No?"

# game/game/script.rpy:3814
translate es playername_9db098e8:

    # dv "Of course not."
    dv "Por supuesto que no."

# game/game/script.rpy:3816
translate es playername_bec2b278:

    # dv "You are a selfish little shit..."
    dv "Que egoísta de mierda..."

# game/game/script.rpy:3820
translate es playername_2f3dcbe5:

    # dv "{i} But I like you [criminalname]. {/i}"
    dv "{i}Pero me gustas, [criminalname].{/i}"

# game/game/script.rpy:3822
translate es playername_0358e963:

    # dv "So I'm giving you a second chance."
    dv "Así que te estoy dando una segunda oportunidad."

# game/game/script.rpy:3826
translate es playername_6699ea91:

    # "He stares down at my terrified form. His eyes rake over my body lingering on my neck."
    "Me observa desde arriba, con mi cuerpo temblando de miedo. Su mirada recorre mi figura, deteniéndose en mi cuello."

# game/game/script.rpy:3832
translate es playername_80157e97:

    # "I scrape up what courage I have and level my gaze at him."
    "Reúno el poco valor que me queda y lo miro directamente."

# game/game/script.rpy:3834
translate es playername_addcc303:

    # mc "Why can't you just leave me alone Double?"
    mc "¿Por qué no puedes simplemente dejarme en paz, Double?"

# game/game/script.rpy:3836
translate es playername_316c3777:

    # "Double smiles."
    "Double sonríe."

# game/game/script.rpy:3843
translate es playername_26415d64:

    # "He walks over, closely leaning over into my personal space."
    "Se acerca, invadiendo por completo mi espacio personal."

# game/game/script.rpy:3845
translate es playername_f48e019c:

    # "He blinks slowly like an enamored cat."
    "Parpadea lentamente, como un gato enamorado."

# game/game/script.rpy:3847
translate es playername_a9dcb771:

    # dv "I don't want to."
    dv "No quiero."

# game/game/script.rpy:3849
translate es playername_340434d5:

    # mc "W..what..?"
    mc "¿Q-qué...?"

# game/game/script.rpy:3851
translate es playername_0edb6173:

    # dv "I said, I {i}don't. want. to{/i}."
    dv "Dije que {i}no. quiero. hacerlo.{/i}"

# game/game/script.rpy:3859
translate es playername_efdb6c3b:

    # "Double reaches out, his finger touching my cheek so lightly I could barely even feel it."
    "Double extiende la mano, rozando mi mejilla con un dedo tan suavemente que apenas lo siento."

# game/game/script.rpy:3861
translate es playername_2ec64afa:

    # dv "You always feel like this..."
    dv "Siempre te sientes así..."

# game/game/script.rpy:3863
translate es playername_58cccb59:

    # "He mumbles. His gaze fluttering around my face."
    "Murmura, su mirada revoloteando por mi rostro."

# game/game/script.rpy:3865
translate es playername_f4bc25e9:

    # dv "I can extend out and touch you, yet you always seem just outside of my reach."
    dv "Puedo extender la mano y tocarte, y aun así siempre pareces estar justo fuera de mi alcance."

# game/game/script.rpy:3867
translate es playername_67225b70:

    # "I push his hand away."
    "Aparto su mano."

# game/game/script.rpy:3869
translate es playername_ec7e2ae6:

    # "Underneath his mask he smiles, it is bitter."
    "Debajo de su máscara sonríe, pero es una sonrisa amarga."

# game/game/script.rpy:3871
translate es playername_2321954f:

    # dv "I'll take my leave."
    dv "Me retiraré por ahora."

# game/game/script.rpy:3877
translate es playername_0dde04d2:

    # "He grabs his cup of coffee and saunters towards the door."
    "Toma su taza de café y camina hacia la puerta con paso tranquilo."

# game/game/script.rpy:3879
translate es playername_88f4bfc9:

    # "Double pauses, looking back."
    "Double se detiene, mirando hacia atrás."

# game/game/script.rpy:3883
translate es playername_4dfab007:

    # dv "But remember."
    dv "Pero recuerda."

# game/game/script.rpy:3884
translate es playername_5811f7e9:

    # dv "Next time, {i}I'm taking you with me.{/i}"
    dv "La próxima vez, {i}me iré contigo.{/i}"

# game/game/script.rpy:3886
translate es playername_6c249d5a:

    # "My stomach drops."
    "El estómago se me revuelve."

# game/game/script.rpy:3890
translate es playername_463a48b3:

    # "As soon as Double leaves I run and lock the door."
    "Tan pronto como Double se va, corro y cierro la puerta con llave."

# game/game/script.rpy:3892
translate es playername_53f5ea60:

    # "My legs collapse and I hit the floor."
    "Mis piernas ceden y caigo al suelo."

# game/game/script.rpy:3899
translate es playername_c18c3062:

    # "{i}How did he find me!?{/i}"
    "{i}¡¿Cómo me encontró?!{/i}"

# game/game/script.rpy:3901
translate es playername_076dcc13:

    # "{i}I covered all of my tracks, there's no way..!{/i}"
    "{i}Cubrí todos mis rastros, ¡no hay forma..!{/i}"

# game/game/script.rpy:3903
translate es playername_4b3edf85:

    # "{i}This can't be happening to me..!{/i}"
    "{i}¡Esto no puede estar pasándome..!{/i}"

# game/game/script.rpy:3905
translate es playername_fc59c2d2:

    # "Thoughts pummel violently through my mind one after the other."
    "Los pensamientos golpean mi mente uno tras otro con violencia."

# game/game/script.rpy:3907
translate es playername_e57bd23a:

    # "{i}Where did I go wrong?{/i}"
    "{i}¿En qué fallé?{/i}"

# game/game/script.rpy:3912
translate es playername_0ac80e73:

    # "It takes me a fair while to recover. I spent countless minutes on the cold hard floor before feeling returned to my legs."
    "Me toma bastante tiempo recuperarme. Pasé incontables minutos en el suelo frío y duro antes de que el movimiento regresara a mis piernas."

# game/game/script.rpy:3916
translate es playername_13cc74dd:

    # "I finish the rest of the closing activities between bouts of pure panic and sluggish exhaustion."
    "Termino el resto de las actividades de cierre entre ataques de puro pánico y una agotadora lentitud."

# game/game/script.rpy:3927
translate es playername_f57225cc:

    # "The sun has already set, shifting the angry red glow to a cast of dark blue and city lights."
    "El sol ya se ha puesto, cambiando el resplandor rojo furioso por un tono azul oscuro y luces de ciudad."

# game/game/script.rpy:3934
translate es playername_76d24a5e:

    # "I drag my feet back home, slowly making my way through the city."
    "Arrastro los pies de regreso a casa, avanzando lentamente por la ciudad."

# game/game/script.rpy:3938
translate es playername_b967a9fe:

    # "My head hurts and I feel exhausted."
    "Me duele la cabeza y tengo agotamiento. "

# game/game/script.rpy:3946
translate es playername_00b7d06f:

    # "After crossing the threshold of my small apartment, I flop onto the floor, my energy completely depleted."
    "Después de cruzar el umbral de mi pequeño apartamento, me dejo caer en el suelo, con la energía completamente agotada."

# game/game/script.rpy:3948
translate es playername_a1648a94:

    # "I'm too tired physically and emotionally to even be worried if my apartment is still safe."
    "Tengo demasiado cansancio físico y emocional como para preocuparme si mi apartamento sigue siendo seguro."

# game/game/script.rpy:3950
translate es playername_ac5d2299:

    # "After an hour on the floor I find the energy to drag myself to bed."
    "Después de una hora en el suelo encuentro la energía para arrastrarme hasta la cama."

# game/game/script.rpy:3957
translate es playername_3f998fdd:

    # "{i}I'll escape again the day after tomorrow.{/i}"
    "{i}Volveré a escapar pasado mañana.{/i}"

# game/game/script.rpy:3972
translate es playername_c565e9ed:

    # "Despite it being my day off I head toward the familiar view of the cafe."
    "A pesar de que es mi día libre, me dirijo hacia la vista familiar del café."

# game/game/script.rpy:3974
translate es playername_48be9372:

    # "My heart wrenched at the thought of leaving this job."
    "Mi corazón se retuerce al pensar en dejar este trabajo."

# game/game/script.rpy:3976
translate es playername_dd9256b9:

    # "Sure it wasn't the best job..."
    "Claro que no era el mejor trabajo..."

# game/game/script.rpy:3978
translate es playername_4b612c82:

    # "But it was a life of normalcy for me. I truly didn't know how much I missed that."
    "Pero era una vida de normalidad para mí. Realmente no sabía cuánto extrañaba eso."

# game/game/script.rpy:3983
translate es playername_0ebbf7d3:

    # "Some part of me knew that leaving Haley was going to be one of the hardest things I will have to do."
    "Una parte de mí sabía que dejar a Haley iba a ser una de las cosas más difíciles que tendría que hacer."

# game/game/script.rpy:4005
translate es playername_986386f8:

    # cg "Despite our short time together, Haley and I have become incredibly close."
    cg "A pesar de nuestro corto tiempo juntes, Haley y yo nos volvimos increíblemente cercanes."

# game/game/script.rpy:4007
translate es playername_df8e7061:

    # cg "When I first got hired, I was scared to form any friendships."
    cg "Cuando me contrataron por primera vez, tenía miedo de formar amistades."

# game/game/script.rpy:4009
translate es playername_2af17465:

    # cg "Like a stray backed into the corner, I stayed away and hissed at anyone who came too close."
    cg "Como un animal acorralado, me mantenía lejos y reaccionaba mal con quien se acercara demasiado."

# game/game/script.rpy:4011
translate es playername_4a7f091e:

    # cg "But Haley gave me my space. They supported me with words of encouragement. They let me lean on them until I was able to grow a backbone of my own."
    cg "Pero Haley me dio mi espacio. Me apoyó con palabras de aliento. Me permitió apoyarme en elle hasta que fui capaz de fortalecerme por mi cuenta."

# game/game/script.rpy:4013
translate es playername_fa15763c:

    # cg "I have changed a lot thanks to Haley's patience and kindness."
    cg "He cambiado mucho gracias a la paciencia y amabilidad de Haley."

# game/game/script.rpy:4015
translate es playername_d6ac6080:

    # cg "I'm sure Double was even able to sense the change in me, considering how on edge he is."
    cg "Seguro que incluso Double pudo notar el cambio en mí, considerando lo tenso que está."

# game/game/script.rpy:4017
translate es playername_d1c1571a:

    # cg "I can't risk Double doing something to Haley. So I can't stay."
    cg "No puedo arriesgarme a que Double le haga algo a Haley. Así que no puedo quedarme."

# game/game/script.rpy:4019
translate es playername_01bd5adc:

    # cg "I decide to put to use the backbone that Haley gave me."
    cg "Decido usar la determinación que Haley me dio."

# game/game/script.rpy:4021
translate es playername_a432cda3:

    # cg "They helped and protected me at my lowest, so now I will protect them."
    cg "Elle me ayudo y protegio en mis peores momentos, así que ahora yo le protegeré."

# game/game/script.rpy:4023
translate es playername_1e43ce68:

    # cg "But even so..."
    cg "Pero aun así..."

# game/game/script.rpy:4025
translate es playername_2d5b0136:

    # cg "It's heart wrenching to lose someone who just {i}understood{/i} on the level Haley does."
    cg "Me parte el alma perder a alguien que simplemente {i}entendía{/i} las cosas como lo hace Haley."

# game/game/script.rpy:4027
translate es playername_7b2682e7:

    # cg "And I won't fool myself to say I didn't feel anything for them either..."
    cg "Y no me engañaré diciendo que no sentí algo por elle tampoco..."

# game/game/script.rpy:4040
translate es playername_dc5bec78:

    # "I walk into Cafe Waning Crescent for what is likely to be the last time."
    "Entro a Café Waning Crescent por lo que probablemente será la última vez."

# game/game/script.rpy:4042
translate es playername_def561e4:

    # "In my hand holds my resignation letter."
    "En mi mano sostengo mi carta de renuncia."

# game/game/script.rpy:4044
translate es playername_fe8f9a8a:

    # "My steps feel heavy."
    "Mis pasos se sienten pesados."

# game/game/script.rpy:4046
translate es playername_2382a952:

    # "Haley upon seeing me can sense that something isn't quite right."
    "Haley, al verme, percibe que algo no está bien."

# game/game/script.rpy:4050
translate es playername_ddd4993a:

    # h " %(player_name)s...?"
    h "%(player_name)s...?"

# game/game/script.rpy:4052
translate es playername_dbd68bdf:

    # h "Isn't it your day off...?"
    h "¿No es tu día libre...?"

# game/game/script.rpy:4054
translate es playername_0593782d:

    # "Haley glances at the envelope in my hand, a deep frown appearing on their face."
    "Haley mira el sobre en mi mano, una profunda preocupación aparece en su rostro."

# game/game/script.rpy:4056
translate es playername_fecef994:

    # h "Is this about Miles?"
    h "¿Esto tiene que ver con Miles?"

# game/game/script.rpy:4058
translate es playername_3498c6d7:

    # h "If he did something..."
    h "Si él hizo algo..."

# game/game/script.rpy:4060
translate es playername_e43b82eb:

    # mc "It's not about Miles."
    mc "No se trata de Miles."

# game/game/script.rpy:4062
translate es playername_ce6ba8ce:

    # "Haley's face sinks when they think about what else could prompt me to quit."
    "El rostro de Haley decae al pensar en qué otra cosa podría llevarme a renunciar."

# game/game/script.rpy:4065
translate es playername_b53aa2c5:

    # mc "It isn't about you either Hals."
    mc "Tampoco se trata de ti, Hals."

# game/game/script.rpy:4067
translate es playername_4961af8c:

    # "I bite my lip, my stomach swirling. This was a lot harder than I thought it would be."
    "Me muerdo el labio, mi estómago da vueltas. Esto es mucho más difícil de lo que pensé."

# game/game/script.rpy:4069
translate es playername_70a5d8bb:

    # mc "I...just need to quit."
    mc "Yo... solo necesito renunciar."

# game/game/script.rpy:4071
translate es playername_f9b03880:

    # "Haley's facial expression looks a little hurt."
    "La expresión de Haley parece un poco herida."

# game/game/script.rpy:4077
translate es playername_a27e59fc:

    # "Their expression stings me to my core."
    "Su mirada me atraviesa el alma."

# game/game/script.rpy:4079
translate es playername_93a1af99:

    # "I didn't want to leave them either..."
    "Tampoco quería dejarle..."

# game/game/script.rpy:4081
translate es playername_59b65159:

    # "But I hardly had a choice in any of this."
    "Pero apenas tengo elección en nada de esto."

# game/game/script.rpy:4083
translate es playername_7f6c314d:

    # "Frankly, since meeting Double I hardly had a choice in {i} anything {/i}."
    "Francamente, desde que conocí a Double apenas he tenido elección en {i}nada{/i}."

# game/game/script.rpy:4085
translate es playername_6e1e65b8:

    # "I glance down at the envelope holding it up."
    "Bajo la mirada al sobre, levantándolo un poco."

# game/game/script.rpy:4087
translate es playername_6ecdfea4:

    # mc "I'm sorry to do this."
    mc "Lamento tener que hacer esto."

# game/game/script.rpy:4089
translate es playername_424b0cf6:

    # h "If you want time off-"
    h "Si quieres tiempo libre–"

# game/game/script.rpy:4091
translate es playername_0037d1f0:

    # mc "No,...no I just need to get-"
    mc "No... no, solo necesito–"

# game/game/script.rpy:4093
translate es playername_174de739:

    # "{i}'-Away'. But I can't say that. I won't dare pull Haley into this mess, my mess.{/i}"
    "{i}'Alejarme'. Pero no puedo decir eso. No me atreveré a arrastrar a Haley a este lío, a mi lío.{/i}"

# game/game/script.rpy:4095
translate es playername_194df7c0:

    # mc "Need to get some fresh air."
    mc "Necesito un poco de aire fresco."

# game/game/script.rpy:4097
translate es playername_2fded262_1:

    # h "..."
    h "..."

# game/game/script.rpy:4099
translate es playername_f20265bd:

    # "Haley has trouble making eye contact."
    "A Haley le cuesta mantener el contacto visual."

# game/game/script.rpy:4101
translate es playername_2e466539:

    # "Their face is more stoic than ever, but I knew them well enough to see the flashes of hurt that swims across their expression."
    "Su rostro es más estoico que nunca, pero le conozco lo suficiente para ver los destellos de dolor que cruzan su expresión."

# game/game/script.rpy:4103
translate es playername_c66eacf1:

    # h "There's nothing I can say huh...?"
    h "No hay nada que pueda decir, ¿verdad...?"

# game/game/script.rpy:4105
translate es playername_193ee4ed:

    # mc "...no..."
    mc "...no..."

# game/game/script.rpy:4107
translate es playername_12ab3bf4:

    # "Silence drifts between us and I hand them the envelope. "
    "El silencio flota entre ambos y le entrego el sobre."

# game/game/script.rpy:4109
translate es playername_53e1a318:

    # "I desperately want to say 'sorry' but it dies on my tongue before it can surface to my lips."
    "Deseo desesperadamente decir 'lo siento', pero las palabras mueren en mi garganta antes de salir."

# game/game/script.rpy:4111
translate es playername_acceb1ef:

    # h "It's okay."
    h "Está bien."

# game/game/script.rpy:4113
translate es playername_1ffb60e0:

    # "Hal whispers. They force a smile."
    "Susurra Hal. Forzando una sonrisa."

# game/game/script.rpy:4117
translate es playername_f3b6c34f:

    # h "I'm sure it's for a good reason %(player_name)s."
    h "Estoy segure de que es por una buena razón, %(player_name)s."

# game/game/script.rpy:4121
translate es playername_21d06ae3:

    # h "I'm just... going to really miss you."
    h "Solo que... voy a extrañarte mucho."

# game/game/script.rpy:4123
translate es playername_6339b2d9:

    # h "I thought maybe ...we had something..."
    h "Pensé que tal vez... teníamos algo..."

# game/game/script.rpy:4126
translate es playername_acd16be8:

    # "Haley suddenly becomes flustered, their face turning a light pink. They face away."
    "Haley de repente se sonroja, su rostro se tiñe de rosa. Se gira."

# game/game/script.rpy:4130
translate es playername_51341ab9:

    # h "Ah! Shit, Never mind! I can't believe I'm really making this more awkward than it already is."
    h "¡Ah! Mierda, ¡olvídalo! No puedo creer que esté haciendo esto aún más incómodo de lo que ya es."

# game/game/script.rpy:4132
translate es playername_ab7a1f7e:

    # h "Ugh, sorry."
    h "Ugh, perdón."

# game/game/script.rpy:4134
translate es playername_562da540:

    # "I can't help but to smile a bit."
    "No puedo evitar sonreír un poco."

# game/game/script.rpy:4136
translate es playername_d1d7bfcc:

    # "{i}I thought it was only me that felt something...{/i}"
    "{i}Pensé que solo yo sentía algo...{/i}"

# game/game/script.rpy:4138
translate es playername_286555be:

    # "{i}Maybe if I stuck around longer Hals and I could have started dating or something...{/i}"
    "{i}Tal vez si me quedara más tiempo, Hals y yo podríamos haber empezado a salir o algo así...{/i}"

# game/game/script.rpy:4140
translate es playername_cec345ec:

    # "I felt even more depressed at the thought of having to leave this city now."
    "Me sentí aún más triste al pensar en tener que dejar esta ciudad ahora."

# game/game/script.rpy:4142
translate es playername_032e374f:

    # "{i}Fuck. This sucks.{/i}"
    "{i}Mierda. Esto apesta.{/i}"

# game/game/script.rpy:4144
translate es playername_b51e6f62:

    # "I force a smile unsure of what to say."
    "Fuerzo una sonrisa, sin saber qué decir."

# game/game/script.rpy:4148
translate es playername_dd07fb22:

    # h "Sorry, I'm just being selfish."
    h "Perdón, solo estoy siendo egoísta."

# game/game/script.rpy:4150
translate es playername_c23a0921:

    # h "Do what's best for you %(player_name)s."
    h "Haz lo que sea mejor para ti, %(player_name)s."

# game/game/script.rpy:4154
translate es playername_bd6e6dc4:

    # h "Just know, you aren't getting rid of me that easily."
    h "Solo recuerda, no te librarás de mí tan fácilmente."

# game/game/script.rpy:4157
translate es playername_14099f23_1:

    # "I can't help but to smile."
    "No puedo evitar sonreír."

# game/game/script.rpy:4159
translate es playername_6946df11:

    # mc "I never {i}wanted{/i} to get rid of you Hals."
    mc "Nunca {i}quise{/i} librarme de ti, Hals."

# game/game/script.rpy:4161
translate es playername_cc4373d8:

    # h "Yeah yeah, sure."
    h "Sí, sí, claro."

# game/game/script.rpy:4163
translate es playername_2a9ae424:

    # h "Maybe someday when whatever you are running from is over, you can come back."
    h "Tal vez algún día, cuando sea que estés dejando atrás lo que sea de lo que huyes, puedas volver."

# game/game/script.rpy:4165
translate es playername_e36cffc4:

    # mc "How do you know I'm running from something?"
    mc "¿Cómo sabes que estoy huyendo de algo?"

# game/game/script.rpy:4169
translate es playername_54c26156:

    # h "Ive looked in a mirror before %(player_name)s."
    h "Me he visto en un espejo antes, %(player_name)s."

# game/game/script.rpy:4171
translate es playername_5abe8e7d:

    # "It didn't feel appropriate to ask any further, so I just hand them the envelope."
    "No parecía apropiado seguir preguntando, así que solo le entrego el sobre."

# game/game/script.rpy:4174
translate es playername_fc847814:

    # h "I'm guessing you aren't finishing out the week?"
    h "¿Supongo que no terminarás la semana?"

# game/game/script.rpy:4176
translate es playername_6a20a80d:

    # "I shake my head."
    "Niego con la cabeza."

# game/game/script.rpy:4178
translate es playername_4bbe5891_1:

    # mc "Sorry..."
    mc "Perdón..."

# game/game/script.rpy:4180
translate es playername_517b42f7:

    # h "Thought so. Don't worry, we will be fine. Your last paycheck will be in next week."
    h "Lo imaginaba. No te preocupes, estaremos bien. Tu último cheque llegará la próxima semana."

# game/game/script.rpy:4182
translate es playername_18e9e82c:

    # "Haley pulls me into a hug."
    "Haley me abraza."

# game/game/script.rpy:4199
translate es playername_1d74a2ed:

    # "They pull back looking at me warmly."
    "Se aparta mirándome con calidez."

# game/game/script.rpy:4215
translate es playername_0658f392:

    # " Haley forces a smile despite the sadness that swims under the surface."
    "Haley fuerza una sonrisa a pesar de la tristeza que se esconde debajo."

# game/game/script.rpy:4218
translate es playername_d003c41a:

    # h "Well....stay safe and I wish you all the best %(player_name)s."
    h "Bueno... cuídate y te deseo lo mejor, %(player_name)s."

# game/game/script.rpy:4220
translate es playername_be4b44f7:

    # h "If you need anything, and I mean {i} anything {/i} you have my number."
    h "Si necesitas algo, y me refiero a {i}cualquier cosa{/i}, tienes mi número."

# game/game/script.rpy:4222
translate es playername_875ef176:

    # "I nod unable to speak as a lump swells in my throat."
    "Asiento sin poder hablar, mientras un nudo se forma en mi garganta."

# game/game/script.rpy:4224
translate es playername_322b98ac:

    # h "You will be great wherever you end up, I know it. Everything will be okay, I promise."
    h "Serás genial dondequiera que termines, lo sé. Todo estará bien, te lo prometo."

# game/game/script.rpy:4226
translate es playername_25fabe31:

    # mc "Thanks Hals."
    mc "Gracias, Hals."

# game/game/script.rpy:4229
translate es playername_5d93daeb:

    # "Haley ruffles my hair turning away."
    "Haley revuelve mi cabello y se da la vuelta."

# game/game/script.rpy:4244
translate es playername_1d2ad062:

    # h "I'm going to go file this and take a smoke."
    h "Voy a archivar esto y a fumar un poco."

# game/game/script.rpy:4246
translate es playername_ed975ada:

    # "They look over their shoulder."
    "Me mira por encima del hombro."

# game/game/script.rpy:4248
translate es playername_68c8e606:

    # h "Bye %(player_name)s."
    h "Adiós, %(player_name)s."

# game/game/script.rpy:4250
translate es playername_e5db816c:

    # mc "Bye Hal."
    mc "Adiós, Hal."

# game/game/script.rpy:4257
translate es playername_8b7127d6:

    # "I walk out of the store looking back at it one last time."
    "Salgo de la tienda, mirando hacia atrás una última vez."

# game/game/script.rpy:4264
translate es playername_ca6624e7:

    # "I decide to take the long way home to be alone with my thoughts."
    "Decido tomar el camino largo a casa para estar a solas con mis pensamientos."

# game/game/script.rpy:4270
translate es playername_ec80b6c6:

    # "As I walk I notice a magazine left on a bench. The wind picks up and it flies onto the ground."
    "Mientras camino, noto una revista olvidada en un banco. El viento sopla y la hace volar al suelo."

# game/game/script.rpy:4272
translate es playername_ee153b32:

    # "I pick it up to recycle it, the wind only becoming more intense."
    "La recojo para reciclarla, pero el viento solo se vuelve más intenso."

# game/game/script.rpy:4276
translate es playername_8e2f12f4:

    # "As I am walking back home my eye glances at the magazine."
    "Mientras camino de regreso a casa, mi mirada se posa en la revista."

# game/game/script.rpy:4278
translate es playername_5f26cf61:

    # "Familiarity catching my eye."
    "Una sensación de familiaridad capta mi atención."

# game/game/script.rpy:4280
translate es playername_b3ff917a:

    # "{i}Binary Star...?{/i}"
    "{i}¿Binary Star...?{/i}"

# game/game/script.rpy:4303
translate es playername_33393c1a:

    # cg "Binary star adorns the cover splayed across like a greek god."
    cg "Binary Star adorna la portada, extendido como un dios griego."

# game/game/script.rpy:4305
translate es playername_78270058:

    # cg "{i}I guess that Luke guy was onto something. Ray really does look similar to Binary Star...{/i}"
    cg "{i}Supongo que ese tipo Luke tenía razón. Ray realmente se parece mucho a Binary Star...{/i}"

# game/game/script.rpy:4307
translate es playername_3c9cbc57:

    # cg "{i} They could be cousins. If Ray had those red eyes, they could even be brothers.{/i}"
    cg "{i}Podrían ser primos. Si Ray tuviera esos ojos rojos, podrían incluso ser hermanos.{/i}"

# game/game/script.rpy:4309
translate es playername_2e130861:

    # cg "Binary Star's bright red eyes were unsettling to me no matter how hard his smile shined."
    cg "Los brillantes ojos rojos de Binary Star me resultaban inquietantes sin importar cuán brillante fuera su sonrisa."

# game/game/script.rpy:4311
translate es playername_618e5bee:

    # cg "I couldn't deny that the cover was ...attractive though."
    cg "Aunque no podía negar que la portada era... atractiva."

# game/game/script.rpy:4313
translate es playername_0957f077:

    # cg "I glance at the headline."
    cg "Miro el titular."

# game/game/script.rpy:4315
translate es playername_4e92fb9a:

    # cg "{i}'Inside the Dazzling world of Binary Star!' {/i}"
    cg "{i}'¡Dentro del deslumbrante mundo de Binary Star!'{/i}"

# game/game/script.rpy:4317
translate es playername_106436f5:

    # cg "Curiosity gets the better of me and I flip to the interview."
    cg "La curiosidad me gana y paso a la entrevista."

# game/game/script.rpy:4319
translate es playername_6d94b36b:

    # cg "{i}From Binary Star's time fighting for world peace, to his new city, our favorite hero tells us everything-{/i}"
    cg "{i}Desde la época de Binary Star luchando por la paz mundial, hasta su nueva ciudad, nuestro héroe favorito nos cuenta todo.{/i}"

# game/game/script.rpy:4321
translate es playername_2dbe2a3e:

    # n "{i}Everyone's favorite hero has moved home base and is more popular than ever.{/i}"
    n "{i}El héroe favorito de todos ha cambiado su base de operaciones y es más popular que nunca.{/i}"

# game/game/script.rpy:4323
translate es playername_a4ac233c:

    # n "{i}From posing for the newest names in Vogue, to defending cities from Alien attacks, Binary Star's brilliance never seems to fade.{/i}"
    n "{i}Desde posar para los nuevos nombres de Vogue, hasta defender ciudades de ataques alienígenas, el brillo de Binary Star nunca parece desvanecerse.{/i}"

# game/game/script.rpy:4325
translate es playername_2b3377c6:

    # n "{i}Today we had the chance to sit down and talk one-on-one with our favorite Hero from the stars.{/i}"
    n "{i}Hoy tuvimos la oportunidad de sentarnos y hablar cara a cara con nuestro héroe favorito de las estrellas.{/i}"

# game/game/script.rpy:4339
translate es playername_23616765:

    # n "{b}Despite being everyone's favorite hero, you seem to have been taking on a new look recently.{/b}"
    n "{b}A pesar de ser el héroe favorito de todos, parece que has adoptado una nueva apariencia recientemente.{/b}"

# game/game/script.rpy:4341
translate es playername_4561ace1:

    # n "{b}This new, dangerous, and dare I say {i}sexy{/i} look is driving fans wild! Can you tell us what inspired this change?{/b}"
    n "{b}¡Este nuevo look peligroso y, me atrevo a decir, {i}sexy{/i}, está volviendo locos a los fans! ¿Podrías contarnos qué inspiró este cambio?{/b}"

# game/game/script.rpy:4343
translate es playername_f8afeef2:

    # n "{b}Binary Star: {/b} {color=#CD9300}'(Binary Star gives a polite laugh) Well, I wanted to show a new side of myself to the fans'{/color}"
    n "{b}Binary Star: {/b} {color=#CD9300}'(Binary Star suelta una risa educada) Bueno, quería mostrar un nuevo lado de mí a los fans.'{/color}"

# game/game/script.rpy:4346
translate es playername_59695cc9:

    # n "{color=#CD9300}'I want people to understand that us heroes aren't just robots, we are human too.{/color}"
    n "{color=#CD9300}'Quiero que la gente entienda que los héroes no somos solo robots, también somos humanos.{/color}"

# game/game/script.rpy:4349
translate es playername_6311c125:

    # n "{color=#CD9300}'I think citizens can loose interest in heroes because we may come off as ostentatious. I want to show that we are human too.{/color}"
    n "{color=#CD9300}'Creo que los ciudadanos pueden perder interés en los héroes porque podemos parecer ostentosos. Quiero mostrar que también somos humanos.{/color}"

# game/game/script.rpy:4351
translate es playername_7f62d544:

    # n "{color=#CD9300}'I enjoy my time off, I drink black coffee almost every morning, I have even been even thinking of adopting a cat.'{/color}"
    n "{color=#CD9300}'Disfruto mi tiempo libre, tomo café negro casi todas las mañanas, incluso he estado pensando en adoptar un gato.'{/color}"

# game/game/script.rpy:4353
translate es playername_9b93327c:

    # n "{color=#CD9300}'I find happiness in a lot of things that others may call boring. I just call them normal.' {/color}"
    n "{color=#CD9300}'Encuentro felicidad en muchas cosas que otros podrían llamar aburridas. Yo simplemente las llamo normales.'{/color}"

# game/game/script.rpy:4359
translate es playername_33c6cf33:

    # n "{b}Fans are saying that you are taking on a more sexy and edgy look to appeal to a more mature crowd.{/b}"
    n "{b}Los fans dicen que estás adoptando una imagen más sexy y atrevida para atraer a un público más maduro.{/b}"

# game/game/script.rpy:4361
translate es playername_7584ea33:

    # n "{b} The current theory stands that it {i}has{/i} been a while since you have been seen with a partner. Perhaps spring is upon our favorite Hero?{/b}"
    n "{b}La teoría actual sostiene que ha pasado un tiempo desde que se te vio con una pareja. ¿Tal vez la primavera ha llegado para nuestro héroe favorito?{/b}"

# game/game/script.rpy:4363
translate es playername_f214f069:

    # n "{b}Binary Star: {/b} {color=#CD9300}'I'm lucky to have such dedicated fans that care for my wellbeing.'{/color}"
    n "{b}Binary Star: {/b} {color=#CD9300}'Tengo la suerte de tener fans tan dedicados que se preocupan por mi bienestar.'{/color}"

# game/game/script.rpy:4365
translate es playername_e05e87ba:

    # n "{color=#CD9300}'I hope that my fans can see that I'm someone with depth, someone with emotion, an edge.' {/color}"
    n "{color=#CD9300}'Espero que mis fans puedan ver que soy alguien con profundidad, con emociones, con un filo.'{/color}"

# game/game/script.rpy:4367
translate es playername_377299ad:

    # n "(Binary Star gives a coy smirk) {color=#CD9300}'Although, I can't say that my change wasn't inspired by a...special someone.' {/color}"
    n "(Binary Star esboza una sonrisa pícara) {color=#CD9300}'Aunque, no puedo decir que mi cambio no haya sido inspirado por... alguien especial.'{/color}"

# game/game/script.rpy:4375
translate es playername_25e356f9:

    # "Suddenly the ground begins to shake."
    "De repente el suelo comienza a temblar."

# game/game/script.rpy:4377
translate es playername_282e5851_1:

    # mc "What...?"
    mc "¿Qué...?"

# game/game/script.rpy:4379
translate es playername_2e348721:

    # "{i}Is an earthquake happening...?{/i}"
    "{i}¿Está ocurriendo un terremoto...?{/i}"

# game/game/script.rpy:4383
translate es playername_190d7af0:

    # "My footing becomes uneven as the ground is jolted in every which way."
    "Mi equilibrio se vuelve inestable mientras el suelo se sacude en todas direcciones."

# game/game/script.rpy:4385
translate es playername_cbb82a31:

    # "I hear a scream in the distance."
    "Escucho un grito a lo lejos."

# game/game/script.rpy:4391
translate es playername_528af519:

    # "Suddenly Smoke rushes, encapsulating everything."
    "De repente el humo avanza, envolviéndolo todo."

# game/game/script.rpy:4393
translate es playername_5e4dbbfa:

    # "I attempt to run but could only get so far before giant unearthly black shadows take form."
    "Intento correr, pero solo logro avanzar un poco antes de que gigantescas sombras negras y antinaturales tomen forma."

# game/game/script.rpy:4395
translate es playername_7cbb2a01:

    # "It dawned on me what was happening."
    "Comprendo lo que está ocurriendo."

# game/game/script.rpy:4397
translate es playername_58325cd0:

    # "Some ungodly monster was attacking the city."
    "Algún monstruo infernal estaba atacando la ciudad."

# game/game/script.rpy:4399
translate es playername_ab26b185:

    # "The Aliens, horrible creatures that destroy everything they touch."
    "Los Alienígenas, horribles criaturas que destruyen todo lo que tocan."

# game/game/script.rpy:4401
translate es playername_c017d3fd:

    # "Suddenly I think of Miles and Haley and my heart jumps into my throat."
    "De pronto pienso en Miles y Haley, y el corazón se me sube a la garganta."

# game/game/script.rpy:4403
translate es playername_14ea3437:

    # "{i}I have to help them!{/i}"
    "{i}¡Tengo que ayudarlos!{/i}"

# game/game/script.rpy:4408
translate es playername_ce5a24c5:

    # "I sprint back towards the cafe in a pure panic, knowing that it will take me closer to where the monsters roam."
    "Corro de vuelta hacia el café en puro pánico, sabiendo que eso me llevará más cerca de donde merodean los monstruos."

# game/game/script.rpy:4415
translate es playername_e4203d75:

    # "When I get there the cafe is already half collapsed."
    "Cuando llego, el café ya está medio colapsado."

# game/game/script.rpy:4417
translate es playername_dde68d39:

    # "My heart is beating out of my chest. I swivel my head desperately, but all I see is smoke."
    "Mi corazón late con fuerza desmedida. Giro la cabeza desesperadamente, pero todo lo que veo es humo."

# game/game/script.rpy:4419
translate es playername_652ce468:

    # "Screams surround me no matter where I turn, the smoke only becoming thicker."
    "Los gritos me rodean por todas partes, el humo se vuelve más espeso."

# game/game/script.rpy:4423
translate es playername_b832a166:

    # mc "HALEY!!"
    mc "¡¡HALEY!!"

# game/game/script.rpy:4426
translate es playername_4de41b36:

    # "I scream."
    "Grito."

# game/game/script.rpy:4428
translate es playername_47158d1c:

    # mc "MILES!!!"
    mc "¡¡MILES!!"

# game/game/script.rpy:4432
translate es playername_4d68eb1c:

    # "I continue to scream and sprint and search for my coworkers."
    "Sigo gritando y corriendo mientras busco a mis compañeros de trabajo."

# game/game/script.rpy:4437
translate es playername_c5729a75:

    # "Suddenly I feel a vibration in my pocket."
    "De repente siento una vibración en mi bolsillo."

# game/game/script.rpy:4441
translate es playername_06b39cd1:

    # "The caller ID read 'Haley' and I scramble to pick up."
    "El identificador de llamadas muestra 'Haley' y me apresuro a contestar."

# game/game/script.rpy:4443
translate es playername_2800f605:

    # "The minute I accept the call Haley is talking at breakneck speeds."
    "En cuanto acepto la llamada, Haley habla a toda velocidad."

# game/game/script.rpy:4445
translate es playername_0d29eb24:

    # hp "%(player_name)s LISTEN TO ME!"
    hp "%(player_name)s ¡ESCÚCHAME!"

# game/game/script.rpy:4447
translate es playername_269d1e56:

    # hp "DON'T COME TO THE CAFE OR THE WEST DISTRICT!"
    hp "¡NO VENGAS AL CAFÉ NI AL DISTRITO OESTE!"

# game/game/script.rpy:4449
translate es playername_f8000400:

    # mc "Are you Okay!? Where are you!?"
    mc "¿Estás bien!? ¿Dónde estás!?"

# game/game/script.rpy:4451
translate es playername_0299997b:

    # hp "Miles and I are safe! The minute I felt something was wrong, we high tailed it out just in time!"
    hp "¡Miles y yo estamos a salvo! ¡En cuanto sentí que algo andaba mal, salimos corriendo justo a tiempo!"

# game/game/script.rpy:4453
translate es playername_97334cff:

    # hp "Where are yo-"
    hp "¿Dónde es-"

# game/game/script.rpy:4459
translate es playername_5e3f5b67:

    # "The ground shakes so violently that my phone drops onto the ground."
    "El suelo tiembla con tanta fuerza que el teléfono se me cae al suelo."

# game/game/script.rpy:4461
translate es playername_00e774ee:

    # "I crouch down to find it, smoke fills my lungs burning them."
    "Me agacho para buscarlo, el humo llena mis pulmones, quemándolos."

# game/game/script.rpy:4467
translate es playername_4030311a:

    # "As I am crouched down, the ground starts to shake with increasing violence."
    "Mientras me agacho, el suelo comienza a temblar con más violencia."

# game/game/script.rpy:4473
translate es playername_dd303e3c:

    # "So much so, that I am unable to get up."
    "Tanto que no puedo levantarme."

# game/game/script.rpy:4482
translate es playername_5d373ca4:

    # "I look up, a dark shadow lurks near me. I can't help but to stare at the horrific creature, alien, destructive, death."
    "Levanto la vista, una sombra oscura se cierne cerca de mí. No puedo evitar mirar a la horrenda criatura, alienígena, destructiva, mortal."

# game/game/script.rpy:4485
translate es playername_f262c737:

    # "My body shakes at the sight. I crawl behind a displaced facade."
    "Mi cuerpo tiembla al verla. Me arrastro detrás de una fachada desplazada."

# game/game/script.rpy:4501
translate es playername_519953b4:

    # "It lurks closer."
    "Se acerca."

# game/game/script.rpy:4520
translate es playername_437aa8bd:

    # "I try to stop myself from shaking but it is futile."
    "Intento dejar de temblar, pero es inútil."

# game/game/script.rpy:4522
translate es playername_9b23cfba:

    # "As the giant form lurks near me, I cover my mouth to keep myself from screaming."
    "Cuando la enorme figura se aproxima, me tapo la boca para no gritar."

# game/game/script.rpy:4524
translate es playername_cf763eb8:

    # "It pauses..."
    "Se detiene..."

# game/game/script.rpy:4526
translate es playername_e232d0b3_1:

    # mc "!!!"
    mc "¡¡¡!!!"

# game/game/script.rpy:4528
translate es playername_ee3d7983:

    # "A scream further away caught it's attention. The ungodly creature lumbered towards the sound, crushing and destroying as it went."
    "Un grito más lejano capta su atención. La criatura impía se dirige hacia el sonido, aplastando y destruyendo a su paso."

# game/game/script.rpy:4538
translate es playername_1535dd7a:

    # "I tried to get up, to run, to save myself, but my knees faltered plummeting me back towards the ground."
    "Intento levantarme, correr, salvarme, pero mis rodillas fallan, haciéndome caer de nuevo al suelo."

# game/game/script.rpy:4540
translate es playername_73013de6:

    # cg "{color=#CD9300}'Excuse me,'{/color}"
    cg "{color=#CD9300}'Disculpa,'{/color}"

# game/game/script.rpy:4543
translate es playername_fcddf54c:

    # cg "I hear a voice behind me and turn around."
    cg "Escucho una voz detrás de mí y me giro."

# game/game/script.rpy:4573
translate es playername_01b3ea80:

    # cg "{color=#CD9300}'Do you need help?'{/color}"
    cg "{color=#CD9300}'¿Necesitas ayuda?'{/color}"

# game/game/script.rpy:4576
translate es playername_6f38eddd:

    # cg "I look up to see a hand reaching towards me..."
    cg "Levanto la vista y veo una mano extendida hacia mí..."

# game/game/script.rpy:4578
translate es playername_d7e309b6:

    # cg "A hand....connected to the body of the hero I saw on a magazine not 30 minutes prior."
    cg "Una mano... unida al cuerpo del héroe que había visto en una revista no más de 30 minutos antes."

# game/game/script.rpy:4580
translate es playername_e8242298:

    # cg "{color=#510f80}'Binary....Star?'{/color}"
    cg "{color=#510f80}'¿Binary... Star?'{/color}"

# game/game/script.rpy:4582
translate es playername_bb9bd46d:

    # cg "He smiles."
    cg "Él sonríe."

# game/game/script.rpy:4584
translate es playername_0280390d:

    # cg "{color=#CD9300}'Yes?'{/color}"
    cg "{color=#CD9300}'¿Sí?'{/color}"

# game/game/script.rpy:4586
translate es playername_fad0564b:

    # cg "Before I can stop myself, I blurt out my first thought."
    cg "Antes de poder contenerme, suelto lo primero que pienso."

# game/game/script.rpy:4588
translate es playername_41629cf7:

    # cg "{color=#510f80}'You look different in person.'{/color}"
    cg "{color=#510f80}'Te ves diferente en persona.'{/color}"

# game/game/script.rpy:4590
translate es playername_ef11f956:

    # cg "He seems unsure of what to say but flashes a dazzling smile."
    cg "Parece no saber qué decir, pero muestra una sonrisa deslumbrante."

# game/game/script.rpy:4592
translate es playername_db6beeae:

    # cg "{color=#CD9300}'I'll take that as a compliment.'{/color}"
    cg "{color=#CD9300}'Lo tomaré como un cumplido.'{/color}"

# game/game/script.rpy:4594
translate es playername_b0bd5576:

    # cg "{color=#510f80}'Oh sorry, I didn't mean it as an insult!'{/color}"
    cg "{color=#510f80}'Oh, lo siento, ¡no quise que sonara como un insulto!'{/color}"

# game/game/script.rpy:4596
translate es playername_9b9d3f0a:

    # cg "I can hear screaming in the distance."
    cg "Escucho gritos a lo lejos."

# game/game/script.rpy:4600
translate es playername_8f0b2aad:

    # cg "I look past the hero and see someone being picked up by the large creature."
    cg "Miro más allá del héroe y veo a alguien siendo levantado por la enorme criatura."

# game/game/script.rpy:4602
translate es playername_0ee769d0:

    # cg "{color=#510f80}'Maybe you should help them?'{/color}"
    cg "{color=#510f80}'¿Tal vez deberías ayudarlos?'{/color}"

# game/game/script.rpy:4604
translate es playername_40a8955b:

    # cg "His gaze doesn't falter from me."
    cg "Su mirada no se aparta de mí."

# game/game/script.rpy:4606
translate es playername_c9d10d80:

    # cg "{color=#CD9300}'My side-kick will take care of it.'{/color}"
    cg "{color=#CD9300}'Mi compañero se encargará de eso.'{/color}"

# game/game/script.rpy:4612
translate es playername_118490f8:

    # cg "{color=#510f80}'Uh, okay...'{/color}"
    cg "{color=#510f80}'Uh, está bien...'{/color}"

# game/game/script.rpy:4614
translate es playername_d39fd3d2:

    # cg "{color=#CD9300}'Let me help you up.'{/color}"
    cg "{color=#CD9300}'Déjame ayudarte a levantarte.'{/color}"

# game/game/script.rpy:4623
translate es playername_d7ee67af:

    # "I take his hand and the Hero helps me to my feet. I lean on him a bit as my legs were still wobbly."
    "Tomo su mano y el héroe me ayuda a ponerme de pie. Me apoyo un poco en él, ya que mis piernas aún están temblorosas."

# game/game/script.rpy:4632
translate es playername_3acc5336:

    # bs "You don't seem like you will be able to walk."
    bs "No pareces en condiciones de caminar."

# game/game/script.rpy:4634
translate es playername_34591506:

    # "Before I can protest the hero lifts me bridal-style with ease."
    "Antes de que pueda protestar, el héroe me levanta en brazos con facilidad."

# game/game/script.rpy:4658
translate es playername_37e49149:

    # bs "Looks like I'll have to air-lift you out."
    bs "Parece que tendré que sacarte volando."

# game/game/script.rpy:4660
translate es playername_7d731f33:

    # mc "Wait, Binary, um- Mister Star, there are other people that probably need your help more."
    mc "Espera, Binary, um... señor Star, hay otras personas que probablemente necesitan más tu ayuda."

# game/game/script.rpy:4662
translate es playername_7950bc8c:

    # mc "My legs are probably fine now. I can just run away."
    mc "Mis piernas ya deben estar bien. Puedo correr."

# game/game/script.rpy:4666
translate es playername_ff750d19:

    # "He glances down at me and does not answer."
    "Él me mira hacia abajo y no responde."

# game/game/script.rpy:4670
translate es playername_f180e2e9:

    # "The uncharacteristic expression disappears as quickly as it graced his face."
    "La expresión poco característica desaparece tan rápido como apareció."

# game/game/script.rpy:4690
translate es playername_499dce22:

    # "We lift into the air traveling at fast speeds, his red cape flowing behind him."
    "Nos elevamos por el aire a gran velocidad, su capa roja ondeando detrás de él."

# game/game/script.rpy:4692
translate es playername_28c8f343:

    # "After a few minutes Binary Star lowers me to the ground."
    "Después de unos minutos, Binary Star me baja al suelo."

# game/game/script.rpy:4699
translate es playername_70348e1b:

    # bs "There we go, how are you feeling?"
    bs "Ahí estamos, ¿cómo te sientes?"

# game/game/script.rpy:4701
translate es playername_b83e0779:

    # mc "Uh, confused? Overwhelmed...?"
    mc "¿Con confusión? ¿Grave?"

# game/game/script.rpy:4703
translate es playername_95d41485:

    # "He hovers close, glancing around my form."
    "Él flota cerca, observándome de arriba abajo."

# game/game/script.rpy:4705
translate es playername_2d15706a:

    # bs "Are you hurt at all?"
    bs "¿Te lastimaste?"

# game/game/script.rpy:4707
translate es playername_c135ac4d:

    # mc "No, I'm fine I think."
    mc "No, estoy bien, creo."

# game/game/script.rpy:4709
translate es playername_a9afbfb5:

    # "A silence drifts between us."
    "Un silencio se extiende entre nosotros."

# game/game/script.rpy:4711
translate es playername_a2c7e9c7:

    # mc "Oh, thanks for your help Mr. Star."
    mc "Oh, gracias por tu ayuda, señor Star."

# game/game/script.rpy:4713
translate es playername_221d8ae6:

    # "He smiles brightly."
    "Él sonríe con brillo."

# game/game/script.rpy:4715
translate es playername_4f180eed:

    # bs "No problem at all!"
    bs "¡Ningún problema!"

# game/game/script.rpy:4717
translate es playername_5cb19c88:

    # "Another small silence drifts between us."
    "Otro pequeño silencio se instala entre nosotros."

# game/game/script.rpy:4719
translate es playername_20d1f56a:

    # "I clear my throat awkwardly."
    "Carraspeo torpemente."

# game/game/script.rpy:4721
translate es playername_17dba66e:

    # bs "I suppose I should leave then..."
    bs "Supongo que debería irme entonces..."

# game/game/script.rpy:4723
translate es playername_6dcc8065:

    # "I blink, his tone made it feel like a trick question."
    "Parpadeo; su tono hace que parezca una pregunta trampa."

# game/game/script.rpy:4725
translate es playername_1d0a4a60:

    # mc "Yeah, I'm not sure how much hero-ing you will do here."
    mc "Sí, no se cuánto heroísmo podrás hacer aquí. "

# game/game/script.rpy:4727
translate es playername_56bbde6a:

    # mc "This far away seems pretty safe, aside from the smoke."
    mc "Tan lejos parece bastante seguro, salvo por el humo."

# game/game/script.rpy:4729
translate es playername_8b7c94c9:

    # bs "Once the aliens are gone the smoke will clear up."
    bs "Una vez que los alienígenas se vayan, el humo desaparecerá."

# game/game/script.rpy:4731
translate es playername_6c5336a5:

    # bs "Just stay inside, and try not to breathe too much of it in."
    bs "Solo quédate adentro y trata de no respirar demasiado."

# game/game/script.rpy:4744
translate es playername_d03be581:

    # "I look around and start in the surroundings for the first time since we landed."
    "Miro alrededor y por primera vez observo el entorno desde que aterrizamos."

# game/game/script.rpy:4746
translate es playername_538f3355:

    # "{i}This area looks really familiar...{/i}"
    "{i}Este lugar me resulta muy familiar...{/i}"

# game/game/script.rpy:4748
translate es playername_768038ef:

    # bs "What's your name? I'd love to take you out to-"
    bs "¿Cómo te llamas? Me encantaría invitarte a-"

# game/game/script.rpy:4770
translate es playername_b9539cbd:

    # "{i}Oh! It's my neighborhood!{/i}"
    "{i}¡Oh! ¡Es mi vecindario!{/i}"

# game/game/script.rpy:4776
translate es playername_a14c8cfc:

    # mc "Oh, My apartment is right here! That's so lucky I don't have to call a cab to get home!"
    mc "¡Oh, mi apartamento está justo aquí! ¡Qué suerte, no tengo que pedir un taxi para volver a casa!"

# game/game/script.rpy:4780
translate es playername_a1d98c86:

    # "Binary Star looked a bit awe struck."
    "Binary Star parecía un poco asombrado."

# game/game/script.rpy:4782
translate es playername_7717aee5:

    # "I cringe, realizing that I just interrupted him."
    "Me estremezco al darme cuenta de que lo acabo de interrumpir."

# game/game/script.rpy:4784
translate es playername_71d5e9d9:

    # mc "Oh sorry, what were you saying?"
    mc "Oh, lo siento, ¿qué decías?"

# game/game/script.rpy:4786
translate es playername_e9ba84a3:

    # bs "It's...it's nothing."
    bs "Es... nada."

# game/game/script.rpy:4788
translate es playername_235c4cde:

    # mc "Okay, well I should probably go inside then and not distract you from hero duties."
    mc "Está bien, bueno, probablemente debería entrar y no distraerte de tus deberes heroicos."

# game/game/script.rpy:4789
translate es playername_80561b8b:

    # mc "Thanks again Mr. Star."
    mc "Gracias de nuevo, señor Star."

# game/game/script.rpy:4790
translate es playername_11ca333d:

    # "I give a small wave goodbye while walking towards my apartment."
    "Hago un pequeño gesto de despedida mientras camino hacia mi apartamento."

# game/game/script.rpy:4800
translate es playername_3a88e82c:

    # "I enter into my apartment tossing my stuff onto the counter."
    "Entro en mi apartamento y dejo mis cosas sobre el mostrador."

# game/game/script.rpy:4802
translate es playername_8abf6cd3:

    # "I send Haley a text letting them know I made it home safe."
    "Le envío un mensaje a Haley para avisarle que llegué a casa a salvo."

# game/game/script.rpy:4804
translate es playername_2b5f9e19:

    # "Switching on the TV, I flip to the news station."
    "Enciendo la televisión y cambio al canal de noticias."

# game/game/script.rpy:4808
translate es playername_438a705e:

    # "On the news shows flashes of light and color as the heroes battle the long legged aliens."
    "En las noticias se muestran destellos de luz y color mientras los héroes luchan contra los alienígenas de patas largas."

# game/game/script.rpy:4810
translate es playername_96633fab:

    # "The street signs of the cafe flies across the screen slamming into one of the creatures."
    "Los letreros de la calle del café vuelan por la pantalla y golpean a una de las criaturas."

# game/game/script.rpy:4812
translate es playername_c72c70cd:

    # "It suddenly occurs to me that Ray could have been in the area."
    "De repente se me ocurre que Ray podría haber estado en la zona."

# game/game/script.rpy:4814
translate es playername_607d0b7e:

    # "I scramble to grab my phone."
    "Corro a tomar mi teléfono."

# game/game/script.rpy:4816
translate es playername_8cd6d3e9:

    # "The phone rings a bit and goes to voicemail."
    "El teléfono suena un poco y pasa al buzón de voz."

# game/game/script.rpy:4818
translate es playername_e90bc64a:

    # mc "Um, hi Ray! This is-"
    mc "Eh, hola Ray, soy yo..."

# game/game/script.rpy:4822
translate es playername_8cdce30b:

    # "The phone begins to vibrate in my hand."
    "El teléfono comienza a vibrar en mi mano."

# game/game/script.rpy:4826
translate es playername_1b9cd677:

    # "It's Ray calling me back. I quickly answer."
    "Es Ray devolviendo la llamada. Contesto rápidamente."

# game/game/script.rpy:4828
translate es playername_dff5569e:

    # mc "Hi!"
    mc "¡Hola!"

# game/game/script.rpy:4830
translate es playername_aa0f7a72:

    # rp "Hey, %(player_name)s. You called?"
    rp "Hey, %(player_name)s. ¿Llamabas?"

# game/game/script.rpy:4832
translate es playername_924feb8a:

    # mc "Yeah! I'm not sure if you heard the news but stay out of West District today!"
    mc "¡Sí! No sé si viste las noticias, ¡pero mantente alejado del Distrito Oeste hoy!"

# game/game/script.rpy:4834
translate es playername_c751c71a:

    # "There is silence on the other line and I thought I heard a scream."
    "Hay silencio en la otra línea y creo escuchar un grito."

# game/game/script.rpy:4836
translate es playername_8557a9f4:

    # mc "Uh Ray?"
    mc "Eh, ¿Ray?"

# game/game/script.rpy:4838
translate es playername_7dd18a31:

    # rp "Yeah? Oh, sorry I must have spaced."
    rp "¿Sí? Oh, perdón, creo que me distraje."

# game/game/script.rpy:4840
translate es playername_8483e6d1:

    # rp "I ...heard the news, I'll be sure to stay out of West District."
    rp "Escuché las noticias... me aseguraré de mantenerme lejos del Distrito Oeste."

# game/game/script.rpy:4842
translate es playername_db1ea032:

    # "A large crash resounds in the background of the call."
    "Un fuerte estruendo resuena al fondo de la llamada."

# game/game/script.rpy:4844
translate es playername_96235f48:

    # mc "Is everything okay?"
    mc "¿Todo está bien?"

# game/game/script.rpy:4846
translate es playername_1c6cdb5f:

    # rp "...Yeah, why?"
    rp "...Sí, ¿por qué?"

# game/game/script.rpy:4848
translate es playername_7f490c56:

    # mc "I just thought I heard something..."
    mc "Es que pensé que escuché algo..."

# game/game/script.rpy:4850
translate es playername_bf1e6533:

    # rp "Is that so?"
    rp "¿Ah, sí?"

# game/game/script.rpy:4852
translate es playername_b3c40050:

    # mc "Yeah it was like-"
    mc "Sí, fue como—"

# game/game/script.rpy:4854
translate es playername_bd111bfb:

    # "I glance up at the news program."
    "Levanto la vista hacia el noticiero."

# game/game/script.rpy:4856
translate es playername_d3f790bb:

    # "On the live screen in the background of the news report showed national hero Binary Star..."
    "En la pantalla en vivo, al fondo del informe, se mostraba al héroe nacional Binary Star..."

# game/game/script.rpy:4869
translate es playername_3d50c2a2:

    # "Talking on his cellphone."
    "Hablando por su teléfono celular."

# game/game/script.rpy:4871
translate es playername_5263abd6:

    # rp "Hello? %(player_name)s?"
    rp "¿Hola? ¿%(player_name)s?"

# game/game/script.rpy:4875
translate es playername_b5ef4c10:

    # "Binary Star's mouth movements lined up perfectly with Ray's voice through the screen."
    "Los movimientos de la boca de Binary Star coincidían perfectamente con la voz de Ray a través del teléfono."

# game/game/script.rpy:4877
translate es playername_9d10fd08:

    # "My mind couldn't believe what it was seeing."
    "Mi mente no podía creer lo que estaba viendo."

# game/game/script.rpy:4879
translate es playername_c1fef349:

    # mc "Hi..."
    mc "Hola..."

# game/game/script.rpy:4881
translate es playername_2c0e8b62:

    # rp "Are you doing okay? You seem kinda off."
    rp "¿Estás bien? Has dejado de hablar."

# game/game/script.rpy:4885
translate es playername_6c587e18:

    # "The movements of Binary Star's mouth matched up perfectly with Ray's voice in my phone."
    "Los movimientos de la boca de Binary Star coincidían exactamente con la voz de Ray en mi teléfono."

# game/game/script.rpy:4889
translate es playername_2fbdb86e:

    # mc "AHH!!"
    mc "¡¡AHH!!"

# game/game/script.rpy:4891
translate es playername_08095554:

    # "Out of shock I hurl my phone across the room."
    "Del susto arrojo el teléfono al otro lado de la habitación."

# game/game/script.rpy:4896
translate es playername_03774899:

    # "It slams into the wall, the screen going black."
    "Golpea la pared, la pantalla se apaga."

# game/game/script.rpy:4898
translate es playername_adc26c66:

    # "I see Binary Star, no, {i} Ray {/i} mouth my name on the tv program first confused, then concerned."
    "Veo a Binary Star —no, {i}Ray{/i}— pronunciar mi nombre en el programa de televisión, primero confundido, luego preocupado."

# game/game/script.rpy:4902
translate es playername_e9d8e2bd:

    # "Ray mouths my name one more time into the phone. He then puts his phone into his pocket."
    "Ray articula mi nombre una vez más hacia el teléfono. Luego guarda el móvil en su bolsillo."

# game/game/script.rpy:4904
translate es playername_c93117cf:

    # "Half a second later a cloud of dust remained from where he once stood."
    "Medio segundo después, solo queda una nube de polvo donde estaba."

# game/game/script.rpy:4911
translate es playername_664bdd1d:

    # "Some part of me knew it would only be a matter of minutes until he was at my door."
    "Algo dentro de mí sabía que solo sería cuestión de minutos antes de que llegara a mi puerta."

# game/game/script.rpy:4913
translate es playername_52e4c7cc:

    # "I grab my jacket and keys running outside as fast as I can."
    "Tomo mi chaqueta y mis llaves y salgo corriendo tan rápido como puedo."

# game/game/script.rpy:4918
translate es playername_7a174519:

    # "My heart was beating a million miles a minute and I knew I needed space for my thoughts to process what I just discovered."
    "Mi corazón late a mil por hora y sé que necesito espacio para procesar lo que acabo de descubrir."

# game/game/script.rpy:4920
translate es playername_b244c1a8:

    # "I sprinted from my apartment building. Once I knew I was in the clear my gait slowed."
    "Salgo corriendo de mi edificio de apartamentos. Una vez que estoy lejos, mi paso se ralentiza."

# game/game/script.rpy:4927
translate es playername_495b9ae9:

    # "{i}Let's just...think {/i}."
    "{i}Solo... pensemos.{/i}"

# game/game/script.rpy:4929
translate es playername_5b572d38:

    # "My heart pounded in my chest as I waked the lonely residential streets."
    "Mi corazón late con fuerza en mi pecho mientras camino por las solitarias calles residenciales."

# game/game/script.rpy:4931
translate es playername_c6424535:

    # "{i}National hero, 'Binary Star' is without a doubt 'Ray' ...a guy who only orders black coffee and always looks tired.{/i}"
    "{i}El héroe nacional 'Binary Star' es, sin lugar a dudas, 'Ray'... un tipo que solo pide café negro y siempre parece cansado.{/i}"

# game/game/script.rpy:4933
translate es playername_f508f595:

    # mc "They just seem nothing alike."
    mc "Simplemente no parecen la misma persona."

# game/game/script.rpy:4935
translate es playername_bd1b5694:

    # mc "But I can't deny that Binary's interview in the magazine had the same interests as Ray."
    mc "Pero no puedo negar que la entrevista de Binary en la revista tenía los mismos intereses que Ray."

# game/game/script.rpy:4937
translate es playername_dbf8e99a:

    # "I mumble to myself."
    "Murmuro."

# game/game/script.rpy:4939
translate es playername_854c4a6d:

    # "{i}Binary Star is always smiling. To the people he is a shining example of patriotism, courage, and kindness.{/i}"
    "{i}Binary Star siempre está sonriendo. Para la gente es un ejemplo brillante de patriotismo, valor y bondad.{/i}"

# game/game/script.rpy:4941
translate es playername_f97679a3:

    # mc "Ray on the other hand..."
    mc "Ray, en cambio..."

# game/game/script.rpy:4943
translate es playername_72cc93e9:

    # "{i}...Looked like he would willingly jump off a bridge at the slightest inconvenience.{/i}"
    "{i}...Parecía alguien que se lanzaría de un puente ante la mínima molestia.{/i}"

# game/game/script.rpy:4945
translate es playername_f159ee43:

    # "I continue to walk, making my way deeper into the suburb."
    "Sigo caminando, adentrándome más en el suburbio."

# game/game/script.rpy:4947
translate es playername_6411d551:

    # "{i} Binary Star is so optimistic and charismatic, but Ray seems like every sentence he utters takes a week off of his life.{/i}"
    "{i}Binary Star es tan optimista y carismático, pero Ray parece que cada frase que dice le quita una semana de vida.{/i}"

# game/game/script.rpy:4949
translate es playername_21a5af1e:

    # "{i}If I didn't see it myself, I truly wouldn't have believed it.{/i}"
    "{i}Si no lo hubiera visto con mis propios ojos, realmente no lo habría creído.{/i}"

# game/game/script.rpy:4951
translate es playername_a2740f11:

    # "I stop in my tracks, a realization coming back to me."
    "Me detengo en seco, una realización vuelve a mí."

# game/game/script.rpy:4953
translate es playername_979faa79:

    # "{i}The Binary Star that saved me, his eyes weren't red. His eyes were a deep black, just like Ray's eyes{/i}."
    "{i}El Binary Star que me salvó no tenía los ojos rojos. Sus ojos eran de un negro profundo, igual que los de Ray.{/i}"

# game/game/script.rpy:4955
translate es playername_4866e711:

    # "I bury my face into my hands and groan."
    "Me cubro la cara con las manos y gimo."

# game/game/script.rpy:4959
translate es playername_e70fc7ab:

    # mc "Have I really been just....flirting with 'Binary Star' this whole time?!"
    mc "¿De verdad he estado... coqueteando con 'Binary Star' todo este tiempo?"

# game/game/script.rpy:4961
translate es playername_7398dcf8:

    # mc "This situation is just so...fucking weird."
    mc "Esta situación es tan... jodidamente rara."

# game/game/script.rpy:4966
translate es playername_5736f7c9:

    # dv "What situation?"
    dv "¿Qué situación?"

# game/game/script.rpy:4968
translate es playername_6139d410:

    # "As I look up I only get a glance at his face before being knocked out cold."
    "Levanto la vista y apenas alcanzo a ver su rostro antes de desmayarme."

# game/game/script.rpy:4975
translate es playername_ace7f5ff:

    # "I soon wake up to the sound of dripping water."
    "Pronto despierto con el sonido del agua goteando."

# game/game/script.rpy:4985
translate es playername_2dc7cb12:

    # "I glance around dreamily."
    "Miro alrededor con mareo."

# game/game/script.rpy:5006
translate es playername_b517aef2:

    # "Soon, I come to."
    "Pronto reacciono."

# game/game/script.rpy:5020
translate es playername_18aa7e32:

    # "{i}This is not my apartment!{/i}"
    "{i}¡Este no es mi apartamento!{/i}"

# game/game/script.rpy:5022
translate es playername_b1e2147b:

    # "I jolt awake whipping my head around desperately."
    "Me incorporo de golpe, mirando desesperadamente a mi alrededor."

# game/game/script.rpy:5024
translate es playername_f5e1bd26:

    # "The scenery of a concrete warehouse graces my vision."
    "La escena de un almacén de concreto llena mi visión."

# game/game/script.rpy:5030
translate es playername_905b72a7:

    # un "'Boss [criminalname] is awake!' One henchman calls."
    un "'¡Jefe [criminalname] despertó!' grita uno de los secuaces."

# game/game/script.rpy:5032
translate es playername_b025990b:

    # "I tried to scream, but the cloth gag prevented me."
    "Intento gritar, pero la mordaza de tela me lo impide."

# game/game/script.rpy:5036
translate es playername_c14a324c:

    # "{i}Classic.{/i}"
    "{i}Clásico.{/i}"

# game/game/script.rpy:5040
translate es playername_d043e703:

    # "As if being summoned by my thoughts, double walks up, crouching in front of me."
    "Como si hubiera sido invocado por mis pensamientos, Double se acerca y se agacha frente a mí."

# game/game/script.rpy:5047
translate es playername_e03af636:

    # dv "Wakey wakey {i}[criminalname]{/i}..."
    dv "Despierta, despierta {i}[criminalname]{/i}..."

# game/game/script.rpy:5051
translate es playername_bbb1e2b4:

    # "He grabs my face jostling it back and forth lightly."
    "Toma mi rostro y lo sacude suavemente de un lado a otro."

# game/game/script.rpy:5053
translate es playername_3530c617:

    # dv "Aw, don't look so spiteful~"
    dv "Aw, no pongas esa cara de rencor~"

# game/game/script.rpy:5055
translate es playername_69290227:

    # dv "You're going to make me feel hurt."
    dv "Vas a hacer que me sienta herido."

# game/game/script.rpy:5057
translate es playername_cd25ef1d:

    # "I yank at my ties but they are so tight that I don't think even I could slip out of them..."
    "Tiro de mis ataduras, pero están tan apretadas que no creo que ni yo pueda soltarlas..."

# game/game/script.rpy:5061
translate es playername_579be2a8:

    # "Double winks as if reading my mind."
    "Double me guiña un ojo como si leyera mi mente."

# game/game/script.rpy:5065
translate es playername_164a71d1:

    # dv "Reinforced just for you."
    dv "Reforzadas solo para ti."

# game/game/script.rpy:5067
translate es playername_01b5494f:

    # dv "And you think I don't know you~"
    dv "Y tú crees que no te conozco~"

# game/game/script.rpy:5071
translate es playername_bcf83843:

    # dv "Let's face it %(player_name)s, {i} nobody {/i} knows you better than I do."
    dv "Seamos sinceros %(player_name)s, {i}nadie{/i} te conoce mejor que yo."

# game/game/script.rpy:5073
translate es playername_689039e3:

    # dv "{i}Nobody.{/i}"
    dv "{i}Nadie.{/i}"

# game/game/script.rpy:5077
translate es playername_79ade95f:

    # "Double pulls out a knife and my blood runs cold."
    "Double saca un cuchillo y mi sangre se hiela."

# game/game/script.rpy:5079
translate es playername_0335cdf4:

    # dv "So I'd like to ask you to {i} stay put {/i}. Kay?"
    dv "Así que me gustaría pedirte que {i}no te muevas{/i}. ¿De acuerdo?"

# game/game/script.rpy:5083
translate es playername_c5edfa31:

    # "I nod slowly."
    "Asiento lentamente."

# game/game/script.rpy:5098
translate es playername_43441fca:

    # "Double's eyes squint into a smile."
    "Los ojos de Double se entrecierran en una sonrisa."

# game/game/script.rpy:5102
translate es playername_9192c91d:

    # dv "Great, glad we are on the same page."
    dv "Genial, me alegra que estemos en la misma página."

# game/game/script.rpy:5106
translate es playername_589a641c:

    # "Double's ability was teleportation."
    "La habilidad de Double era la teletransportación."

# game/game/script.rpy:5108
translate es playername_63ee58e0:

    # "An essentially non-violent power by most people's standards."
    "Un poder esencialmente no violento según los estándares de la mayoría de la gente."

# game/game/script.rpy:5110
translate es playername_948e92de:

    # "But Double himself..."
    "Pero Double..."

# game/game/script.rpy:5112
translate es playername_fcf349d9:

    # "Is a monster."
    "Es un monstruo."

# game/game/script.rpy:5114
translate es playername_f1c09867:

    # "And the way he could use his ability was creatively horrific..."
    "Y la forma en que podía usar su habilidad era creativamente horrenda..."

# game/game/script.rpy:5120
translate es playername_1727deeb:

    # "I stare at Double in defiance."
    "Miro a Double con desafío."

# game/game/script.rpy:5122
translate es playername_b84b88bd:

    # dv "Ohh {i} look at you. {/i}"
    dv "Ohh {i}mírate.{/i}"

# game/game/script.rpy:5124
translate es playername_2bab9b61:

    # "He grabs my face between his index and thumb jostling me lightly."
    "Toma mi rostro entre su índice y su pulgar, sacudiéndolo ligeramente."

# game/game/script.rpy:5128
translate es playername_196e3381:

    # dv "You are {i} so fucking cute. {/i}"
    dv "Eres {i}tan jodidamente adorable.{/i}"

# game/game/script.rpy:5132
translate es playername_161313bf:

    # dv "This is why I just {i} had {/i} to have you back all to myself %(player_name)s."
    dv "Por eso simplemente {i}tenía{/i} que tenerte de vuelta solo para mí, %(player_name)s."

# game/game/script.rpy:5134
translate es playername_f2c31f11:

    # dv "When you glare like that I just know I can't give you up to anyone else."
    dv "Cuando me miras así, sé que no puedo entregarte a nadie más."

# game/game/script.rpy:5136
translate es playername_b4581717:

    # "He sighs in an almost dreamlike way. His smile is genuine, as if he is truly having fun."
    "Suspira de una forma casi soñadora. Su sonrisa es genuina, como si realmente se estuviera divirtiendo."

# game/game/script.rpy:5138
translate es playername_6e8ca6ed:

    # "{i} Fucking psycho... {/i}"
    "{i}Maldito psicópata...{/i}"

# game/game/script.rpy:5142
translate es playername_2b9140fa:

    # dv "Though, i'm not sure if our crew will be able to forgive you..."
    dv "Aunque, no estoy seguro de que nuestra banda pueda perdonarte..."

# game/game/script.rpy:5146
translate es playername_494e0564:

    # "I look up noticing the 20 or so henchmen that surround Double."
    "Levanto la vista y noto a los veinte o más secuaces que rodean a Double."

# game/game/script.rpy:5148
translate es playername_eb12ec46:

    # "I spot Ripley but he refuses to make eye contact with me."
    "Distingo a Ripley, pero se niega a hacer contacto visual conmigo."

# game/game/script.rpy:5168
translate es playername_d8b719c7:

    # "Guilt clouds his features as he stares off into space very intentionally."
    "La culpa nubla sus facciones mientras mira al vacío intencionadamente."

# game/game/script.rpy:5170
translate es playername_ad1b26c3:

    # "I felt a form of rage that I couldn't quite explain..."
    "Sentí una forma de rabia que no podía explicar..."

# game/game/script.rpy:5184
translate es playername_9d1627d1:

    # "...despite the fact that Ripley has already been through what I was about to go through."
    "...a pesar de que Ripley ya había pasado por lo que yo estaba a punto de sufrir."

# game/game/script.rpy:5203
translate es playername_3c95a235:

    # cg "{color=#1F28AD} 'You see, my men here want to rip your throat out.' {/color}"
    cg "{color=#1F28AD} 'Verás, mis hombres aquí quieren arrancarte la garganta.' {/color}"

# game/game/script.rpy:5205
translate es playername_442d053d:

    # cg "{color=#1F28AD} 'Do some lasting damage.' {/color}"
    cg "{color=#1F28AD} 'Hacerte un daño duradero.' {/color}"

# game/game/script.rpy:5214
translate es playername_7cfebec3:

    # cg "{color=#1F28AD} 'You betrayed us {i}[criminalname]{/i}.' {/color}"
    cg "{color=#1F28AD} 'Nos traicionaste {i}[criminalname]{/i}.' {/color}"

# game/game/script.rpy:5216
translate es playername_b25f67ac:

    # cg "He spits my old alias out of his mouth as if it were the remains of a chewed up sunflower seed."
    cg "Escupe mi antiguo alias de su boca como si fueran los restos de una semilla de girasol masticada."

# game/game/script.rpy:5218
translate es playername_3f1c080a:

    # cg "{color=#1F28AD} 'And that hurt. We were family, closer than family.' {/color}"
    cg "{color=#1F28AD} 'Y eso dolió. Éramos familia, más que familia.' {/color}"

# game/game/script.rpy:5220
translate es playername_f0594ee7:

    # cg "{color=#1F28AD} 'Right?' {/color}"
    cg "{color=#1F28AD} '¿Verdad?' {/color}"

# game/game/script.rpy:5224
translate es playername_f776d5c2:

    # cg "All of the henchmen shout agreements."
    cg "Todos los secuaces gritan de acuerdo."

# game/game/script.rpy:5226
translate es playername_07e541b6:

    # cg "It was obvious that their rage has been worked up by Double for {i} months {/i} at this point."
    cg "Era evidente que Double había alimentado su ira durante {i}meses{/i}."

# game/game/script.rpy:5228
translate es playername_321f8b7e:

    # cg "{i}...and now they wanted to get even.{/i}"
    cg "{i}...y ahora querían vengarse.{/i}"

# game/game/script.rpy:5230
translate es playername_01584cb9:

    # cg "I tried to stop my body from shaking but it was in vain."
    cg "Intenté evitar que mi cuerpo temblara, pero fue en vano."

# game/game/script.rpy:5237
translate es playername_e96db964:

    # cg "Double catches my feeble attempts and smiles. Evil, intentional."
    cg "Double nota mis débiles intentos y sonríe. Malvado, deliberado."

# game/game/script.rpy:5239
translate es playername_882b3656:

    # cg "{color=#1F28AD} 'Now Night Crew...' {/color}"
    cg "{color=#1F28AD} 'Ahora, Night Crew...' {/color}"

# game/game/script.rpy:5243
translate es playername_c77a05b6:

    # cg "{color=#1F28AD} 'What do we think would even the scales?' {/color}"
    cg "{color=#1F28AD} '¿Qué creen que equilibraría la balanza?' {/color}"

# game/game/script.rpy:5245
translate es playername_f2d9178f:

    # cg "{color=#1F28AD} 'An eye for an eye right?' {/color}"
    cg "{color=#1F28AD} '¿Un ojo por un ojo, cierto?' {/color}"

# game/game/script.rpy:5247
translate es playername_2f0875fd:

    # cg "{color=#1F28AD} 'What our little [criminalname] did to us, is a betrayal that will never heal...' {/color}"
    cg "{color=#1F28AD} 'Lo que [criminalname] nos hizo es una traición que nunca sanará...' {/color}"

# game/game/script.rpy:5249
translate es playername_23ff32d3:

    # cg "{color=#1F28AD} '{i}So{/i}, I would like to encourage something that is also lasting.' {/color}"
    cg "{color=#1F28AD} '{i}Así que{/i}, me gustaría fomentar algo que también sea duradero.' {/color}"

# game/game/script.rpy:5251
translate es playername_08d4aa02:

    # cg "{color=#1F28AD} 'So our dear [criminalname] will never forget their betrayal of the crew.' {/color}"
    cg "{color=#1F28AD} 'Para que [criminalname] nunca olvide su traición a la banda.' {/color}"

# game/game/script.rpy:5253
translate es playername_2151f99a:

    # cg "Double laughs, glancing at me."
    cg "Double ríe, echándome una mirada."

# game/game/script.rpy:5255
translate es playername_98666275:

    # cg "{color=#1F28AD} {i}'Poetic don't ya think?'{/i}{/color}"
    cg "{color=#1F28AD}{i}'Poético, ¿no crees?'{/i}{/color}"

# game/game/script.rpy:5257
translate es playername_bf6b6fe2:

    # cg "The henchmen get eager. I see a fair amount of faces in the crowd that I haven't seen before."
    cg "Los secuaces se entusiasman. Veo muchas caras que no había visto antes."

# game/game/script.rpy:5259
translate es playername_2708273b:

    # cg "And some faces I used to know are gone..."
    cg "Y algunas caras que solía conocer ya no están..."

# game/game/script.rpy:5261
translate es playername_4b20395d:

    # cg "I can't suppress the shiver that runs down my spine at the thought of what could have possibly happened to them."
    cg "No puedo reprimir el escalofrío que recorre mi espalda al pensar en lo que pudo haberles ocurrido."

# game/game/script.rpy:5268
translate es playername_5c4d6937:

    # cg "{color=#1F28AD} 'So, men, what would even the scales?"
    cg "{color=#1F28AD} 'Entonces, hombres, ¿qué equilibraría la balanza?"

# game/game/script.rpy:5272
translate es playername_01056e72:

    # hm "A finger!"
    hm "¡Un dedo!' {/color}"

# game/game/script.rpy:5274
translate es playername_91acb976:

    # cg "A henchman shouts, the excitement in his tone makes my blood run cold."
    cg "Grita un secuaz, la emoción en su tono hace que mi sangre se congele."

# game/game/script.rpy:5276
translate es playername_961f7df3:

    # hm2 "{i}Two{/i} fingers!"
    hm2 "{i}¡Dos{/i} dedos!"

# game/game/script.rpy:5278
translate es playername_8e095e59:

    # cg "The men laugh at the casual one-upping, as if the reality of my fingers weren't at stake right in front of them."
    cg "Los hombres ríen con esa competencia casual, como si la realidad de mis dedos no estuviera en juego justo frente a ellos."

# game/game/script.rpy:5280
translate es playername_d10e4c2a:

    # cg "I fight against my own brain that so desperately wants to disassociate."
    cg "Lucho contra mi propio cerebro que desesperadamente quiere disociarse."

# game/game/script.rpy:5288
translate es playername_cdc8d9c4:

    # cg "{color=#1F28AD} 'Aww [criminalname], you are {i}so{/i} popular~' {/color}"
    cg "{color=#1F28AD} 'Aww [criminalname], eres {i}tan{/i} popular~' {/color}"

# game/game/script.rpy:5290
translate es playername_82f5eefc:

    # cg "{color=#1F28AD} 'Looks like they want any part of you!' {/color}"
    cg "{color=#1F28AD} '¡Parece que todos quieren una parte de ti!' {/color}"

# game/game/script.rpy:5301
translate es playername_50781f0f:

    # "Double laughs, genuinely enjoying my fear and the chaos."
    "Double ríe, disfrutando genuinamente de mi miedo y del caos."

# game/game/script.rpy:5303
translate es playername_6f7cd243:

    # "The crowd goes wild and my stomach churns violently."
    "La multitud enloquece y mi estómago se revuelve violentamente."

# game/game/script.rpy:5307
translate es playername_917316cf:

    # dv "So we have our conclusion then?"
    dv "¿Entonces ya tenemos nuestra conclusión?"

# game/game/script.rpy:5311
translate es playername_805e23fc:

    # "The men cheer."
    "Los hombres vitorean."

# game/game/script.rpy:5313
translate es playername_59cc763d:

    # "He holds out his hand and the knife is replaced with a larger machete."
    "Extiende su mano y el cuchillo se transforma en un machete más grande."

# game/game/script.rpy:5317
translate es playername_f5f07d80:

    # dv "Ripley bring the ice."
    dv "Ripley, trae el hielo."

# game/game/script.rpy:5319
translate es playername_dc53e24e:

    # "Double turns to me smiling."
    "Double se vuelve hacia mí sonriendo."

# game/game/script.rpy:5321
translate es playername_56e2714e:

    # dv "So heres the deal honey-"
    dv "Así que aquí está el trato, cariño—"

# game/game/script.rpy:5323
translate es playername_ec0d6a33:

    # "He unwraps my ties, grabbing one of my wrists and slamming my hand down on the cinder block in front of me."
    "Desata mis ataduras, toma una de mis muñecas y golpea mi mano contra el bloque de cemento frente a mí."

# game/game/script.rpy:5329
translate es playername_de68065f:

    # dv "I'm going to cut two fingers off."
    dv "Voy a cortarte dos dedos."

# game/game/script.rpy:5332
translate es playername_6924303c:

    # dv "One of them I'll be keeping for myself..."
    dv "Uno de ellos me lo quedaré yo..."

# game/game/script.rpy:5334
translate es playername_f617f559:

    # dv "As a little token of penance for what you did."
    dv "Como pequeño recordatorio de lo que hiciste."

# game/game/script.rpy:5338
translate es playername_043e78bf:

    # dv "The other... I'll give it back to you all nicely wrapped up in an ice bag."
    dv "El otro... te lo devolveré bien envuelto en una bolsa con hielo."

# game/game/script.rpy:5342
translate es playername_473a0f32:

    # dv "I'll even let you choose which finger you want to keep."
    dv "Incluso te dejaré elegir qué dedo quieres conservar."

# game/game/script.rpy:5344
translate es playername_eaa55877:

    # dv "I want you to have that decision because I love you~"
    dv "Quiero que tomes esa decisión porque te amo~"

# game/game/script.rpy:5349
translate es playername_9fb9fa19:

    # dv "Then you will be free to desperately search for an ER to reattach it for you."
    dv "Luego serás libre de buscar desesperadamente una sala de urgencias para que te lo reimplanten."

# game/game/script.rpy:5364
translate es playername_6bae5c64:

    # dv "{i}Just like I desperately searched and searched for you.{/i}"
    dv "{i}Así como yo busqué y busqué desesperadamente por ti.{/i}"

# game/game/script.rpy:5366
translate es playername_5804aaf7:

    # "He leans back, a shallow smile on his lips."
    "Se reclina, con una sonrisa leve en los labios."

# game/game/script.rpy:5380
translate es playername_6e3fdb10:

    # "He folds my fingers except for my index."
    "Dobla mis dedos, dejando solo el índice extendido."

# game/game/script.rpy:5384
translate es playername_860d95d3:

    # dv "Don't squirm so much. If I mangle it or make the cut too low, they won't be able to reattach it."
    dv "No te muevas tanto. Si lo destrozo o corto demasiado abajo, no podrán volver a unirlo."

# game/game/script.rpy:5386
translate es playername_9a0ea781:

    # "He touches the cold knife to my finger making a small cut where he plans to aim for."
    "Apoya el frío filo del cuchillo en mi dedo, haciendo un pequeño corte donde planea apuntar."

# game/game/script.rpy:5388
translate es playername_f2ab3ffe:

    # "My stomach twists."
    "Mi estómago se retuerce."

# game/game/script.rpy:5403
translate es playername_a637f4b3:

    # "I attempt to look away but his hand with the machete quickly moves to my face."
    "Intento apartar la mirada, pero su mano con el machete se mueve rápidamente hacia mi cara."

# game/game/script.rpy:5418
translate es playername_a5a1da47:

    # "He grasps my jaw, forcing my face back to it's original position."
    "Sujeta mi mandíbula, obligándome a mirar de nuevo."

# game/game/script.rpy:5420
translate es playername_8e30e5e5:

    # dv "No. Don't you dare look away from me. From this."
    dv "No. No te atrevas a apartar la mirada de mí. De esto."

# game/game/script.rpy:5424
translate es playername_3a1e0015:

    # dv "You have to witness the loss of something valuable {i}just like I did{/i}."
    dv "Tienes que presenciar la pérdida de algo valioso {i}igual que yo{/i}."

# game/game/script.rpy:5428
translate es playername_e888c660:

    # dv "If you close your eyes, I will take another finger for good measure."
    dv "Si cierras los ojos, te quitaré otro dedo por precaución."

# game/game/script.rpy:5431
translate es playername_4c5739c4:

    # "Tears begin to streak down my face."
    "Las lágrimas comienzan a deslizarse por mi rostro."

# game/game/script.rpy:5435
translate es playername_d6c8abbf:

    # dv "Oh %(player_name)s...ohh it's okay."
    dv "Oh %(player_name)s... ohh, está bien."

# game/game/script.rpy:5437
translate es playername_7ec02cac:

    # "Double coos stroking away some tears before moving back to my wrist."
    "Murmura Double, acariciando mis lágrimas antes de volver a mi muñeca."

# game/game/script.rpy:5439
translate es playername_310b67ee:

    # dv "Don't cry honey, this will be over before you can blink."
    dv "No llores, cariño, esto terminará antes de que puedas parpadear."

# game/game/script.rpy:5441
translate es playername_d6440a11:

    # "The tears refuse to stop as I begin to sob out of fear."
    "Las lágrimas no se detienen mientras empiezo a sollozar de miedo."

# game/game/script.rpy:5443
translate es playername_a4ec8900:

    # dv "I'll take care of you nicely throughout the healing process...I promise."
    dv "Te cuidaré bien durante el proceso de sanación... lo prometo."

# game/game/script.rpy:5458
translate es playername_e99e980b:

    # "He leans forward placing a few kisses on my tear-stained cheeks through his mask."
    "Se inclina hacia adelante y deposita algunos besos sobre mis mejillas empapadas en lágrimas a través de su máscara."

# game/game/script.rpy:5460
translate es playername_1123fa48:

    # "He then leans back with a wide smile under his mask."
    "Luego se recuesta con una amplia sonrisa bajo su máscara."

# game/game/script.rpy:5475
translate es playername_cc3b5d16:

    # "I shake knowing what was coming next."
    "Tiemblo, sabiendo lo que vendría a continuación."

# game/game/script.rpy:5479
translate es playername_8f54ec75:

    # "He raises the large knife in what feels to be slow motion."
    "Levanta el gran cuchillo en lo que parece cámara lenta."

# game/game/script.rpy:5483
translate es playername_2028333b:

    # r "What the fuck do you think you're doing?"
    r "¿Qué demonios crees que estás haciendo?"

# game/game/script.rpy:5494
translate es playername_265333f7:

    # "I look in disbelief."
    "Miro incrédulo."

# game/game/script.rpy:5496
translate es playername_09e4413b:

    # "{i}Ray...!{/i}"
    "{i}¡Ray...!{/i}"

# game/game/script.rpy:5498
translate es playername_79fbdca9:

    # "I start to yell under my mouth gag."
    "Intento gritar bajo la mordaza que me cubre la boca."

# game/game/script.rpy:5500
translate es playername_459b2839:

    # "{i}Double is going to kill him if he stays here!{/i}"
    "{i}¡Double va a matarlo si se queda aquí!{/i}"

# game/game/script.rpy:5502
translate es playername_23111b0e:

    # "I panic but my screams are stopped by the gag that wraps my mouth."
    "Entro en pánico, pero mis gritos se ahogan por la mordaza que me cubre la boca."

# game/game/script.rpy:5508
translate es playername_d7f36d0c:

    # "Double becomes annoyed and grabs my face violently looking at me square in the eye."
    "Double se irrita y agarra mi rostro violentamente, mirándome directamente a los ojos."

# game/game/script.rpy:5510
translate es playername_7e49949d:

    # "I become silent at Double's stare."
    "Guardo silencio ante la mirada de Double."

# game/game/script.rpy:5514
translate es playername_8fce9793:

    # "Ray seems incredibly upset."
    "Ray parece increíblemente molesto."

# game/game/script.rpy:5518
translate es playername_033fe7ff:

    # r "Let go."
    r "Suéltale."

# game/game/script.rpy:5520
translate es playername_d4f76d7a:

    # "Ray glares at Double who just laughs."
    "Ray fulmina a Double con la mirada, quien solo ríe."

# game/game/script.rpy:5547
translate es playername_dd0f2b94:

    # "He gets up facing Ray who steps closer."
    "Se levanta frente a Ray, que da un paso adelante."

# game/game/script.rpy:5552
translate es playername_c80273aa:

    # dv "I'm sorry? {i}Who {/i} are you?"
    dv "¿Perdón? ¿{i}Quién{/i} eres tú?"

# game/game/script.rpy:5554
translate es playername_7f2c520f:

    # "Ray just stares, the same deep glare adorning his face."
    "Ray simplemente lo observa, con esa misma mirada profunda en el rostro."

# game/game/script.rpy:5556
translate es playername_d127bd43:

    # dv "Look, for your own well being I'd advise you to just move along."
    dv "Mira, por tu propio bien, te aconsejaría que siguieras tu camino."

# game/game/script.rpy:5558
translate es playername_6ae8f664:

    # dv "You are interrupting a pivotal moment here."
    dv "Estás interrumpiendo un momento crucial aquí."

# game/game/script.rpy:5562
translate es playername_f24bea0e:

    # r "{i}let go of %(player_name)s.{/i}"
    r "{i}Suelta a %(player_name)s.{/i}"

# game/game/script.rpy:5567
translate es playername_96e07fff:

    # "Now Double looks ticked off."
    "Ahora Double parece enfadado."

# game/game/script.rpy:5569
translate es playername_817a2995:

    # r "Let me take %(player_name)s and go. Then you and your cronies can be free to do ....whatever you do."
    r "Déjame llevarme a %(player_name)s y nos vamos. Luego tú y tus lacayos pueden dedicarse a... lo que sea que hagan."

# game/game/script.rpy:5571
translate es playername_854bc177:

    # "Double laughs without humor."
    "Double ríe sin humor."

# game/game/script.rpy:5575
translate es playername_73294c1c:

    # dv "Fine, you want to stick around? Don't tell me I didn't warn you-"
    dv "Bien, ¿quieres quedarte? No digas que no te lo advertí—"

# game/game/script.rpy:5577
translate es playername_ca4df499:

    # "Ray's stern voice cuts off Double."
    "La voz firme de Ray interrumpe a Double."

# game/game/script.rpy:5581
translate es playername_bbb98c2c:

    # r "I don't think you heard me properly."
    r "No creo que me hayas escuchado bien."

# game/game/script.rpy:5585
translate es playername_1e866433:

    # r "I said {b}{i}Fuck. Off.{/i}{/b}"
    r "Dije {b}{i}Lárgate.{/i}{/b}"

# game/game/script.rpy:5587
translate es playername_dd627d73:

    # "Ray's eyes flash a familiar red."
    "Los ojos de Ray brillan con un rojo familiar."

# game/game/script.rpy:5589
translate es playername_2be92f92:

    # "A red glow I had seen adorn posters and news programs for years."
    "Un resplandor rojo que había visto en carteles y noticieros durante años."

# game/game/script.rpy:5595
translate es playername_ca18ab7b:

    # "Double laughs."
    "Double ríe."

# game/game/script.rpy:5599
translate es playername_734dea5b:

    # dv "Oh you have got to be fucking kidding me!"
    dv "¡Oh, tienes que estar jodiéndome!"

# game/game/script.rpy:5601
translate es playername_ae9d7fb9:

    # "Double turns to me incredulously."
    "Double se vuelve hacia mí, incrédulo."

# game/game/script.rpy:5603
translate es playername_849298ec:

    # dv "{i}This{/i} is your watchdog? Fucking {i}Binary Star{/i}?!"
    dv "¿{i}Él{/i} es tu perro guardián? ¿El maldito {i}Binary Star{/i}?!"

# game/game/script.rpy:5605
translate es playername_5daa6bde:

    # "Double paces, clearly frustrated."
    "Double camina de un lado a otro, visiblemente frustrado."

# game/game/script.rpy:5607
translate es playername_3b6a8b5d:

    # dv "Out of everyone, {i}this{/i} is your hero boy-toy?"
    dv "De entre todos, ¿{i}éste{/i} es tu héroe, tu chico bonito?"

# game/game/script.rpy:5609
translate es playername_1cf2ca57:

    # dv "Goddammit..."
    dv "Maldita sea..."

# game/game/script.rpy:5611
translate es playername_b1f0c291:

    # "Ray just stands there glowering at Double."
    "Ray simplemente se queda allí, lanzándole una mirada fulminante a Double."

# game/game/script.rpy:5613
translate es playername_737d8773:

    # "Ray shoots a glance at my face and his expression becomes more furious than ever."
    "Ray lanza una mirada a mi rostro y su expresión se vuelve más furiosa que nunca."

# game/game/script.rpy:5617
translate es playername_865b1268:

    # dv "Fine! Whatever! I guess I'll be the first to take down Binary Star then."
    dv "¡Bien! ¡Como sea! Supongo que seré el primero en derribar a Binary Star, entonces."

# game/game/script.rpy:5632
translate es playername_1de44f15:

    # "Double throws the knife but in a split second it is cut down by an angry red laser."
    "Double lanza el cuchillo, pero en una fracción de segundo es destruido por un láser rojo de ira."

# game/game/script.rpy:5640
translate es playername_2d825896:

    # "With a yell the henchmen run towards Ray their weapons in tow."
    "Con un grito, los secuaces corren hacia Ray con sus armas en mano."

# game/game/script.rpy:5660
translate es playername_33a25fd7:

    # "Blood splatters across my body..."
    "La sangre salpica mi cuerpo..."

# game/game/script.rpy:5662
translate es playername_7d2fa532:

    # "As the henchman to the left of me is sliced cleanly in two...."
    "Mientras el secuaz a mi izquierda es partido limpiamente en dos..."

# game/game/script.rpy:5666
translate es playername_82ef0372:

    # "His blood splashes against the ground."
    "Su sangre se derrama sobre el suelo."

# game/game/script.rpy:5670
translate es playername_18434762:

    # "What happens next is only what can be described as a one-sided blood bath."
    "Lo que ocurre después solo puede describirse como una masacre unilateral."

# game/game/script.rpy:5672
translate es playername_b5a91328:

    # "The Henchmen soon realized they were no competition for the top hero 'Binary Star'."
    "Los secuaces pronto se dieron cuenta de que no eran competencia para el héroe número uno, 'Binary Star'."

# game/game/script.rpy:5676
translate es playername_550ac6a8:

    # "Some attempted to flee."
    "Algunos intentaron huir."

# game/game/script.rpy:5680
translate es playername_eaa3ecd3:

    # "But that didn't stop Binary Star from slaughtering them like a child stomping a line of ants."
    "Pero eso no detuvo a Binary Star de masacrarlos como un niño pisoteando una fila de hormigas."

# game/game/script.rpy:5691
translate es playername_b2e28feb:

    # "As I sat tied up, severed body parts dropped to the ground like pinata party favors."
    "Mientras yo permanecía con las manos atadas, partes del cuerpo caían al suelo como si fueran dulces de una piñata."

# game/game/script.rpy:5693
translate es playername_6ab4305e:

    # "Organs spilled out of torsos mid-run. They splayed across the ground with splatters that made my mind go numb."
    "Los órganos se derramaban de los torsos en plena huida. Se extendían por el suelo con salpicaduras que entumecían mi mente."

# game/game/script.rpy:5695
translate es playername_6048bbbd:

    # "Double took advantage of Binary Star being distracted with his henchmen. In a split second Double used his ability and phased away."
    "Double aprovechó que Binary Star estaba distraído con sus secuaces. En una fracción de segundo, Double usó su habilidad y desapareció."

# game/game/script.rpy:5697
translate es playername_00755a3c:

    # "I couldn't move, I couldn't scream, my mind was no longer living in the same moment my body was."
    "No podía moverme, no podía gritar, mi mente ya no vivía en el mismo momento que mi cuerpo."

# game/game/script.rpy:5702
translate es playername_94c735ea:

    # "After what felt was hours, but likely only a few minutes, the last body cracked against the floor."
    "Después de lo que parecieron horas, pero probablemente solo fueron unos minutos, el último cuerpo cayó al suelo con un golpe seco."

# game/game/script.rpy:5704
translate es playername_a7ac4571:

    # "As the concrete floor was decorated like an abstract painting, the Binary star approaches me."
    "Mientras el suelo de cemento quedaba decorado como una pintura abstracta, Binary Star se acerca a mí."

# game/game/script.rpy:5712
translate es playername_8ee21531:

    # cg "He hunches down with the knife he picked up from the ground."
    cg "Se agacha con el cuchillo que recogió del suelo."

# game/game/script.rpy:5714
translate es playername_6de1c188:

    # cg "With the knife he cuts the ties from my wrists."
    cg "Con el cuchillo corta las ataduras de mis muñecas."

# game/game/script.rpy:5716
translate es playername_2208345a:

    # cg "I notice eyes are back to black."
    cg "Noto que sus ojos han vuelto a ser negros."

# game/game/script.rpy:5718
translate es playername_d8fa465f:

    # cg "Some part of me is thankful for it."
    cg "Una parte de mí se siente agradecida por eso."

# game/game/script.rpy:5720
translate es playername_8bdd5dbb:

    # cg "But like a gun with the safety on, I feel as relieved as I can knowing danger is only an impulse away."
    cg "Pero, como una pistola con el seguro puesto, siento alivio sabiendo que el peligro está solo a un impulso de distancia."

# game/game/script.rpy:5722
translate es playername_9b1e4b73:

    # cg "{color=#CD9300}'%(player_name)s...'{/color}"
    cg "{color=#CD9300}'%(player_name)s...'{/color}"

# game/game/script.rpy:5724
translate es playername_7b63530f:

    # cg "{color=#CD9300}'Are you okay?'{/color}"
    cg "{color=#CD9300}'¿Estás bien?'{/color}"

# game/game/script.rpy:5726
translate es playername_b4adbca3:

    # cg "I can see him say something in a far off place, but my brain does not register."
    cg "Puedo verlo decir algo desde un lugar lejano, pero mi cerebro no lo registra."

# game/game/script.rpy:5728
translate es playername_e1c7e272:

    # cg "{color=#CD9300}'%(player_name)s...?'{/color}"
    cg "{color=#CD9300}'%(player_name)s...?'{/color}"

# game/game/script.rpy:5730
translate es playername_134ff183:

    # cg "He brushes my cheek with his sleeve. I can feel the wet being smeared off."
    cg "Rozó mi mejilla con su manga. Siento cómo limpia la humedad."

# game/game/script.rpy:5732
translate es playername_11ec824c:

    # cg "I exist in a different world at this point."
    cg "En este punto existo en un mundo diferente."

# game/game/script.rpy:5734
translate es playername_f563cc48:

    # cg "I can't even feel my beating heart or my uneven breath."
    cg "Ni siquiera siento mi corazón latiendo ni mi respiración irregular."

# game/game/script.rpy:5736
translate es playername_10f1d5a1:

    # cg "I simply know they are there without me and that is all."
    cg "Simplemente sé que están ahí sin mí, y eso es todo."

# game/game/script.rpy:5738
translate es playername_a3b23494:

    # cg "I look at {i} his {/i} face, smeared with death."
    cg "Miro su rostro, {i}manchado de muerte.{/i}"

# game/game/script.rpy:5740
translate es playername_9539bc84:

    # cg "He has a peculiar expression, something I can't quite place."
    cg "Tiene una expresión peculiar, algo que no logro descifrar."

# game/game/script.rpy:5742
translate es playername_6a17a74b:

    # cg "{color=#CD9300}'Don't worry, we are going to get you home.'{/color}"
    cg "{color=#CD9300}'No te preocupes, te llevaremos a casa.'{/color}"

# game/game/script.rpy:5744
translate es playername_6c0300eb:

    # cg "As he says my name, I try to respond but no words surface."
    cg "Cuando dice mi nombre, intento responder, pero no salen palabras."

# game/game/script.rpy:5746
translate es playername_61becf71:

    # cg "{color=#CD9300}'Do you think you can get up?'{/color}"
    cg "{color=#CD9300}'¿Crees que puedes levantarte?'{/color}"

# game/game/script.rpy:5748
translate es playername_59328b46:

    # cg "Like a puppet I try to follow his words, but the minute I stand the world spins and I plummet towards darkness."
    cg "Como una marioneta, intento seguir sus palabras, pero en cuanto me pongo de pie el mundo gira y caigo en la oscuridad."

# game/game/script.rpy:5759
translate es playername_a8cec96f:

    # "I wake up with a start."
    "Despierto de un sobresalto."

# game/game/script.rpy:5771
translate es playername_1effe7b4:

    # "Seeing my roof, feeling my bed sheets helps to ground me."
    "Ver mi techo, sentir mis sábanas, me ayuda a ubicarme."

# game/game/script.rpy:5773
translate es playername_7f7d318a:

    # mc "When did I change into my pajamas...?"
    mc "¿Cuándo me puse el pijama...?"

# game/game/script.rpy:5777
translate es playername_be9c953d:

    # cg "{color=#CD9300}Hm? Oh, I helped.{/color}"
    cg "{color=#CD9300}¿Hm? Oh, te ayudé.{/color}"

# game/game/script.rpy:5791
translate es playername_4fe28f97:

    # cg "I yell in surprise, whipping my head towards the window."
    cg "Grito por la sorpresa, girando la cabeza hacia la ventana. "

# game/game/script.rpy:5808
translate es playername_71702be4:

    # cg "By the window leaned a casual Ray."
    cg "Apoyado en la ventana estaba Ray, con aire casual."

# game/game/script.rpy:5821
translate es playername_197a4b83:

    # cg "He smokes a cigarette, blowing the smoke out of the window."
    cg "Fuma un cigarrillo, exhalando el humo hacia afuera."

# game/game/script.rpy:5837
translate es playername_da6c9039:

    # cg "We look at each other in silence for a minute before he speaks up."
    cg "Nos miramos en silencio por un minuto antes de que hable."

# game/game/script.rpy:5841
translate es playername_0d7f42f8:

    # cg "{color=#CD9300}'You slept pretty deeply, you were out of it.'{/color}"
    cg "{color=#CD9300}'Dormiste bastante profundo, estabas fuera de todo.'{/color}"

# game/game/script.rpy:5843
translate es playername_23347550:

    # cg "{color=#CD9300} 'It would probably be best if you got some more sleep.'{/color}"
    cg "{color=#CD9300}'Probablemente sería mejor que durmieras un poco más.'{/color}"

# game/game/script.rpy:5845
translate es playername_f4bfdc9a:

    # cg "My body shakes at the memories that swarm me."
    cg "Mi cuerpo tiembla ante los recuerdos que me invaden."

# game/game/script.rpy:5847
translate es playername_c1de6355:

    # cg "{i}Does that mean it wasn't a dream...?{/i}"
    cg "{i}¿Eso significa que no fue un sueño...?{/i}"

# game/game/script.rpy:5849
translate es playername_ea195bc5:

    # cg "{color=#CD9300} 'You weren't dreaming...' {/color}"
    cg "{color=#CD9300}'No estabas soñando...'{/color}"

# game/game/script.rpy:5851
translate es playername_3200caac:

    # cg "{i}Did he just read my thoughts...?{/i}"
    cg "{i}¿Acaba de leer mis pensamientos...?{/i}"

# game/game/script.rpy:5859
translate es playername_eb6c60a9:

    # cg "{color=#CD9300}'Sorry... it's a bad habit.'{/color}"
    cg "{color=#CD9300}'Perdón... es un mal hábito.'{/color}"

# game/game/script.rpy:5861
translate es playername_415b352e:

    # cg "I touch my face, there is no blood on it."
    cg "Toco mi rostro, no hay sangre en él."

# game/game/script.rpy:5863
translate es playername_309dbb6e:

    # cg "'How...?'"
    cg "'¿Cómo...?'"

# game/game/script.rpy:5873
translate es playername_81bca5b8:

    # cg "Ray grimaces and blows more smoke out the window."
    cg "Ray hace una mueca y exhala más humo por la ventana."

# game/game/script.rpy:5875
translate es playername_726d9781:

    # cg "{color=#CD9300}'You ...don't remember taking a shower when you got back...?'{/color}"
    cg "{color=#CD9300}'¿No recuerdas haberte duchado cuando regresaste...?'{/color}"

# game/game/script.rpy:5877
translate es playername_6682d492:

    # cg "I shake my head slowly feeling confused, some distant memories start to return."
    cg "Niego lentamente con la cabeza, sintiéndome confundida, algunos recuerdos lejanos comienzan a volver."

# game/game/script.rpy:5879
translate es playername_c58a4a73:

    # cg "{color=#CD9300}'It will probably all come back with enough rest... just try to take it easy for now.'{/color}"
    cg "{color=#CD9300}'Probablemente todo volverá con suficiente descanso... solo trata de tomártelo con calma por ahora.'{/color}"

# game/game/script.rpy:5881
translate es playername_d88a601f:

    # cg "I try to find the proper response but words don't formulate."
    cg "Intento encontrar una respuesta adecuada, pero las palabras no se forman."

# game/game/script.rpy:5883
translate es playername_826e7994:

    # cg "I nod."
    cg "Asiento."

# game/game/script.rpy:5885
translate es playername_54dfc922:

    # cg "Ray sighs."
    cg "Ray suspira."

# game/game/script.rpy:5893
translate es playername_c54b63a2:

    # cg "{color=#CD9300}'.....can I come over there?'{/color}"
    cg "{color=#CD9300}'.....¿Puedo acercarme?'{/color}"

# game/game/script.rpy:5895
translate es playername_a93fa8d0:

    # cg "I slowly nod again, unsure if I completely meant it."
    cg "Asiento lentamente otra vez, sin saber de si realmente lo quiero."

# game/game/script.rpy:5906
translate es playername_3cd17d4b:

    # "Ray pushes himself off the wall he was leaning against."
    "Ray se separa de la pared en la que estaba apoyado."

# game/game/script.rpy:5908
translate es playername_be24fcc8:

    # "He places his cigarette in the ashtray and turns towards me."
    "Coloca su cigarrillo en el cenicero y se gira hacia mí."

# game/game/script.rpy:5924
translate es playername_5a63c6b6:

    # "He approaches me and I can't help but to flinch."
    "Se acerca y no puedo evitar estremecerme."

# game/game/script.rpy:5930
translate es playername_ae6783a6:

    # "He carefully sits down at the edge of my bed and I can't help but to scoot further away from him."
    "Se sienta con cuidado al borde de mi cama y no puedo evitar alejarme más de él."

# game/game/script.rpy:5934
translate es playername_2fa666de:

    # r "I'm sorry for what you had to see...I didn't want you to see me like that."
    r "Lamento lo que tuviste que ver... no quería que me vieras así."

# game/game/script.rpy:5944
translate es playername_3fee62a2:

    # mc "See you like a psycho murderer...?"
    mc "¿Verte como un asesino psicópata...?"

# game/game/script.rpy:5948
translate es playername_91246f9c:

    # mc "You slaughtered those people as if they were-"
    mc "Mataste a esas personas como si fueran-"

# game/game/script.rpy:5950
translate es playername_ec81b7b5:

    # mc "As if they were...!"
    mc "¡Como si fueran...!"

# game/game/script.rpy:5954
translate es playername_12dcfc7b:

    # "I stop talking because I wasn't sure if I trusted my stomach."
    "Dejo de hablar porque no estaba segura de confiar en mi estómago."

# game/game/script.rpy:5956
translate es playername_9ed4fe31:

    # "There is an awkward silence before Ray sighs."
    "Hay un silencio incómodo antes de que Ray suspire."

# game/game/script.rpy:5958
translate es playername_b17cb857:

    # r "Yeah, that's fair."
    r "Sí, es justo."

# game/game/script.rpy:5960
translate es playername_f43e08bb:

    # r "I was scared for you, angry, and.... I kinda lost it."
    r "Estaba asustado por ti, enfadado y... perdí el control."

# game/game/script.rpy:5962
translate es playername_ea6c1299:

    # mc "{i}Totally lost it!{/i}"
    mc "{i}¡Totalmente perdido!{/i}"

# game/game/script.rpy:5964
translate es playername_48be3edc:

    # r "Yeah, totally lost it."
    r "Sí, totalmente perdido."

# game/game/script.rpy:5966
translate es playername_b124fa78:

    # mc "I thought heroes weren't allowed to kill...?"
    mc "¿Pensé que los héroes no tenían permitido matar...?"

# game/game/script.rpy:5970
translate es playername_8ee18db9:

    # "Ray's lips form a tight line."
    "Los labios de Ray se tensan."

# game/game/script.rpy:5972
translate es playername_3de96fcf:

    # r "Do you think crime would go away if we weren't?"
    r "¿Crees que el crimen desaparecería si no lo hiciéramos?"

# game/game/script.rpy:5974
translate es playername_7e517588:

    # r "Do you think Heroes are allowed to decide if they want this job?"
    r "¿Crees que los Héroes pueden decidir si quieren este trabajo?"

# game/game/script.rpy:5976
translate es playername_2a825516:

    # r "%(player_name)s. Heroes are glorified military weapons."
    r "%(player_name)s. Los héroes son armas militares glorificadas."

# game/game/script.rpy:5978
translate es playername_31228235:

    # r "At the end of the day we are just the police but with shiny new packaging and horrifying abilities."
    r "Al final del día, somos solo la policía, pero con un nuevo empaque brillante y habilidades aterradoras."

# game/game/script.rpy:5980
translate es playername_3b2fa9d1:

    # r "If the government doesn't make us work for them, these abilities can end up being a fast pass to anarchy and terrorism."
    r "Si el gobierno no nos hace trabajar para ellos, estas habilidades pueden convertirse rápidamente en un pase directo hacia la anarquía y el terrorismo."

# game/game/script.rpy:5982
translate es playername_ee1d644f:

    # r "So then I guess we preform war crimes and terrorism under the name of the government instead."
    r "Entonces supongo que cometemos crímenes de guerra y terrorismo en nombre del gobierno."

# game/game/script.rpy:5984
translate es playername_a7232c02:

    # "Ray laughs but it is empty and hollow."
    "Ray ríe, pero su risa suena vacía y hueca."

# game/game/script.rpy:5988
translate es playername_199643b1:

    # "His eyes are emotionless."
    "Sus ojos carecen de emoción."

# game/game/script.rpy:5990
translate es playername_9617ccef:

    # "I am unable to say anything back."
    "No puedo responder nada."

# game/game/script.rpy:5992
translate es playername_63f48ac3:

    # "I never had much faith in heroes but reality is even more horrifying than what I thought."
    "Nunca tuve mucha fe en los héroes, pero la realidad es incluso más aterradora de lo que pensaba."

# game/game/script.rpy:5994
translate es playername_c69ea991:

    # mc "So, you aren't going to get arrested for the...the..."
    mc "Entonces, ¿no vas a ser arrestado por la... la..."

# game/game/script.rpy:5996
translate es playername_90138aaa:

    # r "The {i}slaughter?{/i} No, there is already a clean up team there dealing with it."
    r "¿La {i}matanza?{/i} No, ya hay un equipo de limpieza encargándose de eso."

# game/game/script.rpy:5998
translate es playername_2ef0b504:

    # r "As far as everyone else is concerned, those criminals disappeared without a trace."
    r "Para todos los demás, esos criminales desaparecieron sin dejar rastro."

# game/game/script.rpy:6000
translate es playername_3d383927:

    # "The clear disgust showed on my face and Ray grimaced."
    "El claro disgusto se refleja en mi rostro y Ray hace una mueca."

# game/game/script.rpy:6004
translate es playername_667f5dfd:

    # r "This is the reality of things %(player_name)s."
    r "Esta es la realidad de las cosas, %(player_name)s."

# game/game/script.rpy:6006
translate es playername_720b65a9:

    # r "I'm not saying it's good, but it's the reality."
    r "No digo que sea buena, pero es la realidad."

# game/game/script.rpy:6008
translate es playername_a04d57a5:

    # r "I may have lost my cool, I admit that..."
    r "Puede que haya perdido los estribos, lo admito..."

# game/game/script.rpy:6012
translate es playername_792d4237:

    # r "But If you heard what they wanted to do with you in their thoughts...you would feel the same way I did..."
    r "Pero si hubieras oído lo que pensaban hacerte... sentirías lo mismo que yo..."

# game/game/script.rpy:6018
translate es playername_9959a45a:

    # mc "That was honestly... a nightmare..."
    mc "Eso fue sinceramente... una pesadilla..."

# game/game/script.rpy:6020
translate es playername_8262fe04:

    # mc "I don't think I'm going to get over that for like... most of my life."
    mc "No creo que supere eso en... la mayor parte de mi vida."

# game/game/script.rpy:6022
translate es playername_3fe28524:

    # mc "And to be honest, I'm probably a atleast a bit traumatized."
    mc "Y honestamente, probablemente tengo un trauma ahora."

# game/game/script.rpy:6026
translate es playername_9fe879a5:

    # "Ray avoids eye contact, he looks uncomfortable."
    "Ray evita el contacto visual, parece incómodo."

# game/game/script.rpy:6028
translate es playername_5e05e533:

    # r "I'm sorry for showing you ...that. I just wasn't thinking."
    r "Perdón por mostrarte... eso. Simplemente no pensé."

# game/game/script.rpy:6032
translate es playername_94d0342a:

    # r "I panicked which is... new for me."
    r "Entré en pánico, lo cual es... nuevo para mí."

# game/game/script.rpy:6034
translate es playername_1d410044:

    # mc "It wasn't pleasant to say the least..."
    mc "No fue agradable, por decir lo mínimo..."

# game/game/script.rpy:6036
translate es playername_99a9a632:

    # mc "I don't think I'm going to be able to rid my mind of that carnage for a long time."
    mc "No creo que pueda borrar esa carnicería de mi mente por mucho tiempo."

# game/game/script.rpy:6038
translate es playername_18efd8f6:

    # mc "But without you I'd be forever at the whims of double {i} or {/i} I'd be dead."
    mc "Pero sin ti, estaría para siempre a merced de Double {i} o {/i} estaría sin vida."

# game/game/script.rpy:6040
translate es playername_71fc4ff8:

    # mc "Even if I survived and he took me, long enough at the whims of double and I'd be dead either way."
    mc "Incluso si hubiera sobrevivido y él me hubiera capturado, tarde o temprano, a merced de Double, moriría de todos modos."

# game/game/script.rpy:6042
translate es playername_11b6159a:

    # mc "So... thanks for saving me Ray."
    mc "Así que... gracias por salvarme, Ray."

# game/game/script.rpy:6046
translate es playername_a7944d27:

    # "Ray gives a small sympathetic smile."
    "Ray esboza una pequeña sonrisa comprensiva."

# game/game/script.rpy:6048
translate es playername_427fe259:

    # "I smile back wide, trying to lighten the atmosphere."
    "Le devuelvo una amplia sonrisa, intentando aligerar el ambiente."

# game/game/script.rpy:6050
translate es playername_4dcd8ad9:

    # mc "Or, I guess I should say, 'The top hero {i} Binary Star {/i}'."
    mc "O supongo que debería decir, 'El héroe principal {i} Binary Star {/i}'."

# game/game/script.rpy:6054
translate es playername_1507b0b4:

    # "Ray groans."
    "Ray gime con fastidio."

# game/game/script.rpy:6056
translate es playername_3fed6c75:

    # r "Yeah I was kind of hoping that me being Binary Star was something you would never piece together..."
    r "Sí, esperaba que nunca descubrieras que yo era Binary Star..."

# game/game/script.rpy:6058
translate es playername_f1003350:

    # mc "You do seem completely different from your hero persona."
    mc "Pareces completamente diferente de tu persona heroica."

# game/game/script.rpy:6060
translate es playername_5d1eddd9:

    # "Ray gives me a leveled look."
    "Ray me lanza una mirada seria."

# game/game/script.rpy:6062
translate es playername_24072d35:

    # r "That guy and I have {i} nothing {/i} in common."
    r "Ese tipo y yo no tenemos {i} nada {/i} en común."

# game/game/script.rpy:6064
translate es playername_7423d923:

    # mc "Well, either way, I think I like Ray better than him anyways."
    mc "Bueno, de cualquier modo, creo que me gusta más Ray que él."

# game/game/script.rpy:6066
translate es playername_695b49fc:

    # "Ray smirks."
    "Ray sonríe con una ligera mueca."

# game/game/script.rpy:6068
translate es playername_38c8447c:

    # r "That's a first."
    r "Esa es nueva."

# game/game/script.rpy:6070
translate es playername_96119408:

    # "I open my mouth to reply, but I am cut off by a dull pain on my jaw."
    "Abro la boca para responder, pero un dolor sordo en la mandíbula me interrumpe."

# game/game/script.rpy:6072
translate es playername_a3bc1bd2:

    # mc "Oww..."
    mc "Auu..."

# game/game/script.rpy:6074
translate es playername_fc4910af:

    # "I rub it, realizing it's the place where Double grabbed me before."
    "La froto, dándome cuenta de que es el lugar donde Double me agarró antes."

# game/game/script.rpy:6076
translate es playername_91be529b:

    # "Ray comes closer."
    "Ray se acerca."

# game/game/script.rpy:6093
translate es playername_adf34174:

    # r "Let me see..."
    r "Déjame ver..."

# game/game/script.rpy:6096
translate es playername_adafdf32:

    # "I scoot further away instinctively."
    "Me alejo instintivamente."

# game/game/script.rpy:6100
translate es playername_7b8e161b:

    # "Ray pauses, a hurt look travels across his face."
    "Ray se detiene, con una expresión dolida en el rostro."

# game/game/script.rpy:6102
translate es playername_62562f5b:

    # "He whispers in a soft voice."
    "Susurra con voz suave."

# game/game/script.rpy:6106
translate es playername_2ed16380:

    # r "I'm not going to hurt you %(player_name)s, I promise."
    r "No voy a hacerte daño, %(player_name)s, lo prometo."

# game/game/script.rpy:6108
translate es playername_200098c6:

    # r "If you just trust me, I would never hurt you."
    r "Si solo confías en mí, nunca te haría daño."

# game/game/script.rpy:6110
translate es playername_10445cf0:

    # "I stare at him searching his face."
    "Lo miro, buscando en su rostro."

# game/game/script.rpy:6112
translate es playername_b5de315c:

    # r "I know you don't trust me now..."
    r "Sé que no confías en mí ahora..."

# game/game/script.rpy:6114
translate es playername_a2c75922:

    # r "But please, at least let me see your wounds..."
    r "Pero por favor, al menos déjame ver tus heridas..."

# game/game/script.rpy:6133
translate es playername_aa2f8275:

    # "He softly turns my face so he can see where the pain was originating from."
    "Gira mi rostro suavemente para ver de dónde provenía el dolor."

# game/game/script.rpy:6137
translate es playername_8c5bbc07:

    # "His face falls into a deep frown."
    "Su expresión se transforma en una profunda mueca."

# game/game/script.rpy:6139
translate es playername_d0ee49df:

    # r "I don't think you want to look in a mirror for a couple of days..."
    r "No creo que quieras mirarte en el espejo por un par de días..."

# game/game/script.rpy:6161
translate es playername_79a43d64:

    # mc "A couple days?!"
    mc "¿¡Un par de días!?"

# game/game/script.rpy:6163
translate es playername_bca161c9:

    # mc "I need to go grocery shopping!"
    mc "¡Necesito ir a hacer las compras!"

# game/game/script.rpy:6167
translate es playername_9e947dbf:

    # r "What, to buy more mac-and-cheese?"
    r "¿Para comprar más macarrones con queso?"

# game/game/script.rpy:6169
translate es playername_2fc29f4f:

    # r "No you don't."
    r "No, no lo necesitas."

# game/game/script.rpy:6171
translate es playername_282e5851_2:

    # mc "What...?"
    mc "¿Qué...?"

# game/game/script.rpy:6173
translate es playername_5f9ed24f:

    # r "It's best if you stay here."
    r "Es mejor que te quedes aquí."

# game/game/script.rpy:6175
translate es playername_94ea181e:

    # "I am about to protest but Ray firms his voice a little."
    "Estoy a punto de protestar, pero Ray endurece un poco su voz."

# game/game/script.rpy:6179
translate es playername_43bbbfac:

    # r "I haven't found Double Vision yet."
    r "Aún no he encontrado a Double Vision."

# game/game/script.rpy:6181
translate es playername_5b69ffc0:

    # "My mouth strains into a tight line."
    "Aprieto los labios."

# game/game/script.rpy:6183
translate es playername_d965fe2b:

    # "Ray's voice softens."
    "La voz de Ray se suaviza."

# game/game/script.rpy:6187
translate es playername_3aad6c8d:

    # r "Don't worry, I'm going to keep searching."
    r "No te preocupes, seguiré buscando."

# game/game/script.rpy:6189
translate es playername_316da664:

    # mc "After that.... bloodbath, Double has probably already ran for the hills."
    mc "Después de esa... masacre, probablemente Double ya haya huido."

# game/game/script.rpy:6192
translate es playername_b3255e3d:

    # "Ray gives a humorless chuckle."
    "Ray suelta una risa sin humor."

# game/game/script.rpy:6196
translate es playername_ea463355:

    # r "Unfortunately I doubt that..."
    r "Desafortunadamente, lo dudo..."

# game/game/script.rpy:6198
translate es playername_b62d4575:

    # r "I read his thoughts back at the warehouse, he is pretty attached to you."
    r "Leí sus pensamientos en el almacén, está bastante apegado a ti."

# game/game/script.rpy:6200
translate es playername_b707e513:

    # r "He may become desperate without you."
    r "Podría volverse desesperado sin ti."

# game/game/script.rpy:6202
translate es playername_a8e231ed:

    # "Ray frowns deeply."
    "Ray frunce el ceño profundamente."

# game/game/script.rpy:6204
translate es playername_3f860e17:

    # r "Please stay inside here, where I can make sure you will be safe."
    r "Por favor, quédate aquí adentro, donde pueda asegurarme de que estés a salvo."

# game/game/script.rpy:6207
translate es playername_cc6f054e:

    # "Ray gives an uncomfortable chuckle."
    "Ray suelta una risa incómoda."

# game/game/script.rpy:6209
translate es playername_cd6ac01b:

    # r "Maybe, but it's good to stay vigilant."
    r "Tal vez, pero es bueno mantenerse alerta."

# game/game/script.rpy:6211
translate es playername_c6d3d5f2:

    # r "I scanned his thoughts back at the warehouse and he seems to have history with you."
    r "Leí sus pensamientos en el almacén y parece tener historia contigo."

# game/game/script.rpy:6213
translate es playername_8ab78218:

    # r "So it's probably best for you to stay inside here, where I can protect you."
    r "Así que probablemente sea mejor que te quedes aquí, donde pueda protegerte."

# game/game/script.rpy:6215
translate es playername_9131c2fd:

    # "Ray forces a smile."
    "Ray fuerza una sonrisa."

# game/game/script.rpy:6219
translate es playername_d7c54df8:

    # r "You still look so exhausted..."
    r "Aún pareces tener agotamiento... "

# game/game/script.rpy:6223
translate es playername_2be01d57:

    # cg "Ray moves back to the window looking out at the night view of concrete buildings and urban sprawl."
    cg "Ray se aleja hacia la ventana, mirando la vista nocturna de los edificios de concreto y la expansión urbana."

# game/game/script.rpy:6243
translate es playername_e60d8e6c:

    # cg "He pulls out another cigarette bringing it up to his lips."
    cg "Saca otro cigarrillo y lo lleva a sus labios."

# game/game/script.rpy:6247
translate es playername_86d8670a:

    # cg "{color=#CD9300}'Try to get some sleep'{/color}"
    cg "{color=#CD9300}'Intenta dormir un poco'{/color}"

# game/game/script.rpy:6255
translate es playername_2180c53c:

    # cg "{color=#CD9300}'I'll keep an eye on you until I have to go to work.'{/color}"
    cg "{color=#CD9300}'Te vigilaré hasta que tenga que ir a trabajar.'{/color}"

# game/game/script.rpy:6259
translate es playername_3b72a1dc:

    # cg "I soon become taken by the exhaustion of the day and drift off to sleep."
    cg "Pronto, el cansancio del día me vence y me duermo."

# game/game/script.rpy:6278
translate es playername_4a345384:

    # "I wake up with the sense that I dreamt about Ray."
    "Despierto con la sensación de que soñé con Ray."

# game/game/script.rpy:6280
translate es playername_b02a7c01:

    # "I drowsily look around the room, Ray must have left for work already."
    "Somnolientamente miro alrededor de la habitación, Ray ya debe haberse ido al trabajo."

# game/game/script.rpy:6282
translate es playername_28e6df99:

    # "Part of me was a little disappointed..."
    "Una parte de mí estaba un poco decepcionada..."

# game/game/script.rpy:6286
translate es playername_a43dfdd2:

    # "I get up and inspect the fridge, it was pretty empty so I settled on eating some leftovers."
    "Me levanto e inspecciono el refrigerador, estaba bastante vacío, así que me conformé con comer algunas sobras."

# game/game/script.rpy:6288
translate es playername_a20cefa7_1:

    # "..."
    "..."

# game/game/script.rpy:6290
translate es playername_3a078c9b:

    # "Throughout the day I shift between watching TV programs, playing on my phone, and reading my book."
    "Durante el día alterno entre ver programas de televisión, jugar en mi teléfono y leer mi libro."

# game/game/script.rpy:6291
translate es playername_a20cefa7_2:

    # "..."
    "..."

# game/game/script.rpy:6295
translate es playername_687f8d59:

    # "I wake up with the sense that I dreamt about the old times with Double."
    "Despierto con la sensación de que soñé con los viejos tiempos con Double."

# game/game/script.rpy:6297
translate es playername_aa8553cf:

    # "He used to be so much nicer..."
    "Solía ser mucho más amable..."

# game/game/script.rpy:6299
translate es playername_44ae3989:

    # "Or was he like this all along and I just didn't catch it?"
    "¿O fue así todo el tiempo y yo simplemente no lo noté?"

# game/game/script.rpy:6303
translate es playername_a43dfdd2_1:

    # "I get up and inspect the fridge, it was pretty empty so I settled on eating some leftovers."
    "Me levanto e inspecciono el refrigerador, estaba bastante vacío, así que me conformé con comer algunas sobras."

# game/game/script.rpy:6305
translate es playername_a20cefa7_3:

    # "..."
    "..."

# game/game/script.rpy:6307
translate es playername_4c0ce4f7:

    # "Throughout the day I shift between watching TV programs, playing on my phone, and reading some articles."
    "Durante el día alterno entre ver programas de televisión, jugar en mi teléfono y leer algunos artículos."

# game/game/script.rpy:6309
translate es playername_a20cefa7_4:

    # "..."
    "..."

# game/game/script.rpy:6311
translate es playername_c2681b13:

    # "I try to get in some good reading just to pass the time, but I can feel my attention not able to stick to anything."
    "Intento concentrarme en una buena lectura solo para pasar el tiempo, pero siento que mi atención no logra mantenerse en nada."

# game/game/script.rpy:6315
translate es playername_03b90698:

    # "After a few hours of being lazy I can feel the exhaustion setting in."
    "Después de unas horas de pereza, puedo sentir el cansancio apoderándose de mí."

# game/game/script.rpy:6317
translate es playername_24cbf0cd:

    # "The sun is beginning to set."
    "El sol comienza a ponerse."

# game/game/script.rpy:6321
translate es playername_8fa911c3:

    # "I decide to do some stretches to keep the blood flow to my legs"
    "Decido hacer algunos estiramientos para mantener la circulación en las piernas."

# game/game/script.rpy:6325
translate es playername_7f100937:

    # "{i}'Tap tap tap'{/i}"
    "{i}'Tap tap tap'{/i}"

# game/game/script.rpy:6329
translate es playername_7f100937_1:

    # "{i}'Tap tap tap'{/i}"
    "{i}'Tap tap tap'{/i}"

# game/game/script.rpy:6331
translate es playername_a979022e:

    # "When I glance to where the noise is coming from I notice a small black cat at my window."
    "Cuando miro hacia donde proviene el ruido, noto un pequeño gato negro en mi ventana."

# game/game/script.rpy:6333
translate es playername_75861ba3:

    # "{i}How did a cat get 5 stories up?!{/i}"
    "{i}¿Cómo llegó un gato al quinto piso?{/i}"

# game/game/script.rpy:6335
translate es playername_ceeaf203:

    # "I immediately open up my window and grab the cat bringing it into the apartment."
    "Inmediatamente abro la ventana y agarro al gato, metiéndolo al apartamento."

# game/game/script.rpy:6342
translate es playername_64062c38:

    # mc "Oh my god what were you doing out there kitty?"
    mc "Oh, Dios mío, ¿qué hacías allá afuera, gatito?"

# game/game/script.rpy:6344
translate es playername_a6d7fed1:

    # "The cat wiggles in my arms and I let it down in my apartment."
    "El gato se retuerce en mis brazos y lo dejo en el suelo del apartamento."

# game/game/script.rpy:6357
translate es playername_42e866cc:

    # "The cat wanders around the apartment sniffing everything it's small nose can reach."
    "El gato deambula por el lugar olfateando todo lo que su pequeña nariz puede alcanzar."

# game/game/script.rpy:6359
translate es playername_52d100b3:

    # "I sit on the bed watching the cat."
    "Me siento en la cama observando al gato."

# game/game/script.rpy:6363
translate es playername_bf1c24b1:

    # "When the cat finishes whatever rounds it was making, it stares at me curiously."
    "Cuando el gato termina las vueltas que estaba dando, me mira con curiosidad."

# game/game/script.rpy:6365
translate es playername_c0eee101:

    # mc "Do you want to play..?"
    mc "¿Quieres jugar...?"

# game/game/script.rpy:6367
translate es playername_f27dc576:

    # "I dig in my closet to find the basket of cat care items that I probably should have given away ages ago."
    "Rebusco en mi armario para encontrar la canasta con artículos de cuidado para gatos que probablemente debí haber regalado hace años."

# game/game/script.rpy:6369
translate es playername_40d82795:

    # "I pull out a feather toy and crouch down in front of the cat."
    "Saco un juguete de plumas y me agacho frente al gato."

# game/game/script.rpy:6371
translate es playername_370cfb4e:

    # "The cat stares up at the feather toy with an...unamused look."
    "El gato mira el juguete con una expresión... poco impresionada."

# game/game/script.rpy:6373
translate es playername_a4959bd3:

    # "I bounce the toy up and down but it fails to interest the cat who just rubs it's paw against it's face instead."
    "Muevo el juguete de arriba abajo, pero no logra interesarlo; en cambio, se frota la pata contra la cara."

# game/game/script.rpy:6375
translate es playername_75fa2389:

    # "I try a few more toys but the cat even seems amused with my frustration."
    "Intento con algunos juguetes más, pero el gato parece divertirse con mi frustración."

# game/game/script.rpy:6377
translate es playername_eae1e358:

    # "Eventually the cat turns around stretching up towards my bed."
    "Eventualmente el gato se da vuelta y se estira hacia mi cama."

# game/game/script.rpy:6381
translate es playername_2cbbe6f6:

    # mc "You wanna get up there?"
    mc "¿Quieres subir allí?"

# game/game/script.rpy:6385
translate es playername_bd191837:

    # "I ask carefully picking up the cat and placing it onto my bed."
    "Pregunto, levantando con cuidado al gato y colocándolo sobre mi cama."

# game/game/script.rpy:6403
translate es playername_5fe45ddb:

    # "After sniffing around a bit the cat lays down."
    "Después de olfatear un poco, el gato se recuesta."

# game/game/script.rpy:6410
translate es playername_42943041:

    # "It looks so comfortable I can't help but to yawn as well."
    "Se ve tan cómodo que no puedo evitar bostezar también."

# game/game/script.rpy:6412
translate es playername_65a220ef:

    # "I decide to follow suit, laying down on the bed blanketed by the rare warm sun."
    "Decido seguir su ejemplo, acostándome en la cama bajo el cálido y raro sol."

# game/game/script.rpy:6415
translate es playername_2a235001:

    # "The cat gets up and walks over to me."
    "El gato se levanta y camina hacia mí."

# game/game/script.rpy:6418
translate es playername_9650dc57:

    # "The cat curls up next to me. Its soft warmth comforting me."
    "El gato se acurruca a mi lado. Su suave calidez me reconforta."

# game/game/script.rpy:6432
translate es playername_f2687bfc:

    # cg "{color=#510f80} ' How did you get here kitty? You must be pretty agile to find your way up 5 stories.' {/color}"
    cg "{color=#510f80} '¿Cómo llegaste aquí, gatito? Debes ser bastante ágil para subir cinco pisos.' {/color}"

# game/game/script.rpy:6434
translate es playername_03790185:

    # cg "I mumble to the cat."
    cg "Murmuro al gato."

# game/game/script.rpy:6438
translate es playername_5f238dc9:

    # cg "The cat gives a soft 'meow', almost looking proud of its accomplishments."
    cg "El gato emite un suave 'miau', casi como si estuviera orgulloso de su hazaña."

# game/game/script.rpy:6442
translate es playername_b23533b5:

    # cg "As I pet and talk to the cat, it purrs in response."
    cg "Mientras lo acaricio y le hablo, el gato ronronea en respuesta."

# game/game/script.rpy:6444
translate es playername_04e9e58a:

    # cg "Between the warmth of the sun and the cat curled up next to me, I soon get tired and my eyes refuse to stay open."
    cg "Entre el calor del sol y el gato acurrucado junto a mí, pronto me entra el sueño y mis ojos se niegan a mantenerse abiertos."

# game/game/script.rpy:6446
translate es playername_c36cf84c:

    # cg "I can't help but to fall asleep with the cat beside me."
    cg "No puedo evitar dormir con el gato a mi lado."

# game/game/script.rpy:6448
translate es playername_ef732a84:

    # cg "....."
    cg "....."

# game/game/script.rpy:6464
translate es playername_ae3f1649:

    # cg "......."
    cg "......."

# game/game/script.rpy:6477
translate es playername_3864166a:

    # cg "The door clicks closed and my eyes drift open."
    cg "La puerta se cierra con un clic y mis ojos se abren lentamente."

# game/game/script.rpy:6486
translate es playername_d333fb10:

    # r "Still tired?"
    r "¿Aun con cansancio? "

# game/game/script.rpy:6493
translate es playername_73b538e7:

    # "Ray walks in with full hero attire on carrying a sizeable duffle bag."
    "Ray entra con su atuendo completo de héroe, cargando una bolsa de lona bastante grande."

# game/game/script.rpy:6495
translate es playername_4318c4a4:

    # "His expression looks more exhausted than usual."
    "Su expresión parece más agotada de lo habitual."

# game/game/script.rpy:6497
translate es playername_ddd00c84:

    # "Part of his hero outfit is ripped in different areas."
    "Parte de su traje de héroe está rasgado en distintas zonas."

# game/game/script.rpy:6499
translate es playername_0d2b7de5:

    # "I grimace at a particularly nasty slash on his side."
    "Hago una mueca al ver un corte particularmente feo en su costado."

# game/game/script.rpy:6501
translate es playername_d405779c:

    # "Ray follows my eyes and covers the slash with his arm."
    "Ray sigue mi mirada y cubre el corte con el brazo."

# game/game/script.rpy:6503
translate es playername_347c543f:

    # r "It looks worse than it is I promise."
    r "No es tan grave como parece, lo prometo."

# game/game/script.rpy:6505
translate es playername_2b5ac205:

    # "I get up to take a closer look but Ray quickly takes a step back."
    "Me levanto para observar más de cerca, pero Ray da un paso atrás rápidamente."

# game/game/script.rpy:6518
translate es playername_7afdf9d8:

    # r "I rushed back here to check on you, so I haven't taken a shower yet."
    r "Volví corriendo para ver cómo estabas, así que no me he duchado aún."

# game/game/script.rpy:6520
translate es playername_7b00bdd5:

    # mc "Oh, sorry! I didn't mean to-"
    mc "¡Oh, perdón! No quise—"

# game/game/script.rpy:6522
translate es playername_40f23a55:

    # r "No, it's okay, I just can't guarantee I don't smell entirely horrible right now..."
    r "No, está bien, solo que no puedo garantizar que no huela terrible ahora mismo..."

# game/game/script.rpy:6524
translate es playername_feb98de1:

    # mc "Do you want to shower here?"
    mc "¿Quieres ducharte aquí?"

# game/game/script.rpy:6526
translate es playername_b7424db3:

    # r "Oh, do you mind?"
    r "¿Oh, te molesta?"

# game/game/script.rpy:6528
translate es playername_98feb1c3:

    # r "I was just stopping by here to make sure you are doing okay."
    r "Solo venía a asegurarme de que estabas bien."

# game/game/script.rpy:6530
translate es playername_0ee35e7b:

    # r "I was going to head to mine and come back here later."
    r "Pensaba ir a mi casa y regresar más tarde."

# game/game/script.rpy:6532
translate es playername_c5254326:

    # r "But I guess that would save me a trip."
    r "Pero supongo que eso me ahorraría un viaje."

# game/game/script.rpy:6534
translate es playername_4eb21e92:

    # mc "Yeah feel free."
    mc "Sí, siéntete libre."

# game/game/script.rpy:6536
translate es playername_e8cfebda:

    # mc "There should be some fresh towels in the bathroom."
    mc "Debería haber toallas limpias en el baño."

# game/game/script.rpy:6538
translate es playername_dd0ee98f:

    # "I look at him."
    "Lo miro."

# game/game/script.rpy:6540
translate es playername_5eae9502:

    # mc "I don't think you will fit in my clothes though..."
    mc "Aunque no creo que entres en mi ropa..."

# game/game/script.rpy:6542
translate es playername_db4ce681:

    # "Ray drops his duffle bag on the ground."
    "Ray deja su bolsa en el suelo."

# game/game/script.rpy:6544
translate es playername_a72905fe:

    # r "No worries, I always take extra clothing to work."
    r "No hay problema, siempre llevo ropa extra al trabajo."

# game/game/script.rpy:6548
translate es playername_1da02792:

    # r "Never know what's going to happen right?"
    r "Nunca se sabe lo que puede pasar, ¿verdad?"

# game/game/script.rpy:6557
translate es playername_60425d78:

    # "I push out the memories of the carnage from my mind."
    "Aparto los recuerdos del caos de mi mente."

# game/game/script.rpy:6562
translate es playername_12f10706:

    # mc "Uh....yeah..."
    mc "Eh... sí..."

# game/game/script.rpy:6566
translate es playername_69cfa195:

    # "Ray surely sensing what I was thinking looks somewhat awkward."
    "Ray, notando claramente en qué pensaba, parece algo incómodo."

# game/game/script.rpy:6568
translate es playername_03afe6ce:

    # "He forces a smile."
    "Fuerza una sonrisa."

# game/game/script.rpy:6572
translate es playername_2fcf5d3a:

    # r "I'm going to..."
    r "Voy a..."

# game/game/script.rpy:6574
translate es playername_a10c6785:

    # "He gestures toward the bathroom."
    "Hace un gesto hacia el baño."

# game/game/script.rpy:6576
translate es playername_56e8528c:

    # mc "Yeah! Yeah, of course."
    mc "¡Sí! Sí, claro."

# game/game/script.rpy:6578
translate es playername_b3655c90:

    # "He saunters towards the bathroom."
    "Camina hacia el baño."

# game/game/script.rpy:6582
translate es playername_3005c9fa:

    # "A couple of seconds later Ray speaks through the door."
    "Unos segundos después, Ray habla desde el otro lado de la puerta."

# game/game/script.rpy:6584
translate es playername_ccf9c41b:

    # r "Uh, hey %(player_name)s...?"
    r "Eh, oye, %(player_name)s...?"

# game/game/script.rpy:6586
translate es playername_f49fff8f:

    # mc "Yeah?"
    mc "¿Sí?"

# game/game/script.rpy:6600
translate es playername_aba319a2:

    # "I approach the bathroom door."
    "Me acerco a la puerta del baño."

# game/game/script.rpy:6602
translate es playername_cd26dc7e:

    # r "Do you mind helping me with something?"
    r "¿Podrías ayudarme con algo?"

# game/game/script.rpy:6604
translate es playername_5c090e89:

    # mc "...."
    mc "...."

# game/game/script.rpy:6606
translate es playername_81067f26:

    # r "It's...nothing weird."
    r "No es nada raro."

# game/game/script.rpy:6608
translate es playername_227878c9:

    # mc "Uh, sure do you want me to come in?"
    mc "Eh, claro, ¿quieres que entre?"

# game/game/script.rpy:6610
translate es playername_555666ff:

    # r "Yeah."
    r "Sí."

# game/game/script.rpy:6634
translate es playername_196cf83e:

    # cg "I open the bathroom door to see Ray hunched over the sink."
    cg "Abro la puerta del baño y veo a Ray inclinado sobre el lavabo."

# game/game/script.rpy:6636
translate es playername_7b68eeb4:

    # cg "The top part of his jumpsuit is off and his hair hangs partially wet."
    cg "La parte superior de su traje está quitada y su cabello cae parcialmente húmedo."

# game/game/script.rpy:6638
translate es playername_9656c92f:

    # cg "I eye the gash on his side, red and angry looking."
    cg "Observo la herida en su costado, roja y con mal aspecto."

# game/game/script.rpy:6640
translate es playername_0f2ab66a:

    # cg "{color=#CD9300} 'I can't reach the top part that well. Do you mind cleaning it?'{/color} "
    cg "{color=#CD9300} 'No puedo alcanzar bien la parte de arriba. ¿Te importaría limpiarla?' {/color}"

# game/game/script.rpy:6642
translate es playername_2ac3529f:

    # cg "Ray looks awkwardly away."
    cg "Ray aparta la mirada con incomodidad."

# game/game/script.rpy:6644
translate es playername_796fefb9:

    # cg "{color=#CD9300} 'You can say no if you want...'{/color} "
    cg "{color=#CD9300} 'Puedes decir que no si quieres...' {/color}"

# game/game/script.rpy:6646
translate es playername_121cdbac:

    # cg "{color=#CD9300} 'I'll just wash it in the shower water and hope it's good enough...'{/color} "
    cg "{color=#CD9300} 'La lavaré con el agua de la ducha y espero que sea suficiente...' {/color}"

# game/game/script.rpy:6648
translate es playername_62b60a12:

    # cg "{color=#510f80} 'What were you fighting...?'{/color} "
    cg "{color=#510f80} '¿Con qué estabas peleando...?' {/color}"

# game/game/script.rpy:6650
translate es playername_fc3aa294:

    # cg "Ray grimaces, he knows what I'm getting at."
    cg "Ray hace una mueca; sabe exactamente a lo que me refiero."

# game/game/script.rpy:6652
translate es playername_33913ce8:

    # cg "{color=#CD9300} 'A Crawler.'{/color}"
    cg "{color=#CD9300} 'Un Crawler.'{/color}"

# game/game/script.rpy:6654
translate es playername_3ea9e6dc:

    # cg "{color=#CD9300} 'The type of alien that you saw before.'{/color}"
    cg "{color=#CD9300} 'El tipo de alienígena que viste antes.'{/color}"

# game/game/script.rpy:6656
translate es playername_db8253f8:

    # cg "{color=#CD9300} 'Their attacks are becoming more frequent.'{/color}"
    cg "{color=#CD9300} 'Sus ataques se están volviendo más frecuentes.'{/color}"

# game/game/script.rpy:6658
translate es playername_ab0fb28e:

    # cg "{color=#CD9300} 'And it was destroying the City.'{/color}"
    cg "{color=#CD9300} 'Y estaba destruyendo la Ciudad.'{/color}"

# game/game/script.rpy:6660
translate es playername_e673c040:

    # cg "{color=#510f80} 'Okay...'{/color}"
    cg "{color=#510f80} 'Está bien...'{/color}"

# game/game/script.rpy:6662
translate es playername_3086041f:

    # cg "I walked towards Ray and grabbed the bottle of hydrogen peroxide from his hand."
    cg "Caminé hacia Ray y tomé la botella de peróxido de hidrógeno de su mano."

# game/game/script.rpy:6664
translate es playername_707c439d:

    # cg "I cleaned the wound as thoroughly as I could."
    cg "Limpié la herida tan a fondo como pude."

# game/game/script.rpy:6666
translate es playername_04d209f1:

    # cg "Ray doesn't even flinch at the touch of the hydrogen peroxide."
    cg "Ray ni siquiera se inmuta con el contacto del peróxido de hidrógeno."

# game/game/script.rpy:6668
translate es playername_ac973dba:

    # cg "He sighs."
    cg "Suspira."

# game/game/script.rpy:6670
translate es playername_1c963149:

    # cg "{color=#CD9300} 'Thanks %(player_name)s.'{/color} "
    cg "{color=#CD9300} 'Gracias %(player_name)s.'{/color}"

# game/game/script.rpy:6672
translate es playername_697d186c:

    # cg "{color=#510f80} 'No problem.'{/color}"
    cg "{color=#510f80} 'No hay problema.'{/color}"

# game/game/script.rpy:6674
translate es playername_d49c533c:

    # cg "I stand awkwardly trying not to stare at Ray's undressed upper half."
    cg "Me quedo de pie torpemente, intentando no mirar la mitad superior del cuerpo desnudo de Ray."

# game/game/script.rpy:6676
translate es playername_bd7b3362:

    # cg "{color=#CD9300} 'Uh, I'm going to take a shower now.'{/color}"
    cg "{color=#CD9300} 'Eh, voy a ducharme ahora.'{/color}"

# game/game/script.rpy:6678
translate es playername_ce68d00e:

    # cg "{color=#510f80} 'Oh right, I'll get out of your hair.'{/color}"
    cg "{color=#510f80} 'Oh, claro, no te molesto más.'{/color}"

# game/game/script.rpy:6696
translate es playername_829228d8:

    # "As I open the door it suddenly closes by a weight behind me."
    "Cuando abro la puerta, de repente se cierra por un peso detrás de mí."

# game/game/script.rpy:6698
translate es playername_0d7f8824:

    # "I turn around and see Ray looming over my body."
    "Me doy la vuelta y veo a Ray inclinándose sobre mi cuerpo."

# game/game/script.rpy:6703
translate es playername_5f9b772e_1:

    # "...."
    "...."

# game/game/script.rpy:6705
translate es playername_18362496:

    # "He stares intensely, his face coming ever closer."
    "Me mira con intensidad, su rostro acercándose cada vez más."

# game/game/script.rpy:6707
translate es playername_b2d06612:

    # "He pauses just as his breath drifts across my face."
    "Se detiene justo cuando su aliento roza mi cara."

# game/game/script.rpy:6709
translate es playername_b362bb4b:

    # "Ray lifts a hand to my face, brushing his thumb across my cheek."
    "Ray levanta una mano hacia mi rostro, rozando mi mejilla con el pulgar."

# game/game/script.rpy:6711
translate es playername_7f960c56:

    # "He then holds up a small black hair that must have been sitting on my face."
    "Luego sostiene un pequeño cabello negro que debió estar en mi cara."

# game/game/script.rpy:6713
translate es playername_56779f9f:

    # "My face heats up."
    "Mi rostro se calienta."

# game/game/script.rpy:6715
translate es playername_d9fd421f:

    # mc "There was a cat in here earlier and-"
    mc "Había un gato aquí antes y—"

# game/game/script.rpy:6717
translate es playername_0ca7d35a:

    # r "A cat...on the 5th floor...?"
    r "¿Un gato... en el quinto piso...?"

# game/game/script.rpy:6719
translate es playername_2bf285de:

    # "I blanche, unsure how to explain it."
    "Me paralizo, sin saber cómo explicarlo. "

# game/game/script.rpy:6721
translate es playername_8621a536:

    # mc "Maybe a neighbor let it out..?"
    mc "¿Quizá un vecino lo dejó salir...?"

# game/game/script.rpy:6723
translate es playername_a9afbfb5_1:

    # "A silence drifts between us."
    "Un silencio se extiende entre nosotros."

# game/game/script.rpy:6725
translate es playername_501c57db:

    # "Some dark emotion shifts under Ray's eyes that I can't quite place."
    "Una emoción oscura se mueve bajo los ojos de Ray que no logro identificar."

# game/game/script.rpy:6727
translate es playername_b3cee815:

    # "I glance down at the gash on Ray's side."
    "Dirijo la mirada hacia el corte en el costado de Ray."

# game/game/script.rpy:6731
translate es playername_6893a5d2:

    # "The red is starting to bloom and run."
    "El rojo empieza a extenderse y a correr."

# game/game/script.rpy:6733
translate es playername_19f75fe8:

    # "{i}Was I too rough? {/i}"
    "{i}¿Use mucha fuerza?{/i}"

# game/game/script.rpy:6737
translate es playername_dfc8d1b7:

    # mc "Does it... hurt...?"
    mc "¿Le... duele...?"

# game/game/script.rpy:6742
translate es playername_9dada033:

    # "Before I can process what is happening, Ray grabs my wrist pressing it deeply into his side."
    "Antes de poder procesar lo que ocurre, Ray toma mi muñeca y la presiona con fuerza contra su costado."

# game/game/script.rpy:6744
translate es playername_8d3e348a:

    # "I can feel the bandages grow damp with blood under the pressure of my hand."
    "Puedo sentir cómo las vendas se humedecen con sangre bajo la presión de mi mano."

# game/game/script.rpy:6746
translate es playername_051c0df8:

    # "He looks at me, completely expressionless."
    "Me mira, completamente inexpresivo."

# game/game/script.rpy:6748
translate es playername_79a87df3:

    # "His dark eyes seemingly bottomless."
    "Sus ojos oscuros parecen sin fondo."

# game/game/script.rpy:6752
translate es playername_89380a54:

    # "I try to yank my hand away but he only presses it deeper into his side, my fingers digging into the wound."
    "Intento apartar mi mano, pero solo la presiona más contra su costado, mis dedos hundiéndose en la herida."

# game/game/script.rpy:6754
translate es playername_15a58e82:

    # mc "S-stop!"
    mc "¡D-detente!"

# game/game/script.rpy:6758
translate es playername_f7576696:

    # "I yelp, beginning to feel a bit sick by his flesh slowly being parted by my fingertips."
    "Grito, empezando a sentirme un poco mal al notar su carne separarse lentamente bajo mis dedos."

# game/game/script.rpy:6763
translate es playername_3fbce7ea:

    # "He lets go of my wrist. I instinctively take a step back, cornered into the door."
    "Suelta mi muñeca. Instintivamente doy un paso atrás, contra la puerta."

# game/game/script.rpy:6766
translate es playername_a4d18941:

    # r "No, %(player_name)s. Nothing you can do will ever hurt me. Nothing can hurt me."
    r "No, %(player_name)s. Nada de lo que hagas podrá herirme. Nada puede herirme."

# game/game/script.rpy:6768
translate es playername_45bf205a:

    # r "This is the price I pay for protecting humanity."
    r "Este es el precio que pago por proteger a la humanidad."

# game/game/script.rpy:6770
translate es playername_18b8ea56:

    # r "While you play with ...cats."
    r "Mientras tú juegas con... gatos."

# game/game/script.rpy:6772
translate es playername_caa7b789:

    # "His tone sounded almost sardonic. I wasn't really sure what he meant. I try to search his face, but it remains expressionless."
    "Su tono sonaba casi sarcástico. No sabia que quería decir. Intento buscar algo en su rostro, pero permanece inexpresivo."

# game/game/script.rpy:6774
translate es playername_78c9a2cc:

    # "Ray's cool gaze never once leaving my own."
    "La mirada fría de Ray no se aparta ni un segundo de la mía."

# game/game/script.rpy:6778
translate es playername_9a259445:

    # r "So...are you joining me then?"
    r "Entonces... ¿te unirás a mí?"

# game/game/script.rpy:6782
translate es playername_f38d5280:

    # "Ray reaches to the shower turning it on."
    "Ray se acerca a la ducha y la enciende."

# game/game/script.rpy:6784
translate es playername_39651df7:

    # r "You seem to take your sweet time leaving, so I assume you want a show or something?"
    r "Pareces tardarte en irte, así que supongo que quieres un espectáculo o algo así."

# game/game/script.rpy:6786
translate es playername_190aba0d:

    # "A smirk drifts across Ray's face as he starts to pull down the rest of his jumpsuit that sits loosely at his waist."
    "Una sonrisa burlona cruza el rostro de Ray mientras empieza a bajar el resto de su mono, que cuelga suelto en su cintura."

# game/game/script.rpy:6788
translate es playername_306caab8:

    # mc "Asshole."
    mc "Idiota."

# game/game/script.rpy:6792
translate es playername_468a9d4b:

    # "I mumble leaving the bathroom. Ray chuckles as the door clicks shut."
    "Murmuro saliendo del baño. Ray suelta una risa mientras la puerta se cierra con un clic."

# game/game/script.rpy:6802
translate es playername_28000ee6:

    # "I leave the bathroom closing the door behind me."
    "Salgo del baño cerrando la puerta detrás de mí."

# game/game/script.rpy:6804
translate es playername_36ca0aba:

    # "The various scars that adorn Ray's body are seared into my mind."
    "Las diversas cicatrices que cubren el cuerpo de Ray quedan grabadas en mi mente."

# game/game/script.rpy:6806
translate es playername_c5cf9b6b:

    # "Just what has he been fighting all this time...?"
    "¿Contra qué ha estado luchando todo este tiempo...?"

# game/game/script.rpy:6810
translate es playername_2f6bbdab:

    # "I can hear Ray give a tired sigh as the shower water hits his body."
    "Puedo escuchar a Ray soltar un suspiro cansado mientras el agua de la ducha golpea su cuerpo."

# game/game/script.rpy:6813
translate es playername_161a4ad0:

    # "Having Binary Star in my small apartment...honestly it scares me."
    "Tener a Binary Star en mi pequeño apartamento... honestamente me asusta."

# game/game/script.rpy:6815
translate es playername_eae30b92:

    # "Back when I was a part of the Night Crew some of my criminal compatriots would come back to the base absolutely terrified."
    "Cuando era parte del Night Crew, algunos de mis compañeros criminales volvían a la base absolutamente aterrados."

# game/game/script.rpy:6817
translate es playername_a3aefd58:

    # "They would shake as if withstanding an arctic freeze. They would be unable to speak, their eyes hollowed and distant."
    "Temblaban como si soportaran un frío ártico. No podían hablar, sus ojos vacíos y distantes."

# game/game/script.rpy:6819
translate es playername_0466e13a:

    # "And the next day they would be gone."
    "Y al día siguiente, desaparecían."

# game/game/script.rpy:6821
translate es playername_f21d1ca7:

    # "I wouldn't dare ask Double what happened to them."
    "Jamás me atrevería a preguntarle a Double qué les pasaba."

# game/game/script.rpy:6823
translate es playername_61a22a8f:

    # "His white knuckles said more than his voice ever could."
    "Sus nudillos blancos decían más que su voz."

# game/game/script.rpy:6825
translate es playername_8176584d:

    # "Now, I think I understood."
    "Ahora, creo que lo entendía."

# game/game/script.rpy:6827
translate es playername_3bd96d95:

    # "The sickening sounds wouldn't stop coming back to me."
    "Los horribles sonidos no dejaban de regresar a mi mente."

# game/game/script.rpy:6829
translate es playername_0f086030:

    # "It made my stomach flip and my legs shake."
    "Me revolvían el estómago y me hacían temblar las piernas."

# game/game/script.rpy:6831
translate es playername_2014ed7a:

    # "But despite my numbing fear....I had to know."
    "Pero a pesar del miedo que me paralizaba... tenía que saberlo."

# game/game/script.rpy:6833
translate es playername_3ceae3dc:

    # "{i}Who are you Binary Star?{/i}"
    "{i}¿Quién eres tú, Binary Star?{/i}"

# game/game/script.rpy:6836
translate es playername_92483e22:

    # "Having The national hero Binary Star in my small apartment felt...surreal."
    "Tener al héroe nacional Binary Star en mi pequeño apartamento se sentía... irreal."

# game/game/script.rpy:6838
translate es playername_4a2362e9:

    # "The high standard set for all heroes past and present currently in my shower..."
    "El alto estándar establecido para todos los héroes, pasados y presentes, estaba ahora en mi ducha..."

# game/game/script.rpy:6840
translate es playername_8ef70dba:

    # "Not as 'Binary Star' but as Ray."
    "No como 'Binary Star', sino como Ray."

# game/game/script.rpy:6842
translate es playername_bcff6ad1:

    # "The same Ray that would stop in for black coffee looking like he hasn't gotten an ounce of sleep for at least a week."
    "El mismo Ray que se detenía por un café negro, con aspecto de no haber dormido en una semana."

# game/game/script.rpy:6844
translate es playername_03ef04c8:

    # "The same Ray that would skeptically try a green latte. Who would carry my groceries for me."
    "El mismo Ray que probaba un latte verde con escepticismo. Que cargaba mis compras por mí."

# game/game/script.rpy:6846
translate es playername_d2134e6a:

    # "To be honest, I wasn't sure exactly how to feel."
    "Sinceramente, no sabía exactamente cómo sentirme."

# game/game/script.rpy:6848
translate es playername_9108865e:

    # "They seemed like two completely different people, yet the evidence was clearly in front of me."
    "Parecían dos personas completamente distintas, pero la evidencia estaba frente a mí."

# game/game/script.rpy:6850
translate es playername_a20cefa7_5:

    # "..."
    "..."

# game/game/script.rpy:6852
translate es playername_3ceae3dc_1:

    # "{i}Who are you Binary Star?{/i}"
    "{i}¿Quién eres tú, Binary Star?{/i}"

# game/game/script.rpy:6856
translate es playername_18d500d4:

    # "The sun continues to set a brilliant red closing in on nightime."
    "El sol continúa poniéndose en un rojo brillante que da paso a la noche."

# game/game/script.rpy:6858
translate es playername_c88015fe:

    # "Soon enough Ray steps out of the bathroom clothed in a comfy sweater and jeans as normal."
    "Pronto Ray sale del baño vestido con un suéter cómodo y jeans, como siempre."

# game/game/script.rpy:6866
translate es playername_c870edc9:

    # r "Have you eaten?"
    r "¿Has comido?"

# game/game/script.rpy:6870
translate es playername_31eced54:

    # "He glances at me while drying off his hair with a towel."
    "Me mira mientras se seca el cabello con una toalla."

# game/game/script.rpy:6872
translate es playername_6a20a80d_1:

    # "I shake my head."
    "Niego con la cabeza."

# game/game/script.rpy:6874
translate es playername_865bc202:

    # mc "No, I'm not too hungry."
    mc "No, no tengo mucha hambre."

# game/game/script.rpy:6878
translate es playername_aa3e8688:

    # r "You should eat at least something, your body has been through a lot."
    r "Deberías comer al menos algo, tu cuerpo ha pasado por mucho."

# game/game/script.rpy:6880
translate es playername_0acda16a:

    # r "I'll order you some food."
    r "Pediré algo de comida para ti."

# game/game/script.rpy:6882
translate es playername_b174efaa:

    # mc "Wow, my hero~"
    mc "Vaya, mi héroe~"

# game/game/script.rpy:6886
translate es playername_a350bc68:

    # "A little smirk plays on Ray's lips."
    "Una pequeña sonrisa aparece en los labios de Ray."

# game/game/script.rpy:6888
translate es playername_f724af16:

    # r "And don't you forget it Star."
    r "Y no lo olvides, Estrella."

# game/game/script.rpy:6892
translate es playername_4c137a26:

    # r "What kind of food do you like?"
    r "¿Qué tipo de comida te gusta?"

# game/game/script.rpy:6894
translate es playername_8619f2c6:

    # "I shrug."
    "Me encojo de hombros."

# game/game/script.rpy:6896
translate es playername_7ba3483e:

    # mc "Maybe something...comforting."
    mc "Quizá algo... reconfortante."

# game/game/script.rpy:6898
translate es playername_91fb26b4:

    # "Ray chuckles."
    "Ray se ríe."

# game/game/script.rpy:6902
translate es playername_4f147133:

    # r "Catch."
    r "Atrápalo."

# game/game/script.rpy:6904
translate es playername_c4f03d7b:

    # "He tosses me his phone and leans against the wall."
    "Me lanza su teléfono y se apoya contra la pared."

# game/game/script.rpy:6925
translate es playername_0966b75a:

    # r "Get whatever you want."
    r "Pide lo que quieras."

# game/game/script.rpy:6927
translate es playername_ce8e544a:

    # mc "Whatever I want huh? Maybe I'm feeling some wagyu and lobster."
    mc "¿Lo que quiera, eh? Tal vez me apetezca wagyu y langosta."

# game/game/script.rpy:6929
translate es playername_d32a7b71:

    # "I peek up at Ray who just smirks down at me."
    "Levanto la vista hacia Ray, que solo me mira con una sonrisa burlona."

# game/game/script.rpy:6931
translate es playername_7cb686e1:

    # r "Are you trying to scare me? Get two."
    r "¿Intentas asustarme? Pide dos."

# game/game/script.rpy:6933
translate es playername_129c2868:

    # "I groan."
    "Gimo."

# game/game/script.rpy:6935
translate es playername_8cd8ae30:

    # mc "You are no fun~"
    mc "No tienes nada de divertido~"

# game/game/script.rpy:6939
translate es playername_e489b25b:

    # r "I fight villains all day, a little brat like you is hardly enough to push my buttons."
    r "Peleo con villanos todo el día, un diablillo como tú difícilmente logra alterarme."

# game/game/script.rpy:6941
translate es playername_04b60551:

    # mc "Wow! Insults huh?"
    mc "¡Vaya! ¿Insultos, eh?"

# game/game/script.rpy:6945
translate es playername_66ca2066:

    # "Ray laughs brushing a hand through his damp hair."
    "Ray ríe, pasando una mano por su cabello húmedo."

# game/game/script.rpy:6947
translate es playername_dbf846b4:

    # "Part of me wondered how Ray would react if he found out that I used to be a small-time villain."
    "Parte de mí se preguntaba cómo reaccionaría Ray si descubriera que solía ser parte de los villanos."

# game/game/script.rpy:6949
translate es playername_a4b599f5:

    # "When he pushes his hair back I notice his pierced ears."
    "Cuando se echa el cabello hacia atrás, noto sus orejas perforadas."

# game/game/script.rpy:6951
translate es playername_4680bf68:

    # mc "Kinda strange for a hero like you to have their ears pierced."
    mc "Un poco extraño para un héroe como tú tener las orejas perforadas."

# game/game/script.rpy:6953
translate es playername_e9100004:

    # r "Hmm? ...You think so?"
    r "¿Hmm? ...¿Eso crees?"

# game/game/script.rpy:6955
translate es playername_71843aa4:

    # mc "It doesn't really fit the 'hero' image."
    mc "No encaja mucho con la imagen de 'héroe'."

# game/game/script.rpy:6957
translate es playername_a4a00bc5:

    # r "Yeah, I guess not."
    r "Sí, supongo que no."

# game/game/script.rpy:6959
translate es playername_8f2d3edf:

    # mc "When did you get them pierced?"
    mc "¿Cuándo te las perforaste?"

# game/game/script.rpy:6961
translate es playername_d7514360:

    # r "Ah, hmm...sometime when I was a teenager..."
    r "Ah, hmm... en algún momento cuando era adolescente..."

# game/game/script.rpy:6963
translate es playername_47b35cb9:

    # r "I don't exactly remember {i}when {/i} to be honest."
    r "Para ser sincero, no recuerdo exactamente {i}cuándo{/i}."

# game/game/script.rpy:6965
translate es playername_ea6e8ec6:

    # mc "Went through a rebellious phase huh?"
    mc "¿Pasaste por una etapa rebelde, eh?"

# game/game/script.rpy:6967
translate es playername_eecbf4bc:

    # r "Something like that."
    r "Algo así."

# game/game/script.rpy:6969
translate es playername_f03c7007:

    # r "They were so strict at the NAHA, it was hard not to be a shitty rebellious teenager at least once."
    r "Eran tan estrictos en la NAHA que era difícil no ser un adolescente rebelde de mierda al menos una vez."

# game/game/script.rpy:6971
translate es playername_6bc7d9b2:

    # mc "A lot of people get recruited into being a hero, but you were basically one from birth huh?"
    mc "Mucha gente es reclutada para ser héroe, pero tú básicamente lo fuiste desde que naciste, ¿no?"

# game/game/script.rpy:6973
translate es playername_17e5f398:

    # r "I was talented like that."
    r "Tenía talento para eso."

# game/game/script.rpy:6975
translate es playername_6a336543:

    # mc "Did you still get to do like...normal kid things?"
    mc "¿Aun así podías hacer... cosas normales de niño?"

# game/game/script.rpy:6979
translate es playername_85f34a57:

    # "Ray's face falls for half a second before snapping back to it's original expression."
    "El rostro de Ray decae por medio segundo antes de volver a su expresión habitual."

# game/game/script.rpy:6983
translate es playername_4760c8d6:

    # r "Of course, my childhood was pretty normal, even boring."
    r "Por supuesto, mi infancia fue bastante normal, incluso aburrida."

# game/game/script.rpy:6985
translate es playername_af4a5744:

    # r "Somehow, I don't get the feeling that {i}you{/i} can be the judge of what 'normal' things are."
    r "De alguna forma, no me da la impresión de que {i}tú{/i} puedas juzgar lo que es 'normal'."

# game/game/script.rpy:6987
translate es playername_a97b2200:

    # r "As I'm pretty sure lattes aren't usually green."
    r "Estoy bastante seguro de que los lattes no suelen ser verdes."

# game/game/script.rpy:6989
translate es playername_777d41b1:

    # mc "Rudeee!"
    mc "¡Grosero!"

# game/game/script.rpy:6991
translate es playername_c41a2493:

    # "I hold up his phone as if I will throw it."
    "Levanto su teléfono como si fuera a lanzarlo."

# game/game/script.rpy:6993
translate es playername_91fb26b4_1:

    # "Ray chuckles."
    "Ray se ríe."

# game/game/script.rpy:6995
translate es playername_5ac4fd62:

    # r "It was a joke, a JOKE!"
    r "¡Era una broma, una BROMA!"

# game/game/script.rpy:6997
translate es playername_33b0bdc2:

    # "I glare at him, phone still in the air."
    "Lo miro con el ceño fruncido, el teléfono aún en el aire."

# game/game/script.rpy:6999
translate es playername_992cb799:

    # r "Okay! Okay, I'm sorry, I didn't mean it."
    r "¡Está bien! ¡Está bien, lo siento, no fue mi intención!"

# game/game/script.rpy:7012
translate es playername_00921701:

    # r "I'm sure you had a very normal upbringing and turned out very..."
    r "Seguro que tu crianza fue muy normal y que resultaste muy..."

# game/game/script.rpy:7014
translate es playername_76914e8f:

    # r "{i}Normal {/i} from it."
    r "{i}Normal{/i} gracias a eso."

# game/game/script.rpy:7040
translate es playername_3d10a9f5:

    # "I lower the phone and Ray sits next to me on the bed."
    "Bajo el teléfono y Ray se sienta a mi lado en la cama."

# game/game/script.rpy:7044
translate es playername_a86a23a1:

    # "I hand his phone back."
    "Le devuelvo el teléfono."

# game/game/script.rpy:7046
translate es playername_271c6a25:

    # r "You didn't order anything..?"
    r "¿No pediste nada..?"

# game/game/script.rpy:7048
translate es playername_207b58f5:

    # mc "I can just do it on my own phone, I don't want to have you spend money on me like that."
    mc "Puedo hacerlo desde mi propio teléfono, no quiero que gastes dinero en mí de esa forma."

# game/game/script.rpy:7052
translate es playername_964c130f:

    # "Ray rolls his eyes."
    "Ray pone los ojos en blanco."

# game/game/script.rpy:7054
translate es playername_4a84f0e4:

    # r "I'll go out and pick you up something then."
    r "Entonces saldré y te compraré algo."

# game/game/script.rpy:7056
translate es playername_c9f8c2bc:

    # mc "There's some food in the fridge, I'll just find something from there."
    mc "Hay algo de comida en el refrigerador, ya encontraré algo ahí."

# game/game/script.rpy:7073
translate es playername_20e20d8a:

    # "I get up and open the fridge, finding some fruits to snack on."
    "Me levanto y abro el refrigerador, encontrando unas frutas para picar."

# game/game/script.rpy:7075
translate es playername_4992dac1:

    # "Ray narrows his eyes at the small amount of food, but doesn't comment."
    "Ray entrecierra los ojos ante la poca cantidad de comida, pero no comenta nada."

# game/game/script.rpy:7077
translate es playername_d4af937d:

    # "I sit on the kitchen counter and start to eat the fruit."
    "Me siento sobre la encimera de la cocina y empiezo a comer la fruta."

# game/game/script.rpy:7079
translate es playername_3d5f8111:

    # mc "So what are those alien things anyways?"
    mc "Entonces, ¿qué son esas cosas alienígenas exactamente?"

# game/game/script.rpy:7081
translate es playername_46af4b8f:

    # "Ray sighs."
    "Ray suspira."

# game/game/script.rpy:7086
translate es playername_4290b368:

    # r "We aren't really sure. Every couple of weeks they send one or two more."
    r "No estamos realmente seguros. Cada par de semanas envían uno o dos más."

# game/game/script.rpy:7088
translate es playername_b618994d:

    # r "Lately it has been happening with more frequency."
    r "Últimamente ha estado ocurriendo con más frecuencia."

# game/game/script.rpy:7090
translate es playername_551ca08b:

    # r "They are really destructive... and seem to...kill rather than eat or capture."
    r "Son muy destructivos... y parecen... matar en lugar de comer o capturar."

# game/game/script.rpy:7092
translate es playername_00067c4d:

    # r "So you have to be really careful if you end up around one."
    r "Así que debes tener mucho cuidado si alguna vez te encuentras cerca de uno."

# game/game/script.rpy:7094
translate es playername_ff4404f4:

    # r "Their sight isn't too good, but they have excellent hearing."
    r "Su vista no es muy buena, pero tienen un oído excelente."

# game/game/script.rpy:7101
translate es playername_71247219:

    # "Ray approaches me, looking down at me from where I sit on the counter."
    "Ray se acerca a mí, mirándome desde donde estoy en la encimera."

# game/game/script.rpy:7103
translate es playername_06c7738a:

    # r "If you are ever in trouble, just yell for me and no matter where I am..."
    r "Si alguna vez estás en peligro, solo grita por mí y sin importar dónde esté..."

# game/game/script.rpy:7105
translate es playername_bf1f6acf:

    # r "{b}I will save you.{/b}"
    r "{b}Te salvaré.{/b}"

# game/game/script.rpy:7107
translate es playername_74956026:

    # "His intense gaze pierces my eyes."
    "Su mirada intensa atraviesa mis ojos."

# game/game/script.rpy:7127
translate es playername_0e7b86c9:

    # "I look away, his depthless eyes making me feel flustered."
    "Aparto la vista, sus ojos insondables me hacen sentir nervios."

# game/game/script.rpy:7146
translate es playername_9ea61b2a:

    # "He places his hand on my face redirecting it back towards his own."
    "Coloca su mano en mi rostro, dirigiéndolo de nuevo hacia el suyo."

# game/game/script.rpy:7148
translate es playername_7e3180ae:

    # "He brushes away some fruit juice I didn't realize was on my cheek."
    "Limpia un poco de jugo de fruta que no me había dado cuenta que tenía en la mejilla."

# game/game/script.rpy:7151
translate es playername_10801f09:

    # r "It's never boring with you around, that's for sure."
    r "Contigo cerca nunca es aburrido, eso seguro."

# game/game/script.rpy:7153
translate es playername_0e4e006c:

    # "I blush, embarrassed."
    "Me sonrojo, por la vergüenza."

# game/game/script.rpy:7168
translate es playername_bfdafe13:

    # "After finishing my fruit, I throw away the container and head towards my bed flipping on the TV."
    "Después de terminar mi fruta, tiro el envase y me dirijo a la cama encendiendo la televisión."

# game/game/script.rpy:7170
translate es playername_2898be11:

    # "There was a special on music that has hit top charts lately."
    "Había un especial sobre música que había llegado a los primeros puestos últimamente."

# game/game/script.rpy:7172
translate es playername_ea216d0a:

    # mc "Oh look there's Blaze!"
    mc "Oh, ¡mira, ahí está Blaze!"

# game/game/script.rpy:7174
translate es playername_fa3ec1d7:

    # mc "I didn't know he was in a band."
    mc "No sabía que estaba en una banda."

# game/game/script.rpy:7181
translate es playername_894549fd:

    # "Ray sits next to me."
    "Ray se sienta a mi lado."

# game/game/script.rpy:7183
translate es playername_ea669678:

    # r "Yeah, I don't think he is in it for a love of music though."
    r "Sí, aunque no creo que lo haga por amor a la música."

# game/game/script.rpy:7185
translate es playername_a61867f1:

    # mc "What kind of music do you like?"
    mc "¿Qué tipo de música te gusta?"

# game/game/script.rpy:7188
translate es playername_4ba02f1f:

    # "Ray looks at me with a smile playing on his lips."
    "Ray me mira con una sonrisa juguetona en los labios."

# game/game/script.rpy:7190
translate es playername_0a968e2d:

    # r "I don't know...I don't really go out of my way to listen to any specific kind of music."
    r "No lo sé... no suelo ir buscando un tipo específico de música."

# game/game/script.rpy:7192
translate es playername_f809e78e:

    # r "Whatever's on the radio is fine, I guess."
    r "Lo que suene en la radio está bien, supongo."

# game/game/script.rpy:7194
translate es playername_66983fa8:

    # mc "Really? You give me the vibe that you would be into classic rock or something."
    mc "¿En serio? Me das la vibra de que te gustaría el rock clásico o algo así."

# game/game/script.rpy:7198
translate es playername_ea12d15c:

    # r "Are...you calling me old or something...?"
    r "¿Estás... llamándome viejo o algo...?"

# game/game/script.rpy:7200
translate es playername_56a69308:

    # mc "NO! Not at all."
    mc "¡NO! Para nada."

# game/game/script.rpy:7203
translate es playername_3025e57a:

    # r "Good, you aren't allowed to comment on my age unless you can outrun me."
    r "Bien, no tienes permitido comentar sobre mi edad a menos que puedas correr más rápido que yo."

# game/game/script.rpy:7205
translate es playername_8ddc672c:

    # mc "There is going to come a day where I can..."
    mc "Llegará el día en que pueda hacerlo..."

# game/game/script.rpy:7207
translate es playername_b2778eff:

    # "Ray scoffs."
    "Ray resopla."

# game/game/script.rpy:7211
translate es playername_9bafc913:

    # r "Not on your life kid."
    r "Ni en tus sueños."

# game/game/script.rpy:7213
translate es playername_81dfae1b:

    # mc "...too proud."
    mc "...demasiado orgulloso."

# game/game/script.rpy:7218
translate es playername_8ca0ac78:

    # r "The articles say my 'pride' is what's sexy about me."
    r "Los artículos dicen que mi 'orgullo' es lo que me hace sexy."

# game/game/script.rpy:7220
translate es playername_9f62f3ff:

    # mc "You search yourself on the internet!? That's embarrassing Ray, I'd never admit to something like that."
    mc "¿¡Te buscas a ti mismo en internet!? Eso es vergonzoso, Ray, yo nunca admitiría algo así."

# game/game/script.rpy:7222
translate es playername_7864662b:

    # r "The internet? No, not really. Magazines, sometimes when I see one with my name on the cover. It's hard not to be curious."
    r "¿Internet? No, no realmente. Revistas, a veces cuando veo una con mi nombre en la portada. Es difícil no sentir curiosidad."

# game/game/script.rpy:7224
translate es playername_0fec3139:

    # mc "Magazines? I take it back, you really are an old man."
    mc "¿Revistas? Me retracto, definitivamente sí eres un viejo."

# game/game/script.rpy:7228
translate es playername_f8236259:

    # "Ray's smile looks a little annoyed."
    "La sonrisa de Ray parece un poco molesta."

# game/game/script.rpy:7230
translate es playername_7f094578:

    # r "You are such a little brat..."
    r "Eres como un diablillo..."

# game/game/script.rpy:7232
translate es playername_cacaf5e2:

    # "I laugh. Blaze's face shows across the screen, sweating on stage while he screams into a microphone."
    "Me río. El rostro de Blaze aparece en la pantalla, sudando en el escenario mientras grita frente al micrófono."

# game/game/script.rpy:7236
translate es playername_2ba66032:

    # mc "You know, he came in to order coffee once..."
    mc "Sabes, vino una vez a pedir café..."

# game/game/script.rpy:7240
translate es playername_a1e31ee7:

    # r "I vaguely remember your coworker mentioning it..."
    r "Vagamente recuerdo que tu compañero de trabajo lo mencionó..."

# game/game/script.rpy:7242
translate es playername_afc20c44:

    # r "I'm guessing Blaze wasn't there for the coffee?"
    r "Supongo que Blaze no estaba ahí por el café, ¿eh?"

# game/game/script.rpy:7246
translate es playername_a0847b44:

    # mc "He wouldn't take 'no' for an answer."
    mc "No aceptaba un 'no' por respuesta."

# game/game/script.rpy:7248
translate es playername_f3be20a0:

    # mc "He was...very determined on taking me out to dinner."
    mc "Estaba... muy empeñado en invitarme a cenar."

# game/game/script.rpy:7250
translate es playername_9ea9acc0:

    # mc "I'm not stupid enough to think that for someone like him an offer like that is simply a nice invitation."
    mc "No soy tan idiota como para pensar que, para alguien como él, una oferta así es solo una amable invitación."

# game/game/script.rpy:7252
translate es playername_43e4bb53:

    # mc "I get the feeling that he's the type to feel owed after taking someone out to dinner."
    mc "Tengo la sensación de que es del tipo que se siente con derecho a algo después de invitar a alguien a cenar."

# game/game/script.rpy:7256
translate es playername_cf62a5c6:

    # "Ray had a deep frown. His silence was a bit unnerving."
    "Ray tenía un profundo ceño fruncido. Su silencio resultaba un poco inquietante."

# game/game/script.rpy:7258
translate es playername_0891d9fd:

    # "I attempted to lighten the mood."
    "Intenté aligerar el ambiente."

# game/game/script.rpy:7260
translate es playername_49839f72:

    # mc "I don't know how you survived with him as a sidekick. I couldn't even survive 15 minutes around the guy."
    mc "No sé cómo sobreviviste teniéndolo como compañero. Yo no podría soportar ni quince minutos cerca de ese tipo."

# game/game/script.rpy:7264
translate es playername_be309383:

    # r " After a while I essentially fired him, but the NAHA decided to just promote him into a hero in order to 'preserve my clean record'."
    r "Después de un tiempo básicamente lo despedí, pero la NAHA decidió promoverlo a héroe para 'preservar mi historial limpio'."

# game/game/script.rpy:7266
translate es playername_ae1aca13:

    # mc "What's the NAHA...?"
    mc "¿Qué es la NAHA...?"

# game/game/script.rpy:7268
translate es playername_5d1a8768:

    # "A smirk quirked on Ray's lips."
    "Una sonrisa ladeada se dibujó en los labios de Ray."

# game/game/script.rpy:7272
translate es playername_8c22a258:

    # r "'North American Heroes Association.'"
    r "'North American Heroes Association.'"

# game/game/script.rpy:7276
translate es playername_2da0bc86:

    # r "You really don't know anything about heroes huh?"
    r "Realmente no sabes nada sobre héroes, ¿eh?"

# game/game/script.rpy:7278
translate es playername_46b7b77a:

    # "I roll my eyes."
    "Pongo los ojos en blanco."

# game/game/script.rpy:7280
translate es playername_9c17dce1:

    # mc "Do you {i} want {/i} me to freak out over you?"
    mc "¿Quieres que me altere por ti?"

# game/game/script.rpy:7282
translate es playername_9ec057e0:

    # mc "'Oh my GOD Binary Star is in my apartment, I can now die happy!~'"
    mc "'¡Oh DIOS MÍO, Binary Star está en mi apartamento, ahora puedo morir feliz!~'"

# game/game/script.rpy:7283
translate es playername_91fb26b4_2:

    # "Ray chuckles."
    "Ray se ríe."

# game/game/script.rpy:7287
translate es playername_c9464852:

    # r "If it's you, I don't even mind shaking your hand or autographing your forehead."
    r "Si se trata de ti, no me molestaría ni darte la mano ni firmarte la frente."

# game/game/script.rpy:7289
translate es playername_66d8be85:

    # mc "Do people ask for that...?"
    mc "¿La gente pide eso...?"

# game/game/script.rpy:7293
translate es playername_594a1b33:

    # r "You would be...surprised what people ask for."
    r "Te sorprendería lo que la gente pide."

# game/game/script.rpy:7295
translate es playername_86a6a636:

    # "I shudder."
    "Tirité."

# game/game/script.rpy:7301
translate es playername_b2e8b75f:

    # "Ray gets up, positioning himself against the familiar wall."
    "Ray se levanta, colocándose contra la pared familiar."

# game/game/script.rpy:7303
translate es playername_51e7d89b:

    # r "You should get some sleep... it's late and your body is probably still healing from the shock."
    r "Deberías dormir un poco… es tarde y tu cuerpo probablemente aún se está recuperando del shock."

# game/game/script.rpy:7305
translate es playername_403c43a1:

    # "Some part of me does feel nervous about Ray in my very small apartment..."
    "Una parte de mí sí se siente nerviosa por Ray en mi pequeño apartamento…"

# game/game/script.rpy:7307
translate es playername_39024f79:

    # "He smirks at me and I look away quickly remembering that he can read my thoughts."
    "Él me sonríe con aire burlón y aparto la mirada rápidamente, recordando que puede leer mis pensamientos."

# game/game/script.rpy:7311
translate es playername_e3cf5eda:

    # "He lights a cigarette."
    "Enciende un cigarrillo."

# game/game/script.rpy:7328
translate es playername_51cc7425:

    # cg "{color=#CD9300}'Get some sleep Star, I'll watch over you until my shift.'{/color}"
    cg "{color=#CD9300}'Duerme un poco, Estrella, te vigilaré hasta mi turno.'{/color}"

# game/game/script.rpy:7336
translate es playername_e702a628:

    # cg "{color=#510f80}'Ray, I can't sleep alone...'{/color}"
    cg "{color=#510f80}'Ray, no puedo dormir sin compañía...'{/color}"

# game/game/script.rpy:7344
translate es playername_751ec9e0:

    # cg "{color=#CD9300}'.....'{/color}"
    cg "{color=#CD9300}'.....'{/color}"

# game/game/script.rpy:7346
translate es playername_5534743c:

    # cg "{color=#CD9300} 'Excuse me....?'{/color}"
    cg "{color=#CD9300} '¿Disculpa....?'{/color}"

# game/game/script.rpy:7348
translate es playername_f9c20947:

    # cg "{color=#510f80}'I'm too scared to sleep alone...'{/color}"
    cg "{color=#510f80}'Tengo demasiado miedo para dormir sin compañía...'{/color}"

# game/game/script.rpy:7350
translate es playername_c7c85f33:

    # cg "{color=#CD9300}'...'{/color}"
    cg "{color=#CD9300}'...'{/color}"

# game/game/script.rpy:7352
translate es playername_965c8ac8:

    # cg "{color=#510f80}'So can you...sleep with me~'{/color}"
    cg "{color=#510f80}'Entonces... ¿puedes dormir conmigo~?'{/color}"

# game/game/script.rpy:7354
translate es playername_efc2b4a5:

    # cg "You stare at Ray pleadingly."
    cg "Miras a Ray suplicante."

# game/game/script.rpy:7366
translate es playername_f7d63862:

    # cg "Ray sighs. He puts out his cigarette and closes the window."
    cg "Ray suspira. Apaga su cigarrillo y cierra la ventana."

# game/game/script.rpy:7381
translate es playername_3c6dd874:

    # "He approaches the side of the bed."
    "Se acerca al costado de la cama."

# game/game/script.rpy:7383
translate es playername_3bbc6da0:

    # r "I have to report to the office in a few hours so I won't be able to stay all night."
    r "Tengo que presentarme en la oficina en unas horas, así que no podré quedarme toda la noche."

# game/game/script.rpy:7385
translate es playername_05bbcfcc:

    # mc "Just till I fall asleep."
    mc "Solo hasta que me duerma."

# game/game/script.rpy:7387
translate es playername_b9b755e5_4:

    # r "..."
    r "..."

# game/game/script.rpy:7389
translate es playername_56a2acce:

    # mc "Pleaaassee Ray?"
    mc "¿Pooor favor, Ray?"

# game/game/script.rpy:7391
translate es playername_8e85046d:

    # "I give my biggest pleading eyes and Ray sighs."
    "Le pongo mi mejor cara de súplica y Ray suspira."

# game/game/script.rpy:7393
translate es playername_aaf6a4e7:

    # r "Fine. Scoot over."
    r "Está bien. Muévete un poco."

# game/game/script.rpy:7396
translate es playername_bf600798:

    # "Ray takes off his outer sweater making a comment about how it smelled like smoke."
    "Ray se quita su suéter exterior haciendo un comentario sobre cómo olía a humo."

# game/game/script.rpy:7398
translate es playername_cf2439db:

    # "I scoot over leaving room for the chronically tired looking man."
    "Me hago a un lado dejando espacio para el hombre con aspecto crónicamente cansado."

# game/game/script.rpy:7400
translate es playername_cd6874f3:

    # "The bed dips as Ray gets in."
    "La cama se hunde cuando Ray se mete."

# game/game/script.rpy:7421
translate es playername_1d3b287b:

    # cg "Once in the bed he props his head up on his hand looking down at me."
    cg "Una vez en la cama, apoya la cabeza en su mano mirándome hacia abajo."

# game/game/script.rpy:7423
translate es playername_2854824c:

    # cg "He looks awkward and somewhat uncomfortable."
    cg "Parece incómodo y algo tenso."

# game/game/script.rpy:7425
translate es playername_76f0c038:

    # cg "He shifts his gaze away avoiding eye contact."
    cg "Aparta la mirada, evitando el contacto visual."

# game/game/script.rpy:7427
translate es playername_c90acb3b:

    # cg "I continue to gaze at him."
    cg "Sigo mirándolo."

# game/game/script.rpy:7432
translate es playername_2f02d4d3:

    # cg "He pushes my face away lightly."
    cg "Él aparta mi cara suavemente."

# game/game/script.rpy:7433
translate es playername_e28af2c6:

    # cg "{color=#CD9300} 'Stop.' {/color}"
    cg "{color=#CD9300} 'Detente.' {/color}"

# game/game/script.rpy:7434
translate es playername_6797da3a:

    # cg "{color=#510f80} 'You are so far away...' {/color}"
    cg "{color=#510f80} 'Estás tan lejos...' {/color}"

# game/game/script.rpy:7435
translate es playername_c7c85f33_1:

    # cg "{color=#CD9300}'...'{/color}"
    cg "{color=#CD9300}'...'{/color}"

# game/game/script.rpy:7436
translate es playername_de6974cb:

    # cg "{color=#510f80} 'I'm so cold....' {/color}"
    cg "{color=#510f80} 'Tengo tanto frío....' {/color}"

# game/game/script.rpy:7441
translate es playername_d8459c42:

    # cg "{color=#CD9300} '...' {/color}"
    cg "{color=#CD9300} '...' {/color}"

# game/game/script.rpy:7442
translate es playername_70e44e70:

    # cg "{color=#510f80} {i} 'so...sooo cold~~' {/i}{/color}"
    cg "{color=#510f80} {i} 'tan... taaan frío~~' {/i}{/color}"

# game/game/script.rpy:7443
translate es playername_d8459c42_1:

    # cg "{color=#CD9300} '...' {/color}"
    cg "{color=#CD9300} '...' {/color}"

# game/game/script.rpy:7444
translate es playername_d2d3a074:

    # cg "{color=#510f80} 'It's almost like I'm all alone,... I feel like maybe I'll get scared again...' {/color}"
    cg "{color=#510f80} 'Es casi como si estuviera completamente sin nadie,... siento que tal vez me asuste otra vez...' {/color}"

# game/game/script.rpy:7451
translate es playername_41c27c41:

    # cg "Ray groans."
    cg "Ray gime con fastidio."

# game/game/script.rpy:7452
translate es playername_17cf5f4d:

    # cg "{color=#CD9300} 'Fine!' {/color}"
    cg "{color=#CD9300} '¡Está bien!' {/color}"

# game/game/script.rpy:7467
translate es playername_f4e6ed1a:

    # cg "He wraps an arm around my waist easily pulling me closer into him."
    cg "Me envuelve la cintura con un brazo, atrayéndome fácilmente hacia él."

# game/game/script.rpy:7469
translate es playername_adbaf12a:

    # cg " His chest feels firm and warm, padded by his sweater. "
    cg "Su pecho se siente firme y cálido, acolchado por su suéter."

# game/game/script.rpy:7471
translate es playername_b1189e85:

    # cg "{i} So that's what you were hiding under that frumpy sweater Mr.Ray... {/i}"
    cg "{i} Así que esto era lo que escondías bajo ese suéter feo, señor Ray... {/i}"

# game/game/script.rpy:7477
translate es playername_d9a45b09:

    # cg "{color=#CD9300} 'It's {i} not {/i} frumpy and don't think shit like that when you are this close to me.' {/color}"
    cg "{color=#CD9300} 'No es {i} feo {/i} y no pienses esas cosas estando tan cerca de mí.' {/color}"

# game/game/script.rpy:7479
translate es playername_16081c4c:

    # cg "{color=#510f80} 'Hey! It's not like I asked you to read my thoughts!' {/color}"
    cg "{color=#510f80} '¡Oye! ¡No es como si te hubiera pedido que leyeras mis pensamientos!' {/color}"

# game/game/script.rpy:7485
translate es playername_b6c96b64:

    # cg "{color=#CD9300} 'It's not like I {i} want to {/i}.' {/color}"
    cg "{color=#CD9300} 'No es como si {i} quisiera {/i} hacerlo.' {/color}"

# game/game/script.rpy:7487
translate es playername_080ee2f1:

    # cg "{color=#CD9300} 'It's hard not to when you are...this close.' {/color}"
    cg "{color=#CD9300} 'Es difícil no hacerlo cuando estás... tan cerca.' {/color}"

# game/game/script.rpy:7489
translate es playername_5a2aba9f:

    # cg "{color=#510f80} 'Pervert.' {/color}"
    cg "{color=#510f80} 'Pervertido.' {/color}"

# game/game/script.rpy:7499
translate es playername_590e90da:

    # cg "{color=#CD9300} 'Exhibitionist.'{/color}"
    cg "{color=#CD9300} 'Exhibicionista.'{/color}"

# game/game/script.rpy:7501
translate es playername_f34955cd:

    # cg "I laugh out loud."
    cg "Suelto una carcajada."

# game/game/script.rpy:7506
translate es playername_5daa9fde:

    # cg "Ray ruffles my hair."
    cg "Ray me revuelve el cabello."

# game/game/script.rpy:7508
translate es playername_f66b0e5f:

    # cg "{color=#CD9300} 'Stop being a brat and get some sleep.'{/color}"
    cg "{color=#CD9300} 'Deja de actuar como un diablillo y duerme un poco.'{/color}"

# game/game/script.rpy:7510
translate es playername_677f0d22:

    # cg "I muster up all the sarcasm I can."
    cg "Reuno toda la ironía que puedo."

# game/game/script.rpy:7512
translate es playername_399990f3:

    # cg "{color=#510f80} {i}'Yes sir.'{/i} {/color}"
    cg "{color=#510f80} {i}'Sí señor.'{/i} {/color}"

# game/game/script.rpy:7514
translate es playername_7a5a106d:

    # cg "I could feel Ray's dick twitch in his pants and he shifts slightly away from me."
    cg "Pude sentir el miembro de Ray estremecerse en sus pantalones y él se aparta ligeramente de mí."

# game/game/script.rpy:7516
translate es playername_02026504:

    # cg "I shove my body closer to his."
    cg "Empujo mi cuerpo más cerca del suyo."

# game/game/script.rpy:7529
translate es playername_68eeb2cd:

    # cg "{color=#CD9300} 'Don't play with me %(player_name)s...' {/color}"
    cg "{color=#CD9300} 'No juegues conmigo %(player_name)s...' {/color}"

# game/game/script.rpy:7531
translate es playername_9ebec0fb:

    # cg "{color=#CD9300} 'You need sleep.' {/color}"
    cg "{color=#CD9300} 'Necesitas dormir.' {/color}"

# game/game/script.rpy:7533
translate es playername_566ef800:

    # cg "{color=#510f80} 'You know what I need?' {/color}"
    cg "{color=#510f80} '¿Sabes qué necesito?' {/color}"

# game/game/script.rpy:7535
translate es playername_636cedad:

    # cg "{color=#CD9300} 'Yes, now go to-' {/color}"
    cg "{color=#CD9300} 'Sí, ahora ve a-' {/color}"

# game/game/script.rpy:7537
translate es playername_d5035207:

    # cg "{color=#510f80} 'I think {i} part {/i} of your body knows what I need.' {/color}"
    cg "{color=#510f80} 'Creo que {i}una parte{/i} de tu cuerpo sabe lo que necesito.' {/color}"

# game/game/script.rpy:7539
translate es playername_ef7f31f1:

    # cg "I could feel him get increasingly harder."
    cg "Podía sentirlo endurecerse cada vez más."

# game/game/script.rpy:7547
translate es playername_d6c1ce9b:

    # cg "{color=#CD9300} %(player_name)s... {/color}"
    cg "{color=#CD9300} %(player_name)s... {/color}"

# game/game/script.rpy:7553
translate es playername_acb57e64:

    # cg "{color=#CD9300} 'If you keep being a fucking tease, neither of us are going to get any sleep tonight.' {/color}"
    cg "{color=#CD9300} 'Si sigues provocando así, ninguno de los dos dormirá esta noche.' {/color}"

# game/game/script.rpy:7555
translate es playername_f187009c:

    # cg "{color=#CD9300} 'That is a promise.' {/color}"
    cg "{color=#CD9300} 'Eso es una promesa.' {/color}"

# game/game/script.rpy:7564
translate es playername_09fb6bb0:

    # cg "Ray leans in. His hot whispered breath brushing over the shell of my ear."
    cg "Ray se inclina. Su aliento caliente roza la parte de atrás de mi oreja."

# game/game/script.rpy:7570
translate es playername_0a62bc38:

    # cg "{color=#CD9300} 'You are stepping on my last ounce of self control %(player_name)s.' {/color}"
    cg "{color=#CD9300} 'Estás pisando mi última gota de autocontrol, %(player_name)s.' {/color}"

# game/game/script.rpy:7572
translate es playername_4d091b1a:

    # cg "Ray's tone was seeped in warning. "
    cg "El tono de Ray estaba cargado de advertencia."

# game/game/script.rpy:7574
translate es playername_2c707436:

    # cg "I sigh in defeat."
    cg "Suspiro con derrota."

# game/game/script.rpy:7576
translate es playername_38895491:

    # cg "{color=#510f80}'Fineeee, I'll stop.'{/color}"
    cg "{color=#510f80}'Bueeeno, pararé.'{/color}"

# game/game/script.rpy:7580
translate es playername_4af94f72:

    # cg "Good."
    cg "Bien."

# game/game/script.rpy:7582
translate es playername_8c6a74e4:

    # cg "Ray pats my head slowly, weaving his fingers into my hair."
    cg "Ray me acaricia la cabeza lentamente, entrelazando sus dedos en mi cabello."

# game/game/script.rpy:7584
translate es playername_87e8a303:

    # cg "His other arm wrapped firmly around my waist."
    cg "Su otro brazo se envuelve firmemente alrededor de mi cintura."

# game/game/script.rpy:7586
translate es playername_13b84782:

    # cg "With the comfort of Ray right next to me I'm able to drift off into sleep."
    cg "Con el consuelo de Ray justo a mi lado logro dormir."

# game/game/script.rpy:7601
translate es playername_5bcf981c:

    # "I stare at Ray as he gazes back, the frame of the city silhouetting him beautifully."
    "Miro a Ray mientras él me devuelve la mirada, con el marco de la ciudad silueteándolo hermosamente."

# game/game/script.rpy:7603
translate es playername_c2a02036:

    # "He puffs on his cigarette while staring at me."
    "Da una calada a su cigarrillo mientras me observa."

# game/game/script.rpy:7605
translate es playername_38c4ab7f:

    # "His gaze almost felt....seductive."
    "Su mirada se sentía casi... seductora."

# game/game/script.rpy:7607
translate es playername_50b69bbd:

    # "I could feel my face heating up, at this rate I would never fall asleep."
    "Pude sentir mi rostro arder; a este paso nunca me dormiría."

# game/game/script.rpy:7609
translate es playername_a543bffc:

    # "I shifted my body away from him so I could stare at the wall instead."
    "Giré mi cuerpo dándole la espalda para mirar la pared en su lugar."

# game/game/script.rpy:7611
translate es playername_54cff36d:

    # "I could hear Ray chuckle a bit."
    "Pude oír a Ray reírse un poco."

# game/game/script.rpy:7613
translate es playername_cd9bfef8:

    # "{i}....bastard.{/i}"
    "{i}....bastardo.{/i}"

# game/game/script.rpy:7615
translate es playername_5135822b:

    # "After enough time passes I'm able to relax enough and drift off to sleep."
    "Después de un rato logré relajarme lo suficiente para dormirme."

# game/game/script.rpy:7633
translate es playername_720a32ff:

    # "When I wake up in the next morning Ray is nowhere to be found."
    "Cuando me despierto a la mañana siguiente, Ray ya no está."

# game/game/script.rpy:7635
translate es playername_e8e76c37:

    # "I stretch and get up."
    "Me estiro y me levanto."

# game/game/script.rpy:7637
translate es playername_fb2c0b3d:

    # "I spot a note on the bedside table."
    "Veo una nota sobre la mesa de noche."

# game/game/script.rpy:7640
translate es playername_033f47d6:

    # "{color=#CD9300} 'I left some breakfast for you in the fridge.' {/color}"
    "{color=#CD9300} 'Te dejé algo de desayuno en el refrigerador.' {/color}"

# game/game/script.rpy:7642
translate es playername_b25dc531:

    # "{color=#CD9300} 'Please refrain from going outside. If you have to, call me first.' {/color}"
    "{color=#CD9300} 'Por favor, evita salir. Si tienes que hacerlo, llámame primero.' {/color}"

# game/game/script.rpy:7644
translate es playername_2aff29eb:

    # "{color=#CD9300} 'Rest up %(player_name)s, I'll see you again tonight.' {/color}"
    "{color=#CD9300} 'Descansa, %(player_name)s, te veré esta noche.' {/color}"

# game/game/script.rpy:7646
translate es playername_6168e85f:

    # "I notice an additional note at the bottom."
    "Noto una nota adicional al final."

# game/game/script.rpy:7648
translate es playername_5921789c:

    # "{color=#CD9300} 'P.S, I didn't get a single wink of sleep thanks to {i}SOMEBODY{/i}...I won't name names.' {/color}"
    "{color=#CD9300} 'P.D. No dormí ni un segundo gracias a {i}ALGUIEN{/i}... no diré nombres.' {/color}"

# game/game/script.rpy:7650
translate es playername_efd7269c:

    # "{color=#CD9300} 'I left some breakfast for you in the fridge, feel free to heat that up and eat it.' {/color}"
    "{color=#CD9300} 'Te dejé algo de desayuno en el refrigerador, siéntete libre de calentarlo y comerlo.' {/color}"

# game/game/script.rpy:7652
translate es playername_b25dc531_1:

    # "{color=#CD9300} 'Please refrain from going outside. If you have to, call me first.' {/color}"
    "{color=#CD9300} 'Por favor, evita salir. Si tienes que hacerlo, llámame primero.' {/color}"

# game/game/script.rpy:7654
translate es playername_2aff29eb_1:

    # "{color=#CD9300} 'Rest up %(player_name)s, I'll see you again tonight.' {/color}"
    "{color=#CD9300} 'Descansa, %(player_name)s, te veré esta noche.' {/color}"

# game/game/script.rpy:7658
translate es playername_c1a04921:

    # "I spend most of the day sitting around reading and flipping through Tv."
    "Paso la mayor parte del día sentada, leyendo y cambiando canales en la televisión."

# game/game/script.rpy:7660
translate es playername_70ab4a7a:

    # "There was a special showing on Heroes."
    "Había una emisión especial sobre héroes."

# game/game/script.rpy:7662
translate es playername_c26617b5:

    # "Despite Binary star being rated top hero, there wasn't actually much information about him."
    "A pesar de que Binary Star estaba clasificado como héroe principal, en realidad no había mucha información sobre él."

# game/game/script.rpy:7664
translate es playername_64633aad:

    # "His parents died when he was young and so he was taken in by a top hero at the time 'Steel Sheriff'."
    "Sus padres murieron cuando era joven, por lo que fue acogido por un héroe de alto rango de la época, 'Steel Sheriff'."

# game/game/script.rpy:7666
translate es playername_e40aff5c:

    # "Steel Sheriff lovingly raised him as a normal boy, also training him into the hero that we now know today."
    "Steel Sheriff lo crió con cariño como a un chico normal, además de entrenarlo para convertirse en el héroe que hoy conocemos."

# game/game/script.rpy:7668
translate es playername_518336b9:

    # "I decided to search steel Sheriff on the internet to learn more about him."
    "Decidí buscar a Steel Sheriff en internet para aprender más sobre él."

# game/game/script.rpy:7670
translate es playername_2b35b6fe_2:

    # mc "..."
    mc "..."

# game/game/script.rpy:7672
translate es playername_ba00c4f3:

    # "{i}'10 Reasons why Steel Sheriff is a true Golden Age hero!' {/i}"
    "{i}'10 razones por las que Steel Sheriff es un verdadero héroe de la Edad Dorada!'{/i}"

# game/game/script.rpy:7674
translate es playername_0b87321e:

    # "{i} 'Steel Sheriff is reaching his 60s but even in retirement he isn't slowing down!' {/i}"
    "{i}'Steel Sheriff se acerca a los 60, pero incluso en el retiro no está disminuyendo el paso!'{/i}"

# game/game/script.rpy:7676
translate es playername_54aa8c5c:

    # "All of the top results were articles felt very...PR driven. I decided to check social media to get a better understanding of common opinion."
    "Todos los resultados principales eran artículos que se sentían muy... dirigidos por relaciones públicas. Decidí revisar las redes sociales para comprender mejor la opinión común."

# game/game/script.rpy:7678
translate es playername_2b35b6fe_3:

    # mc "..."
    mc "..."

# game/game/script.rpy:7680
translate es playername_c83a4cfc:

    # "The first result that appeared was a thread from a couple of weeks ago that amassed 120k likes."
    "El primer resultado que apareció fue un hilo de hace un par de semanas que acumuló 120 000 me gusta."

# game/game/script.rpy:7682
translate es playername_76b94a73:

    # "'THREAD: Steel Sheriff got away with everything, we should be talking about it:'"
    "'HILO: Steel Sheriff se salió con la suya en todo, deberíamos estar hablando de eso:'"

# game/game/script.rpy:7684
translate es playername_8fea2db2:

    # mc "Hmm..."
    mc "Hmm..."

# game/game/script.rpy:7688
translate es playername_8d9120e1:

    # "I click in the thread and start to read."
    "Hago clic en el hilo y empiezo a leer."

# game/game/script.rpy:7690
translate es playername_11425ded:

    # "'{i} During the 'Golden age' of Heroes in the '80s Steel Sheriff was quite popular.{/i}'"
    "'{i}Durante la 'Edad Dorada' de los Héroes en los años 80, Steel Sheriff era bastante popular.{/i}'"

# game/game/script.rpy:7692
translate es playername_ee802a96:

    # "'{i}Now he seems to be living remotely and out of the spotlight as his name has been steeped in controversy.{/i}'"
    "'{i}Ahora parece vivir retirado y fuera del foco público, ya que su nombre se ha visto envuelto en controversia.{/i}'"

# game/game/script.rpy:7694
translate es playername_4fd6c3e5:

    # "The thread was long, but essentially it boiled down to a gross misuse of power."
    "El hilo era largo, pero en esencia se reducía a un grave abuso de poder."

# game/game/script.rpy:7696
translate es playername_0be42bd3:

    # "Steel Sheriff have been accused of many sexual assaults and ....{i} worse{/i}."
    "Steel Sheriff fue acusado de múltiples agresiones sexuales y de... {i}peores cosas{/i}."

# game/game/script.rpy:7698
translate es playername_d59895bc:

    # "Not only that, but he seems to have been blatantly homophobic and misogynistic in the past."
    "No solo eso, sino que en el pasado parecía haber sido abiertamente homofóbico y misógino."

# game/game/script.rpy:7700
translate es playername_6f2212dc:

    # "After retirement he spiralled into alcoholism and lives in a remote area of Oklahoma."
    "Tras su retiro cayó en el alcoholismo y vive en una zona remota de Oklahoma."

# game/game/script.rpy:7702
translate es playername_db845926:

    # "Nobody sees much of him anymore, but his 60th birthday coming up has reignited feeling about him amongst the populace."
    "Ya casi nadie lo ve, pero su cumpleaños número 60 ha reavivado los sentimientos sobre él entre la gente."

# game/game/script.rpy:7704
translate es playername_2b35b6fe_4:

    # mc "..."
    mc "..."

# game/game/script.rpy:7706
translate es playername_f037c87f:

    # "I can't help but to wonder how having someone like that as a caretaker may have impacted Ray."
    "No puedo evitar preguntarme cómo haber tenido a alguien así como tutor pudo haber afectado a Ray."

# game/game/script.rpy:7708
translate es playername_6b8125f1:

    # "Apparently Ray never had any brothers or sisters. So after his parents passed, Steel Sheriff was the only one that Ray could call family."
    "Aparentemente Ray nunca tuvo hermanos ni hermanas. Así que después de que sus padres fallecieron, Steel Sheriff fue la única persona a la que Ray pudo llamar familia."

# game/game/script.rpy:7710
translate es playername_bdce6c10:

    # "I wonder how Ray feels about him..."
    "Me pregunto cómo se sentirá Ray respecto a él..."

# game/game/script.rpy:7712
translate es playername_a20cefa7_6:

    # "..."
    "..."

# game/game/script.rpy:7714
translate es playername_2c1996dc:

    # "I decide to shake the weird feeling and change the channel."
    "Decido sacudirme la sensación rara y cambiar de canal."

# game/game/script.rpy:7716
translate es playername_5e213d22:

    # "It lands on the news. Across the screen shows some heroes fighting an alien."
    "Cae en las noticias. En la pantalla se muestran algunos héroes luchando contra un alienígena."

# game/game/script.rpy:7718
translate es playername_4422a694:

    # "I watch the live news segment but I don't catch the familiar flash of blue, blonde and red."
    "Veo el segmento en vivo, pero no alcanzo a distinguir el familiar destello azul, rubio y rojo."

# game/game/script.rpy:7720
translate es playername_1f0711ae:

    # "{i}I thought Ray said he had work today..?{/i}"
    "{i}¿Pensé que Ray dijo que tenía trabajo hoy...?{/i}"

# game/game/script.rpy:7722
translate es playername_2ff30a8b:

    # "I try and shrug off the suspicion, I'm sure heroes also have assignments that aren't in the public eye."
    "Trato de apartar la sospecha; estoy seguro de que los héroes también tienen misiones que no son públicas."

# game/game/script.rpy:7724
translate es playername_4c2337df:

    # "While scrolling on social media I see somebody talking about fan fiction writing tips."
    "Mientras navego en redes sociales veo a alguien hablando sobre consejos para escribir fan fiction."

# game/game/script.rpy:7726
translate es playername_9d3605fd:

    # "{i}I wonder if Ray has fan fiction about him?{/i}"
    "{i}¿Me pregunto si Ray tendrá fan fiction sobre él?{/i}"

# game/game/script.rpy:7728
translate es playername_aba6bb03:

    # "I search up some fan fictions of Binary Star."
    "Busco algunas fanfictions de Binary Star."

# game/game/script.rpy:7730
translate es playername_7b8269e5:

    # "Most of them were admittedly great portrayals of 'Binary Star' that is shown in the media."
    "La mayoría eran, admitidamente, grandes representaciones del 'Binary Star' que se muestra en los medios."

# game/game/script.rpy:7732
translate es playername_6a899c2c:

    # "I can't help to laugh to myself at the difference between the fan portrayal of Binary Star and...how Ray {i} actually {/i} acts."
    "No puedo evitar reírme para mis adentros ante la diferencia entre la versión de los fans de Binary Star y... cómo Ray {i}realmente{/i} actúa."

# game/game/script.rpy:7737
translate es playername_5d665602:

    # n "{i} 'Y/N your smile has the power to ignite a light within me—a light that burns brighter than any danger I face. I... I have fallen deeply in love with you.' {/i}"
    n "{i}'Y/N, tu sonrisa tiene el poder de encender una luz dentro de mí—una luz que brilla más que cualquier peligro al que me enfrente. Yo... me he enamorado profundamente de ti.'{/i}"

# game/game/script.rpy:7739
translate es playername_eaea4682:

    # n "{i} Y/N's breath caught in her throat as she stared into Binary Star's mesmerizing red eyes. A wave of emotions washed over her, threatened to pull her to sea, and she found herself unable to form words.{/i}"
    n "{i}La respiración de Y/N se detuvo en su garganta al mirar a los hipnotizantes ojos rojos de Binary Star. Una oleada de emociones le envolvió, amenazando con arrastrarle al mar, y se encontró incapaz de pronunciar palabra.{/i}"

# game/game/script.rpy:7741
translate es playername_7071716e:

    # n "{i}Instead, she expressed her feelings through a heartfelt smile that mirrored his own.{/i}"
    n "{i}En su lugar, expresó sus sentimientos con una sonrisa sincera que reflejaba la de él.{/i}"

# game/game/script.rpy:7743
translate es playername_ed348738:

    # n "{i}YN's heart soared at his words, her eyes shining with unspoken affection. She felt a deep connection with Binary Star, one that extended beyond his heroic persona.{/i}"
    n "{i}El corazón de Y/N se elevó con sus palabras, sus ojos brillando con un afecto no dicho. Sintió una conexión profunda con Binary Star, una que trascendía su faceta heroica.{/i}"

# game/game/script.rpy:7745
translate es playername_9e81b252:

    # "I scrolled past a couple of chapters of the lovey-dovey stuff to find the risque parts."
    "Pasé un par de capítulos de las partes románticas para llegar a las más atrevidas."

# game/game/script.rpy:7751
translate es playername_6da2fd42:

    # n "{i} 'YN, I need you more than light itself.'{/i}"
    n "{i}'Y/N, te necesito más que a la propia luz.'{/i}"

# game/game/script.rpy:7753
translate es playername_0903beb8:

    # n "{i} 'Ever since I saw you at that club dancing your worries away, I knew I needed you desperately.' {/i}"
    n "{i}'Desde que te vi en aquel club bailando para liberar tus preocupaciones, supe que te necesitaba desesperadamente.'{/i}"

# game/game/script.rpy:7755
translate es playername_5cc027b4:

    # n "{i} 'I will save the world over and over, just to have your body once.' {/i}"
    n "{i}'Salvaré el mundo una y otra vez, solo para tener tu cuerpo una vez.'{/i}"

# game/game/script.rpy:7757
translate es playername_3c56fb9e:

    # n "He places a deep needy kiss onto my lips, hands following the dips and curves across my body."
    n "Él deposita un beso profundo y necesitado en mis labios, sus manos siguiendo las curvas de mi cuerpo."

# game/game/script.rpy:7759
translate es playername_4d43179d:

    # n "I can't suppress a moan."
    n "No puedo reprimir un gemido."

# game/game/script.rpy:7761
translate es playername_6dc4590d:

    # n "Binary star gives me a bright smile."
    n "Binary Star me dedica una sonrisa brillante."

# game/game/script.rpy:7763
translate es playername_540189e4:

    # n " {i} 'Don't worry, I will treat your body with care dear Y/N', just like when I saved the bridge from collapsing- {/i}"
    n "{i}'No te preocupes, trataré tu cuerpo con cuidado, Y/N', igual que cuando salvé el puente de derrumbarse–{/i}"

# game/game/script.rpy:7765
translate es playername_8778080e:

    # "I laugh out loud."
    "Suelto una carcajada."

# game/game/script.rpy:7767
translate es playername_68648105:

    # "I wonder if the inconsistency in character is because nobody really knows {i} how {/i} Binary Star would react to being horny."
    "Me pregunto si la inconsistencia del personaje se debe a que nadie realmente sabes {i}cómo{/i} reaccionaría Binary Star al estar excitado."

# game/game/script.rpy:7769
translate es playername_1e977de3:

    # "Every word makes me laugh, as I can't help imagining Ray saying these ridiculous lines."
    "Cada palabra me hace reír, porque no puedo evitar imaginar a Ray diciendo esas líneas ridículas."

# game/game/script.rpy:7771
translate es playername_0d9c7cbd:

    # "Time flies by as I become absorbed in Binary Star fan fiction."
    "El tiempo pasa volando mientras me absorbo en el fan fiction de Binary Star."

# game/game/script.rpy:7781
translate es playername_7536dfe3:

    # "The door sounds and Ray enters through my apartment door."
    "Se escucha la puerta y Ray entra a mi apartamento."

# game/game/script.rpy:7783
translate es playername_dd92e309:

    # "After walking in he pauses giving me a curious look."
    "Al entrar se detiene y me lanza una mirada curiosa."

# game/game/script.rpy:7789
translate es playername_97e9c398:

    # r "You look like you are up to no good %(player_name)s...."
    r "Parece que estás tramando algo, %(player_name)s..."

# game/game/script.rpy:7791
translate es playername_af92ef0a:

    # "He looks tired, smelling a bit like smoke."
    "Se ve cansado, huele un poco a humo."

# game/game/script.rpy:7793
translate es playername_ebc7d957:

    # mc "You aren't in your hero uniform?"
    mc "¿No estás con tu uniforme de héroe?"

# game/game/script.rpy:7795
translate es playername_0de732f5:

    # r "I didn't do any frontline hero work today. Just some paperwork."
    r "No hice trabajo de héroe en primera línea hoy. Solo algo de papeleo."

# game/game/script.rpy:7809
translate es playername_9d20f486:

    # "I hop up approaching him."
    "Me levanto y me acerco a él."

# game/game/script.rpy:7811
translate es playername_47581bab:

    # mc "You smell like smoke."
    mc "Hueles a humo."

# game/game/script.rpy:7813
translate es playername_08a123e3:

    # r "Oh do I?"
    r "¿Ah sí?"

# game/game/script.rpy:7817
translate es playername_76e4c10c:

    # r "Hmm, sorry."
    r "Hmm, lo siento."

# game/game/script.rpy:7828
translate es playername_c6bfa5cf:

    # r "There was a fire nearby the office, it must have settled in my hair."
    r "Hubo un incendio cerca de la oficina, debió quedarse impregnado en mi cabello."

# game/game/script.rpy:7832
translate es playername_3f2dc1e6:

    # r "Mind if I take a shower here?"
    r "¿Te importa si me ducho aquí?"

# game/game/script.rpy:7834
translate es playername_9fe11afc:

    # mc "Sure, you know where the towels are."
    mc "Claro, sabes dónde están las toallas."

# game/game/script.rpy:7838
translate es playername_affc52c4_1:

    # r "Thanks."
    r "Gracias."

# game/game/script.rpy:7841
translate es playername_b4ce0930:

    # "Ray showers and the smell of soap fills up the apartment."
    "Ray se ducha y el olor a jabón llena el apartamento."

# game/game/script.rpy:7843
translate es playername_d831f828:

    # "I put on some music and open up the window to let some fresh air in."
    "Pongo algo de música y abro la ventana para dejar entrar aire fresco."

# game/game/script.rpy:7845
translate es playername_20634194:

    # "I think back to the news on the TV earlier today."
    "Pienso en las noticias que vi más temprano en la televisión."

# game/game/script.rpy:7847
translate es playername_2d6bbb36:

    # "It is a little weird that a building fire wasn't featured."
    "Es un poco extraño que no hayan mencionado un incendio en un edificio."

# game/game/script.rpy:7849
translate es playername_d40ccd1a:

    # "Ray gets out of the shower, drying his hair off with a towel."
    "Ray sale de la ducha, secándose el cabello con una toalla."

# game/game/script.rpy:7851
translate es playername_929ee432:

    # mc "Ray, I think I'm going a little stir-crazy."
    mc "Ray, creo que estoy enloqueciendo un poco por estar en aislamiento. "

# game/game/script.rpy:7853
translate es playername_0c14900c:

    # mc "I don't know how much more time I'll be able to stay cooped up inside."
    mc "No sé cuánto más podré seguir aquí en este encierro."

# game/game/script.rpy:7858
translate es playername_e41e4b4e:

    # "Ray grimaces."
    "Ray hace una mueca."

# game/game/script.rpy:7860
translate es playername_d75fd830:

    # r "I know, I know, I'm sorry."
    r "Lo sé, lo sé, lo siento."

# game/game/script.rpy:7862
translate es playername_a1806cb2:

    # r "I'm just worried something will happen to you and I won't be able to find you."
    r "Solo me preocupa que te pase algo y no pueda encontrarte."

# game/game/script.rpy:7864
translate es playername_f16e6438:

    # r "I was actually thinking..."
    r "De hecho, estaba pensando..."

# game/game/script.rpy:7866
translate es playername_e5288ce1:

    # r "In the meantime...until we find Double..."
    r "Mientras tanto... hasta que encontremos a Double..."

# game/game/script.rpy:7868
translate es playername_77a08008:

    # r "Would you move in with me..?"
    r "¿Te mudarías conmigo...?"

# game/game/script.rpy:7870
translate es playername_2b35b6fe_5:

    # mc "..."
    mc "..."

# game/game/script.rpy:7872
translate es playername_c540e2a6:

    # r "My place is larger so you can move around a bit more."
    r "Mi hogar es más grande, así que podrías moverte un poco más."

# game/game/script.rpy:7874
translate es playername_e1b68c52:

    # r "It also has better security, so you won't have to feel worried about staying here."
    r "También tiene mejor seguridad, así que no tendrías que preocuparte por quedarte aquí."

# game/game/script.rpy:7876
translate es playername_0c6086af:

    # "I chew on my lip."
    "Me muerdo el labio."

# game/game/script.rpy:7878
translate es playername_4a2ef417:

    # mc "I don't know..."
    mc "No lo sé..."

# game/game/script.rpy:7882
translate es playername_7cb87384:

    # mc "That's kinda sudden..."
    mc "Eso es algo repentino..."

# game/game/script.rpy:7886
translate es playername_431720df:

    # "He pats my head."
    "Me acaricia la cabeza."

# game/game/script.rpy:7888
translate es playername_a7853f66:

    # r "I guess that was a bit sudden, sorry. Maybe just think about it."
    r "Supongo que fue un poco repentino, lo siento. Tal vez solo piénsalo."

# game/game/script.rpy:7892
translate es playername_78eae3b3:

    # r "I don't think it's very safe for you here."
    r "No creo que sea muy seguro para ti aquí."

# game/game/script.rpy:7894
translate es playername_fda94de6:

    # r "As long as Double is around and knows where you live there is a chance that he can come get you at anytime."
    r "Mientras Double esté suelto y sepa dónde vives, hay una posibilidad de que venga por ti en cualquier momento."

# game/game/script.rpy:7898
translate es playername_8c2ea0d3:

    # r "And honestly, that scares me."
    r "Y sinceramente, eso me asusta."

# game/game/script.rpy:7900
translate es playername_5ffb34e5:

    # r "%(player_name)s...."
    r "%(player_name)s...."

# game/game/script.rpy:7902
translate es playername_faf5ca51:

    # r "There isn't much ti-"
    r "No hay mucho ti–"

# game/game/script.rpy:7908
translate es playername_4c00bf13:

    # "Ray's phone buzzes."
    "El teléfono de Ray vibra."

# game/game/script.rpy:7914
translate es playername_6186d541:

    # r "Sorry, I have to take this..."
    r "Perdón, tengo que atender esto..."

# game/game/script.rpy:7918
translate es playername_922eff06:

    # "He picks it up leaving my apartment."
    "Lo toma y sale de mi apartamento."

# game/game/script.rpy:7920
translate es playername_821e165a:

    # "My heart can't stop pounding at his offer."
    "Mi corazón no deja de latir con fuerza por su propuesta."

# game/game/script.rpy:7922
translate es playername_4f17eadc:

    # "{i} 'What the hell... that was so sudden...'{/i}"
    "{i}'Qué demonios... eso fue tan repentino...'{/i}"

# game/game/script.rpy:7924
translate es playername_facae919:

    # "{i} 'He isn't wrong that I am in a very worrying position... '{/i}"
    "{i}'No se equivoca al decir que estoy en una situación muy preocupante...'{/i}"

# game/game/script.rpy:7926
translate es playername_84416613:

    # "{i} 'But abandoning my apartment to move in with him seems...extreme.'{/i}'"
    "{i}'Pero abandonar mi apartamento para mudarme con él parece... extremo.'{/i}"

# game/game/script.rpy:7932
translate es playername_d50a3170:

    # "After a half an hour or so on the phone I can hear the front door close."
    "Después de una media hora al teléfono escucho la puerta del frente cerrarse."

# game/game/script.rpy:7936
translate es playername_c4dafc59:

    # "Ray returns inside."
    "Ray vuelve a entrar."

# game/game/script.rpy:7941
translate es playername_d1f7cfc1:

    # r "Sorry, some work stuff."
    r "Perdón, cosas del trabajo."

# game/game/script.rpy:7943
translate es playername_ce330cfb:

    # mc "No worries."
    mc "No te preocupes."

# game/game/script.rpy:7947
translate es playername_dc4bdca8:

    # r "Have you eaten yet?"
    r "¿Has comido ya?"

# game/game/script.rpy:7949
translate es playername_aad55968:

    # mc "I shake my head."
    mc "Niego con la cabeza."

# game/game/script.rpy:7951
translate es playername_70e7de7c:

    # mc "Not yet."
    mc "Aún no."

# game/game/script.rpy:7955
translate es playername_8dacea45:

    # r "Can I make you something?"
    r "¿Puedo prepararte algo?"

# game/game/script.rpy:7957
translate es playername_c9557d2e:

    # mc "What..!? You do not have to cook me a meal in my own apartment!"
    mc "¿¡Qué…!? ¡No tienes que cocinarme una comida en mi propio apartamento!"

# game/game/script.rpy:7961
translate es playername_e9e3d230:

    # r "I don't mind..."
    r "No me importa…"

# game/game/script.rpy:7965
translate es playername_7f2f268a:

    # "He walks towards the small kitchenette."
    "Camina hacia la pequeña cocina."

# game/game/script.rpy:7980
translate es playername_1b2f71f9:

    # r "To be honest, I enjoy cooking."
    r "Para ser honesto, disfruto cocinar."

# game/game/script.rpy:7982
translate es playername_46eda385:

    # r "I don't get a lot of opportunities to cook for someone else."
    r "No tengo muchas oportunidades de cocinar para alguien más."

# game/game/script.rpy:7984
translate es playername_efc533f9:

    # r "So, I'd like to. If that is okay with you?"
    r "Así que me gustaría hacerlo. ¿Está bien para ti?"

# game/game/script.rpy:7986
translate es playername_1c474d4b:

    # mc "I guess so... I just feel bad. I should be cooking for you."
    mc "Supongo que sí… Solo me siento mal. Yo debería cocinar para ti."

# game/game/script.rpy:7988
translate es playername_b149ef09:

    # "Ray gives me a little smirk."
    "Ray me lanza una pequeña sonrisa."

# game/game/script.rpy:7992
translate es playername_2501e375:

    # r "I'm not sure if I'd trust your cooking."
    r "No estoy seguro de que confiaría en tu cocina."

# game/game/script.rpy:7994
translate es playername_37e57acf:

    # mc "You act like I'd poison you!"
    mc "¡Actúas como si fuera a envenenarte!"

# game/game/script.rpy:7998
translate es playername_658216c6:

    # r "I'm impervious to poison, so you wouldn't do any damage to me with that method."
    r "Soy inmune al veneno, así que no podrías hacerme daño con ese método."

# game/game/script.rpy:8000
translate es playername_de0d35c7:

    # mc "You say that as if I can do damage to you in other ways."
    mc "Dices eso como si pudiera hacerte daño de otras formas."

# game/game/script.rpy:8006
translate es playername_c7a089de:

    # "Ray just smiles as he starts to chop up some vegetables."
    "Ray solo sonríe mientras empieza a picar unas verduras."

# game/game/script.rpy:8010
translate es playername_cb2dfc1e:

    # "I watch him in the kitchen as my music plays in the background."
    "Lo observo en la cocina mientras mi música suena de fondo."

# game/game/script.rpy:8012
translate es playername_caa32e22:

    # "He was surprisingly skilled at cooking."
    "Era sorprendentemente hábil cocinando."

# game/game/script.rpy:8016
translate es playername_bef851f9:

    # "Soon enough dinner was made and I sit down at the table with Ray."
    "En poco tiempo la cena estuvo lista y me siento a la mesa con Ray."

# game/game/script.rpy:8036
translate es playername_46c95dc8:

    # "The veggie pasta smells delicious."
    "La pasta con vegetales huele deliciosa."

# game/game/script.rpy:8038
translate es playername_1334566a:

    # mc "Wow, Ray..."
    mc "Wow, Ray…"

# game/game/script.rpy:8042
translate es playername_9185dbdf:

    # "He looks proud of his work."
    "Se ve orgulloso de su trabajo."

# game/game/script.rpy:8044
translate es playername_90f21cc7:

    # r "Dive in."
    r "Adelante."

# game/game/script.rpy:8046
translate es playername_39bffeff:

    # "I mumble a 'thanks for the meal' start eating."
    "Murmuro un 'gracias por la comida' y empiezo a comer."

# game/game/script.rpy:8048
translate es playername_10438501:

    # mc "WOW!"
    mc "¡WOW!"

# game/game/script.rpy:8050
translate es playername_fe25ac44:

    # "Ray laughs."
    "Ray se ríe."

# game/game/script.rpy:8053
translate es playername_41ca1c3a:

    # "The pasta was incredibly good."
    "La pasta estaba increíblemente buena."

# game/game/script.rpy:8057
translate es playername_90700ea7:

    # r "If you have any preferences let me know, I can cook just about anything."
    r "Si tienes alguna preferencia, dímelo, puedo cocinar casi cualquier cosa."

# game/game/script.rpy:8059
translate es playername_1037dcd3:

    # mc "This is so good! I'd be happy with this again!"
    mc "¡Esto está tan bueno! ¡Sería feliz comiendo esto otra vez!"

# game/game/script.rpy:8063
translate es playername_0885b853:

    # r "Noted."
    r "Anotado."

# game/game/script.rpy:8067
translate es playername_2750bc46:

    # "I make quick work of dinner, not realizing how hungry I got."
    "Termino la cena rápidamente, sin darme cuenta de cuánta hambre tenía."

# game/game/script.rpy:8069
translate es playername_299df0a4:

    # "After dinner I tried to do the dishes but Ray ended up helping anyways."
    "Después de cenar intenté lavar los platos, pero Ray terminó ayudando de todos modos."

# game/game/script.rpy:8071
translate es playername_6444f692:

    # "It was a strange feeling, living together, even though we technically weren't."
    "Era una sensación extraña, vivir juntos, aunque técnicamente no lo estuviéramos."

# game/game/script.rpy:8073
translate es playername_a98eec99:

    # "When clean-up was done, we sat and chatted about various things."
    "Cuando terminamos de limpiar, nos sentamos a charlar de varias cosas."

# game/game/script.rpy:8088
translate es playername_b8641f20:

    # r "My place has a pretty large kitchen, and it does feel like a shame not to use it."
    r "Mi hogar tiene una cocina bastante grande, y me parece una pena no usarla."

# game/game/script.rpy:8090
translate es playername_5418fab9:

    # r "So I try to make the most of it."
    r "Así que trato de aprovecharla al máximo."

# game/game/script.rpy:8092
translate es playername_e369b015:

    # "I level a look at Ray."
    "Dirijo una mirada a Ray."

# game/game/script.rpy:8095
translate es playername_19fcb7b1:

    # r "What?"
    r "¿Qué?"

# game/game/script.rpy:8097
translate es playername_e634f859:

    # mc "I'm still surprised you can cook so well..."
    mc "Aún me sorprende que cocines tan bien…"

# game/game/script.rpy:8101
translate es playername_f89bba57:

    # r "I have other skills outside of saving citizens in distress you know."
    r "Tengo otras habilidades además de salvar ciudadanos en apuros, ¿sabes?"

# game/game/script.rpy:8103
translate es playername_a093fa41:

    # mc "I read about some of your skills earlier today~"
    mc "Leí sobre algunas de tus habilidades hoy más temprano~"

# game/game/script.rpy:8105
translate es playername_8e3d9cec:

    # "I joke. Ray gives me a skeptical look."
    "Bromeo. Ray me lanza una mirada escéptica."

# game/game/script.rpy:8107
translate es playername_6f558f31:

    # r "Is that right..?"
    r "¿Ah, sí…?"

# game/game/script.rpy:8109
translate es playername_c6988ce2:

    # "I pick up my phone and click on a random Binary Star fan fiction I was reading earlier."
    "Tomo mi teléfono y abro una fanfic de Binary Star que estaba leyendo antes."

# game/game/script.rpy:8111
translate es playername_5f24983d:

    # mc "'{i} When Binary Star looked at you from across the club with his ruby red eyes you felt undressed on the spot.' {/i}"
    mc "'{i}Cuando Binary Star te miró desde el otro lado del club con sus ojos rojo rubí, te sentiste al desnudo en un instante.{/i}'"

# game/game/script.rpy:8114
translate es playername_bf0de919:

    # mc "'{i}He grabs your hand taking you to the quieter hallway where he pushes you against the wall, his plush lips encapsulating your own.'{/i} "
    mc "'{i}Toma tu mano llevándote a un pasillo más tranquilo, donde te empuja contra la pared, sus labios suaves encapsulando los tuyos.{/i}'"

# game/game/script.rpy:8116
translate es playername_48825f5b:

    # mc "'{i} Binary Star pulls back, heat in his eyes. 'Heroes have to blow off some steam too, and you look like just the citizen to help' he whispers huskily.{/i}'"
    mc "'{i}Binary Star se aparta, con fuego en los ojos. 'Los héroes también tienen que liberar algo de tensión, y pareces justo el ciudadano para ayudar', susurra con voz ronca.{/i}'"

# game/game/script.rpy:8120
translate es playername_93ec3494:

    # r "What the fuck...?"
    r "¿Qué carajos…?"

# game/game/script.rpy:8124
translate es playername_01592d5d:

    # "Ray walks over standing over me."
    "Ray se acerca, poniéndose de pie frente a mí."

# game/game/script.rpy:8130
translate es playername_e7b71935:

    # "I hand him my phone and he starts to look, his eyes widening at the increasingly graphic nature of the fan fiction."
    "Le entrego mi teléfono y empieza a leer, sus ojos se agrandan ante lo gráfico del texto."

# game/game/script.rpy:8132
translate es playername_94445318:

    # r "...My lord..."
    r "…Santo cielo…"

# game/game/script.rpy:8134
translate es playername_fd62914e:

    # mc "Wow Ray, pretty bold of you. In public at a nightclub too!"
    mc "Wow, Ray, bastante atrevido de tu parte. ¡Y en público, en un club nocturno!"

# game/game/script.rpy:8136
translate es playername_0db8fe78:

    # "Ray glances up from the phone with a skeptical look."
    "Ray levanta la mirada del teléfono con una expresión escéptica."

# game/game/script.rpy:8138
translate es playername_36f16ccf:

    # r "Did you... write this...?"
    r "¿Tú… escribiste esto…?"

# game/game/script.rpy:8140
translate es playername_403cf1d6:

    # mc "No! It's fan fiction, there are thousands of these."
    mc "¡No! Es fanfic, hay miles de estas."

# game/game/script.rpy:8144
translate es playername_000c7ebf:

    # "A smirk appears on Ray's lips, he leans towering over me closer."
    "Una sonrisa aparece en los labios de Ray, se inclina sobre mí, más cerca."

# game/game/script.rpy:8146
translate es playername_54955ca2:

    # r "Is this the kind of stuff you like %(player_name)s...?"
    r "¿Este es el tipo de cosas que te gustan, %(player_name)s…?"

# game/game/script.rpy:8150
translate es playername_fcbdfb6f:

    # "A dangerous smile stretches across his face."
    "Una sonrisa peligrosa se extiende por su rostro."

# game/game/script.rpy:8163
translate es playername_e4881ccb:

    # r "Do you want me to drag you to the back of a club..."
    r "¿Quieres que te arrastre al fondo de un club…"

# game/game/script.rpy:8175
translate es playername_5a1b7dfc:

    # r "...And take you all for myself..."
    r "…Y te tome solo para mí…"

# game/game/script.rpy:8187
translate es playername_de8b331b:

    # r "While covering your mouth so others don't hear as you desperately moan my name?"
    r "¿Mientras cubro tu boca para que los demás no escuchen cómo gimes desesperadamente mi nombre?"

# game/game/script.rpy:8189
translate es playername_36e6e2ea:

    # "My teasing has fully backfired."
    "Mi broma se ha vuelto completamente en mi contra."

# game/game/script.rpy:8191
translate es playername_78d04949:

    # "Ray gives a look of warning."
    "Ray me lanza una mirada de advertencia."

# game/game/script.rpy:8204
translate es playername_576df197:

    # "My face heats up and I scoot back as I'm sure he can hear my heartbeat from where I sit."
    "Mi rostro se calienta y me alejo un poco, segura de que puede oír mi corazón desde donde está."

# game/game/script.rpy:8206
translate es playername_57a0d5dc:

    # mc "NO, I just thought it was funny...!"
    mc "¡NO, solo pensé que era gracioso…!"

# game/game/script.rpy:8210
translate es playername_900c5f37:

    # "Ray shrugs."
    "Ray se encoge de hombros."

# game/game/script.rpy:8214
translate es playername_6a34bf73:

    # r "Too bad, let me know if you change your mind."
    r "Qué lástima, avísame si cambias de opinión."

# game/game/script.rpy:8218
translate es playername_183b4b71:

    # "{i}'Too bad!?'{/i}"
    "{i}¿'Qué lástima'!{/i}"

# game/game/script.rpy:8220
translate es playername_2e63cf0c:

    # "Ray saunters off to the window to light a cigarette per usual."
    "Ray se aleja hacia la ventana para encender un cigarrillo, como de costumbre."

# game/game/script.rpy:8231
translate es playername_32d49a0e:

    # cg "I am unable to look him in the eye and I hear him chuckle."
    cg "Soy incapaz de mirarlo a los ojos y lo oigo reírse."

# game/game/script.rpy:8233
translate es playername_7acfa23f:

    # cg "I get up and get ready to go to sleep."
    cg "Me levanto y me preparo para dormir."

# game/game/script.rpy:8235
translate es playername_96b8f358:

    # cg "I lay down in the bed, hyper aware of Ray's presence, but he stands looking out the window."
    cg "Me recuesto en la cama, muy consciente de la presencia de Ray, pero él sigue de pie mirando por la ventana."

# game/game/script.rpy:8239
translate es playername_7bed3cf4:

    # cg "After a while of failed attempts to fall asleep I look towards Ray."
    cg "Después de varios intentos fallidos de dormir, miro hacia Ray."

# game/game/script.rpy:8241
translate es playername_55eba4b9:

    # cg "{color=#510f80}'Ray...?'{/color}"
    cg "{color=#510f80}'¿Ray…?'{/color}"

# game/game/script.rpy:8245
translate es playername_c4ea767b:

    # cg "He glances at me."
    cg "Él me lanza una mirada."

# game/game/script.rpy:8247
translate es playername_dbacb227:

    # cg "{color=#CD9300} 'Hm?' {/color}"
    cg "{color=#CD9300}'¿Hm?'{/color}"

# game/game/script.rpy:8249
translate es playername_d4ff8124:

    # cg "{color=#510f80}'Can you cuddle with me until I fall asleep?' {/color}"
    cg "{color=#510f80}'¿Puedes abrazarme hasta que me duerma?'{/color}"

# game/game/script.rpy:8255
translate es playername_926b1024:

    # cg "A small smile plays on his lips as he puts out his cigarette."
    cg "Una pequeña sonrisa se dibuja en sus labios mientras apaga el cigarrillo."

# game/game/script.rpy:8262
translate es playername_5e45f63d:

    # cg "{color=#CD9300} 'Sure.' {/color}"
    cg "{color=#CD9300}'Claro.'{/color}"

# game/game/script.rpy:8264
translate es playername_c37b0f6c:

    # cg "He walks over taking off his sweater."
    cg "Camina hacia mí quitándose el suéter."

# game/game/script.rpy:8283
translate es playername_0a3dffd3:

    # cg "The bed dips and he drapes an arm around my waist."
    cg "La cama se hunde y pasa un brazo alrededor de mi cintura."

# game/game/script.rpy:8285
translate es playername_2977d414:

    # cg "There was some comfortability with Ray that I wasn't used to."
    cg "Había algo en Ray que me hacía sentir confortable, algo a lo que no le tenía costumbre."

# game/game/script.rpy:8287
translate es playername_f350b51b:

    # cg "With him I felt...safe."
    cg "Con él me sentía… a salvo."

# game/game/script.rpy:8289
translate es playername_91a3953c:

    # cg "I think about the special I watched earlier in the day."
    cg "Pienso en el especial que vi más temprano ese día."

# game/game/script.rpy:8291
translate es playername_213704e5:

    # cg "{color=#510f80} 'Ray...?' {/color}"
    cg "{color=#510f80}'¿Ray…?'{/color}"

# game/game/script.rpy:8293
translate es playername_04603390:

    # cg "{color=#CD9300} 'Yeah?' {/color}"
    cg "{color=#CD9300}'¿Sí?'{/color}"

# game/game/script.rpy:8295
translate es playername_f421a6f4:

    # cg "{color=#510f80} 'Was...being with Steel Sheriff hard?' {/color}"
    cg "{color=#510f80}'¿Fue… difícil estar con Steel Sheriff?'{/color}"

# game/game/script.rpy:8299
translate es playername_24ce0ad4:

    # cg "Ray sucks his teeth in thought."
    cg "Ray chasquea los dientes, pensativo."

# game/game/script.rpy:8301
translate es playername_45d158d8:

    # cg "{color=#CD9300} 'It...certainly wasn't easy.' {/color}"
    cg "{color=#CD9300}'No… ciertamente no fue fácil.'{/color}"

# game/game/script.rpy:8303
translate es playername_5483a6fa:

    # cg "{color=#CD9300} 'He wasn't a good person....probably still isn't. We don't talk anymore.' {/color}"
    cg "{color=#CD9300}'No era una buena persona… probablemente aún no lo sea. Ya no hablamos.'{/color}"

# game/game/script.rpy:8305
translate es playername_13868f76:

    # cg "{color=#510f80} 'When was the last time you talked?' {/color}"
    cg "{color=#510f80}'¿Cuándo fue la última vez que hablaste con él?'{/color}"

# game/game/script.rpy:8307
translate es playername_5b31e0ca:

    # cg "{color=#CD9300} 'Maybe 6 years ago or so...'{/color}"
    cg "{color=#CD9300}'Quizás hace unos seis años…'{/color}"

# game/game/script.rpy:8309
translate es playername_8d443144:

    # cg "{color=#CD9300} 'He was my guardian for about 11 years. Steel was a ...deeply troubled person that hurt people wherever he went.'{/color}"
    cg "{color=#CD9300}'Fue mi tutor durante unos once años. Steel era una persona… profundamente perturbada que lastimaba a quien se le cruzara.'{/color}"

# game/game/script.rpy:8313
translate es playername_8acd0be7:

    # cg "Ray looks at my worried expression. He ruffles my hair with a sympathetic smile."
    cg "Ray mira mi expresión preocupada. Me despeina con una sonrisa comprensiva."

# game/game/script.rpy:8315
translate es playername_be8906cc:

    # cg "{color=#CD9300} 'Don't worry, he couldn't hurt me. He tried to once, and learned his lesson.'{/color}"
    cg "{color=#CD9300}'No te preocupes, no podía hacerme daño. Lo intentó una vez y aprendió la lección.'{/color}"

# game/game/script.rpy:8317
translate es playername_1cf7c1af:

    # cg "{color=#CD9300} 'Since that day he lost interested in messing with me...' {/color}"
    cg "{color=#CD9300}'Desde ese día perdió el interés en meterse conmigo…'{/color}"

# game/game/script.rpy:8319
translate es playername_eaa7117c:

    # cg "{color=#CD9300} 'Steel is the kind of trash that only punches down at people who won't fight back.'{/color}"
    cg "{color=#CD9300}'Steel es el tipo de basura que solo golpea hacia abajo, a quienes no pueden defenderse.'{/color}"

# game/game/script.rpy:8321
translate es playername_1ebeb4aa:

    # cg "{color=#CD9300} 'The minute I turned 18, I left Steel for good. The NAHA was forced to figure out the PR spin for the situation.' {/color}"
    cg "{color=#CD9300}'En cuanto cumplí 18, dejé a Steel para siempre. La NAHA tuvo que inventar una versión pública de lo ocurrido.'{/color}"

# game/game/script.rpy:8323
translate es playername_55a40627:

    # cg "{color=#CD9300} 'I think they landed on something like: Binary Star paving his own path towards Herodom...something like that'"
    cg "{color=#CD9300}'Creo que dijeron algo como: Binary Star forjando su propio camino hacia el heroísmo… algo así.'{/color}"

# game/game/script.rpy:8327
translate es playername_64b59e0c:

    # cg "{color=#CD9300} 'Did you have a hard time with Double Vision?'{/color}"
    cg "{color=#CD9300}'¿Tú tuviste un tiempo difícil con Double Vision?'{/color}"

# game/game/script.rpy:8329
translate es playername_abceedc2:

    # cg "I chew my lip in thought."
    cg "Muerdo mi labio, y pienso."

# game/game/script.rpy:8331
translate es playername_f7d1a0e1:

    # cg "{color=#510f80} 'Double wasn't always bad. He was very courteous to me most of the time...'{/color}"
    cg "{color=#510f80} 'Double no siempre fue malo. La mayoría del tiempo fue muy cortés conmigo…'{/color}"

# game/game/script.rpy:8333
translate es playername_f62cc03f:

    # cg "{color=#510f80} 'But things started to go bad, and then didn't stop snowballing.'{/color}"
    cg "{color=#510f80} 'Pero las cosas empezaron a empeorar, y luego no dejaron de hacerlo.'{/color}"

# game/game/script.rpy:8335
translate es playername_6fcd3dcd:

    # cg "{color=#510f80} 'I think... maybe he was manipulative and violent all along, but because it wasn't pointed at me...' {/color}"
    cg "{color=#510f80} 'Creo que… tal vez siempre fue manipulador y violento, pero como no era conmigo…'{/color}"

# game/game/script.rpy:8337
translate es playername_5d0816e7:

    # cg "{color=#510f80} 'I refused to look...and other people got hurt because of that.' {/color}"
    cg "{color=#510f80} 'Me negué a mirar… y otras personas salieron heridas por eso.'{/color}"

# game/game/script.rpy:8339
translate es playername_99967625:

    # cg "I sigh and Ray pulls me closer. He runs a hand through my hair comfortingly."
    cg "Suspiro y Ray me atrae más cerca. Pasa una mano por mi cabello de manera reconfortante."

# game/game/script.rpy:8344
translate es playername_184405a6:

    # cg "{color=#510f80}'The way he was in the warehouse...it was never that bad. Before, I had an inclination that he was capable of killing me, now I know for sure that he is.' {/color}"
    cg "{color=#510f80}'Como estaba en el almacén… nunca había sido tan grave. Antes intuía que era capaz de matarme, ahora sé con certeza que lo es.'{/color}"

# game/game/script.rpy:8346
translate es playername_80b16de1:

    # cg "{color=#CD9300}'It will be okay, I promise I will keep you safe.' {/color}"
    cg "{color=#CD9300}'Todo estará bien, te prometo que te mantendré a salvo.'{/color}"

# game/game/script.rpy:8348
translate es playername_81f50436:

    # cg "I glance up at Ray who gives me a little smile."
    cg "Levanto la mirada hacia Ray, quien me dedica una pequeña sonrisa."

# game/game/script.rpy:8350
translate es playername_039c0352:

    # cg "{color=#510f80} 'Why are you doing all of this Ray..?' {/color}"
    cg "{color=#510f80}'¿Por qué haces todo esto, Ray…?'{/color}"

# game/game/script.rpy:8352
translate es playername_06f6457c:

    # cg "{color=#510f80} 'You have no obligation to spend all of your time watching over me.' {/color}"
    cg "{color=#510f80}'No tienes ninguna obligación de pasar todo tu tiempo cuidándome.'{/color}"

# game/game/script.rpy:8354
translate es playername_19810ff6:

    # cg "{color=#510f80} 'I'm thankful for your help, but I don't really understand your motives.' {/color}"
    cg "{color=#510f80}'Agradezco tu ayuda, pero realmente no entiendo tus motivos.'{/color}"

# game/game/script.rpy:8356
translate es playername_7f394a97:

    # cg "Ray levels a look at me."
    cg "Ray me lanza una mirada seria."

# game/game/script.rpy:8358
translate es playername_8b14056a:

    # cg "A silence crosses over us as Ray studies my face."
    cg "Un silencio nos envuelve mientras Ray estudia mi rostro."

# game/game/script.rpy:8360
translate es playername_9ed400d4:

    # cg "{color=#510f80} 'You don't have to say why if you are uncomfortable...sorry-' {/color}"
    cg "{color=#510f80}'No tienes que decir por qué si te resulta incómodo… perdón-'{/color}"

# game/game/script.rpy:8362
translate es playername_0dc6e25c:

    # cg "Ray places his hand on my cheek pulling it softly so I face him."
    cg "Ray coloca su mano en mi mejilla y la gira suavemente para que lo mire."

# game/game/script.rpy:8378
translate es playername_95552cad:

    # cg "He looks at me quietly, a softness passing through his eyes."
    cg "Me observa en silencio, una suavidad cruza sus ojos."

# game/game/script.rpy:8380
translate es playername_45d0b103:

    # cg "{color=#CD9300} '%(player_name)s.....' {/color}"
    cg "{color=#CD9300}'%(player_name)s…..'{/color}"

# game/game/script.rpy:8382
translate es playername_47e622a3:

    # cg "{color=#CD9300} '...'{/color}"
    cg "{color=#CD9300}'...'{/color}"

# game/game/script.rpy:8384
translate es playername_8c98e901:

    # cg "{color=#CD9300} 'I love you.' {/color}"
    cg "{color=#CD9300}'Te amo.'{/color}"

# game/game/script.rpy:8386
translate es playername_5a1c67ac:

    # cg "{color=#510f80} 'Wha-?!' {/color}"
    cg "{color=#510f80}'¿Qué-?!'{/color}"

# game/game/script.rpy:8388
translate es playername_509ff046:

    # cg "{color=#CD9300} {i}'I'm in love with you %(player_name)s.' {/i} {/color}"
    cg "{color=#CD9300}{i}'Estoy enamorado de ti, %(player_name)s.'{/i}{/color}"

# game/game/script.rpy:8390
translate es playername_34316c23:

    # cg "{color=#CD9300} 'From the first moment I saw you, I fell for you.' {/color} "
    cg "{color=#CD9300}'Desde el primer momento en que te vi, caí por ti.'{/color}"

# game/game/script.rpy:8392
translate es playername_65f8976b:

    # cg "{color=#CD9300} 'Every interaction with you after that only served to further solidify my love for you.' {/color}"
    cg "{color=#CD9300}'Cada interacción contigo después de eso solo sirvió para reforzar mi amor por ti.'{/color}"

# game/game/script.rpy:8394
translate es playername_de643ba0:

    # cg "{color=#CD9300} 'I wanted to make you love me too...' {/color}"
    cg "{color=#CD9300}'Quería hacer que tú también me amaras…'{/color}"

# game/game/script.rpy:8396
translate es playername_71aa23aa:

    # cg "Ray gives a self deprecating laugh."
    cg "Ray suelta una risa autocrítica."

# game/game/script.rpy:8404
translate es playername_0bf06bb7:

    # cg "{color=#CD9300} 'But I suppose I'm no good at making people love me without a PR team.' {/color}"
    cg "{color=#CD9300}'Pero supongo que no soy bueno haciendo que la gente me ame sin un equipo de relaciones públicas.'{/color}"

# game/game/script.rpy:8406
translate es playername_15d0f089:

    # cg "My mouth hangs open, face heating up at the bold confession."
    cg "Mi boca queda entreabierta, el rostro me arde ante la audaz confesión."

# game/game/script.rpy:8408
translate es playername_7787f821:

    # cg "..."
    cg "..."

# game/game/script.rpy:8416
translate es playername_3dc3bc32:

    # cg "{color=#CD9300} 'You don't have to respond, I'm not looking for affirmation...' {/color}"
    cg "{color=#CD9300}'No tienes que responder, no busco una afirmación…'{/color}"

# game/game/script.rpy:8424
translate es playername_aee58af1:

    # cg "{color=#CD9300} 'I just thought you should know the significance I hold you in. {/color}"
    cg "{color=#CD9300}'Solo pensé que deberías saber la importancia que tienes para mí.'{/color}"

# game/game/script.rpy:8426
translate es playername_b1d79292:

    # cg "{color=#CD9300} 'If I lose you I might as well lose everything.' {/color}"
    cg "{color=#CD9300}'Si te pierdo, podría perderlo todo.'{/color}"

# game/game/script.rpy:8428
translate es playername_d22a8655:

    # cg "{color=#CD9300} 'If you are gone, the world will crumble.' {/color}"
    cg "{color=#CD9300}'Si te vas, el mundo se derrumbará.'{/color}"

# game/game/script.rpy:8430
translate es playername_7e153ea7:

    # cg "{color=#510f80} 'That's kinda dramatic...' {/color}"
    cg "{color=#510f80}'Eso suena algo dramático…'{/color}"

# game/game/script.rpy:8432
translate es playername_390598db:

    # cg "{color=#CD9300} 'I won't apologize for how I feel.'{/color}"
    cg "{color=#CD9300}'No me disculparé por lo que siento.'{/color}"

# game/game/script.rpy:8434
translate es playername_a56c5129:

    # cg "I gaze up at Ray."
    cg "Levanto la mirada hacia Ray."

# game/game/script.rpy:8436
translate es playername_a1069894:

    # cg "It feels somewhat surreal that Ray, {i}Binary Star{/i} just confessed his love for me."
    cg "Se siente algo irreal que Ray, {i}Binary Star{/i}, acabara de confesarme su amor."

# game/game/script.rpy:8438
translate es playername_eda7db54:

    # cg "I continue to stare and his face starts to blush and he looks away."
    cg "Sigo mirándolo, y su rostro comienza a sonrojarse mientras aparta la vista."

# game/game/script.rpy:8445
translate es playername_9c9ea93f:

    # cg "{color=#CD9300} 'What is it?' {/color}"
    cg "{color=#CD9300}'¿Qué ocurre?'{/color}"

# game/game/script.rpy:8447
translate es playername_b98ac222:

    # cg "{color=#510f80} 'Nothing.... you really love me...?' {/color}"
    cg "{color=#510f80}'Nada… ¿de verdad me amas?'{/color}"

# game/game/script.rpy:8449
translate es playername_7770fbd4:

    # cg "{color=#CD9300} 'Don't... repeat it while staring at me like that.' {/color}"
    cg "{color=#CD9300}'No… repitas eso mientras me miras así.'{/color}"

# game/game/script.rpy:8451
translate es playername_3a05b2dc:

    # cg "{i}He's embarrassed.{/i}"
    cg "{i}Está avergonzado.{/i}"

# game/game/script.rpy:8459
translate es playername_b61e3c71:

    # cg "{color=#CD9300} 'I'm {i}not{/i} embarrassed.' {/color}"
    cg "{color=#CD9300}'No estoy {i}avergonzado{/i}.'{/color}"

# game/game/script.rpy:8461
translate es playername_04d0e4cd:

    # cg "{color=#CD9300} 'You are so insufferable.' {/color}"
    cg "{color=#CD9300}'Eres tan insoportable.'{/color}"

# game/game/script.rpy:8469
translate es playername_ea9bfe8c:

    # cg "I laugh and Ray's expression softens up."
    cg "Me río y la expresión de Ray se suaviza."

# game/game/script.rpy:8471
translate es playername_8a47c9b1:

    # cg "He touches my face again, looming ever closer."
    cg "Vuelve a tocar mi rostro, inclinándose cada vez más cerca."

# game/game/script.rpy:8485
translate es playername_333be92a:

    # cg "{color=#CD9300} 'You...are so unbelievably perfect.' {/color}"
    cg "{color=#CD9300}'Eres... increíblemente una maravilla.'{/color}"

# game/game/script.rpy:8487
translate es playername_299698f7:

    # cg "{color=#CD9300} '%(player_name)s...'"
    cg "{color=#CD9300}'%(player_name)s...'{/color}"

# game/game/script.rpy:8488
translate es playername_39cf1374:

    # cg "{color=#CD9300} 'Can I kiss you?' {/color}"
    cg "{color=#CD9300}'¿Puedo besarte?'{/color}"

# game/game/script.rpy:8490
translate es playername_fa57c87f:

    # cg "My heart leaps out of my chest, Ray's face so close to mine I could almost feel the heat rolling off of his skin."
    cg "Mi corazón da un salto, el rostro de Ray tan cerca del mío que casi puedo sentir el calor de su piel."

# game/game/script.rpy:8500
translate es playername_532ef3c4:

    # cg "I nod slowly and Ray's hand moves to the base of my head."
    cg "Asiento lentamente y la mano de Ray se desliza hasta la base de mi cabeza."

# game/game/script.rpy:8509
translate es playername_cf5b675c:

    # cg "He leans in softly pushing his lips into mine."
    cg "Se inclina suavemente, presionando sus labios contra los míos."

# game/game/script.rpy:8515
translate es playername_93f98d7a:

    # cg "His fingers weave into my hair and I can feel him sigh."
    cg "Sus dedos se entrelazan en mi cabello y lo siento suspirar."

# game/game/script.rpy:8517
translate es playername_e4d5be84:

    # cg "When I don't pull back, Ray deepens the kiss. My heart is hammering in my chest."
    cg "Como no me aparto, Ray profundiza el beso. Mi corazón late con fuerza en el pecho."

# game/game/script.rpy:8519
translate es playername_6493e92b:

    # cg "I become greedy at the sensation of Rays lips gently colliding into my own."
    cg "Siento codicia ante la sensación de los labios de Ray rozando los míos."

# game/game/script.rpy:8521
translate es playername_6afb78c0:

    # cg "I want to taste him."
    cg "Quiero saborearlo."

# game/game/script.rpy:8523
translate es playername_a88ccba8:

    # cg "My fingers reach up wrapping into the collar of Ray's shirt, I pull him closer."
    cg "Mis dedos suben, aferrándose al cuello de la camisa de Ray, y lo atraigo más cerca."

# game/game/script.rpy:8525
translate es playername_104f28a2:

    # cg "His hand tightens in my hair in response to my action."
    cg "Su mano se aprieta en mi cabello en respuesta a mi acción."

# game/game/script.rpy:8527
translate es playername_8dc23897:

    # cg "I push my tongue against his lips and he parts his brushing his tongue against my own."
    cg "Presiono mi lengua contra sus labios y él los entreabre, rozando su lengua con la mía."

# game/game/script.rpy:8529
translate es playername_5904042f:

    # cg "He groans and pulls back, a small smile forming on his lips."
    cg "Gime y se aparta, una pequeña sonrisa se forma en sus labios."

# game/game/script.rpy:8533
translate es playername_e95ab46c:

    # cg "I look up at him, hungry."
    cg "Lo miro, hambrienta."

# game/game/script.rpy:8535
translate es playername_bd0a6119:

    # cg "{color=#CD9300} 'We should probably stop...' {/color}"
    cg "{color=#CD9300}'Deberíamos detenernos…'{/color}"

# game/game/script.rpy:8543
translate es playername_e9a94328:

    # cg "{color=#CD9300} 'Or I will have a harder time stopping myself later on.' {/color}"
    cg "{color=#CD9300}'O me costará más detenerme después.'{/color}"

# game/game/script.rpy:8545
translate es playername_c50df1fd:

    # cg "His black eyes are filled with warning."
    cg "Sus ojos negros están llenos de advertencia."

# game/game/script.rpy:8547
translate es playername_6c59becd:

    # cg "{color=#510f80} 'Okay fine.' {/color}"
    cg "{color=#510f80}'Está bien, de acuerdo.'{/color}"

# game/game/script.rpy:8551
translate es playername_14d1bce8:

    # cg "{color=#CD9300} 'Good, thankyou.' {/color}"
    cg "{color=#CD9300}'Bien, gracias.'{/color}"

# game/game/script.rpy:8553
translate es playername_00b84524:

    # cg "He leans down placing a kiss on my forehead."
    cg "Se inclina y deja un beso en mi frente."

# game/game/script.rpy:8557
translate es playername_abd235b0:

    # cg "I shake my head lightly."
    cg "Niego levemente con la cabeza."

# game/game/script.rpy:8566
translate es playername_7dd02199:

    # cg "{color=#510f80} 'Sorry, I don't think I can....' {/color}"
    cg "{color=#510f80}'Lo siento, no creo que pueda…'{/color}"

# game/game/script.rpy:8568
translate es playername_e9874efe:

    # cg "{color=#CD9300} 'It's okay, don't apologize.' {/color}"
    cg "{color=#CD9300}'Está bien, no te disculpes.'{/color}"

# game/game/script.rpy:8575
translate es playername_c9c7e37b:

    # cg "{color=#CD9300} 'I'm sorry for even asking, I got ahead of myself clearly.' {/color}"
    cg "{color=#CD9300}'Perdón por haberlo pedido siquiera, claramente me dejé llevar.'{/color}"

# game/game/script.rpy:8584
translate es playername_680c9584:

    # cg "{color=#CD9300} 'You should try and get some sleep, you look exhausted.' {/color}"
    cg "{color=#CD9300}'Deberías intentar dormir, se te ve el cansancio.'{/color}"

# game/game/script.rpy:8586
translate es playername_8d6fdaa0:

    # cg "{color=#510f80} 'I look exhausted? Ray you look like you haven't slept in weeks.' {/color}"
    cg "{color=#510f80}'¿Se me ve el cansancio? Ray, tú pareces no haber dormido en semanas.'{/color}"

# game/game/script.rpy:8588
translate es playername_862b521a:

    # cg "{color=#CD9300} 'I don't really get much sleep.' {/color}"
    cg "{color=#CD9300}'No duermo mucho, la verdad.'{/color}"

# game/game/script.rpy:8590
translate es playername_d81a2e3e:

    # cg "{color=#510f80} 'Do you think you can sleep in with me tomorrow?' {/color}"
    cg "{color=#510f80}'¿Crees que podrías dormir conmigo mañana?'{/color}"

# game/game/script.rpy:8592
translate es playername_e054f58e:

    # cg "Ray gives a little smile."
    cg "Ray muestra una pequeña sonrisa."

# game/game/script.rpy:8594
translate es playername_cf96944e:

    # cg "{color=#CD9300} 'We will see... try to get some sleep Star.' {/color}"
    cg "{color=#CD9300}'Ya veremos… intenta dormir, Estrella.'{/color}"

# game/game/script.rpy:8596
translate es playername_673fcc08:

    # cg "{color=#510f80} 'You too Ray.' {/color}"
    cg "{color=#510f80}'Tú también, Ray.'{/color}"

# game/game/script.rpy:8603
translate es playername_44ac1e34:

    # cg "I cuddle into him and his arms tighten around me."
    cg "Me acurruco contra él y sus brazos se cierran con fuerza a mi alrededor."

# game/game/script.rpy:8605
translate es playername_5f4c888a:

    # cg "With the comfort of Ray's tight hold I fall asleep in no time."
    cg "Con el consuelo del abrazo de Ray, me duermo en poco tiempo."

# game/game/script.rpy:8627
translate es playername_dc1027ba:

    # "With Ray watching over me, I am able to slowly drift off to sleep."
    "Con Ray velando por mí, logro dormir lentamente."

# game/game/script.rpy:8633
translate es playername_a20cefa7_7:

    # "..."
    "..."

# game/game/script.rpy:8635
translate es playername_1f15b526:

    # "I wake up in the middle of the night."
    "Despierto en medio de la noche."

# game/game/script.rpy:8637
translate es playername_b1992e0b:

    # "Ray's lowered voice bounces off the walls softly."
    "La voz baja de Ray rebota suavemente en las paredes."

# game/game/script.rpy:8651
translate es playername_806bc09b:

    # r "Yeah, I did it. What else do you want me to say?"
    r "Sí, lo hice. ¿Qué más quieres que diga?"

# game/game/script.rpy:8653
translate es playername_b6e19d3e_1:

    # r "...."
    r "...."

# game/game/script.rpy:8655
translate es playername_d8522fdc:

    # r "So, what are you going to do? Actually, let me rephrase that-"
    r "Entonces, ¿qué vas a hacer? En realidad, déjame reformular eso:"

# game/game/script.rpy:8657
translate es playername_679dc7e0:

    # r "What {i}can{/i} you do?"
    r "¿Qué {i}puedes{/i} hacer?"

# game/game/script.rpy:8659
translate es playername_b9b755e5_5:

    # r "..."
    r "..."

# game/game/script.rpy:8661
translate es playername_2ad707b3:

    # r "No, I'd rethink that if I were you."
    r "No, lo reconsideraría si fuera tú."

# game/game/script.rpy:8663
translate es playername_b9825379:

    # r "If you want to put me on trial, the reputation of your best hero is tarnished."
    r "Si quieres enjuiciarme, la reputación de tu mejor héroe quedará arruinada."

# game/game/script.rpy:8666
translate es playername_0c7c2667:

    # r "You can fire me if you want? I'd gladly take the vacation."
    r "¿Quieres despedirme? Aceptaría las vacaciones con gusto."

# game/game/script.rpy:8670
translate es playername_e0c124fa:

    # r "See? Nothing else you can do."
    r "¿Ves? No hay nada más que puedas hacer."

# game/game/script.rpy:8672
translate es playername_b6e19d3e_2:

    # r "...."
    r "...."

# game/game/script.rpy:8674
translate es playername_17c21895:

    # r "What now? Well-"
    r "¿Y ahora qué? Bueno…"

# game/game/script.rpy:8678
translate es playername_81a74a6f:

    # r "I'd recommend you keep a leash on your other heroes."
    r "Te recomendaría que mantengas a tus otros héroes bajo control."

# game/game/script.rpy:8680
translate es playername_963bd907:

    # r "Keep them the fuck away from my personal life."
    r "Mantenlos bien lejos de mi vida personal."

# game/game/script.rpy:8682
translate es playername_1748a8b9:

    # r "Frankly I'd recommend that for any of you."
    r "Francamente, recomendaría eso para cualquiera de ustedes."

# game/game/script.rpy:8684
translate es playername_b9b755e5_6:

    # r "..."
    r "..."

# game/game/script.rpy:8686
translate es playername_962e698b:

    # r "We {i}both{/i} know what I'm capable of and I'm no longer satisfied with playing nice."
    r "Ambos {i}sabemos{/i} de lo que soy capaz, y ya no estoy satisfecho con seguir actuando como si todo estuviera bien."

# game/game/script.rpy:8691
translate es playername_1d49b9c4:

    # "Ray glances at me and I shut my eyes to pretend I'm asleep."
    "Ray me mira de reojo y cierro los ojos para fingir que estoy durmiendo. "

# game/game/script.rpy:8693
translate es playername_ca797683:

    # "I'm unsure if he saw me looking at him, but he walks over and sits near me on the edge of the bed."
    "No se si me vio mirándolo, pero camina hacia mí y se sienta cerca, al borde de la cama."

# game/game/script.rpy:8712
translate es playername_811429b0:

    # "He pats my head softly. He must have thought I was tossing and turning."
    "Me da una palmadita suave en la cabeza. Debe haber pensado que me muevo mientras duermo."

# game/game/script.rpy:8714
translate es playername_552b1733:

    # "After my breathing evens he continues talking on the phone."
    "Después de que mi respiración se estabiliza, continúa hablando por teléfono."

# game/game/script.rpy:8718
translate es playername_b2981b3c:

    # r "I look forward to watching the NAHA actually do their fucking job for once."
    r "Estoy deseando ver a la NAHA hacer su maldito trabajo por una vez."

# game/game/script.rpy:8720
translate es playername_b9b755e5_7:

    # r "..."
    r "..."

# game/game/script.rpy:8722
translate es playername_b9b755e5_8:

    # r "..."
    r "..."

# game/game/script.rpy:8724
translate es playername_ce55cebd:

    # r "Please, be my guest, {i} tell Herschel.{/i} There isn't anything he can do either."
    r "Por favor, sé mi invitado, {i}le digo a Herschel.{/i} Tampoco hay nada que él pueda hacer."

# game/game/script.rpy:8726
translate es playername_ed0e86f8:

    # r "Then you better contact risk management. There is nothing the NAHA can do to make me back down."
    r "Entonces será mejor que contactes con gestión de riesgos. No hay nada que la NAHA pueda hacer para que me retracte."

# game/game/script.rpy:8728
translate es playername_c9f635d8:

    # r "I'm getting what I want, and frankly as far as I'm concerned..."
    r "Estoy consiguiendo lo que quiero, y francamente, en lo que a mí respecta..."

# game/game/script.rpy:8732
translate es playername_f62fb58e:

    # r "{i}Everything else can burn.{/i}"
    r "{i}Todo lo demás puede arder.{/i}"

# game/game/script.rpy:8734
translate es playername_dbaeddca:

    # r "That's about all I have to say regarding that."
    r "Eso es todo lo que tengo que decir al respecto."

# game/game/script.rpy:8738
translate es playername_0e0b1439:

    # r " Last thing, I'm going to be late getting to work tomorrow."
    r "Última cosa, llegaré tarde al trabajo mañana."

# game/game/script.rpy:8742
translate es playername_c4876e23:

    # "Ray glances at me."
    "Ray me lanza una mirada."

# game/game/script.rpy:8744
translate es playername_fc01313a:

    # r "I have decided to sleep in."
    r "He decidido dormir un poco más."

# game/game/script.rpy:8746
translate es playername_7c9d9337:

    # r "Good night."
    r "Buenas noches."

# game/game/script.rpy:8748
translate es playername_79f8c1bc:

    # "Ray hangs up the phone."
    "Ray cuelga el teléfono."

# game/game/script.rpy:8752
translate es playername_f2bb442d:

    # "He gazes down at me, his thumb tracing the features of my face."
    "Me observa, su pulgar trazando los rasgos de mi rostro."

# game/game/script.rpy:8754
translate es playername_93e1b1ca:

    # r "Did I wake you up...?"
    r "¿Te desperté...?"

# game/game/script.rpy:8756
translate es playername_fc05cf58:

    # "I open my eyes slowly. The moonlight blankets Ray like a halo giving him an ethereal glimmer."
    "Abro los ojos lentamente. La luz de la luna envuelve a Ray como un halo que le da un brillo etéreo."

# game/game/script.rpy:8758
translate es playername_1e49a78e:

    # mc "I shake my head slowly."
    mc "Niego lentamente con la cabeza."

# game/game/script.rpy:8762
translate es playername_73e4fd81:

    # "A ghost of a smirk appears on his face."
    "Una sombra de sonrisa aparece en su rostro."

# game/game/script.rpy:8764
translate es playername_a93b68d2:

    # r "You're a good liar %(player_name)s."
    r "Si que te gusta mentir %(player_name)s."

# game/game/script.rpy:8766
translate es playername_93812d71:

    # mc "Is everything okay..?"
    mc "¿Está todo bien..?"

# game/game/script.rpy:8773
translate es playername_adc9cca5:

    # cg "Ray gets into bed next to me, his familiar warmth comforting."
    cg "Ray se mete en la cama a mi lado, su calor familiar reconfortante."

# game/game/script.rpy:8775
translate es playername_594d2b94:

    # cg "He runs his fingers down my cheek leaning in."
    cg "Pasa sus dedos por mi mejilla inclinándose."

# game/game/script.rpy:8777
translate es playername_aa7ff6ff:

    # cg "{color=#CD9300} 'You don't have to worry about anything.' {/color}"
    cg "{color=#CD9300} 'No tienes que preocuparte por nada.' {/color}"

# game/game/script.rpy:8779
translate es playername_447a0382:

    # cg "{color=#CD9300} 'I'll take care of everything.' {/color}"
    cg "{color=#CD9300} 'Yo me encargaré de todo.' {/color}"

# game/game/script.rpy:8781
translate es playername_97c33752:

    # cg "{color=#CD9300} 'Go back to sleep.' {/color}"
    cg "{color=#CD9300} 'Vuelve a dormir.' {/color}"

# game/game/script.rpy:8783
translate es playername_25a9aaae:

    # cg "I nod and lay my head back down."
    cg "Asiento y apoyo de nuevo la cabeza."

# game/game/script.rpy:8787
translate es playername_c63228c3:

    # cg "Soon everything fades into a familiar darkness."
    cg "Pronto todo se desvanece en una oscuridad familiar."

# game/game/script.rpy:8797
translate es playername_6718f5f9:

    # "I wake up as something tickles my cheek."
    "Me despierto cuando algo me hace cosquillas en la mejilla."

# game/game/script.rpy:8799
translate es playername_9d70d2a4:

    # "My eyes readjust and I glance over."
    "Mis ojos se ajustan y miro a un lado."

# game/game/script.rpy:8801
translate es playername_fbc34e6b:

    # "Ray snoozes near me soundly."
    "Ray duerme profundamente cerca de mí."

# game/game/script.rpy:8803
translate es playername_388fad40:

    # "I try to get up but his arms are wrapped tightly around my waist."
    "Intento levantarme pero sus brazos están fuertemente envueltos alrededor de mi cintura."

# game/game/script.rpy:8805
translate es playername_5372161e:

    # "He mumbles something and nuzzles the top of my head."
    "Murmura algo y se acurruca sobre mi cabeza."

# game/game/script.rpy:8807
translate es playername_19d5da04:

    # mc "Ray..."
    mc "Ray..."

# game/game/script.rpy:8809
translate es playername_6d3154b7:

    # r "Mmnn....five more minutes..."
    r "Mmnn... cinco minutos más..."

# game/game/script.rpy:8811
translate es playername_8800423a:

    # mc "Ray...!"
    mc "¡Ray...!"

# game/game/script.rpy:8813
translate es playername_72f51898:

    # "His eyes flutter open. When he realizes his hold on me his face goes pink and he scrambles up."
    "Sus ojos se abren lentamente. Cuando se da cuenta de que aún me sostiene, su rostro se sonroja y se aparta apresurado."

# game/game/script.rpy:8821
translate es playername_2ef8a39e:

    # r "Ah! Sorry, I didn't mean to -, I usually don't-."
    r "¡Ah! Perdón, no quise –, normalmente no–."

# game/game/script.rpy:8823
translate es playername_b1d225d5:

    # mc "It's okay. You were pretty out of it there..."
    mc "Está bien. Estabas bastante dormido..."

# game/game/script.rpy:8827
translate es playername_5dda340a:

    # "Ray stretches, his toned body brushing against the thin black shirt."
    "Ray se estira, su cuerpo tonificado rozando la delgada camiseta negra."

# game/game/script.rpy:8830
translate es playername_6f8d4dbd:

    # r "Yeah, I honestly haven't slept that soundly in ages."
    r "Sí, honestamente no había dormido tan bien en siglos."

# game/game/script.rpy:8832
translate es playername_a79b6b1c:

    # r "I'm surprised I even woke up."
    r "Me sorprende incluso haberme despertado."

# game/game/script.rpy:8834
translate es playername_70b37912:

    # mc "That makes two of us."
    mc "Eso nos hace dos."

# game/game/script.rpy:8836
translate es playername_45eb97ad:

    # "Ray gets out of bed yawning."
    "Ray se levanta de la cama bostezando."

# game/game/script.rpy:8856
translate es playername_d5cd5d71:

    # r "Do you mind if I take a shower?"
    r "¿Te importa si me doy una ducha?"

# game/game/script.rpy:8858
translate es playername_4f671c67:

    # mc "No, not at all."
    mc "No, en absoluto."

# game/game/script.rpy:8862
translate es playername_915a56a9:

    # "The soft sound of footsteps wake me up."
    "El suave sonido de pasos me despierta."

# game/game/script.rpy:8864
translate es playername_38dc6c6a:

    # "My eyes flutter open to the sunlight peaking through the windows."
    "Mis ojos se abren al sol que se filtra por las ventanas."

# game/game/script.rpy:8866
translate es playername_3c614ea8:

    # "{i}How early is it..?{/i}"
    "{i}¿Qué tan temprano es..?{/i}"

# game/game/script.rpy:8868
translate es playername_81b088e7:

    # r "It's 8am-"
    r "Son las 8 a. m.–"

# game/game/script.rpy:8870
translate es playername_6f22b1ec:

    # mc "Ah! Ray!"
    mc "¡Ah! ¡Ray!"

# game/game/script.rpy:8872
translate es playername_c214eccd:

    # "I whip my head over to Ray who stands there looking surprised."
    "Giro la cabeza hacia Ray, que está ahí con cara de sorpresa."

# game/game/script.rpy:8878
translate es playername_c3beb5bc:

    # r "Oh sorry, I didn't mean to shock you..."
    r "Oh, lo siento, no quise asustarte..."

# game/game/script.rpy:8880
translate es playername_9dceb3fb:

    # mc "No, it's okay, you just usually aren't here in the mornings."
    mc "No, está bien, es solo que normalmente no estás aquí por las mañanas."

# game/game/script.rpy:8884
translate es playername_3b1e3d34:

    # "Ray gives a wry smile."
    "Ray sonríe con ironía."

# game/game/script.rpy:8886
translate es playername_5e150228:

    # r "You make me sound like a bad hookup or something."
    r "Me haces sonar como un ligue casual o algo así."

# game/game/script.rpy:8889
translate es playername_64b30ff1:

    # r "Do you want me to do the walk of shame or something..?"
    r "¿Quieres que haga la caminata de la vergüenza o algo..?"

# game/game/script.rpy:8891
translate es playername_cc761816:

    # mc "No..."
    mc "No..."

# game/game/script.rpy:8893
translate es playername_93913ae4:

    # mc "Though, I'm sure you could do a pretty good walk of shame..."
    mc "Aunque, seguro podrías hacer una buena caminata de la vergüenza..."

# game/game/script.rpy:8895
translate es playername_fe25ac44_1:

    # "Ray laughs."
    "Ray se ríe."

# game/game/script.rpy:8899
translate es playername_95cad5ea:

    # r "Wow, what do you take me for?!"
    r "¡Vaya, ¿por quién me tomas?!"

# game/game/script.rpy:8901
translate es playername_5dbbe365:

    # r "I do have to leave for work soon though..."
    r "Aunque tengo que irme al trabajo pronto..."

# game/game/script.rpy:8903
translate es playername_08380174:

    # r "Do you mind if I shower here before leaving?"
    r "¿Te importa si me ducho aquí antes de irme?"

# game/game/script.rpy:8905
translate es playername_de28e1c1:

    # mc "No, go for it."
    mc "No, adelante."

# game/game/script.rpy:8909
translate es playername_d768b14f:

    # r "Don't worry, I'll be out of your hair soon."
    r "No te preocupes, pronto dejaré de molestarte."

# game/game/script.rpy:8917
translate es playername_a79c2368:

    # "He retreats into the bathroom."
    "Se retira al baño."

# game/game/script.rpy:8922
translate es playername_ee505f1b:

    # "I eye his duffle bag that he always brings with him..."
    "Miro su bolso deportivo que siempre trae consigo..."

# game/game/script.rpy:8928
translate es playername_c0ecdfd0:

    # "I know it isn't a nice thing to do...."
    "Sé que no está bien hacerlo..."

# game/game/script.rpy:8931
translate es playername_3df844b8:

    # "But after everything that has been going on I can hardly be blamed for being a little skeptical."
    "Pero después de todo lo que ha estado pasando, difícilmente se me puede culpar por tener un poco escepticismo."

# game/game/script.rpy:8933
translate es playername_36874ca7:

    # "I can't disregard what I saw in that warehouse. I can't disregard what was spoken about on the phone last night..."
    "No puedo ignorar lo que vi en ese almacén. No puedo ignorar lo que se habló por teléfono anoche..."

# game/game/script.rpy:8935
translate es playername_fe550f21:

    # "I can't disregard my safety by having him be around my apartment so often without knowing if he is dangerous or not."
    "No puedo ignorar mi seguridad teniendo a alguien tan seguido en mi apartamento sin saber si es peligroso o no."

# game/game/script.rpy:8939
translate es playername_0b26cedf:

    # "I first poke at his duffle bag."
    "Primero tanteo su bolso deportivo."

# game/game/script.rpy:8943
translate es playername_38a9ad9c:

    # "Then I slowly open it..."
    "Luego lo abro lentamente..."

# game/game/script.rpy:8945
translate es playername_bfeae832:

    # "inside were some changes of clothing."
    "adentro había algo de ropa."

# game/game/script.rpy:8947
translate es playername_dfbb6dcf:

    # "Just a sweatshirt and some jeans."
    "Solo una sudadera y unos jeans."

# game/game/script.rpy:8949
translate es playername_dfc3c0c0:

    # "I smell them but nothing seems off."
    "Los huelo pero no noto nada extraño."

# game/game/script.rpy:8951
translate es playername_7abc87d4:

    # "They smell like Ray, slightly of pine and toasted sugar."
    "Huelen a Ray, un poco a pino y azúcar tostado."

# game/game/script.rpy:8953
translate es playername_e4fb9f20:

    # "While I am digging around in his clothing I accidentally shake loose a carton of cigarettes."
    "Mientras reviso su ropa accidentalmente hago caer una cajetilla de cigarrillos."

# game/game/script.rpy:8955
translate es playername_5e29697f:

    # "{i}I would probably need some stress relief if a whole city relied on me too.{/i}"
    "{i}Probablemente yo también necesitaría algo para aliviar el estrés si toda una ciudad dependiera de mí.{/i}"

# game/game/script.rpy:8957
translate es playername_52c0db6d:

    # "I feel something hard in a pocket."
    "Siento algo duro en un bolsillo."

# game/game/script.rpy:8959
translate es playername_d3e575fb:

    # "{i}That looks like a pen I used to have...{/i}"
    "{i}Eso parece un bolígrafo que yo solía tener...{/i}"

# game/game/script.rpy:8961
translate es playername_37e1e1dd:

    # "There isn't much in his duffle bag."
    "No hay mucho en su bolso deportivo."

# game/game/script.rpy:8963
translate es playername_4effc685:

    # "Some clothing, a notebook, some keys, a couple of phones."
    "Algo de ropa, un cuaderno, unas llaves, un par de teléfonos."

# game/game/script.rpy:8965
translate es playername_1617aea5:

    # "I hear a bump in the shower and realize I probably don't have too much more time to snoop."
    "Escucho un golpe en la ducha y me doy cuenta de que probablemente no tengo mucho más tiempo para husmear."

# game/game/script.rpy:8974
translate es playername_b7f4a9c7:

    # "I tap on one of his phones in the duffle bag."
    "Toco uno de sus teléfonos en el bolso."

# game/game/script.rpy:8976
translate es playername_faba0980:

    # "It's password protected but I can read a couple of the newest text messages."
    "Está protegido con contraseña, pero puedo leer algunos de los mensajes más recientes."

# game/game/script.rpy:8978
translate es playername_3af58531:

    # "None of the texts come from saved numbers."
    "Ninguno proviene de números guardados."

# game/game/script.rpy:8980
translate es playername_820d0b0a:

    # "I expand the first message."
    "Amplío el primer mensaje."

# game/game/script.rpy:8982
translate es playername_5cba400a:

    # "{color=#116670} '{i}Hey BS! This is Myst, I got your number from Chandra. I texted you last week but you never responded. Can you PLEASE consider talking to Herschel for me?'{/i}{/color}"
    "{color=#116670} '{i}¡Hola BS! Soy Myst, obtuve tu número de Chandra. Te escribí la semana pasada pero nunca respondiste. ¿Podrías POR FAVOR considerar hablar con Herschel por mí?{/i}'{/color}"

# game/game/script.rpy:8984
translate es playername_7005cb1a:

    # "The second message comes from the same number."
    "El segundo mensaje proviene del mismo número."

# game/game/script.rpy:8986
translate es playername_9824b85d:

    # "{color=#116670} '{i}Look, I KNOW I fucked up! It won't happen again. The family took the shut-up money and signed a NDA, so if you vouch for me I promise it won't come back to bite you.{/i}' {/color}"
    "{color=#116670} '{i}¡Mira, SÉ que la cagué! No volverá a pasar. La familia aceptó el dinero por callarse y firmó un NDA, así que si respondes por mí prometo que no volverá a perseguirte.{/i}' {/color}"

# game/game/script.rpy:8988
translate es playername_ce093b9b:

    # "While I was reading the second message from this 'Myst' person a new message appeared onto the screen."
    "Mientras leía el segundo mensaje de esta persona 'Myst', un nuevo mensaje apareció en la pantalla."

# game/game/script.rpy:8990
translate es playername_8a784cb2:

    # "{color=#701111} '{i}Need to talk about your recent performance - I have been informed of actions inappropriate by the standards of the NAHA - Tomorrow 8am EST. Herschel.{/i}' {/color}"
    "{color=#701111} '{i}Necesitamos hablar sobre tu desempeño reciente – Se me ha informado de acciones inapropiadas según los estándares de la NAHA – Mañana 8 a. m. EST. Herschel.{/i}' {/color}"

# game/game/script.rpy:8992
translate es playername_377dcd1e:

    # "While trying to close out I accidentally hit the 'reply' button on the message from 'Herschel'."
    "Mientras intentaba cerrar el mensaje accidentalmente presioné el botón de 'responder' en el mensaje de 'Herschel'."

# game/game/script.rpy:8994
translate es playername_187e29f6:

    # "I should have just closed out immediately, but part of me wanted to see what would happen if I respond."
    "Debería haberlo cerrado enseguida, pero parte de mí quería ver qué pasaba si respondía."

# game/game/script.rpy:9001
translate es playername_b1b74c10:

    # "I closed out of the text deciding it wasn't worth it to respond."
    "Cerré el mensaje decidiendo que no valía la pena responder."

# game/game/script.rpy:9003
translate es playername_2cfc2c2d:

    # "Ray might find out and get upset..."
    "Ray podría descubrirlo y molestarse..."

# game/game/script.rpy:9005
translate es playername_aa996c26:

    # "I put the phone away."
    "Guardo el teléfono."

# game/game/script.rpy:9013
translate es playername_b1c9927b:

    # "I quickly type something simple."
    "Escribo rápidamente algo simple."

# game/game/script.rpy:9015
translate es playername_f22da4dc:

    # "the person named Herschel responds back a with a thumbs up emoji."
    "La persona llamada Herschel responde con un emoji de pulgar hacia arriba."

# game/game/script.rpy:9017
translate es playername_fada7ac0:

    # "Something gave me the feeling that this man 'Herschel' wasn't necessarily technologically literate."
    "Algo me dio la sensación de que este hombre 'Herschel' no era necesariamente experto en tecnología."

# game/game/script.rpy:9019
translate es playername_d2b15655:

    # "I close out of the text message and put the phone away."
    "Cierro el mensaje y guardo el teléfono."

# game/game/script.rpy:9027
translate es playername_707e6cdc:

    # "I type and send a simple 'No'."
    "Escribo y envío un simple 'No'."

# game/game/script.rpy:9029
translate es playername_f45c7049:

    # "It only takes a few moments for this person named Herschel to respond."
    "Solo tarda unos momentos en responder esta persona llamada Herschel."

# game/game/script.rpy:9031
translate es playername_51d70e82:

    # "{color=#701111} '{i}Don't play this game Ray. We will not respond lightly. Herschel.{/i}' {/color}"
    "{color=#701111} '{i}No juegues a ese juego, Ray. No responderemos a la ligera. Herschel.{/i}' {/color}"

# game/game/script.rpy:9033
translate es playername_7c937b2a:

    # "Suddenly another text comes in with a long set of numbers."
    "De repente llega otro mensaje con una larga serie de números."

# game/game/script.rpy:9035
translate es playername_cf69bcc6:

    # mc "What the...."
    mc "¿Qué diablos...."

# game/game/script.rpy:9037
translate es playername_9d650ece:

    # "The realization hits me.... Hershel has sent me coordinates."
    "La realización me golpea.... Herschel me ha enviado coordenadas."

# game/game/script.rpy:9039
translate es playername_2ae8a16f:

    # "I don't even waste time verifying that they are {i} my {/i} coordinates before responding back."
    "Ni siquiera pierdo tiempo verificando que son {i}mis{/i} coordenadas antes de responder."

# game/game/script.rpy:9041
translate es playername_4ab7a084:

    # "{i} 'Sorry, it was a joke! Of course I'll be there :)'{/i}"
    "{i}'¡Perdón, era una broma! Por supuesto que estaré :)'{/i}"

# game/game/script.rpy:9043
translate es playername_2f44b675:

    # "Herschel takes a few seconds to respond."
    "Herschel tarda unos segundos en responder."

# game/game/script.rpy:9045
translate es playername_e8159806:

    # "{color=#701111} {i}8am tomorrow. Herschel.{/i} {/color}"
    "{color=#701111} {i}8am mañana. Herschel.{/i} {/color}"

# game/game/script.rpy:9053
translate es playername_ca02d1a0:

    # "I snicker to myself typing up a response."
    "Me río para mis adentros mientras escribo una respuesta."

# game/game/script.rpy:9055
translate es playername_dda88685:

    # "{i}'I'll show you some REAL inappropriate actions by the standards of the NAHA ;) ...'{/i}"
    "{i}'Les mostraré algunas VERDADERAS acciones inapropiadas según los estándares de la NAHA ;)...'{/i}"

# game/game/script.rpy:9057
translate es playername_c71b2da9:

    # "A response comes almost immediately."
    "Una respuesta llega casi de inmediato."

# game/game/script.rpy:9059
translate es playername_794cf499:

    # "{color=#701111} {i}'If that is a threat we will not respond lightly. Herschel.'{/i}{/color}"
    "{color=#701111} {i}'Si eso es una amenaza no responderemos a la ligera. Herschel.'{/i}{/color}"

# game/game/script.rpy:9061
translate es playername_11435950:

    # "My attempt at flirtation has flown far over Herschel's head and into dangerous territory."
    "Mi intento de coqueteo ha pasado por encima de la cabeza de Herschel y ha entrado en territorio peligroso."

# game/game/script.rpy:9063
translate es playername_fbf77f73:

    # "I become determined."
    "Me siento determinada."

# game/game/script.rpy:9065
translate es playername_9f1d9bac:

    # "{color=#701111}{i}'And I wont respond lightly to that sexy little body of yours Herschel.'{/i} {/color}"
    "{color=#701111}{i}'Y yo no responderé a la ligera a ese cuerpecito sexy tuyo, Herschel.'{/i} {/color}"

# game/game/script.rpy:9067
translate es playername_65c3838b:

    # "I cover my mouth to keep myself from laughing out loud as the typing indicator begins and stops multiple times."
    "Me cubro la boca para no reír a carcajadas mientras el indicador de escritura aparece y desaparece varias veces."

# game/game/script.rpy:9069
translate es playername_f9060e7d:

    # "Herschel must really be confused."
    "Herschel debe estar realmente confundido."

# game/game/script.rpy:9071
translate es playername_453f2900:

    # "Finally a text comes through."
    "Finalmente llega un mensaje."

# game/game/script.rpy:9073
translate es playername_29757c44:

    # "{color=#701111} {i}'Did you drink drain cleaner? Take a gunshot to the head? Sober up. 8am tomorrow. Herschel.'{/i} {/color}"
    "{color=#701111} {i}'¿Tomaste limpiador de desagües? ¿Un balazo en la cabeza? Pórtate sobrio. 8am mañana. Herschel.'{/i} {/color}"

# game/game/script.rpy:9075
translate es playername_7ed8423c:

    # "Herschel was certified no fun at all."
    "Herschel no era nada divertido."

# game/game/script.rpy:9077
translate es playername_721d0e52:

    # "I put Ray's phone away."
    "Guardo el teléfono de Ray."

# game/game/script.rpy:9086
translate es playername_cefae8d5:

    # "I glance at a small notebook."
    "Miro un pequeño cuaderno."

# game/game/script.rpy:9088
translate es playername_f8fddb8f:

    # "It seemed like an odd thing to carry for a super hero."
    "Parecía una cosa extraña de llevar para un superhéroe."

# game/game/script.rpy:9093
translate es playername_2b7912ea:

    # "I flip it open."
    "Lo abro."

# game/game/script.rpy:9095
translate es playername_b603680f:

    # "On the pages there are small drawings of different planets and notes."
    "En las páginas hay pequeños dibujos de diferentes planetas y notas."

# game/game/script.rpy:9099
translate es playername_ba5a8e35:

    # "the drawings and notes go on for pages and pages."
    "los dibujos y las notas continúan por páginas y páginas."

# game/game/script.rpy:9101
translate es playername_1ce92704:

    # "Something about the handwriting feels...off to me."
    "Algo en la caligrafía me resulta... extraña."

# game/game/script.rpy:9103
translate es playername_11c39823:

    # "To confirm my suspicion, I hop up to my nightstand. I open the nightstand grabbing the coffee sleeve from Ray I have kept."
    "Para confirmar mi sospecha, me levanto hasta mi mesita de noche. Abro la mesita y tomo la funda de café de Ray que he guardado."

# game/game/script.rpy:9105
translate es playername_253c6449:

    # ".....My suspicions were correct."
    ".....Mis sospechas eran correctas."

# game/game/script.rpy:9109
translate es playername_635a4aac:

    # "The handwriting on the coffee sleeve, and the handwriting from the first good chunk of pages in the notebook are..."
    "La caligrafía en la funda de café y la caligrafía del primer buen puñado de páginas del cuaderno no son..."

# game/game/script.rpy:9111
translate es playername_561c6bc6:

    # "Not similar at all."
    "Para nada similares."

# game/game/script.rpy:9115
translate es playername_a6509b46:

    # "As the pages continue the handwriting gets closer to the handwriting that is on the coffee sleeve."
    "A medida que las páginas continúan, la caligrafía se acerca más a la de la funda de café."

# game/game/script.rpy:9117
translate es playername_5edc9cf6:

    # "{i}Is this all Ray..? Or is this someone else too?{/i}"
    "{i}¿Es todo esto Ray..? ¿O también es de otra persona?{/i}"

# game/game/script.rpy:9119
translate es playername_12027ff5:

    # "The drawings on the pages always looked a bit childish, never seeming to change."
    "Los dibujos en las páginas siempre parecían un poco infantiles, sin cambiar mucho."

# game/game/script.rpy:9121
translate es playername_b0aa4eaf:

    # "The pages near the end trail off, a chunk of pages are missing."
    "Las páginas cerca del final se desvanecen, falta un bloque de páginas."

# game/game/script.rpy:9123
translate es playername_3fb0185f:

    # "The final page has an image of two spheres and the words {i}'{color=#CD9300} We orbit around each other {/color}'{/i}."
    "La página final tiene la imagen de dos esferas y las palabras {i}'{color=#CD9300}Orbitamos alrededor el uno del otro{/color}'{/i}."

# game/game/script.rpy:9127
translate es playername_7fb7681a:

    # "As I am returning everything to the dufflebag, a wallet tumbles out flopping against the floor."
    "Mientras devuelvo todo al bolso deportivo, una billetera cae rodando y golpea contra el suelo."

# game/game/script.rpy:9129
translate es playername_b33a0539:

    # "A square paper slides out of the wallet as it hits the ground."
    "Al chocar, se desliza un papel cuadrado de la billetera."

# game/game/script.rpy:9131
translate es playername_16a26bce:

    # "I snag it off of the ground, opening the wallet to put it back inside."
    "Lo recojo del suelo y abro la billetera para volver a meterlo."

# game/game/script.rpy:9133
translate es playername_86945461:

    # "As I flip around the small square, my hand pauses."
    "Al darle la vuelta al pequeño cuadrado, mi mano se detiene."

# game/game/script.rpy:9139
translate es playername_2a867a14:

    # "My heart threatens to leap from my chest."
    "Mi corazón amenaza con salirse del pecho."

# game/game/script.rpy:9141
translate es playername_b8ed0108:

    # "On the small square that was tucked inside of the wallet was a very familiar view."
    "En el pequeño cuadrado que estaba dentro de la billetera había una vista muy familiar."

# game/game/script.rpy:9143
translate es playername_3a0d2610:

    # "One I saw when looking into the mirror."
    "Una que vi al mirarme al espejo."

# game/game/script.rpy:9145
translate es playername_5d941748:

    # "A view of myself, around 3 years ago."
    "Una vista mía, de hace unos 3 años."

# game/game/script.rpy:9147
translate es playername_cfdc5a72:

    # " {i} 'It's me...in my villain outfit, petting a cat...?' {/i}"
    "{i} '¿Soy yo... en mi traje de villano, acariciando a un gato...?' {/i}"

# game/game/script.rpy:9151
translate es playername_f1f3ba53:

    # "As the shower shuts off I am jolted back to reality."
    "Cuando la ducha se apaga, vuelvo a la realidad de golpe."

# game/game/script.rpy:9153
translate es playername_59ffcfc7:

    # "I shove the picture back inside of the wallet and bury it back into the bag zipping it up just how it was before."
    "Metí la foto de nuevo en la billetera y la enterré dentro de la bolsa cerrándola exactamente como antes."

# game/game/script.rpy:9161
translate es playername_eb19abbb:

    # "I lay myself casually onto the bed pretending to read a book that has been sitting on my nightstand for over a month at this point."
    "Me recuesto casualmente en la cama fingiendo leer un libro que lleva en mi mesita más de un mes."

# game/game/script.rpy:9163
translate es playername_874a0b08:

    # "A couple of minutes later of pretend reading Ray exits the restroom."
    "Un par de minutos después de la lectura fingida Ray sale del baño."

# game/game/script.rpy:9169
translate es playername_a1db04f6:

    # "He approaches and leans against the wall where he usually does, by the window."
    "Se acerca y se apoya en la pared donde suele hacerlo, junto a la ventana."

# game/game/script.rpy:9175
translate es playername_79449bfe:

    # "This time instead of smoking a cigarette, he is fully focused on me."
    "Esta vez, en lugar de fumar un cigarrillo, está totalmente concentrado en mí."

# game/game/script.rpy:9177
translate es playername_3905656e:

    # "His intense look makes me squirm."
    "Su mirada intensa me hace inquietarme."

# game/game/script.rpy:9179
translate es playername_01d1628c:

    # "There is something distant, disconnected about his eyes."
    "Hay algo distante, desconectado en sus ojos."

# game/game/script.rpy:9181
translate es playername_731ed717:

    # r "So, you were digging through my stuff for something..?"
    r "¿Así que estabas hurgando en mis cosas para encontrar algo..?"

# game/game/script.rpy:9184
translate es playername_60d593c8:

    # r "Did you have fun reading through my notebook?"
    r "¿Te divertiste leyendo mi cuaderno?"

# game/game/script.rpy:9186
translate es playername_572abdbb:

    # r "I would have read it for you if you asked me nicely."
    r "Lo habría leído por ti si me lo hubieras pedido amablemente."

# game/game/script.rpy:9189
translate es playername_aaa5ef7e:

    # r "Going through my phone huh?"
    r "¿Hurgando en mi teléfono, eh?"

# game/game/script.rpy:9191
translate es playername_ca7df72a:

    # r "You are a nosey little thing."
    r "Eres una cosita entrometida."

# game/game/script.rpy:9193
translate es playername_23f51b15:

    # r "Kinda an invasion of privacy don't you think?"
    r "Algo así como una invasión de la privacidad, ¿no crees?"

# game/game/script.rpy:9195
translate es playername_cda16fb1:

    # "Despite him saying those things, his tone seemed more teasing than serious."
    "A pesar de que dice esas cosas, su tono suena más burlón que serio."

# game/game/script.rpy:9198
translate es playername_aaa5ef7e_1:

    # r "Going through my phone huh?"
    r "¿Hurgando en mi teléfono, eh?"

# game/game/script.rpy:9200
translate es playername_ca7df72a_1:

    # r "You are a nosey little thing."
    r "Eres una cosita entrometida."

# game/game/script.rpy:9202
translate es playername_23f51b15_1:

    # r "Kinda an invasion of privacy don't you think?"
    r "Algo así como una invasión de la privacidad, ¿no crees?"

# game/game/script.rpy:9206
translate es playername_74c9c565:

    # "Ray cracks a smile."
    "Ray esboza una sonrisa."

# game/game/script.rpy:9208
translate es playername_42129d53:

    # r "By the way, I don't appreciate you role-playing as me and {i}flirting with my boss{/i}."
    r "Por cierto, no aprecio que te hagas pasar por mí y {i}coquetees con mi jefe{/i}."

# game/game/script.rpy:9210
translate es playername_7f36d53b:

    # r "I am NOT going to hear the end of that."
    r "NO voy a oír el final de eso."

# game/game/script.rpy:9212
translate es playername_c8982897:

    # mc "Sorry...it was funny in the moment."
    mc "Lo siento... fue gracioso en el momento."

# game/game/script.rpy:9214
translate es playername_a9c9479e:

    # mc "You can just say it was my mistake or something."
    mc "Puedes decir que fue un error mío o algo así."

# game/game/script.rpy:9216
translate es playername_c778d488:

    # "Ray's face falls."
    "La expresión de Ray se apaga."

# game/game/script.rpy:9220
translate es playername_735eb92c:

    # r "Absolutely not."
    r "Absolutamente no."

# game/game/script.rpy:9222
translate es playername_1181d5a7:

    # r "It's better for both of us if they don't know you exist."
    r "Es mejor para ambos si no saben que existes."

# game/game/script.rpy:9227
translate es playername_c167cd7a:

    # "Ray levels a look at me."
    "Ray me lanza una mirada seria."

# game/game/script.rpy:9229
translate es playername_affbcfe3:

    # r "It seems like you are... unnerved by me on some level."
    r "Parece que estás... a la defensiva conmigo en cierto nivel."

# game/game/script.rpy:9231
translate es playername_7388af23:

    # r "That you don't trust me..."
    r "Que no confías en mí..."

# game/game/script.rpy:9233
translate es playername_a8d4c776:

    # "He pushes himself off of the wall and walks towards me."
    "Se despega de la pared y camina hacia mí."

# game/game/script.rpy:9253
translate es playername_f8bc7ab6:

    # r "So ask me whatever you want."
    r "Así que pregúntame lo que quieras."

# game/game/script.rpy:9255
translate es playername_fea7d403:

    # r "If you ask, I'll tell you anything."
    r "Si preguntas, te diré cualquier cosa."

# game/game/script.rpy:9257
translate es playername_7ca94c62:

    # r "What do you want to know %(player_name)s?"
    r "¿Qué quieres saber %(player_name)s?"

# game/game/script.rpy:9264
translate es playername_27259d90:

    # mc "Why do you have a photo of me in your wallet?"
    mc "¿Por qué tienes una foto mía en tu billetera?"

# game/game/script.rpy:9266
translate es playername_55482015:

    # mc "A photo from three years ago..."
    mc "Una foto de hace tres años..."

# game/game/script.rpy:9270
translate es playername_12b6081e:

    # r "Do you remember what you were doing in that photo?"
    r "¿Recuerdas qué hacías en esa foto?"

# game/game/script.rpy:9272
translate es playername_3569c6bd:

    # "I try and think back..."
    "Trato de recordar..."

# game/game/script.rpy:9274
translate es playername_12cd609d:

    # "{i}What was I doing during that time three years ago...{/i}"
    "{i}¿Qué estaba haciendo en ese momento, hace tres años...?{/i}"

# game/game/script.rpy:9276
translate es playername_cca89d89:

    # "My eyes widen."
    "Mis ojos se abren."

# game/game/script.rpy:9278
translate es playername_96839a96:

    # "{i}I was...robbing a house!{/i}"
    "{i}¡Estaba... robando una casa!{/i}"

# game/game/script.rpy:9280
translate es playername_958440a3:

    # "I look panicked at Ray."
    "Miro a Ray con pánico."

# game/game/script.rpy:9284
translate es playername_11e20b74:

    # r "I'm not going to turn you in or anything dummy."
    r "No voy a entregarte ni nada, idiota."

# game/game/script.rpy:9286
translate es playername_5c94a666:

    # r "At that time I was on my way to my next assignment when I saw you break into the house of legislator Keck."
    r "En ese momento iba en camino a mi siguiente encargo cuando te vi entrar en la casa del legislador Keck."

# game/game/script.rpy:9288
translate es playername_b97b7245:

    # r "I {i} was {/i} going to quickly take care of you."
    r "Yo {i}iba{/i} a encargarme de ti rápidamente."

# game/game/script.rpy:9292
translate es playername_d5657681:

    # r "But I... couldn't bring myself to do it."
    r "Pero no pude obligarme a hacerlo."

# game/game/script.rpy:9296
translate es playername_403c588c:

    # r "It was an odd feeling. Before that moment, I never really had any issues getting rid of criminals..."
    r "Fue una sensación extraña. Antes de ese momento, nunca había tenido problemas para deshacerme de criminales..."

# game/game/script.rpy:9298
translate es playername_057317b6:

    # r "I truly believed that if someone commits a crime they are opening themselves up to punishment."
    r "Realmente creía que si alguien cometía un crimen se exponía al castigo."

# game/game/script.rpy:9302
translate es playername_28176bce:

    # r "That the world was better off.... without them."
    r "Que el mundo estaría mejor.... sin ellos."

# game/game/script.rpy:9306
translate es playername_8775241d:

    # r "But that day, something changed. I kept watching you run around, playing with the cat, and something in me just....couldn't compute that {i}you{/i} were a criminal."
    r "Pero ese día, algo cambió. Seguí viéndote correr, jugar con el gato, y algo en mí simplemente.... no podía aceptar que {i}tú{/i} fueses un criminal."

# game/game/script.rpy:9308
translate es playername_8cb6f532:

    # "His eyes peer into mine."
    "Sus ojos se clavan en los míos."

# game/game/script.rpy:9310
translate es playername_32314c53:

    # r "You had a bag of everything you came there for in hand, all the jewels, money, blackmail..."
    r "Tenías una bolsa con todo lo que fuiste a buscar, todas las joyas, el dinero, el chantaje..."

# game/game/script.rpy:9312
translate es playername_0ce30ee2:

    # r "So without a doubt you were a {i}criminal{/i}."
    r "Así que sin duda eras un {i}criminal{/i}."

# game/game/script.rpy:9314
translate es playername_cd1a7ca4:

    # r "But I couldn't get myself to... dispose of you."
    r "Pero no pude obligarme a... deshacerme de ti."

# game/game/script.rpy:9316
translate es playername_812dcc22:

    # r "So I became curious. I kept trying to predict where you would hit next, just so I could catch a glimpse at you."
    r "Entonces me volví curioso. Seguí intentando predecir dónde atacarías después, solo para poder echarte un vistazo."

# game/game/script.rpy:9318
translate es playername_054fad20:

    # r "Sometimes I was right, sometimes I was wrong."
    r "A veces acertaba, a veces no."

# game/game/script.rpy:9320
translate es playername_746967de:

    # mc "Stalker...."
    mc "Acosador...."

# game/game/script.rpy:9324
translate es playername_fe25ac44_2:

    # "Ray laughs."
    "Ray se ríe."

# game/game/script.rpy:9326
translate es playername_778c64c8:

    # r "I guess I became a little ....obsessed."
    r "Supongo que me volví un poco... obsesionado."

# game/game/script.rpy:9328
translate es playername_ed1c592c:

    # r "You broke my ideals and I had to figure out {i}why{/i}."
    r "Rompiste mis ideales y tenía que averiguar {i}por qué{/i}."

# game/game/script.rpy:9330
translate es playername_f48c93b4:

    # mc "Why didn't you say anything?"
    mc "¿Por qué no dijiste nada?"

# game/game/script.rpy:9334
translate es playername_e0941c9a:

    # r "I couldn't just talk to you."
    r "No podía simplemente hablar contigo."

# game/game/script.rpy:9338
translate es playername_7c0a2b3b:

    # r "If you, a petty criminal knew that you were on 'Binary Star's' radar, you would have disappeared from the city, possibly even the country the next day."
    r "Si tú, una delincuente menor, supieras que estabas en el radar de 'Binary Star', habrías desaparecido de la ciudad, posiblemente incluso del país al día siguiente."

# game/game/script.rpy:9340
translate es playername_c3bb4f4a:

    # r "But eventually you disappeared anyways..."
    r "Pero al final desapareciste de todos modos..."

# game/game/script.rpy:9344
translate es playername_9abea0cf:

    # r "By that time I didn't realize how much of me depended on you...I couldn't sleep, couldn't eat. You were all I thought about."
    r "Para entonces no me di cuenta de cuánto de mí dependía de ti... No podía dormir, no podía comer. Eras todo en lo que pensaba."

# game/game/script.rpy:9346
translate es playername_d7435e3a:

    # r "You had become {i}My Binary Star {/i}, and without you my balance was off."
    r "Te habías convertido en {i}Mi Estrella Binaria{/i}, y sin ti mi equilibrio se perdió."

# game/game/script.rpy:9348
translate es playername_076438f2:

    # r "I became a zombie during my day, I would just smile and say what they wanted me to. And at night I sought you out."
    r "Me convertí en un zombi durante el día, solo sonreía y decía lo que querían oír. Y por la noche te buscaba."

# game/game/script.rpy:9350
translate es playername_a5abb457:

    # r "I finally found you 3 weeks ago. I transferred to work in this city, I purchased a condo."
    r "Finalmente te encontré hace 3 semanas. Me trasladé para trabajar en esta ciudad, compré un condominio."

# game/game/script.rpy:9352
translate es playername_f54ae8aa:

    # r "I formulated the perfect plan to meet you."
    r "Formulé el plan perfecto para conocerte."

# game/game/script.rpy:9356
translate es playername_e0e23d4b:

    # r "You were never supposed to figure out that {i}I {/i} was Binary Star."
    r "Nunca se suponía que descubrieras que {i}yo{/i} era Binary Star."

# game/game/script.rpy:9358
translate es playername_ce3d73d8:

    # r "I was hoping that you would either fall for me {i}or {/i} Binary Star. Not both."
    r "Esperaba que te enamoraras de mí {i}o{/i} de Binary Star. No de ambos."

# game/game/script.rpy:9362
translate es playername_8b03079d:

    # "Ray sighs and rubs his forehead in frustration."
    "Ray suspira y se frota la frente con frustración."

# game/game/script.rpy:9366
translate es playername_bcc28acf:

    # r "I just didn't expect your old partner to also try and chase you down too."
    r "Simplemente no esperaba que tu antiguo compañero también intentara perseguirte."

# game/game/script.rpy:9368
translate es playername_1163bda2:

    # r "And now I know, he truly won't stop until he is 6 feet under."
    r "Y ahora sé que realmente no se detendrá hasta estar seis pies bajo tierra."

# game/game/script.rpy:9370
translate es playername_0f5f6089:

    # "Ray levels an intense gaze at me."
    "Ray me lanza una mirada intensa."

# game/game/script.rpy:9374
translate es playername_62dd06ec:

    # r "After three years I came to the conclusion that you are what matters."
    r "Después de tres años llegué a la conclusión de que tú eres lo que importa."

# game/game/script.rpy:9378
translate es playername_80eba3a4:

    # r "Not crime, not justice, not criminals, or villains, or civilians, or even earth itself. It's {i}you, %(player_name)s{/i}."
    r "No el crimen, ni la justicia, ni los criminales, ni los villanos, ni los civiles, ni siquiera la propia Tierra. Eres {i}tú, %(player_name)s{/i}."

# game/game/script.rpy:9390
translate es playername_cbda000a:

    # "Ray levels his gaze at me so closely I feel like I could hear his heart beat if I focused hard enough."
    "Ray me mira tan de cerca que siento que podría oír los latidos de su corazón si me concentrara lo suficiente."

# game/game/script.rpy:9392
translate es playername_2c0fcce2:

    # r "%(player_name)s I promise I {i}will {/i} keep you safe."
    r "%(player_name)s, te prometo que {i}te mantendré a salvo{/i}."

# game/game/script.rpy:9394
translate es playername_76f68b20:

    # r "I may not be the perfect 'shining hero from the stars' that everyone claims I am....but I will be {i}your {/i} hero."
    r "Puede que no sea el perfecto 'héroe brillante de las estrellas' que todos dicen que soy... pero seré {i}tu{/i} héroe."

# game/game/script.rpy:9396
translate es playername_ae9dd4f8:

    # "I'm not sure how to respond. Some part of me knows 'thank you' isn't an appropriate response for the situation."
    "No se cómo responder. Parte de mí sabe que 'gracias' no es una respuesta apropiada para la situación."

# game/game/script.rpy:9398
translate es playername_a66a6508:

    # "Ray can sense the conflicting expressions that drift across my face."
    "Ray puede percibir las expresiones contradictorias que cruzan mi rostro."

# game/game/script.rpy:9402
translate es playername_2fd6ce05:

    # r "I know that was probably a lot..."
    r "Sé que probablemente fue demasiado..."

# game/game/script.rpy:9414
translate es playername_2c8016e9:

    # r "I'll let you rest..."
    r "Te dejaré descansar..."

# game/game/script.rpy:9416
translate es playername_4ed968da:

    # "He pauses as if he wants to say something, then decides just to leave with a wave."
    "Hace una pausa, como si quisiera decir algo, pero al final decide irse con un gesto."

# game/game/script.rpy:9418
translate es playername_55fef2c6:

    # "Ray gathers his stuff and exits my apartment."
    "Ray recoge sus cosas y sale de mi apartamento."

# game/game/script.rpy:9429
translate es playername_7c9f7b01:

    # "I recall what Luke...{i}'Blaze' {/i} told me a couple days ago..."
    "Recuerdo lo que Luke... {i}'Blaze'{/i} me dijo hace un par de días..."

# game/game/script.rpy:9431
translate es playername_b9beac58:

    # "{i}'Ask Ray how he got his abilities.'{/i}"
    "{i}'Pregúntale a Ray cómo obtuvo sus habilidades.'{/i}"

# game/game/script.rpy:9435
translate es playername_e1485740:

    # "I look up at Ray and he looks back with a slightly stressed expression on his face."
    "Levanto la vista hacia Ray y él me devuelve la mirada con una expresión ligeramente tensa."

# game/game/script.rpy:9437
translate es playername_a28bb54b:

    # "He knows what I have thought."
    "Sabe lo que estoy pensando."

# game/game/script.rpy:9439
translate es playername_82d85c61:

    # mc "Tell me Ray...."
    mc "Dime, Ray...."

# game/game/script.rpy:9441
translate es playername_db33c685:

    # "His lips tighten and he works a hand through his hair."
    "Sus labios se aprietan y pasa una mano por su cabello."

# game/game/script.rpy:9445
translate es playername_7932d056:

    # "His body is tense and he glances back at me."
    "Su cuerpo está tenso y me lanza una mirada de reojo."

# game/game/script.rpy:9447
translate es playername_cf179b96:

    # mc "Ray... you said anything."
    mc "Ray... dijiste cualquier cosa."

# game/game/script.rpy:9449
translate es playername_0352ac52:

    # r "I know."
    r "Lo sé."

# game/game/script.rpy:9451
translate es playername_f22230ec:

    # mc "{i}Ray.{/i}"
    mc "{i}Ray.{/i}"

# game/game/script.rpy:9455
translate es playername_d5ec11e9:

    # r "{size=-10}....fuck.{/size}"
    r "{size=-10}....mierda.{/size}"

# game/game/script.rpy:9457
translate es playername_3ebcfd5c:

    # "He curses under his breath."
    "Maldice por lo bajo."

# game/game/script.rpy:9459
translate es playername_0cd535bd:

    # "I narrow my eyes."
    "Entrecierro los ojos."

# game/game/script.rpy:9461
translate es playername_ca42bae4:

    # mc "{i}What's your ability Ray?{/i}"
    mc "{i}¿Cuál es tu habilidad, Ray?{/i}"

# game/game/script.rpy:9465
translate es playername_1747010b:

    # "He looks at me directly. His eyes so deeply black they might just swallow me whole."
    "Me mira directamente. Sus ojos son tan profundamente negros que podrían tragarme por completo."

# game/game/script.rpy:9479
translate es playername_b9c4834a:

    # "Even the room feels a bit dimmer due to his pressure."
    "Incluso la habitación se siente un poco más oscura debido a su presencia."

# game/game/script.rpy:9494
translate es playername_0ba33901:

    # r "They call me {i}Binary Star{/i}, why?"
    r "Me llaman {i}Binary Star{/i}, ¿por qué?"

# game/game/script.rpy:9496
translate es playername_bfd21eb4:

    # mc "Because you 'Shine so brightly against the evil of night'?"
    mc "¿Porque 'brillas tan intensamente contra el mal de la noche'?"

# game/game/script.rpy:9501
translate es playername_833a7516:

    # "Ray lets out a sound somewhere between a scoff and a laugh."
    "Ray deja escapar un sonido entre una risa y un resoplido."

# game/game/script.rpy:9503
translate es playername_23f5f86a:

    # r "If only that was the case Star."
    r "Ojalá fuera eso, Estrella."

# game/game/script.rpy:9507
translate es playername_7ed5f047:

    # r "What are {i}Binary Stars{/i}?"
    r "¿Qué son las {i}Estrellas Binarias{/i}?"

# game/game/script.rpy:9509
translate es playername_68fb0a7b:

    # mc "Is this a silence lesson or something?"
    mc "¿Esto es una lección de astronomía o algo así?"

# game/game/script.rpy:9513
translate es playername_c5fb94b5:

    # "Ray stares down at me with an immovable expression, he is clearly not in the mood for jokes."
    "Ray me observa con una expresión inamovible, claramente no está de humor para bromas."

# game/game/script.rpy:9517
translate es playername_6d733834:

    # mc "A solar system where there are two stars...?"
    mc "Un sistema solar donde hay dos estrellas...?"

# game/game/script.rpy:9521
translate es playername_461382bd:

    # r "In a Binary system there is a {i} 'primary star' {/i} and a {i}'secondary star'{/i}."
    r "En un sistema binario hay una {i}'estrella primaria'{/i} y una {i}'estrella secundaria'{/i}."

# game/game/script.rpy:9523
translate es playername_3fa5e647:

    # r "Depending on their orbit they can be classified as {i}'Wide Binaries'{/i} and {i}'Close Binaries'{/i}."
    r "Dependiendo de su órbita pueden clasificarse como {i}'Binarias Amplias'{/i} o {i}'Binarias Cercanas'{/i}."

# game/game/script.rpy:9525
translate es playername_c9d244e2:

    # "I am unsure where this is going, but the tone of Ray's voice keeps me from speaking."
    "No estoy segura de hacia dónde va con esto, pero el tono de voz de Ray me impide interrumpirlo."

# game/game/script.rpy:9527
translate es playername_6bb67024:

    # r "In a close Binary, mass can be transferred between the two."
    r "En una Binaria Cercana, la masa puede transferirse entre ambas."

# game/game/script.rpy:9529
translate es playername_295e8c1d:

    # r "The primary star can exert gravitational force strong enough to pull in the smaller star cannibalizing it completely."
    r "La estrella primaria puede ejercer una fuerza gravitacional lo bastante fuerte como para atraer a la más pequeña, devorándola por completo."

# game/game/script.rpy:9531
translate es playername_ff9f38f2:

    # "A silence settles between the two of us. An understanding that leaves me queasy."
    "Se hace un silencio entre nosotros. Un entendimiento que me revuelve el estómago."

# game/game/script.rpy:9533
translate es playername_83a8214b:

    # r "I am said to be the hero with countless abilities, but in reality..."
    r "Se dice que soy el héroe con innumerables habilidades, pero en realidad..."

# game/game/script.rpy:9553
translate es playername_5832fd2f:

    # r "My ability is just one."
    r "Mi habilidad es solo una."

# game/game/script.rpy:9555
translate es playername_dbd5f4d6:

    # r "To pull in smaller stars..."
    r "Atraer a las estrellas más pequeñas..."

# game/game/script.rpy:9559
translate es playername_8c39a1c4:

    # r "{b}And devour them whole.{/b}"
    r "{b}Y devorarlas por completo.{/b}"

# game/game/script.rpy:9561
translate es playername_b26ee631:

    # r "Every ability I have, I killed for."
    r "Cada habilidad que tengo, la obtuve matando."

# game/game/script.rpy:9563
translate es playername_1db969b4:

    # r "Criminals, villains, civilians... even other heroes."
    r "Criminales, villanos, civiles... incluso otros héroes."

# game/game/script.rpy:9565
translate es playername_87729d6e:

    # r "Some were forced upon me..."
    r "Algunas me fueron impuestas..."

# game/game/script.rpy:9567
translate es playername_09658e0b:

    # r "Others were of my own volition."
    r "Otras fueron por mi propia voluntad."

# game/game/script.rpy:9569
translate es playername_504b06ae:

    # "My stomach sinks."
    "Mi estómago se hunde."

# game/game/script.rpy:9571
translate es playername_3805a95b:

    # "It's not out of the question that he would be able to ...slaughter people so easily. After all, I witnessed it myself."
    "No es descabellado pensar que sería capaz de... masacrar personas tan fácilmente. Después de todo, lo presencié yo en persona."

# game/game/script.rpy:9573
translate es playername_34a901e1:

    # "But some part of me felt...disturbed."
    "Pero una parte de mí se siente... perturbada."

# game/game/script.rpy:9577
translate es playername_8281512a:

    # r "I won't deny what I am %(player_name)s. Luke was right, {i}I am a monster.{/i}"
    r "No voy a negar lo que soy, %(player_name)s. Luke tenía razón, {i}soy un monstruo.{/i}"

# game/game/script.rpy:9579
translate es playername_e74db81c:

    # r "I'm not a 'Hero from the Stars', I am essentially only one thing."
    r "No soy un 'Héroe de las Estrellas', soy esencialmente una sola cosa."

# game/game/script.rpy:9583
translate es playername_ec4a8d05:

    # r "A government-funded military weapon."
    r "Un arma militar financiada por el gobierno."

# game/game/script.rpy:9585
translate es playername_74fc30e3:

    # r "Nothing can change that."
    r "Nada puede cambiar eso."

# game/game/script.rpy:9587
translate es playername_78eb09d8:

    # "Despite Ray's stony facade I can sense some sadness in his tone."
    "A pesar de la fachada impasible de Ray, puedo percibir cierta tristeza en su tono."

# game/game/script.rpy:9589
translate es playername_397a3aad:

    # r "I may be a monster, but I promise I {i}will {/i} keep you safe if you let me."
    r "Puede que sea un monstruo, pero te prometo que {i}te mantendré a salvo{/i} si me lo permites."

# game/game/script.rpy:9591
translate es playername_ae9dd4f8_1:

    # "I'm not sure how to respond. Some part of me knows 'thank you' isn't an appropriate response for the situation."
    "No se cómo responder. Parte de mí sabe que 'gracias' no es una respuesta apropiada para la situación."

# game/game/script.rpy:9595
translate es playername_a66a6508_1:

    # "Ray can sense the conflicting expressions that drift across my face."
    "Ray puede percibir las expresiones contradictorias que cruzan mi rostro."

# game/game/script.rpy:9597
translate es playername_9e49ff57:

    # r "I know that was a lot..."
    r "Sé que fue mucho..."

# game/game/script.rpy:9601
translate es playername_a34ccd01:

    # r "I'll let you rest...."
    r "Te dejaré descansar...."

# game/game/script.rpy:9605
translate es playername_ddadd474:

    # "Ray gathers his stuff and leaves my apartment."
    "Ray recoge sus cosas y se va de mi apartamento."

# game/game/script.rpy:9613
translate es playername_207960e5:

    # "When the door closes I let go of a breath I didn't realize I was holding."
    "Cuando la puerta se cierra, suelto un suspiro que no sabía que estaba conteniendo."

# game/game/script.rpy:9620
translate es playername_c4b795e8:

    # "I am left in silence with only my thoughts."
    "Me quedo en silencio, con solo mis pensamientos."

# game/game/script.rpy:9622
translate es playername_3104976a:

    # "{i}It's obvious that Ray...or rather Binary Star is dangerous to some extent.{/i}"
    "{i}Es obvio que Ray... o más bien Binary Star, es peligroso hasta cierto punto.{/i}"

# game/game/script.rpy:9624
translate es playername_023c64a5:

    # "{i}But when he talks about himself without the mask on, something about him just feels so....{/i}"
    "{i}Pero cuando habla de sí mismo sin la máscara, hay algo en él que se siente tan....{/i}"

# game/game/script.rpy:9626
translate es playername_2e475d8d:

    # "{i}Lonely..."
    "{i}Solo..."

# game/game/script.rpy:9628
translate es playername_4a8e4781:

    # " {i}...Distant.{/i}"
    "{i}...Distante.{/i}"

# game/game/script.rpy:9630
translate es playername_49864783:

    # "I sit down, thinking over the previous interaction on repeat."
    "Me siento, repasando mentalmente la interacción anterior una y otra vez."

# game/game/script.rpy:9632
translate es playername_d7d9ebca:

    # "I spend most of the day trying to research information about Binary Star, but I can't really find anything of value."
    "Paso la mayor parte del día intentando investigar información sobre Binary Star, pero realmente no encuentro nada de valor."

# game/game/script.rpy:9636
translate es playername_da2992cd:

    # "The sun is already beginning to set and the restlessness sets in."
    "El sol ya comienza a ponerse y la inquietud se instala."

# game/game/script.rpy:9638
translate es playername_75a59c72:

    # "After a while, I can't help but to do something about my complicated feelings at hand."
    "Después de un rato, no puedo evitar hacer algo respecto a los sentimientos complicados que tengo."

# game/game/script.rpy:9647
translate es playername_c0eb9357:

    # "I decide to give Haley a call."
    "Decido llamar a Haley."

# game/game/script.rpy:9649
translate es playername_5b1eca57:

    # "They warned me before that Binary Star most likely had some skeletons in the closet."
    "Ya me había advertido antes que Binary Star probablemente tenía algunos esqueletos en el armario."

# game/game/script.rpy:9651
translate es playername_9afbe9c5:

    # "Maybe they know more."
    "Tal vez sepa más."

# game/game/script.rpy:9653
translate es playername_56135754:

    # "Or maybe they don't. But either way...Hal's comforting voice is something that I need to hear right now."
    "O tal vez no. Pero de cualquier manera... la voz reconfortante de Hal es algo que necesito oír ahora mismo."

# game/game/script.rpy:9657
translate es playername_4954d6d3:

    # "The dial tone rings softly."
    "El tono de marcación suena suavemente."

# game/game/script.rpy:9659
translate es playername_e5d7eb9c:

    # hp "Hello? %(player_name)s?"
    hp "¿Hola? ¿%(player_name)s?"

# game/game/script.rpy:9661
translate es playername_d9370d36:

    # mc "Hi Hal."
    mc "Hola Hal."

# game/game/script.rpy:9663
translate es playername_9cf01360:

    # hp "%(player_name)s! Are you okay?! I tried texting you but you never responded."
    hp "¡%(player_name)s! ¿Estás bien?! Intenté enviarte mensajes pero nunca respondiste."

# game/game/script.rpy:9665
translate es playername_ce25bda4:

    # hp "I was getting worried, you kinda...dropped off the face of the planet there for a minute."
    hp "Me estaba preocupando, un poco... desapareciste del mapa por un minuto."

# game/game/script.rpy:9667
translate es playername_12b0c581:

    # mc "I'm ...okay."
    mc "Estoy ...bien."

# game/game/script.rpy:9669
translate es playername_b7f38716:

    # hp "You sure? You...don't sound okay?"
    hp "¿Seguro? Tú... ¿no suenas bien?"

# game/game/script.rpy:9671
translate es playername_4cdc8767:

    # "I bite my lip. Everything in me wants to run crying to Hal...but I can't be selfish."
    "Me muerdo el labio. Todo en mí quiere correr llorando hacia Hal... pero no puedo ser egoísta."

# game/game/script.rpy:9673
translate es playername_18fdf61f:

    # "Hal essentially just lost their whole business with the chaos in the West District."
    "Hal esencialmente acaba de perder todo su negocio con el caos en el West District."

# game/game/script.rpy:9675
translate es playername_95c0fe14:

    # "The last thing I want to do is heft more stress onto them."
    "Lo último que quiero es cargarle más estrés."

# game/game/script.rpy:9677
translate es playername_68626875:

    # mc "Yeah, I guess I just missed you is all."
    mc "Sí, supongo que solo te extrañé, eso es todo."

# game/game/script.rpy:9679
translate es playername_6aff3832:

    # "I can hear Hal suck in air suddenly."
    "Puedo oír a Hal inhalar aire de repente."

# game/game/script.rpy:9681
translate es playername_d515c9cd:

    # hp "..."
    hp "..."

# game/game/script.rpy:9683
translate es playername_bf7383b5:

    # mc "Uh Hal...?"
    mc "¿Uh Hal...?"

# game/game/script.rpy:9685
translate es playername_4f449522:

    # hp "Ah! Yeah, sorry ahaha! Yeah, um, me too!"
    hp "¡Ah! ¡Sí, lo siento ajaja! ¡Sí, um, yo también!"

# game/game/script.rpy:9687
translate es playername_3c1841ed:

    # mc "Uh are {i}you {/i} okay?"
    mc "¿Uh estás {i}tú {/i} bien?"

# game/game/script.rpy:9689
translate es playername_732a85b3:

    # "I hear a familiar voice in the background."
    "Oigo una voz familiar en el fondo."

# game/game/script.rpy:9691
translate es playername_183495e8:

    # m "{size=-10}Yooo! Is that %(player_name)s??{/size}"
    m "{size=-10}¡Yooo! ¿Es ese %(player_name)s??{/size}"

# game/game/script.rpy:9693
translate es playername_80c1e013:

    # m "{size=-10}Let me say hi! Wait, your face is SO red hahaha that's so funny! Stone cold Hal down bad- OOF! {/size}"
    m "{size=-10}¡Déjame saludar! ¡Espera, tu cara está TAN roja jajaja eso es tan gracioso! Hal, fríe como el hielo, mal... ¡UF! {/size}"

# game/game/script.rpy:9697
translate es playername_5e54058b:

    # "A large smack sound reverberates over the speaker. Miles groans in the background."
    "Un gran sonido de palmada reverbera por el altavoz. Miles gime en el fondo."

# game/game/script.rpy:9699
translate es playername_ba0e5c2a:

    # hp "So, did you call for anything specific?"
    hp "Entonces, ¿llamaste por algo específico?"

# game/game/script.rpy:9701
translate es playername_5dc02253:

    # mc "Not really..."
    mc "No realmente..."

# game/game/script.rpy:9703
translate es playername_b5d027fb:

    # mc "Remember how you mentioned that you think all heroes have skeletons in their closets?"
    mc "¿Recuerdas cómo mencionaste que piensas que todos los héroes tienen esqueletos en sus armarios?"

# game/game/script.rpy:9705
translate es playername_5a7cd94a:

    # hp "Mhmm. The more powerful the hero, the more packed that closet's going to be."
    hp "Mhmm. Cuanto más poderoso el héroe, más lleno estará ese armario."

# game/game/script.rpy:9707
translate es playername_ec900fe6:

    # mc "Why do you think that?"
    mc "¿Por qué piensas eso?"

# game/game/script.rpy:9709
translate es playername_04ad40bd:

    # hp "Hmm, if you have unlimited power, who will stop you? The government will do anything to protect their assets after-all."
    hp "Hmm, si tienes poder ilimitado, ¿quién te detendrá? Al fin y al cabo, el gobierno hará cualquier cosa para proteger sus activos."

# game/game/script.rpy:9711
translate es playername_462a9bfa:

    # mc "What do you think about...Binary Star?"
    mc "¿Qué piensas sobre...Binary Star?"

# game/game/script.rpy:9713
translate es playername_5d6f5c4a:

    # "Once again there is silence on the other end of the call."
    "Una vez más hay silencio al otro lado de la llamada."

# game/game/script.rpy:9715
translate es playername_070fcd47:

    # hp "Please %(player_name)s, listen to me closely. Run away from Binary Star."
    hp "Por favor %(player_name)s, escúchame atentamente. Aléjate de Binary Star."

# game/game/script.rpy:9717
translate es playername_2649b8a5:

    # hp "I did some asking, some digging, and....nothing good can come from being around him."
    hp "Hice algunas preguntas, algo de investigación, y.... nada bueno puede venir de estar cerca de él."

# game/game/script.rpy:9719
translate es playername_7c4fa66b:

    # hp "He will only cause you misery and chaos. You will never know peace again if you accept him."
    hp "Él solo te causará miseria y caos. Nunca conocerás la paz de nuevo si lo aceptas."

# game/game/script.rpy:9721
translate es playername_8ebd66aa:

    # hp "The best thing you can do is run as far and fast as you can."
    hp "Lo mejor que puedes hacer es huir lo más lejos y rápido que puedas."

# game/game/script.rpy:9723
translate es playername_8a4b89a2:

    # "There is another pause on the other line."
    "Hay otra pausa en la línea."

# game/game/script.rpy:9725
translate es playername_86d23151:

    # hp "I have to go. Just, please tell me you will leave tonight and run very very far away."
    hp "Tengo que irme. Solo, por favor dime que te irás esta noche y huirás muy muy lejos."

# game/game/script.rpy:9727
translate es playername_8956ae47:

    # "I was unable to answer, unsure what to do. Haley's tone left no question of severity of their request."
    "No pude responder, sin saber qué hacer. El tono de Haley no dejaba duda de la severidad de su petición."

# game/game/script.rpy:9729
translate es playername_0e03516c:

    # hp "I'll find you again when you are in a safe place-"
    hp "Te encontraré de nuevo cuando estés en un lugar seguro-"

# game/game/script.rpy:9733
translate es playername_3f909636:

    # "The phone call cuts off suddenly, Haley probably hung up."
    "La llamada se corta de repente, Haley probablemente colgó."

# game/game/script.rpy:9741
translate es playername_9f937d89:

    # "His face appears in my mind."
    "Su cara aparece en mi mente."

# game/game/script.rpy:9743
translate es playername_ab2819ff:

    # "I hate him with burning passion, but I can't ignore that he is my best bet for information at the moment."
    "Lo odio con pasión ardiente, pero no puedo ignorar que es mi mejor opción para información en este momento."

# game/game/script.rpy:9745
translate es playername_fa4742e7:

    # "I unblock his number and then press the dial button."
    "Desbloqueo su número y luego presiono el botón de marcación."

# game/game/script.rpy:9747
translate es playername_62fada8a:

    # "The phone rings and rings, but ultimately Double does not answer."
    "El teléfono suena y suena, pero al final Double no contesta."

# game/game/script.rpy:9751
translate es playername_b284b385:

    # "I sigh and stretch out, suddenly my phone is vibrating."
    "Suspiro y me estiro, de repente mi teléfono está vibrando."

# game/game/script.rpy:9755
translate es playername_06a0b2c2:

    # "I pick up the call."
    "Contesto la llamada."

# game/game/script.rpy:9759
translate es playername_8d7228b1:

    # dvp "And what do I owe this pleasure %(player_name)s?"
    dvp "¿Y a qué debo este placer %(player_name)s?"

# game/game/script.rpy:9761
translate es playername_3872e9be:

    # "His voice is as smug as usual. I can practically see the mocking grin across his face."
    "Su voz es tan presumida como siempre. Prácticamente puedo ver la sonrisa burlona en su cara."

# game/game/script.rpy:9763
translate es playername_a2d252c3:

    # mc "Double."
    mc "Double."

# game/game/script.rpy:9765
translate es playername_8cd68ac1:

    # dvp "Don't act so cold, {i}you're{/i} the one that called {i}me{/i}."
    dvp "No actúes con tanta frialdad, {i}tú{/i} eres el que me llamó {i}a mí{/i}."

# game/game/script.rpy:9767
translate es playername_0dbd8dad:

    # mc "Well you're the one that tried to {i}cut my fucking fingers off{/i}."
    mc "Bueno, tú eres el que intentó {i}cortarme los malditos dedos{/i}."

# game/game/script.rpy:9769
translate es playername_edfef16a:

    # dvp "I still might if you keep pushing~"
    dvp "Todavía podría si sigues insistiendo~"

# game/game/script.rpy:9771
translate es playername_5ebf7dbf:

    # "I ignore him, determined to sticking to my goal at hand."
    "Lo ignoro, decidido a ceñirme a mi objetivo en mano."

# game/game/script.rpy:9773
translate es playername_06f870ef:

    # mc "I have a question."
    mc "Tengo una pregunta."

# game/game/script.rpy:9775
translate es playername_f6bbafb5:

    # dvp "Hmmmm? That riiiight?"
    dvp "¿Hmmmm? ¿Biiiiieeen?"

# game/game/script.rpy:9777
translate es playername_968db017:

    # mc "Yeah, I remember back when we...worked together, you had some run-ins with Binary Star right?"
    mc "Sí, recuerdo cuando... trabajábamos juntos, tuviste algunos encuentros con Binary Star ¿verdad?"

# game/game/script.rpy:9779
translate es playername_4460e5da:

    # dvp "..."
    dvp "..."

# game/game/script.rpy:9781
translate es playername_20829817:

    # mc "Double?"
    mc "¿Double?"

# game/game/script.rpy:9783
translate es playername_b574f9f0:

    # dvp "I'll answer your question if you answer mine first."
    dvp "Responderé tu pregunta si respondes la mía primero."

# game/game/script.rpy:9785
translate es playername_a7468ab5:

    # mc "...Okay?"
    mc "...¿Okey?"

# game/game/script.rpy:9787
translate es playername_c42c957c:

    # dvp "What color underwear are you wearing right now [criminalname]?"
    dvp "¿Qué color de ropa interior llevas puesto ahora [criminalname]?"

# game/game/script.rpy:9789
translate es playername_2b35b6fe_6:

    # mc "..."
    mc "..."

# game/game/script.rpy:9791
translate es playername_ca18ab7b_1:

    # "Double laughs."
    "Double ríe."

# game/game/script.rpy:9793
translate es playername_43f47feb:

    # "{i}What a piece of shit{/i}"
    "{i}Qué pedazo de mierda{/i}"

# game/game/script.rpy:9795
translate es playername_c81bf68d:

    # "{i}I should have known he was just going to mess with me.{/i}"
    "{i}Debería haber sabido que solo iba a jugar conmigo.{/i}"

# game/game/script.rpy:9797
translate es playername_ef5eb8e8:

    # mc "I am NOT answering that."
    mc "NO voy a responder eso."

# game/game/script.rpy:9799
translate es playername_dca6d48f:

    # dvp "So let me get this right..."
    dvp "Entonces déjame entender esto bien..."

# game/game/script.rpy:9801
translate es playername_ebcfb091:

    # "His voice becomes dangerously low."
    "Su voz se vuelve peligrosamente baja."

# game/game/script.rpy:9803
translate es playername_a2862fad:

    # dvp "You call me to get some info on another guy, and you assume I'm just going to play nice?"
    dvp "¿Me llamas para obtener info sobre otro tipo, y asumes que solo voy a portarme bien?"

# game/game/script.rpy:9805
translate es playername_71956153:

    # "Double lets out a harsh laugh."
    "Double suelta una risa dura."

# game/game/script.rpy:9807
translate es playername_40fbc15a:

    # dvp "You are truly more of an idiot than I could have imagined."
    dvp "Realmente eres más idiota de lo que podría haber imaginado."

# game/game/script.rpy:9809
translate es playername_1b38491d:

    # "I resist the urge to throw my phone across the room."
    "Resisto el impulso de tirar mi teléfono al otro lado de la habitación."

# game/game/script.rpy:9811
translate es playername_38a708bb:

    # "The line is silent."
    "La línea está en silencio."

# game/game/script.rpy:9813
translate es playername_22c942d1:

    # dvp "Guess I should hang up then."
    dvp "Supongo que debería colgar entonces."

# game/game/script.rpy:9817
translate es playername_9ec681d6:

    # mc ".....black"
    mc ".....negro"

# game/game/script.rpy:9819
translate es playername_7b645fff:

    # dvp "Oh very sexy~ A classic."
    dvp "Oh muy sexy~ Un clásico."

# game/game/script.rpy:9821
translate es playername_6b476c1d:

    # dvp "I miss seeing you in only a black little thing."
    dvp "Extraño verte solo en una cosita negra."

# game/game/script.rpy:9823
translate es playername_e73b1dd5:

    # dvp "Just thinking about it has me a little excited~"
    dvp "Solo pensarlo me tiene un poco excitado~"

# game/game/script.rpy:9825
translate es playername_73cf1c79:

    # dvp "But it's too bad..."
    dvp "Pero es una lástima..."

# game/game/script.rpy:9829
translate es playername_156e7c09:

    # mc "White."
    mc "Blanco."

# game/game/script.rpy:9831
translate es playername_67d64e56:

    # dvp "White...?"
    dvp "¿Blanco...?"

# game/game/script.rpy:9833
translate es playername_4e0bc1bb:

    # "I could hear the disappointment in his tone."
    "Pude oír la decepción en su tono."

# game/game/script.rpy:9835
translate es playername_3a74d7e8:

    # dvp "Pretty basic, wouldn't you say?"
    dvp "Bastante básico, ¿no dirías?"

# game/game/script.rpy:9837
translate es playername_924cd7b4:

    # dvp "Is it at least lacey or see-through?"
    dvp "¿Al menos es de encaje o transparente?"

# game/game/script.rpy:9839
translate es playername_2b35b6fe_7:

    # mc "..."
    mc "..."

# game/game/script.rpy:9841
translate es playername_67629181:

    # dvp "I guess something innocent suits someone like you."
    dvp "Supongo que algo inocente le queda a alguien como tú."

# game/game/script.rpy:9843
translate es playername_bbeeb44e:

    # mc "What's that supposed to mean?"
    mc "¿Qué se supone que significa eso?"

# game/game/script.rpy:9845
translate es playername_2977f4f1:

    # "I can hear the smile in his voice."
    "Puedo oír la sonrisa en su voz."

# game/game/script.rpy:9847
translate es playername_9c709fd6:

    # dvp "I can come over and show you if you want~"
    dvp "Puedo pasar y mostrártelo si quieres~"

# game/game/script.rpy:9849
translate es playername_4d13e5ea:

    # mc "Oh fuck off."
    mc "Oh vete a la mierda."

# game/game/script.rpy:9851
translate es playername_e3b00981:

    # dvp "Ah, there it is."
    dvp "Ah, ahí está."

# game/game/script.rpy:9853
translate es playername_dd73c6b3:

    # dvp "I just don't trust you though."
    dvp "Solo que no confío en ti, sin embargo."

# game/game/script.rpy:9859
translate es playername_996baebc:

    # "Double honestly scares the shit out of me."
    "Double honestamente me asusta muchísimo."

# game/game/script.rpy:9861
translate es playername_c1fda504:

    # "But I'll be damned if I sit here and let him intimidate me."
    "Pero que me condenen si me siento aquí y dejo que me intimide."

# game/game/script.rpy:9863
translate es playername_450cbcb5:

    # "I decide to throw him off of his balance."
    "Decido desequilibrarlo."

# game/game/script.rpy:9865
translate es playername_c97c94ea:

    # mc "And what makes you think I'm even wearing any?"
    mc "¿Y qué te hace pensar que siquiera llevo algo?"

# game/game/script.rpy:9867
translate es playername_4460e5da_1:

    # dvp "..."
    dvp "..."

# game/game/script.rpy:9869
translate es playername_a4967162:

    # "Double is at a loss for words."
    "Double está sin palabras."

# game/game/script.rpy:9871
translate es playername_80eb5176:

    # mc "Speechless Double? I remember the last time I left you speechless."
    mc "¿Sin palabras Double? Recuerdo la última vez que te dejé sin palabras."

# game/game/script.rpy:9873
translate es playername_b894c21c:

    # dvp "Fuck [criminalname]..."
    dvp "Joder [criminalname]..."

# game/game/script.rpy:9875
translate es playername_f15b1cdc:

    # "He mumbles under his breath."
    "Murmura bajo su aliento."

# game/game/script.rpy:9877
translate es playername_ce78bab6:

    # "Some part of me liked that I still had some hold over him."
    "Una parte de mí disfrutaba saber que aún tenía cierto control sobre él."

# game/game/script.rpy:9879
translate es playername_f56f4214:

    # "Unfortunately for me, he is always quick to recover."
    "Desafortunadamente para mí, él siempre se recupera rápido."

# game/game/script.rpy:9881
translate es playername_72fdbb8b:

    # dvp "I don't believe you."
    dvp "No te creo."

# game/game/script.rpy:9883
translate es playername_a82235a8:

    # mc "What..?"
    mc "¿Perdón..?"

# game/game/script.rpy:9885
translate es playername_82c19d4a:

    # dvp "I said, I don't believe you."
    dvp "Dije, no te creo."

# game/game/script.rpy:9887
translate es playername_110d8258:

    # "I can hear the smirk in his tone."
    "Puedo oír la sonrisa en su tono."

# game/game/script.rpy:9889
translate es playername_8b0ec188:

    # dvp "Send me a picture."
    dvp "Mándame una foto."

# game/game/script.rpy:9891
translate es playername_c6993fa4:

    # mc "Are you serious?!"
    mc "¡¿Hablas en serio?!"

# game/game/script.rpy:9893
translate es playername_29364483:

    # mc "I am NOT doing that."
    mc "NO voy a hacer eso."

# game/game/script.rpy:9895
translate es playername_76e1c377:

    # dvp "Aww, all bark and no bite per usual huh~"
    dvp "Aww, solo ladridos y nada de mordidas, como siempre, ¿eh~?"

# game/game/script.rpy:9897
translate es playername_e5d5ad17:

    # dvp "I guess you don't need me to answer your question then-"
    dvp "Supongo que no necesitas que responda tu pregunta entonces–"

# game/game/script.rpy:9899
translate es playername_240b5370:

    # "I immediately get up, stripping off my top and pants."
    "Me levanto de inmediato, quitándome la parte superior y los pantalones."

# game/game/script.rpy:9901
translate es playername_09305842:

    # mc "I'll show you some bite bastard."
    mc "Te mostraré algo de mordida, bastardo."

# game/game/script.rpy:9903
translate es playername_d4e62502:

    # "After posing for a flawless ass shot paired with a tasteful middle finger, I send over the photo."
    "Después de posar para una foto impecable de mi trasero acompañada de un elegante dedo medio, envío la foto."

# game/game/script.rpy:9905
translate es playername_97b30a1e:

    # dvp "Very nice... almost exactly like I remember..."
    dvp "Muy bien... casi exactamente como la recuerdo..."

# game/game/script.rpy:9907
translate es playername_14df8865:

    # dvp "{i}Pretty whore{/i}. "
    dvp "{i}Como una puta{/i}."

# game/game/script.rpy:9909
translate es playername_4460e5da_2:

    # dvp "..."
    dvp "..."

# game/game/script.rpy:9911
translate es playername_a2d252c3_1:

    # mc "Double."
    mc "Double."

# game/game/script.rpy:9913
translate es playername_a93ee756:

    # dvp "Hmm, so what did you want to know again...?"
    dvp "Hmm, ¿entonces qué era lo que querías saber de nuevo...?"

# game/game/script.rpy:9915
translate es playername_b601affe:

    # dvp "Ah right, {i}Binary Star{/i}."
    dvp "Ah, claro, {i}Binary Star{/i}."

# game/game/script.rpy:9917
translate es playername_6f13ffc3:

    # "Double gives a short spiteful laugh."
    "Doble suelta una corta y rencorosa risa."

# game/game/script.rpy:9919
translate es playername_ddbcdb4a:

    # dvp "You were so lucky you were my partner, you have {i}no idea{/i} what I sheltered you from. You still don't."
    dvp "Tuviste tanta suerte de ser mi compañera, no tienes {i}ni idea{/i} de todo lo que te protegí. Aún no la tienes."

# game/game/script.rpy:9921
translate es playername_2868063f:

    # dvp "The others would come back completely traumatized from seeing their friends being ripped apart by the {i}'heroes'{/i} while you knew none the better."
    dvp "Los demás volvían completamente traumatizados tras ver a sus amigos siendo despedazados por los {i}'héroes'{/i}, mientras tú no tenías ni idea."

# game/game/script.rpy:9923
translate es playername_1b22223f:

    # dvp "None of the heroes ever gave a shit about any of us, and that guy...he was the worst of all."
    dvp "Ninguno de los héroes se preocupó jamás por nosotros, y ese tipo... él era el peor de todos."

# game/game/script.rpy:9925
translate es playername_e799de50:

    # dvp "There was nothing human about those red eyes, no empathy, no guilt, just destruction without mercy."
    dvp "No había nada humano en esos ojos rojos, sin empatía, sin culpa, solo destrucción sin misericordia."

# game/game/script.rpy:9927
translate es playername_624c45ec:

    # dvp "In our world they say if you see a red flash you're already dead."
    dvp "En nuestro mundo se dice que si ves un destello rojo, ya estás muerto."

# game/game/script.rpy:9929
translate es playername_81f95cd0:

    # dvp "The iconic red eyes of National Hero Binary Star being plastered on every TV show, every magazine has to be some kind of irony."
    dvp "Que los icónicos ojos rojos del Héroe Nacional Binary Star estén en cada programa de televisión y cada revista debe ser algún tipo de ironía."

# game/game/script.rpy:9931
translate es playername_fc8d869d:

    # dvp "Is that what you wanted to hear about your new boyfriend? '{i}The child from the stars{/i}' ?"
    dvp "¿Eso era lo que querías saber sobre tu nuevo novio? '{i}El niño de las estrellas{/i}' ?"

# game/game/script.rpy:9933
translate es playername_7743cc6e:

    # mc "Is he really that bad...?"
    mc "¿De verdad es tan malo...?"

# game/game/script.rpy:9936
translate es playername_c5af5723:

    # "Double is quiet."
    "Doble guarda silencio."

# game/game/script.rpy:9938
translate es playername_bf1ffc8f:

    # dvp "I liked you %(player_name)s, you were always a feisty little shit."
    dvp "Me caías bien %(player_name)s, siempre fuiste un diablillo con carácter."

# game/game/script.rpy:9940
translate es playername_e21e2777:

    # dvp "The others told me I was too soft on you... {i}too sweet on you.{/i}"
    dvp "Los demás me decían que era demasiado blando contigo... {i}demasiado dulce contigo.{/i}"

# game/game/script.rpy:9942
translate es playername_0d721307:

    # dvp "{size=-10}....fuck {/size}"
    dvp "{size=-10}....mierda {/size}"

# game/game/script.rpy:9944
translate es playername_090a6818:

    # "Something foreign tints Double's tone. An uncharacteristic hint of emotion breaking through."
    "Algo extraño tiñe el tono de Double. Un indicio de emoción poco característico se cuela."

# game/game/script.rpy:9946
translate es playername_a1bb8dca:

    # dvp "%(player_name)s, you should think hard and make a decision."
    dvp "%(player_name)s, deberías pensarlo bien y tomar una decisión."

# game/game/script.rpy:9948
translate es playername_2a3fde86:

    # dvp "Do you want to live at the whims of a cruel unforgiving creature?-"
    dvp "¿Quieres vivir a merced de una criatura cruel e implacable?-"

# game/game/script.rpy:9950
translate es playername_49e2d416:

    # dvp "Or would you rather die?"
    dvp "¿O preferirías morir?"

# game/game/script.rpy:9952
translate es playername_22c922c4:

    # dvp "Your window to make a decision is closing, soon it will be made for you."
    dvp "Tu ventana para decidir se está cerrando, pronto se decidirá por ti."

# game/game/script.rpy:9954
translate es playername_2b35b6fe_8:

    # mc "..."
    mc "..."

# game/game/script.rpy:9956
translate es playername_9eb0d077:

    # dvp "Even if you cry and beg, I can't come save you this time [criminalname]."
    dvp "Aunque llores y supliques, no puedo venir a salvarte esta vez [criminalname]."

# game/game/script.rpy:9958
translate es playername_0a20cd87:

    # dvp "Binary Star is so far removed from humanity he might as well be from the stars."
    dvp "Binary Star está tan alejado de la humanidad que bien podría venir de las estrellas."

# game/game/script.rpy:9960
translate es playername_e7f794b1:

    # dvp "He is a creature without weaknesses."
    dvp "Es una criatura sin debilidades."

# game/game/script.rpy:9962
translate es playername_1838cfb3:

    # dvp "Well, I guess now he has one, and god knows he's gonna keep that bitch on a short leash."
    dvp "Bueno, supongo que ahora tiene una, y dios sabe que mantendrá a esa perra con una correa corta."

# game/game/script.rpy:9964
translate es playername_3b0747e9:

    # mc "Fuck off."
    mc "Lárgate."

# game/game/script.rpy:9966
translate es playername_bbb1d618:

    # "Double just laughs."
    "Double solo se ríe."

# game/game/script.rpy:9968
translate es playername_dda0fb7f:

    # dvp "Good luck bitch, you're gonna need it. I'll keep your nice little picture as a parting gift~"
    dvp "Buena suerte, perra, la vas a necesitar. Me quedaré con tu bonita foto como regalo de despedida~"

# game/game/script.rpy:9972
translate es playername_22fcefab:

    # "After that the phone goes silent."
    "Después de eso el teléfono queda en silencio."

# game/game/script.rpy:9974
translate es playername_42bdd924:

    # "{i}Did Double really just hang up on me?{/i}"
    "{i}¿Double realmente acaba de colgarme?{/i}"

# game/game/script.rpy:9976
translate es playername_8f866fe6:

    # "Still a scumbag after all this time."
    "Sigue siendo un desgraciado después de todo este tiempo."

# game/game/script.rpy:9979
translate es playername_580cf229:

    # "I try to push his words out of my head."
    "Intento sacar sus palabras de mi cabeza."

# game/game/script.rpy:9981
translate es playername_11aec8e5:

    # "{i}'Do you want to live at the whims of a cruel, unforgiving creature? Or would you rather die?'{/i}"
    "{i}'¿Quieres vivir a merced de una criatura cruel e implacable? ¿O preferirías morir?'{/i}"

# game/game/script.rpy:9983
translate es playername_ed601acf:

    # "Binary-...No, {i}Ray {/i} surely can't be that bad. He has been nothing but kind to me."
    "Binary-... No, {i}Ray{/i} seguramente no puede ser tan malo. No ha hecho más que ser amable conmigo."

# game/game/script.rpy:9985
translate es playername_6e7d69bf:

    # "Double has told me cruel lies in the past, he is definitely just trying to psyche me out."
    "Double me ha dicho mentiras crueles en el pasado, definitivamente solo intenta desestabilizarme."

# game/game/script.rpy:9994
translate es playername_cf4911b7:

    # "I can't help but to feel uneasy about Binary Star."
    "No puedo evitar sentir intranquilidad respecto a Binary Star."

# game/game/script.rpy:10000
translate es playername_310fc9fc:

    # "I decide to continue to search up some additional information about him."
    "Decido seguir buscando información adicional sobre él."

# game/game/script.rpy:10002
translate es playername_53d0c20b:

    # "I look, but there truly isn't much information to be found."
    "Busco, pero realmente no hay mucha información disponible."

# game/game/script.rpy:10006
translate es playername_b87f7908:

    # "The information that does exist is hard to parse between fact or fiction."
    "La que existe es difícil de separar entre hecho o ficción."

# game/game/script.rpy:10010
translate es playername_41cd4323:

    # "While searching there are a lot of click-baity titles about his love life or what he does in his time off."
    "Mientras busco, aparecen muchos títulos llamativos sobre su vida amorosa o lo que hace en su tiempo libre."

# game/game/script.rpy:10012
translate es playername_1fc77167:

    # "But I continue to search for real information."
    "Pero sigo buscando información real."

# game/game/script.rpy:10014
translate es playername_2cab3969:

    # "I finally stumble across a post that sounds...different from the others."
    "Finalmente tropiezo con una publicación que suena... diferente de las demás."

# game/game/script.rpy:10018
translate es playername_1459725b:

    # "I click on it."
    "Hago clic en ella."

# game/game/script.rpy:10020
translate es playername_399fe0c2:

    # "'Binary Star - The truth the Hero Association doesn't want you to know.'"
    "'Binary Star - La verdad que la Asociación de Héroes no quiere que sepas.'"

# game/game/script.rpy:10022
translate es playername_51d0ef78:

    # "{b}05/15 - 6pm{/b}"
    "{b}05/15 - 6pm{/b}"

# game/game/script.rpy:10024
translate es playername_60f71c37:

    # "User 49824 - {color=#70113F} 'This is going to sound crazy I have nothing left to live for, so I'm just going to say it!{/color}"
    "Usuario 49824 - {color=#70113F} 'Esto va a sonar loco, no tengo nada por lo que vivir, ¡así que simplemente lo diré!{/color}"

# game/game/script.rpy:10026
translate es playername_a56c4a9e:

    # "User BlanketImp - {color=#116470}'Nobody asked'{/color}"
    "Usuario BlanketImp - {color=#116470}'Nadie preguntó'{/color}"

# game/game/script.rpy:10028
translate es playername_c5d6267f:

    # "User 49824 - {color=#70113F} 'Binary Star is Human! {/color}"
    "Usuario 49824 - {color=#70113F} '¡Binary Star es humano! {/color}"

# game/game/script.rpy:10030
translate es playername_669c05a3:

    # "User BlanketImp - {color=#116470} 'Didn't ask.' {/color}"
    "Usuario BlanketImp - {color=#116470} 'No pregunté.' {/color}"

# game/game/script.rpy:10032
translate es playername_4b17b4b3:

    # "User 49824 - {color=#70113F} 'I'm not making this shit up!' {/color}"
    "Usuario 49824 - {color=#70113F} '¡No me estoy inventando esta mierda!' {/color}"

# game/game/script.rpy:10034
translate es playername_0373c731:

    # "User 49824 - {color=#70113F} 'My dad passed away last week. We were cleaning out his office and found some documents from his work.' {/color}"
    "Usuario 49824 - {color=#70113F} 'Mi padre falleció la semana pasada. Estábamos limpiando su oficina y encontramos algunos documentos de su trabajo.' {/color}"

# game/game/script.rpy:10036
translate es playername_f295f0bb:

    # "User 49824 - {color=#70113F} 'They confirm that Binary Star was raised in a government lab!'{/color}"
    "Usuario 49824 - {color=#70113F} '¡Confirman que Binary Star fue criado en un laboratorio del gobierno!'{/color}"

# game/game/script.rpy:10038
translate es playername_c43fa910:

    # "User 49824 - {color=#70113F} 'This whole time they have been training him to be a weapon of war.' {/color}"
    "Usuario 49824 - {color=#70113F} 'Todo este tiempo lo han estado entrenando para ser un arma de guerra.' {/color}"

# game/game/script.rpy:10040
translate es playername_c64d4980:

    # "User GrandMud - {color=#117028} 'Dude, go touch grass srsly' {/color}"
    "Usuario GrandMud - {color=#117028} 'Amigo, sal a tomar aire en serio' {/color}"

# game/game/script.rpy:10042
translate es playername_a1eb1264:

    # "User 49824 - {color=#70113F} 'It worked too! Remember how the Southern war ended 16 years ago after going on for over 2 decades?' {/color}"
    "Usuario 49824 - {color=#70113F} '¡Y funcionó también! ¿Recuerdan cómo terminó la guerra del sur hace 16 años después de más de dos décadas?' {/color}"

# game/game/script.rpy:10044
translate es playername_36f42b00:

    # "User 49824 - {color=#70113F} 'It's because they dropped in Binary Star, there are testimonies from locals!' {/color}"
    "Usuario 49824 - {color=#70113F} 'Es porque enviaron a Binary Star, ¡hay testimonios de los locales!' {/color}"

# game/game/script.rpy:10046
translate es playername_7a5568f9:

    # "User 49824 - {color=#70113F} 'Well...that is, before they were {i}slaughtered {/i} to cover up the massacres of the Heroes. At the time Binary was 16 years old and possibly massacred HUNDREDS.' {/color}"
    "Usuario 49824 - {color=#70113F} 'Bueno... eso fue antes de que fueran {i}masacrados{/i} para encubrir las matanzas de los Héroes. En ese momento Binary tenía 16 años y posiblemente masacró a CIENTOS.' {/color}"

# game/game/script.rpy:10048
translate es playername_fed068dc:

    # "User 49824 - {color=#70113F} 'As news tried to break from independent journalists about the massacres at the hands of the Heroes...' {/color}"
    "Usuario 49824 - {color=#70113F} 'Cuando las noticias intentaron salir de periodistas independientes sobre las masacres a manos de los Héroes...' {/color}"

# game/game/script.rpy:10050
translate es playername_b6189752:

    # "User 49824- {color=#70113F} 'The NAHA debuted Binary Star that year to create distractions from the public. And it worked!' {/color}"
    "Usuario 49824 - {color=#70113F} 'La NAHA presentó a Binary Star ese año para distraer al público. ¡Y funcionó!' {/color}"

# game/game/script.rpy:10052
translate es playername_7fdc3a7f:

    # "User BlanketImp - {color=#116470} 'And distracted you from getting sum bitches on ur dick.' {/color}"
    "Usuario BlanketImp - {color=#116470} 'Y te distrajo de conseguirte unas chicas en tu vida.' {/color}"

# game/game/script.rpy:10054
translate es playername_ac81059c:

    # "User GrandMud - {color=#117028} 'Clearly.' {/color}"
    "Usuario GrandMud - {color=#117028} 'Claramente.' {/color}"

# game/game/script.rpy:10056
translate es playername_003085c0:

    # "{b} 06/17 - 10pm{/b}"
    "{b}06/17 - 10pm{/b}"

# game/game/script.rpy:10058
translate es playername_e5920868:

    # "User GrandMud - {color=#117028} 'I looked into some of this stuff and it kinda checks out...' {/color}"
    "Usuario GrandMud - {color=#117028} 'Investigué un poco sobre esto y parece que algo de esto cuadra...' {/color}"

# game/game/script.rpy:10060
translate es playername_d7dbe568:

    # "User GrandMud - {color=#117028} '@User 49824 @BlanketImp {/color}"
    "Usuario GrandMud - {color=#117028} '@Usuario 49824 @BlanketImp {/color}"

# game/game/script.rpy:10062
translate es playername_5f27e4e8:

    # "User GrandMud - {color=#117028} 'I was skeptical at first, but I couldn't stop thinking about it.' {/color}"
    "Usuario GrandMud - {color=#117028} 'Era escéptico al principio, pero no podía dejar de pensar en ello.' {/color}"

# game/game/script.rpy:10064
translate es playername_86a2f081:

    # "User GrandMud - {color=#117028} 'The more I dug, The more it checked out.' {/color}"
    "Usuario GrandMud - {color=#117028} 'Cuanto más investigaba, más coincidía.' {/color}"

# game/game/script.rpy:10066
translate es playername_f726c326:

    # "User GrandMud - {color=#117028} 'Look at this image I finally found.' {/color}"
    "Usuario GrandMud - {color=#117028} 'Miren esta imagen que finalmente encontré.' {/color}"

# game/game/script.rpy:10070
translate es playername_60256a58:

    # "An image appears on screen, it is of a blurry Ray in Military gear."
    "Aparece una imagen en pantalla, es de un Ray borroso con uniforme militar."

# game/game/script.rpy:10072
translate es playername_5b7a7c75:

    # "USer GrandMud - {color=#117028} 'That's Binary Star - It does't look completely like him because they always photoshop him in photos.' {/color}"
    "Usuario GrandMud - {color=#117028} 'Ese es Binary Star - No se ve completamente como él porque siempre lo photoshopean en las fotos.' {/color}"

# game/game/script.rpy:10074
translate es playername_6b93851e:

    # "User GrandMud - {color=#117028} 'But that is 100-percent him. There was no reason for an undercover hero to be there.... {/color}"
    "Usuario GrandMud - {color=#117028} 'Pero es él al cien por ciento. No había razón para que un héroe encubierto estuviera allí.... {/color}"

# game/game/script.rpy:10076
translate es playername_2686ec32:

    # " {color=#116470} - User BlanketImp is online - {/color}"
    "{color=#116470} - Usuario BlanketImp está en línea - {/color}"

# game/game/script.rpy:10078
translate es playername_8b554592:

    # "User GrandMud - {color=#117028} 'Unless they were cleaning up some loose ends - some locals or journalists in hiding.' {/color}"
    "Usuario GrandMud - {color=#117028} 'A menos que estuvieran eliminando cabos sueltos - algunos locales o periodistas escondidos.' {/color}"

# game/game/script.rpy:10080
translate es playername_312fe295:

    # "User BlanketImp - {color=#116470} 'Dude, now you too?!' {/color}"
    "Usuario BlanketImp - {color=#116470} 'Amigo, ¿tú también ahora?!' {/color}"

# game/game/script.rpy:10082
translate es playername_152c7c85:

    # "User BlanketImp - {color=#116470} 'Is there a grass shortage or something?' {/color} "
    "Usuario BlanketImp - {color=#116470} '¿Hay escasez de césped o qué?' {/color}"

# game/game/script.rpy:10084
translate es playername_62f49165:

    # "User GrandMud - {color=#117028} 'I'm serious!' {/color}"
    "Usuario GrandMud - {color=#117028} '¡Hablo en serio!' {/color}"

# game/game/script.rpy:10086
translate es playername_c19aa42c:

    # "User BlanketImp - {color=#116470} 'lol K. You and @User 49824 can crazy talk together. I'm logging off.' {/color}"
    "Usuario BlanketImp - {color=#116470} 'jajaja ok. Tú y @Usuario 49824 pueden hablar locuras juntos. Me desconecto.' {/color}"

# game/game/script.rpy:10088
translate es playername_9b0a462a:

    # "User BlanketImp - {color=#116470} 'Nerds.' {/color}"
    "Usuario BlanketImp - {color=#116470} 'Nerds.' {/color}"

# game/game/script.rpy:10090
translate es playername_bb7e5ebe:

    # "{color=#116470} - User BlanketImp is offline - {/color} "
    "{color=#116470} - Usuario BlanketImp está desconectado - {/color}"

# game/game/script.rpy:10092
translate es playername_abf2cecb:

    # "User GrandMud - {color=#117028} '@User 49824 you online?' {/color}"
    "Usuario GrandMud - {color=#117028} '@Usuario 49824 ¿estás en línea?' {/color}"

# game/game/script.rpy:10094
translate es playername_c4217fd4:

    # "User GrandMud - {color=#117028} 'Guess not...' {/color}"
    "Usuario GrandMud - {color=#117028} 'Parece que no...' {/color}"

# game/game/script.rpy:10096
translate es playername_81e25046:

    # "{color=#117028} - User GrandMud is offline - {/color}"
    "{color=#117028} - Usuario GrandMud está desconectado - {/color}"

# game/game/script.rpy:10100
translate es playername_f6625da5:

    # "{b}07/04 - 7pm{/b}"
    "{b}07/04 - 7pm{/b}"

# game/game/script.rpy:10102
translate es playername_80eab4fc:

    # "User BlanketImp - {color=#116470} 'Dude wtf, I think I'm getting paranoid. There is this van that keeps on following me.' {/color}"
    "Usuario BlanketImp - {color=#116470} 'Amigo, wtf, creo que me estoy volviendo paranoico. Hay una furgoneta que sigue siguiéndome.' {/color}"

# game/game/script.rpy:10104
translate es playername_a579a8c2:

    # "User BlanketImp - {color=#116470} 'I stg I'm not making this shit up.' {/color}"
    "Usuario BlanketImp - {color=#116470} 'Lo juro por dios que no me estoy inventando esta mierda.' {/color}"

# game/game/script.rpy:10106
translate es playername_dc1319fb:

    # "User BlanketImp - {color=#116470} '@User GrandMud !!!' {/color}"
    "Usuario BlanketImp - {color=#116470} '@Usuario GrandMud !!!' {/color}"

# game/game/script.rpy:10108
translate es playername_351d7c5f:

    # "User BlanketImp - {color=#116470} 'Fuck, I'm getting freaked out!' {/color}"
    "Usuario BlanketImp - {color=#116470} '¡Mierda, me estoy asustando!' {/color}"

# game/game/script.rpy:10110
translate es playername_5c62127e:

    # "{color=#116470} - User BlanketImp is offline - {/color}"
    "{color=#116470} - Usuario BlanketImp está desconectado - {/color}"

# game/game/script.rpy:10112
translate es playername_0fd4d656:

    # "......"
    "......"

# game/game/script.rpy:10116
translate es playername_eeb9b01c:

    # "I type a 'hello' in the chat and wait a few minutes but nobody comes online."
    "Escribo un 'hola' en el chat y espero unos minutos, pero nadie se conecta."

# game/game/script.rpy:10118
translate es playername_5953bb66:

    # "I shut the screen off, alone with my thoughts."
    "Apago la pantalla, sola con mis pensamientos."

# game/game/script.rpy:10120
translate es playername_a293d25c:

    # "It's a common rumor that the Hero Association used Heroes to win the Southern war..."
    "Es un rumor común que la Asociación de Héroes usó Héroes para ganar la guerra del Sur..."

# game/game/script.rpy:10122
translate es playername_4f388cee:

    # "But it is literally a war crime to do so, and the Heroes are only for justice. So the general populace basically wrote it off as conspiracy theory."
    "Pero eso es literalmente un crimen de guerra, y los Héroes son solo para la justicia. Así que la población general básicamente lo descartó como una teoría conspirativa."

# game/game/script.rpy:10124
translate es playername_38fac252:

    # "I swallow thickly."
    "Trago con dificultad."

# game/game/script.rpy:10126
translate es playername_389723e8:

    # "After seeing Binary Star casually...kill all of those people in the warehouse, some part of me can't help but to think it's not a simple theory anymore."
    "Después de ver a Binary Star matar casualmente... a todas esas personas en el almacén, una parte de mí no puede evitar pensar que ya no es una simple teoría."

# game/game/script.rpy:10128
translate es playername_58f79fb9:

    # "I put my computer away, starting to feel a little sick."
    "Guardo mi computadora, empezando a sentirme un poco enferma."

# game/game/script.rpy:10132
translate es playername_ec273f01:

    # "After reading all of that, some part of me felt like I knew more but understood less of Binary Star than ever before."
    "Después de leer todo eso, una parte de mí siente que sabe más, pero entiende menos sobre Binary Star que nunca antes."

# game/game/script.rpy:10139
translate es playername_029822c8:

    # "I start to feel exhausted..."
    "Empiezo a sentirme exhausta..."

# game/game/script.rpy:10141
translate es playername_1664d1a5:

    # "Ray isn't home and it's already pretty late."
    "Ray no está en casa y ya es bastante tarde."

# game/game/script.rpy:10145
translate es playername_bc6c3222:

    # "I can't help but to wonder if it is because of our discussion earlier."
    "No puedo evitar preguntarme si es por nuestra discusión anterior."

# game/game/script.rpy:10147
translate es playername_645b09d3:

    # "It certainly left off on an awkward note."
    "Ciertamente terminó en una nota incómoda."

# game/game/script.rpy:10149
translate es playername_c759afe5:

    # "A bit of sadness stung in my heart."
    "Un poco de tristeza punza en mi corazón."

# game/game/script.rpy:10151
translate es playername_7b566bc2:

    # "Despite everything, some part of me still trusted Ray."
    "A pesar de todo, una parte de mí todavía confiaba en Ray."

# game/game/script.rpy:10155
translate es playername_27afbe01:

    # "Part of me was thankful for his absence."
    "Parte de mí agradecía su ausencia."

# game/game/script.rpy:10157
translate es playername_10ce6a91:

    # "Despite all of the time Ray and I have spent together...I still feel like I barely knew him."
    "A pesar de todo el tiempo que Ray y yo hemos pasado juntos... todavía siento que apenas lo conozco."

# game/game/script.rpy:10159
translate es playername_f6b90345:

    # "Like he could flip a switch and become a total stranger."
    "Como si pudiera cambiar en un instante y convertirse en un completo extraño."

# game/game/script.rpy:10161
translate es playername_59cd382d:

    # "And some part of me knew I may never come to understand him."
    "Y alguna parte de mí sabía que tal vez nunca llegaría a comprenderlo."

# game/game/script.rpy:10163
translate es playername_6c27ff45:

    # "That scares me."
    "Eso me asusta."

# game/game/script.rpy:10165
translate es playername_e6407e1a:

    # "I get into bed resting my body against the plush blankets."
    "Me meto en la cama apoyando mi cuerpo contra las suaves mantas."

# game/game/script.rpy:10167
translate es playername_6001a0b1:

    # "My eyes close, covering me in the familiar darkness of sleep."
    "Mis ojos se cierran, cubriéndome con la familiar oscuridad del sueño."

# game/game/script.rpy:10173
translate es playername_199a13cd:

    # "I dream of a peculiar dream. One where Double, Haley and myself are all heroes..."
    "Sueño un sueño peculiar. Uno donde Double, Haley y yo somos héroes..."

# game/game/script.rpy:10175
translate es playername_50d0930e:

    # "We fight to defeat the Ultimate Villain 'Binary Star'."
    "Luchamos para derrotar al Villano Supremo 'Binary Star'."

# game/game/script.rpy:10177
translate es playername_b01c6a8a:

    # "I drive a sword through his chest, he erupts into planetary dust, showering glitter all over myself."
    "Clavo una espada en su pecho, él estalla en polvo planetario, bañándome de brillo."

# game/game/script.rpy:10179
translate es playername_e4d2db45:

    # "I don't feel sad, yet tears swell and pour down my face."
    "No me siento triste, y aun así las lágrimas se acumulan y corren por mi rostro."

# game/game/script.rpy:10181
translate es playername_7b19e752:

    # "The planet heals.... it's finally over."
    "El planeta sana... por fin ha terminado."

# game/game/script.rpy:10187
translate es playername_77d0ca6d:

    # "The dust fall into sparks and soon the earth catches fire."
    "El polvo cae en chispas y pronto la tierra prende fuego."

# game/game/script.rpy:10189
translate es playername_addb071c:

    # "A wild flame licks my face and my body, I can't breathe!"
    "Una llama salvaje lame mi rostro y mi cuerpo, ¡no puedo respirar!"

# game/game/script.rpy:10191
translate es playername_2d2724af:

    # "Help! I can't-"
    "¡Ayuda! ¡No puedo–!"

# game/game/script.rpy:10197
translate es playername_a4975347:

    # "As I dream the smell of smoke drifts across my senses."
    "Mientras sueño, el olor a humo atraviesa mis sentidos."

# game/game/script.rpy:10199
translate es playername_9a2c3efc:

    # "I cough a bit, turning over."
    "Toso un poco, dándome la vuelta."

# game/game/script.rpy:10201
translate es playername_652650d3:

    # mc "...?"
    mc "...?"

# game/game/script.rpy:10203
translate es playername_0a03f4f6:

    # "My eyes flash open as the sent of smoke permeates the area."
    "Mis ojos se abren de golpe al sentir el olor a humo impregnando el aire."

# game/game/script.rpy:10212
translate es playername_859661e4:

    # "I immediately sit up."
    "Me incorporo de inmediato."

# game/game/script.rpy:10214
translate es playername_e232d0b3_2:

    # mc "!!!"
    mc "¡¡¡!!!"

# game/game/script.rpy:10216
translate es playername_fde4106d:

    # "My whole apartment is consumed by flames."
    "Todo mi apartamento está envuelto en llamas."

# game/game/script.rpy:10218
translate es playername_a5e71d32:

    # "I blanche."
    "Palidezco."

# game/game/script.rpy:10220
translate es playername_0eb9b681:

    # "How could it have spread this much without me waking up?!"
    "¿Cómo pudo extenderse tanto sin que me despertara?!"

# game/game/script.rpy:10222
translate es playername_81c28a58:

    # "I quickly stumble out of my bed. The ground is hot as flames lick the far wall. I cough as the smoke starts to get in my lungs."
    "Tropiezo fuera de la cama. El suelo está caliente mientras las llamas lamen la pared del fondo. Toso mientras el humo empieza a llenar mis pulmones."

# game/game/script.rpy:10224
translate es playername_4bf9ed9f:

    # "I can't stop coughing, this is bad...!"
    "¡No puedo dejar de toser, esto está mal...!"

# game/game/script.rpy:10226
translate es playername_ef9b81f9:

    # "I glance around my apartment as it is doused in flames."
    "Miro alrededor de mi apartamento mientras el fuego lo consume todo."

# game/game/script.rpy:10228
translate es playername_612b53c7:

    # "I cough harder as I kneel over, the smoke is suffocating."
    "Toso con más fuerza mientras me arrodillo, el humo me asfixia."

# game/game/script.rpy:10230
translate es playername_ab6f6818:

    # "{i} 'I have to do something fast!' {/i}"
    "{i}'¡Tengo que hacer algo rápido!'{/i}"

# game/game/script.rpy:10236
translate es playername_9a48f3cc:

    # "I make a desperate crawling dash for the front door. Adrenaline shields me from the pain searing through my palms."
    "Me arrastro desesperadamente hacia la puerta principal. La adrenalina me protege del dolor que quema mis palmas."

# game/game/script.rpy:10253
translate es playername_0a1559b8:

    # "The door is closed. I curse reaching for it desperately."
    "La puerta está cerrada. Maldigo mientras la agarro con desesperación."

# game/game/script.rpy:10257
translate es playername_2ff0f41c:

    # "The metal handle sears my fingers peeling the skin directly off, melting it to the door knob."
    "El pomo metálico me quema los dedos, arrancando la piel y fundiéndola en el metal."

# game/game/script.rpy:10263
translate es playername_fe807e9f:

    # "I scream in pain, body shaking. I look away from my hand, concerned that if I glance at it for even a second bile will rise from my stomach."
    "Grito de dolor, el cuerpo me tiembla. Aparto la mirada de mi mano, temiendo que si la veo, las náuseas me dominen."

# game/game/script.rpy:10278
translate es playername_926b9b01:

    # "I shuffle back to the bed desperately grabbing and yanking a sheet off."
    "Retrocedo hasta la cama, agarrando desesperadamente una sábana."

# game/game/script.rpy:10280
translate es playername_87fb6031:

    # "My lungs burn and scream from the hurried action, desperate for any semblance of clean air."
    "Mis pulmones arden y gritan con cada movimiento, desesperados por un poco de aire limpio."

# game/game/script.rpy:10295
translate es playername_b8bf6efc:

    # "I crawl desperately, my vision spotting black, brain hazy from the lack of oxygen."
    "Me arrastro con desesperación, la vista me parpadea en negro, el cerebro nublado por la falta de oxígeno."

# game/game/script.rpy:10314
translate es playername_77958f01:

    # "I fight against it as hard as I possibly can, crawling forward, the door feeling miles away."
    "Lucho con todas mis fuerzas, avanzando a gatas, la puerta se siente a kilómetros."

# game/game/script.rpy:10326
translate es playername_6a4ee209:

    # "My body collapses, unable to take anymore."
    "Mi cuerpo colapsa, incapaz de soportar más."

# game/game/script.rpy:10328
translate es playername_4fe7fed0:

    # "Before my vision fades completely I see light from the doorway."
    "Antes de que mi visión se apague por completo, veo una luz desde la entrada."

# game/game/script.rpy:10346
translate es playername_0d4455d9:

    # "I look around. The front door is too far away, and the balcony door may be too heavy for me to open."
    "Miro alrededor. La puerta principal está demasiado lejos, y la del balcón puede ser demasiado pesada para abrirla."

# game/game/script.rpy:10348
translate es playername_488fce22:

    # "The window falls into my vision. It is already partially open."
    "La ventana entra en mi visión. Ya está entreabierta."

# game/game/script.rpy:10349
translate es playername_8f13a22d:

    # "If I can leverage my body to force it open in one swoop, maybe I can then get some fresh air and jump to the neighbor's balcony."
    "Si logro impulsar mi cuerpo y abrirla de un tirón, tal vez pueda respirar aire fresco y saltar al balcón del vecino."

# game/game/script.rpy:10353
translate es playername_62420b4a:

    # "Its a risky manuever, but I'm willing to try."
    "Es una maniobra arriesgada, pero estoy dispuesta a intentarlo."

# game/game/script.rpy:10366
translate es playername_b35400bb:

    # "I crawl towards the window."
    "Me arrastro hacia la ventana."

# game/game/script.rpy:10372
translate es playername_8c0a6b0a:

    # "Gathering my strength I push the window sill upwards, careful not to fall out."
    "Reuniendo mis fuerzas empujo el marco hacia arriba, con cuidado de no caer."

# game/game/script.rpy:10385
translate es playername_a26754f4:

    # "Black spots cloud my vision. Instead of fresh air coming in through the opening, it seems only smoke is going out."
    "Manchas negras nublan mi visión. En lugar de entrar aire fresco, parece que solo el humo sale por la abertura."

# game/game/script.rpy:10388
translate es playername_158bad58:

    # "I need to hurry."
    "Necesito apurarme."

# game/game/script.rpy:10401
translate es playername_292d1d36:

    # "I crawl up towards the window, my lungs scream at the lack of air."
    "Subo hacia la ventana, mis pulmones gritan por la falta de aire."

# game/game/script.rpy:10414
translate es playername_df8083da:

    # "I slowly and carefully make my way out of the window, I stand up trying to get a foothold on the thin awning."
    "Lentamente y con cuidado salgo por la ventana, poniéndome de pie e intentando apoyar los pies sobre el delgado alero."

# game/game/script.rpy:10416
translate es playername_78538cdb:

    # "I have done this a thousand times before in my previous...career. But none under such difficult circumstances."
    "He hecho esto mil veces antes en mi anterior... carrera. Pero nunca en circunstancias tan difíciles."

# game/game/script.rpy:10432
translate es playername_cdb0150b:

    # "My mind feels hazy and my knees begin to shake. I look towards the neighbors balcony. I have to do this quickly."
    "Mi mente se siente nublada y mis rodillas comienzan a temblar. Miro hacia el balcón del vecino. Tengo que hacerlo rápido."

# game/game/script.rpy:10454
translate es playername_befea76c:

    # "I have to make my leap."
    "Tengo que saltar."

# game/game/script.rpy:10458
translate es playername_ea85a445:

    # "In all but a moment I am soaring through the air."
    "En un instante me encuentro volando por el aire."

# game/game/script.rpy:10460
translate es playername_6300c170:

    # "I am a bit short, I grab desperately to the bottom of the Balcony."
    "Debido a mi baja estatura me agarro desesperadamente a la parte inferior del balcón."

# game/game/script.rpy:10464
translate es playername_24be42f8:

    # "I try to steady my hanging body. My arms shaking with the force, if I can just get my elbows up, I can pull the rest of my body to safety."
    "Intento estabilizar mi cuerpo colgante. Mis brazos tiemblan con fuerza; si logro subir los codos, podré impulsarme hacia la seguridad."

# game/game/script.rpy:10466
translate es playername_cbd8b93e:

    # "My heart pounds as I hang onto the neighbor's balcony desperately. My lungs are screaming at the rush of fresh air as my vision obscures."
    "Mi corazón late con fuerza mientras me aferro desesperada al balcón del vecino. Mis pulmones gritan por el aire fresco mientras mi visión se nubla."

# game/game/script.rpy:10470
translate es playername_fc637833:

    # "My fingertips shake, the sweat making it all the more dangerous as my fingers begin to slip."
    "Mis dedos tiemblan, el sudor lo hace aún más peligroso mientras empiezo a resbalar."

# game/game/script.rpy:10472
translate es playername_b8f04a49:

    # "I try to pull myself up...."
    "Intento impulsarme hacia arriba..."

# game/game/script.rpy:10474
translate es playername_b29a6e73:

    # "But between my shaking overexerted arms, lungs filled with smoke, and slippery fingertips I can't seem to hold on."
    "Pero entre mis brazos temblorosos, los pulmones llenos de humo y los dedos resbaladizos, no logro sostenerme."

# game/game/script.rpy:10478
translate es playername_8d0c33c5:

    # "My body plummets 5 stories towards the ground."
    "Mi cuerpo cae cinco pisos hacia el suelo."

# game/game/script.rpy:10482
translate es playername_7a2fb34c:

    # "I close my eyes waiting for the collision."
    "Cierro los ojos esperando el impacto."

# game/game/script.rpy:10486
translate es playername_f8eba7fd:

    # "Suddenly my body is slammed into the water. My fall somewhat broken by the shallow fountain below."
    "De repente mi cuerpo se estrella contra el agua. Mi caída se frena un poco al caer en la fuente poco profunda de abajo."

# game/game/script.rpy:10488
translate es playername_be1d58b8:

    # "The air is violently stolen from my lungs and I can feel my spine, and legs shattered in multiple places."
    "El aire es arrancado violentamente de mis pulmones y puedo sentir mi columna y mis piernas romperse en varios lugares."

# game/game/script.rpy:10492
translate es playername_ea56eda9:

    # "I try to move, try to get up, but my body won't listen. It screams in protest."
    "Intento moverme, intentar levantarme, pero mi cuerpo no responde. Grita en protesta."

# game/game/script.rpy:10495
translate es playername_9aac99e9:

    # "My vision obscures as my lungs still can not find purchase in any fresh air."
    "Mi visión se nubla mientras mis pulmones aún no encuentran aire fresco."

# game/game/script.rpy:10497
translate es playername_1a8bc511:

    # mc "Please...god."
    mc "Por favor... dios."

# game/game/script.rpy:10499
translate es playername_4253dc5c:

    # "I cry only to myself as my vision fades fully to black."
    "Lloro en silencio mientras mi visión se apaga por completo."

# game/game/script.rpy:10519
translate es playername_c08d6dab:

    # "I knew things were going bad fast."
    "Sabía que las cosas se estaban poniendo feas rápidamente."

# game/game/script.rpy:10527
translate es notrust_53bc0519:

    # "I make my way towards the balcony door. It is the closest to me so it only takes a few seconds to get to."
    "Me dirijo hacia la puerta del balcón. Es la más cercana, así que solo me toma unos segundos llegar."

# game/game/script.rpy:10531
translate es notrust_fd93ba3d:

    # "When I reach out to the doorknob I can feel the heat even before touching it."
    "Cuando extiendo la mano hacia el pomo puedo sentir el calor incluso antes de tocarlo."

# game/game/script.rpy:10535
translate es notrust_64a854b6:

    # "I turn around, yanking a sheet off of the bed and wrap my hand in it."
    "Me doy la vuelta, arrancando una sábana de la cama y envolviendo mi mano con ella."

# game/game/script.rpy:10537
translate es notrust_c3606bee:

    # "I try to push, but the balcony door doesn't budge."
    "Intento empujar, pero la puerta del balcón no se mueve."

# game/game/script.rpy:10539
translate es notrust_46cc82ae:

    # "I curse under my breath."
    "Maldigo por lo bajo."

# game/game/script.rpy:10541
translate es notrust_46656f13:

    # "{i}Why does it have to be jammed now of all times?!{/i}"
    "{i}¿Por qué tiene que atascarse justo ahora?!{/i}"

# game/game/script.rpy:10545
translate es notrust_58c65b69:

    # "I use my full body weight to push against it, but again, no dice."
    "Empujo con todo el peso de mi cuerpo, pero nada."

# game/game/script.rpy:10547
translate es notrust_c20b1597:

    # "My vision begins to spot as my lungs desperately search for any air they can gain purchase in."
    "Mi visión empieza a mancharse mientras mis pulmones buscan desesperadamente aire."

# game/game/script.rpy:10558
translate es notrust_c199c54c:

    # "I again press my body weight against the door, but it doesn't even flinch under my full pressure."
    "Una vez más presiono mi cuerpo contra la puerta, pero ni siquiera cede bajo toda mi fuerza."

# game/game/script.rpy:10571
translate es notrust_fb122f0c:

    # "My legs collapse shaking as my vision swirls."
    "Mis piernas colapsan temblando mientras mi visión da vueltas."

# game/game/script.rpy:10583
translate es notrust_78e31fed:

    # "I reach towards the door crawling on my knees."
    "Extiendo la mano hacia la puerta arrastrándome de rodillas."

# game/game/script.rpy:10587
translate es notrust_a7fedb64:

    # "My body heaves and coughs, unable to relieve my lungs of the soot."
    "Mi cuerpo se sacude y tose, incapaz de liberar mis pulmones del hollín."

# game/game/script.rpy:10600
translate es notrust_caf924ed:

    # "As my vision begins to fade, suddenly a rush of fresh air hits me."
    "A medida que mi visión comienza a desvanecerse, de repente una ráfaga de aire fresco me golpea."

# game/game/script.rpy:10607
translate es notrust_16d052cd:

    # bs "I'm disappointed in you."
    bs "Estoy decepcionado de ti."

# game/game/script.rpy:10628
translate es notrust_e651c960:

    # "Binary Star looks down at me radiant as ever."
    "Binary Star me mira desde arriba, radiante como siempre."

# game/game/script.rpy:10630
translate es notrust_f0eb627a:

    # "Even in these circumstances he glows."
    "Incluso en estas circunstancias, brilla."

# game/game/script.rpy:10632
translate es notrust_9322cbdb:

    # bs "You would really rather die than ask me to save you?"
    bs "¿De verdad preferirías morir antes que pedirme que te salve?"

# game/game/script.rpy:10634
translate es notrust_ab62d9d5:

    # bs "Do you hate me? Are you disgusted by what you found out about me?"
    bs "¿Me odias? ¿Te repugna lo que descubriste sobre mí?"

# game/game/script.rpy:10636
translate es notrust_86faf5e4:

    # bs "Do you think I'm a monster too?"
    bs "¿También piensas que soy un monstruo?"

# game/game/script.rpy:10638
translate es notrust_c9d20330:

    # "I'm unable to answer, all of my words being swallowed by coughs and desperate greedy gasps for the sudden influx of fresh air."
    "Soy incapaz de responder, todas mis palabras son ahogadas por tos y jadeos desesperados ante la repentina entrada de aire fresco."

# game/game/script.rpy:10640
translate es notrust_ba6461f3:

    # bs "You don't have to say anything, I already know you do."
    bs "No tienes que decir nada, ya sé que así es."

# game/game/script.rpy:10645
translate es notrust_2b76d78b:

    # "Binary star smiles kindly."
    "Binary Star sonríe amablemente."

# game/game/script.rpy:10647
translate es notrust_30da8ecd:

    # "His words do not match his expression."
    "Sus palabras no coinciden con su expresión."

# game/game/script.rpy:10649
translate es notrust_2223d3b5:

    # bs "I debated leaving you here, watching the life fade from your eyes. Unshackling myself from humanity once and for all."
    bs "Debatí dejarte aquí, viendo cómo la vida se desvanecía de tus ojos. Liberándome de la humanidad de una vez por todas."

# game/game/script.rpy:10651
translate es notrust_833add30:

    # bs "But it seems I'm...."
    bs "Pero parece que estoy..."

# game/game/script.rpy:10653
translate es notrust_d179e320:

    # bs "...Really struggling with that decision."
    bs "...luchando mucho con esa decisión."

# game/game/script.rpy:10655
translate es notrust_856310b6:

    # bs "So..."
    bs "Así que..."

# game/game/script.rpy:10657
translate es notrust_3fa88e3b:

    # bs "I'll give you a chance to make that decision for me."
    bs "Te daré la oportunidad de tomar esa decisión por mí."

# game/game/script.rpy:10670
translate es notrust_7abe6174:

    # "He approaches, smiling as kind as ever."
    "Se acerca, sonriendo tan amablemente como siempre."

# game/game/script.rpy:10685
translate es notrust_6e7cf9d0:

    # "I struggle to my feet. To meet the hero eye to eye."
    "Me esfuerzo por ponerme de pie. Para mirar al héroe a los ojos."

# game/game/script.rpy:10687
translate es notrust_0957ef88:

    # mc "Why..."
    mc "¿Por qué..."

# game/game/script.rpy:10689
translate es notrust_e2a7c51b:

    # "I choked out between coughs."
    "dije entre tosidos."

# game/game/script.rpy:10691
translate es notrust_6aad53c4:

    # bs "To be frank. I'm tired of being a 'Paragon for humanity'."
    bs "Para ser franco. Estoy cansado de ser un 'Paladín de la humanidad'."

# game/game/script.rpy:10693
translate es notrust_1adc0ecf:

    # bs "It's clear that now even you don't see me as a hero either."
    bs "Está claro que ni siquiera tú me ves ya como un héroe."

# game/game/script.rpy:10695
translate es notrust_1caa9a47:

    # bs "You probably don't even see me as human."
    bs "Probablemente ni siquiera me ves como un ser humano."

# game/game/script.rpy:10697
translate es notrust_6f282030:

    # bs "Not one ounce of affection left in your heart for me."
    bs "No queda ni una pizca de afecto en tu corazón hacia mí."

# game/game/script.rpy:10699
translate es notrust_a4890dc1:

    # bs "And you are even right to think so. To do so."
    bs "Y tienes razón en pensarlo. En hacerlo."

# game/game/script.rpy:10701
translate es notrust_c8728533:

    # bs "and..."
    bs "y..."

# game/game/script.rpy:10703
translate es notrust_094fcab9:

    # bs "I want to...{i} 'retire' {/i} I guess."
    bs "Quiero... {i}'retirarme'{/i}, supongo."

# game/game/script.rpy:10705
translate es notrust_e882f639:

    # "He pauses in thought."
    "Hace una pausa, pensativo."

# game/game/script.rpy:10707
translate es notrust_68c558f8:

    # bs "Well I guess 'retire' may not be the correct word for it."
    bs "Bueno, supongo que 'retirarme' puede que no sea la palabra correcta."

# game/game/script.rpy:10709
translate es notrust_289165cb:

    # "He chuckles."
    "Se ríe."

# game/game/script.rpy:10711
translate es notrust_7d4579a5:

    # bs "What you experienced earlier, with the alien attack was just a {i}recon{/i} of sorts."
    bs "Lo que experimentaste antes, con el ataque alienígena, fue solo un {i}reconocimiento{/i} en cierto modo."

# game/game/script.rpy:10713
translate es notrust_0c4d5c1e:

    # bs "They have many armies waiting for the word to attack. It will happen in a week or so."
    bs "Tienen muchos ejércitos esperando la orden para atacar. Sucederá en una semana aproximadamente."

# game/game/script.rpy:10715
translate es notrust_65546bb8:

    # bs "They will have ships, bodies, and weapons beyond our comprehension."
    bs "Tendrán naves, cuerpos y armas más allá de nuestra comprensión."

# game/game/script.rpy:10717
translate es notrust_25b98fac:

    # bs "The other heroes will only serve as special fodder for ungodly mechanisms."
    bs "Los demás héroes solo servirán como carne de cañón para mecanismos impíos."

# game/game/script.rpy:10719
translate es notrust_c3eb4a42:

    # bs "I could defeat them, it won't be pretty, but I could."
    bs "Podría derrotarlos, no sería bonito, pero podría hacerlo."

# game/game/script.rpy:10721
translate es notrust_01613781:

    # "He brushes a hand through his hair."
    "Pasa una mano por su cabello."

# game/game/script.rpy:10723
translate es notrust_c995feaf:

    # bs "But you see %(player_name)s, I'm having a hard time finding the will to fight for humanity, to save them."
    bs "Pero verás %(player_name)s, me cuesta encontrar la voluntad de luchar por la humanidad, de salvarlos."

# game/game/script.rpy:10725
translate es notrust_ee27f8b8:

    # bs "And the only thing that would make me even remotely want to..."
    bs "Y lo único que podría hacer que quisiera hacerlo aunque fuera un poco..."

# game/game/script.rpy:10727
translate es notrust_22e18701:

    # "He glances downward at me but his silence falls thick."
    "Baja la mirada hacia mí, pero su silencio se hace espeso."

# game/game/script.rpy:10729
translate es notrust_a7a6e57f:

    # bs "To be honest, at this point, I'd just rather watch it all burn."
    bs "Para ser honesto, a este punto, preferiría verlo todo arder."

# game/game/script.rpy:10731
translate es notrust_093d6440:

    # bs "Let the aliens do the hard work and then I'll play 'clean up crew.'"
    bs "Dejar que los alienígenas hagan el trabajo duro y luego yo haré de 'equipo de limpieza'."

# game/game/script.rpy:10737
translate es notrust_6e97d72a:

    # bs "...!"
    bs "¡...!"

# game/game/script.rpy:10739
translate es notrust_5c16c6b2:

    # bs "Hahahaha!"
    bs "¡Jajajajaja!"

# game/game/script.rpy:10741
translate es notrust_eadb63ad:

    # "Binary Star looks at me in genuine surprise and laughs."
    "Binary Star me mira genuinamente sorprendido y se ríe."

# game/game/script.rpy:10743
translate es notrust_e270ade6:

    # bs "%(player_name)s, if you weren't so cute I'd feel bad for you."
    bs "%(player_name)s, si no fueras tan adorable me sentiría mal por ti."

# game/game/script.rpy:10747
translate es notrust_530279c2:

    # bs "This {i}is{/i} me."
    bs "Este {i}soy{/i} yo."

# game/game/script.rpy:10751
translate es notrust_19e93597:

    # bs "For so long I imagined and marveled over what worlds I could be from."
    bs "Durante tanto tiempo imaginé y me maravillaba con los mundos de los que podría provenir."

# game/game/script.rpy:10753
translate es notrust_dfde1b1e:

    # bs "{i}A 'Child From the Stars'{/i}, They called me."
    bs "{i}Un 'Niño de las Estrellas'{/i}, me llamaban."

# game/game/script.rpy:10755
translate es notrust_10c1b876:

    # bs "Imagine my disappointment that all along the 'Star' that birthed me was this planet, Earth."
    bs "Imagina mi decepción al descubrir que la 'estrella' que me dio origen era este planeta, la Tierra."

# game/game/script.rpy:10757
translate es notrust_3deadb0f:

    # bs "To a mother that would rather sell me off as a government project than miss a hit of fentanyl."
    bs "De una madre que prefería venderme como proyecto del gobierno antes que perder una dosis de fentanilo."

# game/game/script.rpy:10759
translate es notrust_522874e9:

    # bs "Earth was my star. A sullied, fading star. {i}Infected.{/i}"
    bs "La Tierra fue mi estrella. Una estrella manchada, agonizante. {i}Infectada.{/i}"

# game/game/script.rpy:10761
translate es notrust_af3a0904:

    # "He levels a look at me. His eyes look like eternity."
    "Me lanza una mirada fija. Sus ojos parecen eternidad."

# game/game/script.rpy:10763
translate es notrust_d6537f33:

    # bs "When I am the only being sitting upon this rotting 'Star'."
    bs "Cuando sea el único ser sentado sobre esta 'estrella' podrida."

# game/game/script.rpy:10765
translate es notrust_23e3b3ed:

    # bs "Amongst the trees, wind, and silent northern lights."
    bs "Entre los árboles, el viento y las silenciosas auroras boreales."

# game/game/script.rpy:10767
translate es notrust_6b56377e:

    # bs "Then maybe I can finally exhale."
    bs "Entonces tal vez pueda finalmente exhalar."

# game/game/script.rpy:10769
translate es notrust_0c571ff2:

    # "He smiles peacefully."
    "Sonríe con paz."

# game/game/script.rpy:10774
translate es notrust_b7d73241:

    # bs "{i}Humanity is cruel.{/i}"
    bs "{i}La humanidad es cruel.{/i}"

# game/game/script.rpy:10776
translate es notrust_0c252ef2:

    # bs "And despite it all, despite the glamor, the advertisements, the campaigns, I am {i}Human{/i}."
    bs "Y a pesar de todo, a pesar del glamour, los anuncios, las campañas, soy {i}Humano{/i}."

# game/game/script.rpy:10778
translate es notrust_7fd6c0c2:

    # "He looks at my scared, doubtful form."
    "Mira mi forma temerosa, llena de duda."

# game/game/script.rpy:10782
translate es notrust_c7e2efa4:

    # bs "I know to you...to some, I probably look like a monster."
    bs "Sé que para ti... para algunos, probablemente parezco un monstruo."

# game/game/script.rpy:10784
translate es notrust_85835ccc:

    # bs "And believe me when I say, I desperately tried to shelter you from that."
    bs "Y créeme cuando digo que desesperadamente traté de protegerte de eso."

# game/game/script.rpy:10786
translate es notrust_eff5ddbd:

    # bs "To everyone else I look like a savior."
    bs "Para los demás parezco un salvador."

# game/game/script.rpy:10790
translate es notrust_cf87b97e:

    # bs "But Frankly, I'm tired of wrestling with stranger's views and expectations of myself, {i}my {/i} identity."
    bs "Pero francamente, estoy cansado de pelear con las percepciones y expectativas ajenas sobre mí, {i}mi{/i} identidad."

# game/game/script.rpy:10794
translate es notrust_4c522d91:

    # bs "I can't stop. I am inexorable."
    bs "No puedo detenerme. Soy inexorable."

# game/game/script.rpy:10796
translate es notrust_5fd7d23a:

    # bs "Only when I see the earth shatter under my force will I be forced to mourn the loss."
    bs "Solo cuando vea la Tierra romperse bajo mi fuerza me veré obligado a lamentar la pérdida."

# game/game/script.rpy:10798
translate es notrust_deab7990:

    # bs "Only as the planet scatters and drifts as a trillion glowing particles will I have to reckon with the conclusion of if I am a 'human' or 'monster'."
    bs "Solo cuando el planeta se disperse y flote como un billón de partículas brillantes tendré que enfrentar la conclusión de si soy 'humano' o 'monstruo'."

# game/game/script.rpy:10800
translate es notrust_d8e89c18:

    # bs "Some part of me thought you could save me."
    bs "Una parte de mí pensó que podías salvarme."

# game/game/script.rpy:10802
translate es notrust_0836893d:

    # "He chuckles in a self depreciating way."
    "Se ríe con una autocrítica amarga."

# game/game/script.rpy:10806
translate es notrust_b9ddf2e0:

    # bs "I realize I was wrong to even place that expectation on you. I am sorry for that %(player_name)s."
    bs "Me doy cuenta de que estaba equivocado al poner esa expectativa en ti. Lo siento por eso %(player_name)s."

# game/game/script.rpy:10808
translate es notrust_e200049d:

    # "The Binary Star hero sheds his mask. He is Ray."
    "El héroe Binary Star se quita la máscara. Es Ray."

# game/game/script.rpy:10832
translate es notrust_a37cd13d:

    # cg "Despite it all, they are one in the same."
    cg "A pesar de todo, son el mismo."

# game/game/script.rpy:10834
translate es notrust_c1afb305:

    # cg "He reaches his hand out towards me."
    cg "Extiende su mano hacia mí."

# game/game/script.rpy:10836
translate es notrust_8a5fcb45:

    # cg "Ray is shining brighter than ever, lighting up the whole room with his divine glow."
    cg "Ray brilla más que nunca, iluminando toda la habitación con su resplandor divino."

# game/game/script.rpy:10838
translate es notrust_9fd8c445:

    # cg "{color=#CD9300} 'Some stars are created by being ripped apart by black holes.' {/color}"
    cg "{color=#CD9300} 'Algunas estrellas se crean al ser desgarradas por agujeros negros.' {/color}"

# game/game/script.rpy:10840
translate es notrust_b0e03561:

    # cg "{color=#CD9300} '%(player_name)s, do you want to be torn apart? Shredded piece by piece, to be born whole, more bright and beautiful than ever before?' {/color}"
    cg "{color=#CD9300} '%(player_name)s, ¿quieres despedazarte? ¿Parte por parte, para renacer completa, más brillante y hermosa que nunca?' {/color}"

# game/game/script.rpy:10842
translate es notrust_06e3e2f8:

    # cg "Some part of me felt it wasn't necessarily a question he was posing."
    cg "Una parte de mí sintió que no era realmente una pregunta."

# game/game/script.rpy:10847
translate es notrust_0d9ee1d7:

    # cg "I take a step back."
    cg "Doy un paso atrás."

# game/game/script.rpy:10856
translate es notrust_fff64959:

    # "Fear takes hold as tears cloud my vision."
    "El miedo se apodera de mí mientras las lágrimas nublan mi visión."

# game/game/script.rpy:10858
translate es notrust_50a228d3:

    # mc "Ray please, don't."
    mc "Ray, por favor, no."

# game/game/script.rpy:10860
translate es notrust_a698c2f3:

    # "Ray looks hurt."
    "Ray parece dolido."

# game/game/script.rpy:10862
translate es notrust_6c8e5c8d:

    # r "After all of this, you will still run from me..?"
    r "¿Después de todo esto, aún huirás de mí..?"

# game/game/script.rpy:10879
translate es notrust_ad041daa:

    # "Binary Star's face falls. The glow snuffs out like a candle, flames fade to nothing in an instant."
    "El rostro de Binary Star decae. El brillo se apaga como una vela, las llamas se desvanecen al instante."

# game/game/script.rpy:10881
translate es notrust_cdf7b287:

    # "I am surrounded by darkness and I am terrified."
    "Me rodea la oscuridad y tengo miedo."

# game/game/script.rpy:10883
translate es notrust_99df54cd:

    # "My flight instincts trigger and I sprint towards the door."
    "Mis instintos de huida se activan y corro hacia la puerta."

# game/game/script.rpy:10890
translate es notrust_7ac8929d:

    # "I reach for the door, desperate."
    "Llego a la puerta, con desespero."

# game/game/script.rpy:10896
translate es notrust_a818d15a:

    # "I crash full force into something soft."
    "Choco de lleno contra algo blando."

# game/game/script.rpy:10909
translate es notrust_fee76d42:

    # cg "{color=#CD9300} 'Really %(player_name)s? I thought you knew better than that by now...' {/color}"
    cg "{color=#CD9300} '¿En serio %(player_name)s? Pensé que ya sabías que eso no funcionaría...' {/color}"

# game/game/script.rpy:10911
translate es notrust_279ff901:

    # cg "{color=#CD9300} 'Running from someone like me?' {/color}"
    cg "{color=#CD9300} '¿Huyendo de alguien como yo?' {/color}"

# game/game/script.rpy:10913
translate es notrust_05968a45:

    # cg "His arm traps me into the corner. I can feel his hot breath dusting my cheek."
    cg "Su brazo me encierra en la esquina. Puedo sentir su aliento cálido rozando mi mejilla."

# game/game/script.rpy:10915
translate es notrust_81cf0eef:

    # cg "{color=#CD9300} 'What is going through that little head of yours to think that was smart?' {/color}"
    cg "{color=#CD9300} '¿Qué pasa por esa cabecita tuya para pensar que eso fue inteligente?' {/color}"

# game/game/script.rpy:10917
translate es notrust_6746e9d0:

    # cg "{color=#CD9300} 'I guess we have to do things the hard way then.' {/color}"
    cg "{color=#CD9300} 'Supongo que tendremos que hacerlo por las malas entonces.' {/color}"

# game/game/script.rpy:10929
translate es notrust_2d63ea23:

    # cg "In the dark a vicious red glow begins to shine."
    cg "En la oscuridad comienza a brillar un resplandor rojo y feroz."

# game/game/script.rpy:10943
translate es notrust_a4adf639:

    # cg "Binary Star smiles."
    cg "Binary Star sonríe."

# game/game/script.rpy:10945
translate es notrust_ff9c37ab:

    # cg "He smiles the same way I have seen a thousand times, among every billboard, poster, magazine."
    cg "Sonríe del mismo modo en que lo he visto mil veces, en cada cartel, póster y revista."

# game/game/script.rpy:10947
translate es notrust_93b93bf3:

    # cg "{color=#CD9300} 'Goodbye, %(player_name)s.' {/color}"
    cg "{color=#CD9300} 'Adiós, %(player_name)s.' {/color}"

# game/game/script.rpy:10972
translate es notrust_2a9d1c3a:

    # cg "A flash of red. A surge of pain."
    cg "Un destello rojo. Una oleada de dolor."

# game/game/script.rpy:10978
translate es notrust_4f1a914a:

    # cg "Everything goes black."
    cg "Todo se vuelve negro."

# game/game/script.rpy:10980
translate es notrust_0edc5fd9:

    # cg "And then, {i}nothing.{/i}"
    cg "Y luego, {i}nada.{/i}"

# game/game/script.rpy:10988
translate es notrust_5f51126e:

    # n "Within a week, an awful war broke out due to alien invasion."
    n "En una semana, estalló una guerra terrible debido a la invasión alienígena."

# game/game/script.rpy:10990
translate es notrust_14be69b3:

    # n "Within a month, all humanity ceased to exist."
    n "En un mes, toda la humanidad dejó de existir."

# game/game/script.rpy:10992
translate es notrust_cc013086:

    # n "Within three months, all living creatures were torn asunder."
    n "En tres meses, todas las criaturas vivientes fueron despedazadas."

# game/game/script.rpy:10994
translate es notrust_2cb66dea:

    # n "Bodies strewn amongst trees, stones, grass. As if it they were innate to the terrain."
    n "Cuerpos esparcidos entre los árboles, las piedras y la hierba. Como si fueran parte del mismo terreno."

# game/game/script.rpy:10996
translate es notrust_3c85e820:

    # n "Within a year, Binary Star had grown tired, lonely."
    n "En el transcurso de un año, Binary Star se había cansado, estaba solo."

# game/game/script.rpy:10998
translate es notrust_4313082f:

    # n "He roamed and mourned, still unable to answer the question that pressed in him demanding a conclusion."
    n "Vagaba y lamentaba, aún incapaz de responder a la pregunta que lo presionaba exigiendo una conclusión."

# game/game/script.rpy:11000
translate es notrust_bb7832c6:

    # n "With a last exhale, Binary Star fulfilled the final purpose he was created for, with the first gift he was ever given."
    n "Con un último suspiro, Binary Star cumplió el propósito final para el que fue creado, con el primer regalo que le fue dado."

# game/game/script.rpy:11002
translate es notrust_17f0e6cc:

    # n "He shined so bright, all of nature was forced to bow before him."
    n "Brilló tan intensamente, que toda la naturaleza se vio obligada a inclinarse ante él."

# game/game/script.rpy:11004
translate es notrust_4d394745:

    # n "And so, for the first time..."
    n "Y así, por primera vez..."

# game/game/script.rpy:11006
translate es notrust_beb5f686:

    # n "Amongst the deafening silence of galaxy dust,"
    n "Entre el ensordecedor silencio del polvo galáctico,"

# game/game/script.rpy:11008
translate es notrust_2edad1bd:

    # n "Ray finally existed."
    n "Ray finalmente existió."

# game/game/script.rpy:11010
translate es notrust_7ede169d:

    # n "Completely alone."
    n "Completamente solo."

# game/game/script.rpy:11020
translate es notrust_25fa7f2a:

    # cg "I take Ray's hand, my heart thumps out of my chest."
    cg "Tomo la mano de Ray, mi corazón late con fuerza fuera del pecho."

# game/game/script.rpy:11022
translate es notrust_5f8cca57:

    # cg "He smiles beautifully, full of cathartic hurt."
    cg "Él sonríe hermosamente, lleno de un dolor catártico."

# game/game/script.rpy:11024
translate es notrust_ce458613:

    # cg "I understood in that moment, that I am the bone that needs to be broken in order to be set in place and heal properly."
    cg "Entendí en ese momento, que soy el hueso que debe romperse para poder colocarse en su lugar y sanar correctamente."

# game/game/script.rpy:11026
translate es notrust_9faa615e:

    # cg "{color=#CD9300} 'The day I met you, was the first day I learned something new about myself.' {/color}"
    cg "{color=#CD9300} 'El día que te conocí, fue el primer día que aprendí algo nuevo sobre mí.' {/color}"

# game/game/script.rpy:11028
translate es notrust_1c4cbfa6:

    # cg "{color=#CD9300} 'I learned that I could love, that I could hope to be human.' {/color}"
    cg "{color=#CD9300} 'Aprendí que podía amar, que podía tener la esperanza de ser humano.' {/color}"

# game/game/script.rpy:11040
translate es notrust_4f3d6f85:

    # cg "Ray holds me close, his hand strokes my cheek."
    cg "Ray me abraza con fuerza, su mano acaricia mi mejilla."

# game/game/script.rpy:11044
translate es notrust_88f4dbca:

    # cg "{color=#CD9300} 'Thankyou for letting me dream %(player_name)s.' {/color}"
    cg "{color=#CD9300} 'Gracias por permitirme soñar %(player_name)s.' {/color}"

# game/game/script.rpy:11046
translate es notrust_dd159b6e:

    # cg "{color=#CD9300} 'I thought I could change, that I could be something other than 'human' or 'monster.' {/color}"
    cg "{color=#CD9300} 'Pensé que podía cambiar, que podía ser algo distinto a 'humano' o 'monstruo'.' {/color}"

# game/game/script.rpy:11048
translate es notrust_7d6f1014:

    # cg "{color=#CD9300} 'But in the end ....' {/color}"
    cg "{color=#CD9300} 'Pero al final...' {/color}"

# game/game/script.rpy:11050
translate es notrust_9d938c8f:

    # cg "{color=#CD9300} '.....' {/color}"
    cg "{color=#CD9300} '.....' {/color}"

# game/game/script.rpy:11052
translate es notrust_047e8ec9:

    # cg "{color=#CD9300} 'But in the end I have a Quasar that shines around me like a halo.' {/color}"
    cg "{color=#CD9300} 'Pero al final tengo un Quásar que brilla a mi alrededor como un halo.' {/color}"

# game/game/script.rpy:11054
translate es notrust_a3a970ad:

    # cg "{color=#CD9300} 'It pulls matter from everything else around it into a single volatile ring' {/color}"
    cg "{color=#CD9300} 'Extrae materia de todo lo que lo rodea hasta formar un único anillo volátil.' {/color}"

# game/game/script.rpy:11056
translate es notrust_b4ec8ca4:

    # cg "{color=#CD9300} 'That ring will shred and swallow until it's had it's fill.' {/color}"
    cg "{color=#CD9300} 'Ese anillo destrozará y devorará hasta saciarse.' {/color}"

# game/game/script.rpy:11058
translate es notrust_dccb8bcb:

    # cg "{color=#CD9300} 'Until nothing else can be cannibalized.' {/color}"
    cg "{color=#CD9300} 'Hasta que ya no quede nada más por consumir.' {/color}"

# game/game/script.rpy:11060
translate es notrust_764459ac:

    # cg "{color=#CD9300} 'It will rage on and on until it fades away from existence completely.' {/color}"
    cg "{color=#CD9300} 'Continuará su furia sin fin hasta desvanecerse completamente de la existencia.' {/color}"

# game/game/script.rpy:11062
translate es notrust_7c705277:

    # cg "He brushes some soot off of my forehead."
    cg "Limpia un poco de hollín de mi frente."

# game/game/script.rpy:11064
translate es notrust_6b283443:

    # cg "He pauses, looking upon my face. A moment of hesitation clouds his features."
    cg "Hace una pausa, observando mi rostro. Un momento de duda nubla sus facciones."

# game/game/script.rpy:11067
translate es notrust_83a2f162:

    # cg "I look up at Ray."
    cg "Levanto la mirada hacia Ray."

# game/game/script.rpy:11072
translate es notrust_85807684:

    # cg "{color=#510f80} 'Ray, I hope you find what you are looking for.' {/color}"
    cg "{color=#510f80} 'Ray, espero que encuentres lo que estás buscando.' {/color}"

# game/game/script.rpy:11074
translate es notrust_643d6a66:

    # cg "Ray looks upon my face with a indecipherable smile and a sigh."
    cg "Ray me observa con una sonrisa indescifrable y un suspiro."

# game/game/script.rpy:11076
translate es notrust_e19d8e7d:

    # cg "There is a sadness that lurks in his dark eyes."
    cg "Hay una tristeza que acecha en sus oscuros ojos."

# game/game/script.rpy:11078
translate es notrust_71814540:

    # cg "He brushes a tear away from my cheek."
    cg "Limpia una lágrima de mi mejilla."

# game/game/script.rpy:11080
translate es notrust_9990c537:

    # cg "{color=#CD9300} 'Don't cry %(player_name)s...'{/color}"
    cg "{color=#CD9300} 'No llores %(player_name)s...'{/color}"

# game/game/script.rpy:11082
translate es notrust_e26ecaec:

    # cg "{color=#CD9300} 'I will keep you with me forever.' {/color}"
    cg "{color=#CD9300} 'Te llevaré conmigo para siempre.' {/color}"

# game/game/script.rpy:11084
translate es notrust_2a3d088e:

    # cg "Ray takes my face into his hands."
    cg "Ray toma mi rostro entre sus manos."

# game/game/script.rpy:11086
translate es notrust_2544d2f4:

    # cg "In a moment that both felt shorter than a thought and longer than an eternity, Ray presses his face to mine."
    cg "En un momento que pareció más corto que un pensamiento y más largo que una eternidad, Ray acerca su rostro al mío."

# game/game/script.rpy:11100
translate es notrust_c5e3712f:

    # cg "His lips passionately gain purchase amongst my own."
    cg "Sus labios se aferran con pasión a los míos."

# game/game/script.rpy:11102
translate es notrust_f5328882:

    # cg "I push back, desperately trying to convey what words can not."
    cg "Respondo, intentando desesperadamente transmitir lo que las palabras no pueden."

# game/game/script.rpy:11104
translate es notrust_56c07627:

    # cg "At that moment I feel the sun. Everything radiates. My heart beats, my skin hums."
    cg "En ese momento siento el sol. Todo irradia. Mi corazón late, mi piel vibra."

# game/game/script.rpy:11106
translate es notrust_67d51b76:

    # cg "I feel metamorphosis."
    cg "Siento una metamorfosis."

# game/game/script.rpy:11108
translate es notrust_ff778334:

    # cg "I look at Ray, he shines."
    cg "Miro a Ray, él brilla."

# game/game/script.rpy:11130
translate es notrust_7128ef87:

    # cg "Parts of me fade, being pulled apart, shredded into dust by the star before me."
    cg "Partes de mí se desvanecen, siendo arrancadas, desmenuzadas en polvo por la estrella ante mí."

# game/game/script.rpy:11132
translate es notrust_6d695535:

    # cg "Ray holds me in his arms. he kisses me desperately between sweet murmured words."
    cg "Ray me sostiene en sus brazos. Me besa con desesperación entre dulces murmullos."

# game/game/script.rpy:11134
translate es notrust_8f98b1df:

    # cg "I can taste the wet salt that runs down his cheeks and falls between our lips."
    cg "Puedo saborear la sal húmeda que corre por sus mejillas y cae entre nuestros labios."

# game/game/script.rpy:11136
translate es notrust_66f19010:

    # cg "He holds me tighter, wrapped in my own cocoon. I can no longer talk, I can no longer see."
    cg "Me abraza más fuerte, envueltos en mi propio capullo. Ya no puedo hablar, ya no puedo ver."

# game/game/script.rpy:11138
translate es notrust_0718946d:

    # cg "Soon my mind is no longer my own."
    cg "Pronto mi mente ya no me pertenece."

# game/game/script.rpy:11140
translate es notrust_838ea291:

    # cg "I shine with Ray, brilliance spread amongst matter and being."
    cg "Brillo junto a Ray, esplendor extendido entre la materia y el ser."

# game/game/script.rpy:11142
translate es notrust_f0a7a0f8:

    # cg "I fade. I am reborn."
    cg "Me desvanezco. Renazco."

# game/game/script.rpy:11162
translate es notrust_ef59cf13:

    # cg "I give ray a bold look."
    cg "Miro a Ray con determinación."

# game/game/script.rpy:11164
translate es notrust_4060b1dd:

    # cg "{color=#510f80} 'Save me Ray.' {/color}"
    cg "{color=#510f80} 'Sálvame, Ray.' {/color}"

# game/game/script.rpy:11166
translate es notrust_7df898c5:

    # cg "{color=#510f80} 'You told me to call out to you for help, now I am.' {/color}"
    cg "{color=#510f80} 'Me dijiste que te llamara cuando necesitara ayuda, y ahora lo hago.' {/color}"

# game/game/script.rpy:11168
translate es notrust_dac12658:

    # cg "{color=#510f80} 'I don't want 'Binary Star' to save me, I don't want him.' {/color}"
    cg "{color=#510f80} 'No quiero que me salve 'Binary Star', no lo quiero a él.' {/color}"

# game/game/script.rpy:11170
translate es notrust_f74482f5:

    # cg "{color=#510f80} 'I want you. I'm asking {i}you, {/i}Ray.' {/color}"
    cg "{color=#510f80} 'Te quiero a ti. Te lo pido {i}a ti,{/i} Ray.' {/color}"

# game/game/script.rpy:11172
translate es notrust_94067ab6:

    # cg "{color=#510f80} 'I want to stay with you.' {/color}"
    cg "{color=#510f80} 'Quiero quedarme contigo.' {/color}"

# game/game/script.rpy:11174
translate es notrust_a887a41e:

    # cg "{color=#510f80} 'I don't want oblivion, I don't want silence. I don't want a greater purpose. I want you. {i}I want to be with you.{/i}' {/color}"
    cg "{color=#510f80} 'No quiero el olvido, no quiero el silencio. No quiero un propósito superior. Te quiero a ti. {i}Quiero estar contigo.{/i}' {/color}"

# game/game/script.rpy:11176
translate es notrust_d030ff59:

    # cg "{color=#510f80} 'Human or monster, it doesn't matter. I don't care.' {/color}"
    cg "{color=#510f80} 'Humano o monstruo, no importa. No me importa.' {/color}"

# game/game/script.rpy:11178
translate es notrust_6a61a1f8:

    # cg "{color=#CD9300} 'You will never trust me...' {/color}"
    cg "{color=#CD9300} 'Nunca confiarás en mí...' {/color}"

# game/game/script.rpy:11180
translate es notrust_ed617f97:

    # cg "I can't help but to laugh, even in these circumstances."
    cg "No puedo evitar reír, incluso en estas circunstancias."

# game/game/script.rpy:11182
translate es notrust_887bf6f0:

    # cg "{color=#510f80} 'Ray, after everything, do you really expect me to be able to trust you?' {/color}"
    cg "{color=#510f80} 'Ray, después de todo, ¿realmente esperas que pueda confiar en ti?' {/color}"

# game/game/script.rpy:11184
translate es notrust_6119a320:

    # cg "{color=#510f80} 'You hardly have ever given me a reason to trust you.' {/color}"
    cg "{color=#510f80} 'Casi nunca me has dado una razón para hacerlo.' {/color}"

# game/game/script.rpy:11186
translate es notrust_d9ec0ecb:

    # cg "{color=#510f80}'But I can tell that....you care for me and..' {/color}"
    cg "{color=#510f80} 'Pero puedo notar que... te importo y...' {/color}"

# game/game/script.rpy:11188
translate es notrust_1a8862d4:

    # cg "{color=#510f80} 'All I know is... some part of me does love you and I don't want to throw that away because of some uncertainty.' {/color}"
    cg "{color=#510f80} 'Todo lo que sé es que... una parte de mí sí te ama y no quiero desechar eso por una simple incertidumbre.' {/color}"

# game/game/script.rpy:11190
translate es notrust_904d84ec:

    # cg "{color=#510f80} 'I want to try and learn to trust you. The {i}real{/i} you.' {/color}"
    cg "{color=#510f80} 'Quiero intentar aprender a confiar en ti. En el {i}verdadero{/i} tú.' {/color}"

# game/game/script.rpy:11192
translate es notrust_711027c4:

    # cg "Ray looks at me, like he doesn't quite know what to say."
    cg "Ray me mira, como si no supiera qué decir."

# game/game/script.rpy:11194
translate es notrust_22c85002:

    # cg "{color=#510f80} 'I want to go on normal dates with you.' {/color}"
    cg "{color=#510f80} 'Quiero tener citas normales contigo.' {/color}"

# game/game/script.rpy:11196
translate es notrust_2bfbbb3c:

    # cg "{color=#510f80} 'I want to get in fights, cry, apologize, laugh, have awkward misunderstandings. I want to surmount differences together.' {/color}"
    cg "{color=#510f80} 'Quiero discutir, llorar, disculparme, reír, tener malentendidos incómodos. Quiero superar las diferencias juntos.' {/color}"

# game/game/script.rpy:11198
translate es notrust_d8459c42:

    # cg "{color=#CD9300} '...' {/color}"
    cg "{color=#CD9300} '...' {/color}"

# game/game/script.rpy:11200
translate es notrust_ecbb93ef:

    # cg "{color=#510f80} 'All this time... you have been what people wanted you to be.' {/color}"
    cg "{color=#510f80} 'Todo este tiempo... has sido lo que la gente quería que fueras.' {/color}"

# game/game/script.rpy:11202
translate es notrust_f2d1ca46:

    # cg "{color=#510f80} 'But the truth is, I don't {i}want {/i} you to {i}be {/i} anyone. I want to grow into someone with you.' {/color}"
    cg "{color=#510f80} 'Pero la verdad es que no {i}quiero{/i} que {i}seas{/i} nadie. Quiero crecer junto a ti.' {/color}"

# game/game/script.rpy:11204
translate es notrust_59dbc219:

    # cg "{color=#CD9300} 'Even if I am not....The hero Binary Star that you want?'{/color}"
    cg "{color=#CD9300} '¿Incluso si no soy... el héroe Binary Star que quieres?' {/color}"

# game/game/script.rpy:11206
translate es notrust_7a551e3b:

    # cg "{color=#510f80} 'I fell for 'Ray' in the coffee shop, not the edited hero on the magazine.' {/color}"
    cg "{color=#510f80} 'Me enamoré de 'Ray' en la cafetería, no del héroe retocado de las revistas.' {/color}"

# game/game/script.rpy:11208
translate es notrust_b0436506:

    # cg "{color=#510f80} 'And I'm not ready to give that up yet.' {/color}"
    cg "{color=#510f80} 'Y no quiero renunciar a eso todavía.' {/color}"

# game/game/script.rpy:11210
translate es notrust_86e38337:

    # cg "{color=#510f80} 'So please, give us a chance to figure this out together.' {/color}"
    cg "{color=#510f80} 'Así que por favor, danos una oportunidad para descubrir esto juntos.' {/color}"

# game/game/script.rpy:11212
translate es notrust_a447d310:

    # cg "{color=#510f80} 'Please, hold on a bit longer, defend this planet a bit longer. Please don't give up on this...on us!' {/color}"
    cg "{color=#510f80} 'Por favor, resiste un poco más, defiende este planeta un poco más. ¡Por favor, no te rindas con esto... con nosotros!' {/color}"

# game/game/script.rpy:11214
translate es notrust_7429ff9c:

    # cg "I entangle our fingers together."
    cg "Entrelazo nuestros dedos."

# game/game/script.rpy:11216
translate es notrust_3ada79ea:

    # cg "Ray is silent as he watches me."
    cg "Ray guarda silencio mientras me observa."

# game/game/script.rpy:11232
translate es notrust_9ef1cd43:

    # cg "His shoulders slump into a tired posture."
    cg "Sus hombros caen en una postura cansada."

# game/game/script.rpy:11234
translate es notrust_e678cfe0:

    # cg "He gives a deep exhale of air."
    cg "Exhala profundamente."

# game/game/script.rpy:11237
translate es notrust_01ccde2b:

    # cg "{color=#510f80} 'I promise I will make you the best black coffee.' {/color}"
    cg "{color=#510f80} 'Te prometo que te prepararé el mejor café negro.' {/color}"

# game/game/script.rpy:11239
translate es notrust_855f1149:

    # cg "Ray's eyes crinkle."
    cg "Los ojos de Ray se entrecierran con una leve sonrisa."

# game/game/script.rpy:11241
translate es notrust_4fc3e4b0:

    # cg "{color=#CD9300} 'That is an offer I can't turn down.' {/color}"
    cg "{color=#CD9300} 'Esa es una oferta que no puedo rechazar.' {/color}"

# game/game/script.rpy:11243
translate es notrust_1bab8ed7:

    # cg "{color=#CD9300} 'This is a money-back guarantee right?' {/color}"
    cg "{color=#CD9300} 'Esto tiene garantía de devolución, ¿cierto?' {/color}"

# game/game/script.rpy:11245
translate es notrust_33129345:

    # cg "He squeezes my hand lightly."
    cg "Aprieta suavemente mi mano."

# game/game/script.rpy:11247
translate es notrust_08e2e9ba:

    # cg "I crack a smile, even under these circumstances."
    cg "Esbozo una sonrisa, incluso en estas circunstancias."

# game/game/script.rpy:11249
translate es notrust_3e9fe4a8:

    # cg "{color=#510f80} 'Always.'{/color}"
    cg "{color=#510f80} 'Siempre.' {/color}"

# game/game/script.rpy:11251
translate es notrust_e8ac59f7:

    # cg "In a instant ray places a sweet kiss on my lips, he lifts me up easily in his arms."
    cg "En un instante, Ray coloca un dulce beso en mis labios y me levanta fácilmente en sus brazos."

# game/game/script.rpy:11253
translate es notrust_d77e0ffb:

    # cg "{color=#510f80} 'Ray?!' {/color}"
    cg "{color=#510f80} '¿¡Ray?!' {/color}"

# game/game/script.rpy:11255
translate es notrust_a565f091:

    # cg "I gasp in shock."
    cg "Exhalo sorprendida."

# game/game/script.rpy:11257
translate es notrust_99e23669:

    # cg "{color=#CD9300} 'What?' {/color}"
    cg "{color=#CD9300} '¿Qué?' {/color}"

# game/game/script.rpy:11259
translate es notrust_41005eaa:

    # cg "He looks down at me with a coy smirk."
    cg "Me mira con una sonrisa pícara."

# game/game/script.rpy:11261
translate es notrust_2aac4ad3:

    # cg "{color=#CD9300} 'I'm really craving some exclusive %(player_name)s's black coffee right now, aren't you?' {/color}"
    cg "{color=#CD9300} 'Realmente tengo antojo del café negro exclusivo de %(player_name)s ahora mismo, ¿no tú?' {/color}"

# game/game/script.rpy:11263
translate es notrust_c078f22d:

    # cg "His face is so close to mine I can't help but to look away. He chuckles."
    cg "Su rostro está tan cerca del mío que no puedo evitar apartar la mirada. Se ríe."

# game/game/script.rpy:11265
translate es notrust_c267eab4:

    # cg "{color=#CD9300} 'Wrap your arms around my neck and hold on tight.'{/color}"
    cg "{color=#CD9300} 'Rodea mi cuello con tus brazos y agárrate fuerte.' {/color}"

# game/game/script.rpy:11275
translate es notrust_fbaf247b:

    # cg "I do as I'm told and in an instant we are in the air flying."
    cg "Hago lo que me dice y, en un instante, estamos volando por el aire."

# game/game/script.rpy:11277
translate es notrust_c854ef27:

    # cg "The night sky is beautiful but the cold air makes me shiver."
    cg "El cielo nocturno es hermoso, pero el aire frío me hace estremecer."

# game/game/script.rpy:11279
translate es notrust_7ae08cc5:

    # cg "Ray holds me a bit tighter, draping his iconic cape over my back."
    cg "Ray me sostiene un poco más fuerte, cubriéndome la espalda con su icónica capa."

# game/game/script.rpy:11281
translate es notrust_0833f8a2:

    # cg "Ray is still an enigma to me."
    cg "Ray sigue siendo un enigma para mí."

# game/game/script.rpy:11283
translate es notrust_74283755:

    # cg "Some part of me thinks I will never quite understand him."
    cg "Una parte de mí piensa que nunca llegaré a entenderlo por completo."

# game/game/script.rpy:11285
translate es notrust_adc23e27:

    # cg "But for the first time we have some semblance of understanding between us."
    cg "Pero por primera vez tenemos una especie de entendimiento entre los dos."

# game/game/script.rpy:11287
translate es notrust_fdcc045b:

    # cg "And it makes me want to learn more about who 'Ray' is."
    cg "Y eso me hace querer aprender más sobre quién es realmente 'Ray'."

# game/game/script.rpy:11289
translate es notrust_f282d069:

    # cg "I want to discover the Bad, the good, and the deep dark shadows that are cast from his luminosity."
    cg "Quiero descubrir lo malo, lo bueno y las sombras profundas que se proyectan desde su luminosidad."

# game/game/script.rpy:11291
translate es notrust_eb0c4651:

    # cg "I close my eyes squeezing Ray tight, hoping, praying to anyone for a future that is kind."
    cg "Cierro los ojos abrazando con fuerza a Ray, esperando, rezando a quien sea por un futuro que sea bondadoso."

# game/game/script.rpy:11308
translate es notrust_85807684_1:

    # cg "{color=#510f80} 'Ray, I hope you find what you are looking for.' {/color}"
    cg "{color=#510f80} 'Ray, espero que encuentres lo que estás buscando.' {/color}"

# game/game/script.rpy:11310
translate es notrust_643d6a66_1:

    # cg "Ray looks upon my face with a indecipherable smile and a sigh."
    cg "Ray me observa con una sonrisa indescifrable y un suspiro."

# game/game/script.rpy:11312
translate es notrust_e19d8e7d_1:

    # cg "There is a sadness that lurks in his dark eyes."
    cg "Hay una tristeza que acecha en sus oscuros ojos."

# game/game/script.rpy:11314
translate es notrust_71814540_1:

    # cg "He brushes a tear away from my cheek."
    cg "Limpia una lágrima de mi mejilla."

# game/game/script.rpy:11316
translate es notrust_9990c537_1:

    # cg "{color=#CD9300} 'Don't cry %(player_name)s...'{/color}"
    cg "{color=#CD9300} 'No llores %(player_name)s...'{/color}"

# game/game/script.rpy:11318
translate es notrust_e26ecaec_1:

    # cg "{color=#CD9300} 'I will keep you with me forever.' {/color}"
    cg "{color=#CD9300} 'Te llevaré conmigo para siempre.' {/color}"

# game/game/script.rpy:11320
translate es notrust_2a3d088e_1:

    # cg "Ray takes my face into his hands."
    cg "Ray toma mi rostro entre sus manos."

# game/game/script.rpy:11322
translate es notrust_8787f989:

    # cg "In a moment that both felt shorter than a second and longer than an eternity. Ray presses his face to mine."
    cg "En un momento que pareció más corto que un segundo y más largo que una eternidad, Ray acerca su rostro al mío."

# game/game/script.rpy:11336
translate es notrust_c5e3712f_1:

    # cg "His lips passionately gain purchase amongst my own."
    cg "Sus labios se aferran con pasión a los míos."

# game/game/script.rpy:11338
translate es notrust_f5328882_1:

    # cg "I push back, desperately trying to convey what words can not."
    cg "Respondo, intentando desesperadamente transmitir lo que las palabras no pueden."

# game/game/script.rpy:11340
translate es notrust_56c07627_1:

    # cg "At that moment I feel the sun. Everything radiates. My heart beats, my skin hums."
    cg "En ese momento siento el sol. Todo irradia. Mi corazón late, mi piel vibra."

# game/game/script.rpy:11342
translate es notrust_67d51b76_1:

    # cg "I feel metamorphosis."
    cg "Siento una metamorfosis."

# game/game/script.rpy:11344
translate es notrust_ff778334_1:

    # cg "I look at Ray, he shines."
    cg "Miro a Ray, él brilla."

# game/game/script.rpy:11363
translate es notrust_7128ef87_1:

    # cg "Parts of me fade, being pulled apart, shredded into dust by the star before me."
    cg "Partes de mí se desvanecen, siendo arrancadas, desmenuzadas en polvo por la estrella ante mí."

# game/game/script.rpy:11365
translate es notrust_6d695535_1:

    # cg "Ray holds me in his arms. he kisses me desperately between sweet murmured words."
    cg "Ray me sostiene en sus brazos. Me besa con desesperación entre dulces murmullos."

# game/game/script.rpy:11367
translate es notrust_8f98b1df_1:

    # cg "I can taste the wet salt that runs down his cheeks and falls between our lips."
    cg "Puedo saborear la sal húmeda que corre por sus mejillas y cae entre nuestros labios."

# game/game/script.rpy:11369
translate es notrust_66f19010_1:

    # cg "He holds me tighter, wrapped in my own cocoon. I can no longer talk, I can no longer see."
    cg "Me abraza más fuerte, envueltos en mi propio capullo. Ya no puedo hablar, ya no puedo ver."

# game/game/script.rpy:11371
translate es notrust_0718946d_1:

    # cg "Soon my mind is no longer my own."
    cg "Pronto mi mente ya no me pertenece."

# game/game/script.rpy:11373
translate es notrust_838ea291_1:

    # cg "I shine with Ray, brilliance spread amongst matter and being."
    cg "Brillo junto a Ray, esplendor extendido entre la materia y el ser."

# game/game/script.rpy:11375
translate es notrust_f0a7a0f8_1:

    # cg "I fade. I am reborn."
    cg "Me desvanezco. Renazco."

# game/game/script.rpy:11395
translate es dblending_f499b06c:

    # "I crawled towards the front door."
    "Me arrastré hacia la puerta principal."

# game/game/script.rpy:11399
translate es dblending_7d8070eb:

    # "{i}It's open! I can escape!{/i}"
    "{i}¡Está abierta! ¡Puedo escapar!{/i}"

# game/game/script.rpy:11404
translate es dblending_d32403ba:

    # "I thanked whatever gods may have been watching over me."
    "Agradecí a los dioses que pudieran estar vigilándome."

# game/game/script.rpy:11406
translate es dblending_d1897c58:

    # "Crawling out into the hallway, I was able to get some more fresh air."
    "Arrastrándome hacia el pasillo, logré conseguir un poco más de aire fresco."

# game/game/script.rpy:11413
translate es dblending_3c457956:

    # "With adrenaline kicked in, I was up on my feet and running in no time."
    "Con la adrenalina en su punto máximo, me puse de pie y corrí sin perder tiempo."

# game/game/script.rpy:11416
translate es dblending_3632f880:

    # "I sprint down the stairs and out the front door. My lungs burned as if they caught fire as well."
    "Bajé las escaleras y salí por la puerta principal. Mis pulmones ardían como si también se incendiaran."

# game/game/script.rpy:11423
translate es dblending_90a1ae69:

    # "Making my way to the street, I can't help but to find the silence...odd."
    "Al llegar a la calle, no pude evitar encontrar extraño el silencio..."

# game/game/script.rpy:11425
translate es dblending_2e6c49bd:

    # "A fire this big and there were no emergency vehicles?"
    "¿Un fuego tan grande y no había vehículos de emergencia?"

# game/game/script.rpy:11429
translate es dblending_ddc4c389:

    # "I needed to find someone to call for help before the fire spreads putting anyone else in danger."
    "Necesitaba encontrar a alguien para pedir ayuda antes de que el fuego se extendiera y pusiera a otros en peligro."

# game/game/script.rpy:11431
translate es dblending_d7065ae9:

    # "As I reached the alleyway to the main street, the adrenaline was wearing off and my legs shook threatening to give out."
    "Al llegar al callejón que daba a la calle principal, la adrenalina comenzó a desvanecerse y mis piernas temblaban, amenazando con colapsar."

# game/game/script.rpy:11433
translate es dblending_e8de6cbb:

    # "I leaned up against the wall, gasping for air."
    "Me apoyé contra la pared, jadeando por aire."

# game/game/script.rpy:11435
translate es dblending_15e5cdf7:

    # "I could only hear the sound of my blood rushing and my heart pounding wildly."
    "Solo podía oír el sonido de mi sangre fluyendo y mi corazón latiendo con fuerza."

# game/game/script.rpy:11439
translate es dblending_6dc02b93:

    # "Suddenly a hand covered my face and I felt a feeling that was {i}all too familiar{/i}."
    "De repente, una mano cubrió mi rostro y sentí una sensación {i}demasiado familiar{/i}."

# game/game/script.rpy:11441
translate es dblending_cb858a53:

    # "My body felt the rush through time and space before collapsing into reality again."
    "Mi cuerpo sintió la sacudida a través del tiempo y el espacio antes de colapsar nuevamente en la realidad."

# game/game/script.rpy:11443
translate es dblending_40be7339:

    # "I look up already knowing who I would find when the hand was moved from my face."
    "Miro hacia arriba, ya sabiendo quién estaría allí cuando retiraran la mano de mi rostro."

# game/game/script.rpy:11459
translate es dblending_5aedb3f1:

    # cg "{color=#1F28AD} 'What's with the nasty look?' {/color}"
    cg "{color=#1F28AD} '¿Y esa cara tan fea?' {/color}"

# game/game/script.rpy:11461
translate es dblending_c3b7b181:

    # cg "I glance around trying to figure out where exactly Double landed us."
    cg "Miro alrededor, intentando averiguar exactamente dónde Double nos había llevado."

# game/game/script.rpy:11463
translate es dblending_11ceb94d:

    # cg "{color=#510f80} '...' {/color}"
    cg "{color=#510f80} '...' {/color}"

# game/game/script.rpy:11468
translate es dblending_900a24dc:

    # cg "{color=#1F28AD} 'Don't worry, I didn't phase you too far.' {/color}"
    cg "{color=#1F28AD} 'No te preocupes, no te desfasé demasiado.' {/color}"

# game/game/script.rpy:11470
translate es dblending_6a60147c:

    # cg " {color=#1F28AD} 'Just far enough away that we don't have to worry about any {i}interruptions{/i}.' {/color}"
    cg "{color=#1F28AD} 'Solo lo suficiente para que no tengamos que preocuparnos por ninguna {i}interrupción{/i}.' {/color}"

# game/game/script.rpy:11472
translate es dblending_3bea49ba:

    # cg "{color=#510f80} 'Don't touch me. Get away from me!' {/color}"
    cg "{color=#510f80} '¡No me toques! ¡Aléjate de mí!' {/color}"

# game/game/script.rpy:11479
translate es dblending_929b1e45:

    # cg "I back up, stumbling and catching myself over some garbage."
    cg "Retrocedo, tropezando y sosteniéndome sobre un montón de basura."

# game/game/script.rpy:11481
translate es dblending_cd5caa73:

    # cg "{color=#510f80} 'When Binary Star finds you he is going to...'"
    cg "{color=#510f80} 'Cuando Binary Star te encuentre, él va a...'"

# game/game/script.rpy:11483
translate es dblending_aae69f02:

    # cg "{color=#1F28AD} 'Do what exactly? 'Bring me to justice'?' {/color}"
    cg "{color=#1F28AD} '¿Hacer qué exactamente? ¿'Llevarme ante la justicia'?' {/color}"

# game/game/script.rpy:11485
translate es dblending_4b544314:

    # cg "Double cackles. It is cold and humorless."
    cg "Double suelta una carcajada. Es fría y sin humor."

# game/game/script.rpy:11487
translate es dblending_4951a699:

    # cg "{color=#1F28AD} 'Grow a brain honey, you should be thanking me.' {/color}"
    cg "{color=#1F28AD} 'Usa la cabeza, cariño, deberías estar agradeciéndome.' {/color}"

# game/game/script.rpy:11489
translate es dblending_2e79096f:

    # cg "{color=#1F28AD} 'You are lucky I got to you first [criminalname].' {/color}"
    cg "{color=#1F28AD} 'Tienes suerte de que yo te encontrara primero [criminalname].' {/color}"

# game/game/script.rpy:11491
translate es dblending_6f461322:

    # cg "{color=#1F28AD} 'Who know what {i}he {/i} would have done.' {/color}"
    cg "{color=#1F28AD} 'Quién sabe lo que {i}él{/i} te habría hecho.' {/color}"

# game/game/script.rpy:11493
translate es dblending_2388c2c6:

    # cg "I continue to catch my breath, glaring up at him."
    cg "Sigo recuperando el aliento, mirándolo con furia."

# game/game/script.rpy:11495
translate es dblending_b3d4d98b:

    # cg "{color=#510f80} 'Binary Star would have saved me.' {/color}"
    cg "{color=#510f80} 'Binary Star me habría salvado.' {/color}"

# game/game/script.rpy:11497
translate es dblending_28e1676c:

    # cg "He tilts his head. Double's eyes crinkle."
    cg "Él inclina la cabeza. Los ojos de Double se entrecierran."

# game/game/script.rpy:11499
translate es dblending_32f73cd2:

    # cg "{color=#1F28AD} 'Are you sure about that?' {/color}"
    cg "{color=#1F28AD} '¿Tienes seguridad de eso?' {/color}"

# game/game/script.rpy:11501
translate es dblending_49c8e637:

    # cg "{color=#1F28AD} 'You really can't be {b}this{/b} ignorant %(player_name)s.' {/color}"
    cg "{color=#1F28AD} 'De verdad no puedes tener {b}tanta{/b} ingenuidad %(player_name)s.' {/color}"

# game/game/script.rpy:11503
translate es dblending_9a27c3a4:

    # cg "{color=#1F28AD} 'He told you didn't he? About his abilities...or rather, {i}ability{/i}.' {/color}"
    cg "{color=#1F28AD} 'Te lo dijo, ¿no? Sobre sus habilidades... o mejor dicho, su {i}habilidad{/i}.' {/color}"

# game/game/script.rpy:11505
translate es dblending_0ac4f480:

    # cg "I look at Double, my silence speak volumes."
    cg "Miro a Double, mi silencio lo dice todo."

# game/game/script.rpy:11507
translate es dblending_99f66144:

    # cg "{color=#1F28AD} 'Then {i}think{/i}. Use your fucking {i}brain{/i}.' {/color}"
    cg "{color=#1F28AD} 'Entonces {i}piensa{/i}. Usa tu maldito {i}cerebro{/i}.' {/color}"

# game/game/script.rpy:11509
translate es dblending_01875221:

    # cg "{color=#1F28AD} 'Before you went to sleep, did you leave anything plugged in?' {/color}"
    cg "{color=#1F28AD} 'Antes de dormir, ¿dejaste algo enchufado?' {/color}"

# game/game/script.rpy:11511
translate es dblending_62124189:

    # cg "{color=#1F28AD} 'When you woke up to your apartment already covered in flames.. Did you smell any gas, any gasoline?' {/color}"
    cg "{color=#1F28AD} 'Cuando despertaste y tu apartamento ya estaba envuelto en llamas... ¿oliste gas, gasolina?' {/color}"

# game/game/script.rpy:11513
translate es dblending_adde76a4:

    # cg "My eyes widen at what Double is insinuating."
    cg "Mis ojos se abren ante lo que Double está insinuando."

# game/game/script.rpy:11515
translate es dblending_a7c4ef79:

    # cg "{color=#1F28AD} 'How were you able to sleep through your apartment catching on fire [criminalname]?' {/color}"
    cg "{color=#1F28AD} '¿Cómo pudiste dormir mientras tu apartamento se incendiaba [criminalname]?' {/color}"

# game/game/script.rpy:11517
translate es dblending_0e363a96:

    # cg "{color=#510f80} 'There's...there's no way...' {/color}"
    cg "{color=#510f80} 'No... no puede ser...' {/color}"

# game/game/script.rpy:11519
translate es dblending_5b2709c3:

    # cg "{color=#510f80} 'You...you must have done this...!' {/color}"
    cg "{color=#510f80} '¡Tú... tú debiste haber hecho esto...!' {/color}"

# game/game/script.rpy:11521
translate es dblending_7c2e60be:

    # cg "Double cackles loudly."
    cg "Double ríe a carcajadas."

# game/game/script.rpy:11523
translate es dblending_7beef350:

    # cg "{color=#1F28AD} {b}'Do you hear yourself?!' {/b} {/color}"
    cg "{color=#1F28AD} {b}'¿Te estas escuchando?!'{/b} {/color}"

# game/game/script.rpy:11525
translate es dblending_bff15dc1:

    # cg "{color=#1F28AD} 'Think [criminalname], who bothered you at the cafe?'{/color}"
    cg "{color=#1F28AD} 'Piensa [criminalname], ¿quién te molestó en el café?'{/color}"

# game/game/script.rpy:11527
translate es dblending_cad5160f:

    # cg "{color=#510f80} 'No...' {/color}"
    cg "{color=#510f80} 'No...' {/color}"

# game/game/script.rpy:11529
translate es dblending_bf23589c:

    # cg "{color=#1F28AD}{i}'Yes'{/i}. {/color}"
    cg "{color=#1F28AD}{i}'Sí.'{/i} {/color}"

# game/game/script.rpy:11531
translate es dblending_77c38dc0:

    # cg "{color=#1F28AD}'Binary Star took out the trash.'{/color}"
    cg "{color=#1F28AD}'Binary Star se encargó de la basura.'{/color}"

# game/game/script.rpy:11533
translate es dblending_52bcbee6:

    # cg "{color=#1F28AD}'And if I didn't come collect you, guess who would have been next?'{/color}"
    cg "{color=#1F28AD}'Y si yo no hubiera venido a recogerte, ¿adivina quién habría sido el siguiente?'{/color}"

# game/game/script.rpy:11535
translate es dblending_c57b05f8:

    # cg "{color=#510f80} 'No, that doesn't make sense...why would he want to kill me...?' {/color}"
    cg "{color=#510f80} 'No, eso no tiene sentido... ¿por qué iba a querer matarme...?' {/color}"

# game/game/script.rpy:11537
translate es dblending_1cb85943:

    # cg "{color=#1F28AD} 'Who knows what that psycho is thinking.'{/color}"
    cg "{color=#1F28AD} 'Quién sabe lo que pasa por la cabeza de ese psicópata.'{/color}"

# game/game/script.rpy:11539
translate es dblending_f7e0e53a:

    # cg "{color=#1F28AD}'I really shouldn't have saved you...'{/color}"
    cg "{color=#1F28AD}'Realmente no debería haberte salvado...'{/color}"

# game/game/script.rpy:11541
translate es dblending_3d6e750c:

    # cg "{color=#1F28AD}'But the thought of someone else, anyone else torching you alive didn't really sit right with me.'{/color}"
    cg "{color=#1F28AD}'Pero la idea de que alguien más, cualquiera, te quemara en viva no me sentó bien.'{/color}"

# game/game/script.rpy:11543
translate es dblending_b4bd7f28:

    # cg "{color=#1F28AD}'So let's go back to old times, new city, new us.'{/color}"
    cg "{color=#1F28AD}'Así que volvamos a los viejos tiempos, nueva ciudad, nuevos nosotros.'{/color}"

# game/game/script.rpy:11545
translate es dblending_74ec451e:

    # cg "{color=#1F28AD}'Don't worry [criminalname] I may not be a hero but...{i}I'll keep you reasonably safe and sound ~{/i}'{/color}"
    cg "{color=#1F28AD}'No te preocupes [criminalname], puede que no sea un héroe pero... {i}te mantendré razonablemente bien y a salvo ~{/i}'{/color}"

# game/game/script.rpy:11547
translate es dblending_74991731:

    # cg "Double laughs as if it is the funniest thing in the world."
    cg "Double ríe como si fuera lo más gracioso del mundo."

# game/game/script.rpy:11549
translate es dblending_7dcdfea0:

    # cg "My face pales."
    cg "Mi rostro palidece."

# game/game/script.rpy:11563
translate es dblending_ebb293da:

    # n "Although it was a new life, it felt reminiscent of old times."
    n "Aunque era una nueva vida, se sentía como los viejos tiempos."

# game/game/script.rpy:11565
translate es dblending_6c848a4c:

    # n "This time Double wasn't keeping any secrets. I witnessed everything, for better or for worse."
    n "Esta vez Double no ocultaba nada. Lo presenciaba todo, para bien o para mal."

# game/game/script.rpy:11567
translate es dblending_542a8b6b:

    # n "I would see Binary Star's face on the screen, on magazines, on big advertisements, peering down at me as if I were an ant."
    n "Veía el rostro de Binary Star en la pantalla, en revistas, en grandes anuncios, mirándome desde lo alto como si fuera una hormiga."

# game/game/script.rpy:11569
translate es dblending_3dda70e7:

    # n "I could almost see the madness swimming behind the wide iconic smile."
    n "Podía casi ver la locura nadando detrás de su amplia sonrisa icónica."

# game/game/script.rpy:11575
translate es dblending_89e39669:

    # n "The Hero screams, peering at me with pleading eyes."
    n "El héroe grita, mirándome con ojos suplicantes."

# game/game/script.rpy:11577
translate es dblending_b0775062:

    # n "Double looks back at me smiling wide, blood splattered face."
    n "Double me mira de vuelta con una amplia sonrisa, su rostro salpicado de sangre."

# game/game/script.rpy:11579
translate es dblending_a9276858:

    # n "{i}'Was trading one madness for another worth it?' {/i}"
    n "{i}'¿Valió la pena cambiar una locura por otra?'{/i}"

# game/game/script.rpy:11581
translate es dblending_447acffd:

    # n "It was a question that swam in the depths of my chest, that crawled up my throat like bile every time Double smiled at me."
    n "Era una pregunta que nadaba en lo profundo de mi pecho, que subía por mi garganta como bilis cada vez que Double me sonreía."

# game/game/script.rpy:11583
translate es dblending_a940d2f3:

    # n "I was too afraid to answer."
    n "Tenía demasiado miedo para responder."

# game/game/script.rpy:11589
translate es dblending_f2ef5432:

    # n "He tells me '{i}Let's get out of here %(player_name)s, the others will take care of the rest.{/i}'"
    n "Él me dice: '{i}Vámonos de aquí %(player_name)s, los demás se encargarán del resto.{/i}'"

# game/game/script.rpy:11591
translate es dblending_84927d80:

    # n "I glance at the screaming man, more flesh being extracted."
    n "Miro al hombre que grita, mientras más carne es arrancada."

# game/game/script.rpy:11593
translate es dblending_474309e6:

    # n "I glance back at double foolishly asking '{i}Is he going to be okay...?{/i}'"
    n "Miro de nuevo a Double y le pregunto tontamente: '{i}¿Va a estar bien...?{/i}'"

# game/game/script.rpy:11595
translate es dblending_daf25515:

    # n "A fake smile stretches across Double's face. His jaw tightens, I can tell he is upset."
    n "Una sonrisa falsa se extiende por el rostro de Double. Su mandíbula se tensa, puedo notar que está molesto."

# game/game/script.rpy:11597
translate es dblending_6256dd6e:

    # n "A paper thin smile, Double asks: {i}'Why? Do you care what happens to him? To a hero..?'{/i}"
    n "Con una sonrisa delgada como papel, Double pregunta: '{i}¿Por qué? ¿Te importa lo que le pase? ¿A un héroe...?{/i}'"

# game/game/script.rpy:11599
translate es dblending_a5027d41:

    # n "I grab double's hand responding: '{i}No, I don't, let's go.{/i}'"
    n "Tomo la mano de Double y respondo: '{i}No, no me importa, vámonos.{/i}'"

# game/game/script.rpy:11601
translate es dblending_2aabc00e:

    # n "Double smiles. Leaning down, he places his lips on my forehead."
    n "Double sonríe. Inclinándose, posa sus labios en mi frente."

# game/game/script.rpy:11603
translate es dblending_ba0833ac:

    # n "I can feel the blood smear where he kisses. Our liturgical smearing of ashes."
    n "Puedo sentir la sangre manchar donde me besa. Nuestra liturgia de cenizas compartida."

# game/game/script.rpy:11605
translate es dblending_230af05b:

    # n "We are the same yet so different."
    n "Somos lo mismo, y a la vez tan diferentes."

# game/game/script.rpy:11607
translate es dblending_412618cd:

    # n "Double doesn't hide anything from me anymore. He expects the same in return."
    n "Double ya no me oculta nada. Espera lo mismo a cambio."

# game/game/script.rpy:11609
translate es dblending_4ff284c9:

    # n "As we walk amongst the city streets, I don't dare look upon the oppressive stare of Binary Star."
    n "Mientras caminamos por las calles de la ciudad, no me atrevo a mirar la mirada opresiva de Binary Star."

# game/game/script.rpy:11611
translate es dblending_c98aebd7:

    # n "He glares down at me, accusations behind his wide smile."
    n "Él me observa desde lo alto, acusaciones ocultas tras su amplia sonrisa."

# game/game/script.rpy:11613
translate es dblending_9b0fbf60:

    # n "I refuse to look even as the red eyes dissolve into the night."
    n "Me niego a mirar, incluso cuando los ojos rojos se disuelven en la noche."

# game/game/script.rpy:11619
translate es dblending_ef524b12:

    # cg "After all, in Double and I's world, there was only room for us and only us."
    cg "Después de todo, en el mundo de Double y mío, solo había espacio para nosotros y únicamente nosotros."

# game/game/script.rpy:11628
translate es haleyending_0cb022fc:

    # "Gathering my strength, I push the window sill upwards."
    "Reuniendo mis fuerzas, empujo hacia arriba el alféizar de la ventana."

# game/game/script.rpy:11632
translate es haleyending_574e5861:

    # "The momentum of the push causes me to fall backwards onto the hard floor."
    "El impulso del empuje me hace caer hacia atrás sobre el suelo duro."

# game/game/script.rpy:11634
translate es haleyending_bca63d68:

    # "I curse to myself, frustration growing."
    "Maldigo en voz baja, la frustración aumentando."

# game/game/script.rpy:11636
translate es haleyending_eb8d17dd:

    # un "'Chirp chirp squeak.'"
    un "'Chirp chirp squeak.'"

# game/game/script.rpy:11638
translate es haleyending_bdef2948:

    # mc "huh...?"
    mc "¿Eh...?"

# game/game/script.rpy:11640
translate es haleyending_8e93809a:

    # "I look up and see a bat in the window."
    "Levanto la vista y veo un murciélago en la ventana."

# game/game/script.rpy:11642
translate es haleyending_75fc3389:

    # "My heart drops."
    "Mi corazón se hunde."

# game/game/script.rpy:11644
translate es haleyending_90d0af42:

    # "I need to shoo it away from the fire immediately!"
    "¡Necesito ahuyentarlo del fuego de inmediato!"

# game/game/script.rpy:11648
translate es haleyending_9e50984b:

    # "I try to leap up, but I slip back onto the hard ground."
    "Intento levantarme de un salto, pero resbalo y vuelvo a caer sobre el suelo duro."

# game/game/script.rpy:11650
translate es haleyending_ae9a2f95:

    # un "'Chirp squeak chirp.'"
    un "'Chirp squeak chirp.'"

# game/game/script.rpy:11652
translate es haleyending_80d4d2be:

    # "The Bat begins to morph, to change shape."
    "El murciélago comienza a transformarse, a cambiar de forma."

# game/game/script.rpy:11654
translate es haleyending_280965f9:

    # "{i}Am I hallucinating...?{/i}"
    "{i}¿Estoy alucinando...?{/i}"

# game/game/script.rpy:11656
translate es haleyending_69d93123:

    # "I rub my eyes but the morphing of the bat continues."
    "Me froto los ojos, pero la transformación del murciélago continúa."

# game/game/script.rpy:11658
translate es haleyending_a3ec70ea:

    # "The Bat begins to take a more human shape, fur shedding into skin, wings into arms."
    "El murciélago empieza a tomar una forma más humana, el pelaje se convierte en piel, las alas en brazos."

# game/game/script.rpy:11660
translate es haleyending_38db7b3c:

    # mc "Am...am I dead..?"
    mc "¿He....muerto...?"

# game/game/script.rpy:11675
translate es haleyending_146aa3a7:

    # cg "{color=#1A5F38} 'No, but if we don't get out of here you might very well be soon.'"
    cg "{color=#1A5F38} 'No, pero si no salimos de aquí podrías estarlo muy pronto.' {/color}"

# game/game/script.rpy:11677
translate es haleyending_c9c0c5c3:

    # cg "The bat has formed into a very familiar figure."
    cg "El murciélago se ha transformado en una figura muy familiar."

# game/game/script.rpy:11679
translate es haleyending_beb97cd3:

    # cg "They sit across my window frame, cool and composed despite the chaos surrounding us."
    cg "Se sienta en el marco de mi ventana, tranquile y compueste a pesar del caos que nos rodea."

# game/game/script.rpy:11681
translate es haleyending_2e4d1cdb:

    # cg "Their green hair sways in the wind."
    cg "Su cabello verde se mece con el viento."

# game/game/script.rpy:11683
translate es haleyending_3913accf:

    # cg "Despite the...bat ears, a very familiar sparkle in their eyes make it impossible not to recognize them."
    cg "A pesar de las... orejas de murciélago, un brillo muy familiar en sus ojos hace imposible no reconocerle."

# game/game/script.rpy:11685
translate es haleyending_85311ba7:

    # cg "{color=#510f80} 'HAL!?' {/color}"
    cg "{color=#510f80} '¡¿HAL?!' {/color}"

# game/game/script.rpy:11687
translate es haleyending_4c81b864:

    # cg "Haley smiles. They sport a catsuit and a mask."
    cg "Haley sonríe. Lleva un traje ajustado y una máscara."

# game/game/script.rpy:11689
translate es haleyending_37d1a133:

    # cg "A suit like that...isn't cheap. It look even custom made."
    cg "Un traje así... no es barato. Parece incluso hecho a medida."

# game/game/script.rpy:11691
translate es haleyending_80f708a0:

    # cg "And was Haley just a BAT?!"
    cg "¿Y Haley era un murciélago?!"

# game/game/script.rpy:11693
translate es haleyending_f97a4324:

    # cg "{color=#1A5F38} '%(player_name)s are you okay...?' {/color}"
    cg "{color=#1A5F38} '%(player_name)s, ¿estás bien...?' {/color}"

# game/game/script.rpy:11695
translate es haleyending_bffd48b5:

    # cg "{color=#510f80} 'Why- why are you-! What are you-! It's dangerous you have to-!' {/color}"
    cg "{color=#510f80} '¡Por qué— por qué eres—! ¡Qué estás—! ¡Es peligroso, tienes que—!' {/color}"

# game/game/script.rpy:11697
translate es haleyending_8f799859:

    # cg "My brain malfunctions and Haley laughs."
    cg "Mi cerebro deja de funcionar y Haley se ríe."

# game/game/script.rpy:11699
translate es haleyending_a86d4ec6:

    # cg "{color=#1A5F38} 'I think the smoke is getting to your head.' {/color}"
    cg "{color=#1A5F38} 'Creo que el humo te está afectando la cabeza.' {/color}"

# game/game/script.rpy:11701
translate es haleyending_8c712742:

    # cg "{color=#1A5F38} 'Let me get you outta here, and then I promise I'll explain everything.' {/color}"
    cg "{color=#1A5F38} 'Déjame sacarte de aquí, y te prometo que luego te explico todo.' {/color}"

# game/game/script.rpy:11703
translate es haleyending_d13d10ff:

    # cg "Haley hops through my window, They make their way over to the balcony door."
    cg "Haley salta por mi ventana y se dirige hacia la puerta del balcón."

# game/game/script.rpy:11711
translate es haleyending_83286924:

    # h "Cover your face."
    h "Cúbrete la cara."

# game/game/script.rpy:11715
translate es haleyending_8a170f33:

    # "I do as I'm told and in one smooth kick Haley shatters the glass."
    "Hago lo que me dicen y, de una sola patada, Haley hace añicos el vidrio."

# game/game/script.rpy:11717
translate es haleyending_dc7d602d:

    # mc "God you're so cool...."
    mc "Dios, eres tan genial..."

# game/game/script.rpy:11719
translate es haleyending_d0e065af:

    # h "Okay, now I {i}know{/i} your brain has lost too much oxygen."
    h "Está bien, ahora {i}sé{/i} que tu cerebro tiene falta de oxígeno."

# game/game/script.rpy:11721
translate es haleyending_c6bbffb0:

    # "Haley plucks me off of the ground and stands me to my feet."
    "Haley me levanta del suelo y me pone de pie."

# game/game/script.rpy:11725
translate es haleyending_33a1de8a:

    # "Haley begins to morph again."
    "Haley empieza a transformarse de nuevo."

# game/game/script.rpy:11732
translate es haleyending_08fbed3b:

    # "Soon a large Siberian tiger is in my apartment. My face pales."
    "Pronto, un gran tigre siberiano está en mi apartamento. Mi rostro palidece."

# game/game/script.rpy:11734
translate es haleyending_b897a371:

    # h "Get on my back."
    h "Súbete a mi espalda."

# game/game/script.rpy:11736
translate es haleyending_b830f9ae:

    # "The tiger talks in Haley's voice...."
    "El tigre habla con la voz de Haley..."

# game/game/script.rpy:11738
translate es haleyending_092cec17:

    # h "I'm going to get you out of here."
    h "Voy a sacarte de aquí."

# game/game/script.rpy:11740
translate es haleyending_98e1120f:

    # "The tiger {i}is{/i} Haley. I approach it cautiously."
    "El tigre {i}es{/i} Haley. Me acerco con cautela."

# game/game/script.rpy:11742
translate es haleyending_e8b54a41:

    # h "Oh my god, hurry up!"
    h "¡Dios mío, apúrate!"

# game/game/script.rpy:11746
translate es haleyending_4160d4d1:

    # "The tiger- {i}Haley{/i} scoops me up with their head onto their back."
    "El tigre— {i}Haley{/i}— me acomoda sobre su lomo con la cabeza."

# game/game/script.rpy:11748
translate es haleyending_e6af9042:

    # "They walk onto the balcony, and back up to the very edge."
    "Caminan hasta el balcón y retroceden hasta el borde."

# game/game/script.rpy:11750
translate es haleyending_4086f97a:

    # h "Hang on as tight as you can, okay?"
    h "Abrázate tan fuerte como puedas, ¿de acuerdo?"

# game/game/script.rpy:11754
translate es haleyending_966b3ca9:

    # "I wrap my arms around Haley and shut my eyes, putting my full faith into Hal."
    "Rodeo a Haley con mis brazos y cierro los ojos, depositando toda mi fe en Hal."

# game/game/script.rpy:11758
translate es haleyending_7e9c9eaf:

    # "Haley takes off into a sprint, soon the air hits my face and we land again."
    "Haley se lanza a correr, pronto el aire golpea mi rostro y aterrizamos nuevamente."

# game/game/script.rpy:11762
translate es haleyending_29cc6292:

    # "I look up and see that we are on the neighbor's balcony."
    "Levanto la vista y veo que estamos en el balcón del vecino."

# game/game/script.rpy:11764
translate es haleyending_5b7aae78:

    # h "One more time. Hang on, okay?"
    h "Una vez más. Aférrate, ¿de acuerdo?"

# game/game/script.rpy:11770
translate es haleyending_cac9318b:

    # "There is another sprint and then leap, a loud metal sound resonates as we land onto the fire escape."
    "Hay otra carrera y luego un salto; un fuerte sonido metálico resuena al aterrizar en la escalera de incendios."

# game/game/script.rpy:11774
translate es haleyending_e0d5b81a:

    # "Haley doesn't stop moving. They continue to sprint down the stairs never breaking stride."
    "Haley no se detiene. Sigue bajando las escaleras sin perder el ritmo."

# game/game/script.rpy:11785
translate es haleyending_153d307e:

    # "When They hit the soil, their gait only speeds up."
    "Cuando pisan el suelo, su paso solo se acelera."

# game/game/script.rpy:11796
translate es haleyending_3dc450cf:

    # "I look up and even the night sky is a blur"
    "Levanto la vista y hasta el cielo nocturno es un borrón."

# game/game/script.rpy:11798
translate es haleyending_c7574b72:

    # h "Keep holding on until I tell you to stop, okay?"
    h "Aferrarte hasta que te diga que pares, ¿de acuerdo?"

# game/game/script.rpy:11800
translate es haleyending_065b6895:

    # "I can hear Haley huff below me. I can't help but to think how soft their fur feels under my face."
    "Puedo oír a Haley resoplar debajo de mí. No puedo evitar pensar lo suave que se siente su pelaje bajo mi rostro."

# game/game/script.rpy:11802
translate es haleyending_0a33a7dc:

    # "After sometime Haley finally slows to a stop placing me onto the ground"
    "Después de un rato, Haley finalmente se detiene y me coloca en el suelo."

# game/game/script.rpy:11808
translate es haleyending_0dafca38:

    # h "Oh my god! What are you doing? I told you to keep the car running!"
    h "¡Dios mío! ¿Qué estás haciendo? ¡Te dije que dejaras el auto encendido!"

# game/game/script.rpy:11810
translate es haleyending_700e9ded:

    # "Haley roars furiously at a certain Miles, who is standing outside beside the car..."
    "Haley ruge furiose hacia un tal Miles, que está de pie junto al coche..."

# game/game/script.rpy:11817
translate es haleyending_d45ff2d1:

    # n "Apparently, Haley has been living a double life as a infamous villain this whole time."
    n "Aparentemente, Haley ha estado viviendo una doble vida como una infame villane todo este tiempo."

# game/game/script.rpy:11819
translate es haleyending_f03003ba:

    # n "Well, {i}'villain'{/i} isn't necessarily the correct term. 'Cat burglar' is probably more appropriate."
    n "Bueno, 'villane' no es necesariamente el término correcto. 'Ladrón felino' sería más apropiado."

# game/game/script.rpy:11821
translate es haleyending_e480fa9f:

    # n "When I used to be a villain Haley's alias was plastered all over magazines: {i}'Shrouded Villain Chimera strikes again'{/i}."
    n "Cuando yo solía ser un villano, el alias de Haley aparecía por todas las revistas: {i}'El Villano Enmascarado Chimera ataca de nuevo'{/i}."

# game/game/script.rpy:11823
translate es haleyending_2dd6ab49:

    # n "But Hal never hurt anyone, always worked alone. The only reason they were labeled a 'villain' was due to the fact that they were taking from the rich and powerful."
    n "Pero Hal nunca lastimó a nadie, siempre trabajaba sole. La única razón por la que se le etiquetaba como 'villane' era porque robaba a los ricos y poderosos."

# game/game/script.rpy:11825
translate es haleyending_36942c5a:

    # n "And were they damn {i}good {/i} at it."
    n "Y era tremendamente {i}buene{/i} en ello."

# game/game/script.rpy:11827
translate es haleyending_585900a0:

    # n "So good in fact, that Miles's dad hunted Haley down and offered an incredible amount of money for Haley to take on Miles as their 'villain apprentice'."
    n "Tan buene, de hecho, que el padre de Miles persiguió a Haley y le ofreció una enorme cantidad de dinero para que aceptara a Miles como su 'aprendiz de villano'."

# game/game/script.rpy:11829
translate es haleyending_83583f71:

    # n "Oh, and did I mention that apparently Miles comes from a long infamous line of villainy heritage?"
    n "Ah, y ¿mencioné que aparentemente Miles proviene de una larga e infame línea de herencia villanesca?"

# game/game/script.rpy:11831
translate es haleyending_dcfc87aa:

    # n "His, dad, brothers, uncles, aunts, mothers, grandmothers, grand fathers, great grandfathers and so on, are some of the most well known villains of all time."
    n "Su padre, hermanos, tíos, tías, madres, abuelas, abuelos, bisabuelos y demás, son algunos de los villanos más conocidos de todos los tiempos."

# game/game/script.rpy:11833
translate es haleyending_b8ff96b7:

    # n "Miles of course, would rather be a hero. But good luck to {i}anyone {/i} who tries to convince his father of that."
    n "Miles, por supuesto, preferiría ser un héroe. Pero buena suerte a {i}cualquiera{/i} que intente convencer a su padre de eso."

# game/game/script.rpy:11835
translate es haleyending_55c304ae:

    # n "So now, Miles, Haley and I roll together."
    n "Así que ahora, Miles, Haley y yo andamos juntos."

# game/game/script.rpy:11837
translate es haleyending_44c890df:

    # n "Sharing a small apartment, we sleep in the day and we lurk in the night."
    n "Compartiendo un pequeño apartamento, dormimos de día y merodeamos de noche."

# game/game/script.rpy:11839
translate es haleyending_45aa0ef2:

    # n "We take what isn't ours, we funnel the money into offshore accounts preparing to flee whenever {i}he {/i} finds us."
    n "Tomamos lo que no es nuestro, transferimos el dinero a cuentas offshore preparándonos para huir cuando {i}él{/i} nos encuentre."

# game/game/script.rpy:11841
translate es haleyending_60771d47:

    # n "Because according to Haley; it's not a matter of how, {i}it's a matter of 'when'{/i}."
    n "Porque según Haley, no es cuestión de 'cómo', sino de {i}'cuándo'{/i}."

# game/game/script.rpy:11843
translate es haleyending_7fd5b7ed:

    # n "Having Haley at my side, I feel like I could take on anything. I would take on anything at the chance for a future where I can keep smiling and laughing with them."
    n "Con Haley a mi lado, siento que podría enfrentar cualquier cosa. Enfrentaría cualquier cosa por una oportunidad de tener un futuro en el que pueda seguir sonriendo y riendo con ellos."

# game/game/script.rpy:11845
translate es haleyending_d76dc4f9:

    # n "With Haley at my side, things are happier, peaceful even. I found my stride again. I didn't know how much I needed them."
    n "Con Haley a mi lado, las cosas son más felices, incluso pacíficas. He vuelto a encontrar mi ritmo. No sabía cuánto le necesitaba."

# game/game/script.rpy:11847
translate es haleyending_b86d51a9:

    # n "They look at me, a familiar smile adorns their beautiful face."
    n "Me miran, una sonrisa familiar adorna su hermoso rostro."

# game/game/script.rpy:11849
translate es haleyending_b2d280c6:

    # n "Falling asleep by Hal's side is a piece of heaven that I'm willing to fight for, to preserve."
    n "Dormir al lado de Hal es un pedazo de cielo por el que voy a luchar, a preservar."

# game/game/script.rpy:11851
translate es haleyending_0ebd151c:

    # n "Be it Heroes or Villains..."
    n "Sean héroes o villanos..."

# game/game/script.rpy:11855
translate es haleyending_b2a89bee:

    # cg "Come what may, {i}I'm ready{/i}."
    cg "Pase lo que pase, {i}tengo preparación{/i}."

# game/game/script.rpy:11868
translate es binarystarending_d3fe53e6:

    # "I yell out his name with all the force that I can manage."
    "Grito su nombre con toda la fuerza que puedo reunir."

# game/game/script.rpy:11870
translate es binarystarending_7cb048a7:

    # mc "Binary Star! Help me!!"
    mc "¡Binary Star! ¡Ayúdame!"

# game/game/script.rpy:11874
translate es binarystarending_61955f2e:

    # "Less than a moment later a gust of fresh air bursts past me from my balcony."
    "Menos de un instante después, una ráfaga de aire fresco estalla desde mi balcón."

# game/game/script.rpy:11878
translate es binarystarending_b9f8a241:

    # cg "I look up and the shining hero stands before me."
    cg "Levanto la vista y el brillante héroe está frente a mí."

# game/game/script.rpy:11885
translate es binarystarending_ed7b0e70:

    # cg "He reaches out his hand towards me, smiling kindly."
    cg "Extiende su mano hacia mí, sonriendo amablemente."

# game/game/script.rpy:11887
translate es binarystarending_e8bca5ec:

    # cg "He is radiant even amongst the smoke and flame."
    cg "Resplandece incluso entre el humo y las llamas."

# game/game/script.rpy:11896
translate es binarystarending_81464622:

    # cg "Despite the destruction around me, I feel no semblance of fear."
    cg "A pesar de la destrucción a mi alrededor, no siento ni rastro de miedo."

# game/game/script.rpy:11898
translate es binarystarending_87a0dcd0:

    # cg "{color=#CD9300} 'I'm here to save you %(player_name)s.' {/color}"
    cg "{color=#CD9300} 'Estoy aquí para salvarte, %(player_name)s.' {/color}"

# game/game/script.rpy:11900
translate es binarystarending_6ed9691f:

    # cg "Without hesitation I grab his hand, pulling myself up. I throw myself in his arms, hugging him with the remainder of the strength in my body."
    cg "Sin dudarlo, agarro su mano, levantándome. Me lanzo a sus brazos, abrazándolo con la fuerza que me queda."

# game/game/script.rpy:11902
translate es binarystarending_9e971980:

    # cg "He freezes, surprised by my action. Binary Star clears his throat and shifts his gaze to the side in a feeble attempt to hide how red his face is."
    cg "Se queda inmóvil, sorprendido por mi acción. Binary Star carraspea y aparta la mirada en un débil intento de ocultar el rubor de su rostro."

# game/game/script.rpy:11904
translate es binarystarending_8aadd205:

    # cg "After a few seconds of patting my head awkwardly he shifts back."
    cg "Después de unos segundos de palmaditas torpes en mi cabeza, vuelve a centrarse."

# game/game/script.rpy:11910
translate es binarystarending_e5a67ca0:

    # "He squats lower settling his forearm under my bum."
    "Se agacha un poco, acomodando su antebrazo bajo mi trasero."

# game/game/script.rpy:11914
translate es binarystarending_f86561d4:

    # "Binary Star easily lifts me up securing my back with his other hand."
    "Binary Star me levanta con facilidad, asegurando mi espalda con su otra mano."

# game/game/script.rpy:11926
translate es binarystarending_4e408507:

    # "He steps out onto the balcony looking at me with a coy smile."
    "Sale al balcón mirándome con una sonrisa pícara."

# game/game/script.rpy:11928
translate es binarystarending_4dbad7bd:

    # r "Hold on tight!"
    r "¡Agárrate fuerte!"

# game/game/script.rpy:11936
translate es binarystarending_46dc11fc:

    # "Suddenly we are flying through the starry sky, his iconic red cape trailing behind."
    "De repente estamos volando por el cielo estrellado, su icónica capa roja ondeando detrás."

# game/game/script.rpy:11938
translate es binarystarending_bb4ae4c6:

    # "The night air is brisk as he flies past skyscrapers and stars."
    "El aire nocturno es frío mientras pasa entre rascacielos y estrellas."

# game/game/script.rpy:11940
translate es binarystarending_cff04711:

    # "Soon enough he settles me down onto a high up balcony, in the middle of downtown."
    "Pronto me deja sobre un balcón alto, en medio del centro de la ciudad."

# game/game/script.rpy:11950
translate es binarystarending_33c34370:

    # mc "You can see the whole city from here..."
    mc "Puedes ver toda la ciudad desde aquí..."

# game/game/script.rpy:11952
translate es binarystarending_f65ed2a4:

    # r "Mhm, that's kinda the point of why they placed me here."
    r "Mhm, ese es el punto de por qué me colocaron aquí."

# game/game/script.rpy:11954
translate es binarystarending_e1ec094c:

    # "He opens up the doors and beckons me inside."
    "Abre las puertas y me hace una seña para entrar."

# game/game/script.rpy:11958
translate es binarystarending_4724f115:

    # "My jaw drops."
    "Mi mandíbula cae."

# game/game/script.rpy:11960
translate es binarystarending_f72f73ad:

    # mc "This is {i}your {/i} apartment?!"
    mc "¿Este es {i}tu{/i} apartamento?!"

# game/game/script.rpy:11962
translate es binarystarending_e7a81d0b:

    # r "Condo, but yes."
    r "Condominio, pero sí."

# game/game/script.rpy:11964
translate es binarystarending_e19eeae9:

    # "He smirks."
    "Sonríe con suficiencia."

# game/game/script.rpy:11966
translate es binarystarending_d14721fd:

    # r "Glad you like it. This is where you will be living from now on."
    r "Me alegra que te guste. Aquí es donde vivirás a partir de ahora."

# game/game/script.rpy:11968
translate es binarystarending_282e5851:

    # mc "What...?"
    mc "¿Qué...?"

# game/game/script.rpy:11970
translate es binarystarending_ff52e0f2:

    # r "Unless you want to go back to your apartment, which I wouldn't personally recommend in it's current state."
    r "A menos que quieras volver a tu apartamento, lo cual no recomendaría personalmente en su estado actual."

# game/game/script.rpy:11983
translate es binarystarending_d5030bc4:

    # "He walks up to me, looking down at me with a serious expression."
    "Se acerca a mí, mirándome con una expresión seria."

# game/game/script.rpy:11985
translate es binarystarending_8af551bf:

    # r "Plus, {i}here{/i} I can keep you safe, I know where you are."
    r "Además, {i}aquí{/i} puedo mantenerte a salvo, sé dónde estás."

# game/game/script.rpy:11987
translate es binarystarending_c11f26c0:

    # mc "I guess that makes sense..."
    mc "Supongo que tiene sentido..."

# game/game/script.rpy:11989
translate es binarystarending_a0f384f7:

    # mc "I promise not to impede, I'll be outta here right when I get a new apartment!"
    mc "Prometo no ser una molestia, me iré justo cuando consiga un nuevo apartamento."

# game/game/script.rpy:11991
translate es binarystarending_a911bf34:

    # "An indecipherable look passes across Ray's expression and I could almost swear I heard him chuckle."
    "Una expresión indescifrable cruza el rostro de Ray y casi podría jurar que lo escuché reír."

# game/game/script.rpy:12003
translate es binarystarending_bba8a940:

    # "He turns away walking into the apartment."
    "Se da la vuelta y camina hacia el interior del apartamento."

# game/game/script.rpy:12005
translate es binarystarending_5f6b1d05:

    # r "{size=-10}We will see about that...{/size}"
    r "{size=-10}Ya veremos eso...{/size}"

# game/game/script.rpy:12007
translate es binarystarending_122f358e:

    # mc "What did you say?"
    mc "¿Qué dijiste?"

# game/game/script.rpy:12009
translate es binarystarending_761a61dd:

    # "He turns around, smiling his signature radiant smile."
    "Se gira, sonriendo con su característica sonrisa radiante."

# game/game/script.rpy:12011
translate es binarystarending_22c20139:

    # r "Nothing. Come, let me show you around your new home Star."
    r "Nada. Ven, déjame mostrarte tu nuevo hogar, Estrella."

# game/game/script.rpy:12017
translate es binarystarending_88929d20:

    # cg "I couldn't help but to follow him. He led me as if a gravitational pull kept us together."
    cg "No pude evitar seguirlo. Me guiaba como si una fuerza gravitacional nos mantuviera unidos."

# game/game/script.rpy:12019
translate es binarystarending_a76f0409:

    # cg "Part of me knew that something didn't feel entirely right."
    cg "Parte de mí sabía que algo no se sentía del todo bien."

# game/game/script.rpy:12021
translate es binarystarending_1dd87cec:

    # cg "By then I was already too enthralled by the hero."
    cg "Pero para entonces ya estaba demasiado fascinado por el héroe."

# game/game/script.rpy:12023
translate es binarystarending_ff0a7759:

    # cg "The way he shined..."
    cg "La forma en que brillaba..."

# game/game/script.rpy:12025
translate es binarystarending_39ec62e6:

    # cg "I couldn't help but to orbit around him."
    cg "No podía evitar orbitar a su alrededor."

# game/game/script.rpy:12051
translate es binarystarending_3840a25a:

    # r "Did you know that some stars can be created by being torn apart by black holes."
    r "¿Sabías que algunas estrellas pueden crearse al ser desgarradas por agujeros negros?"

# game/game/script.rpy:12052
translate es binarystarending_1c9e1981:

    # r "Do you want to be shredded apart in order to be born whole more bright and beautiful than ever before?"
    r "¿Quieres despedazarte para renacer completo, más brillante y con mas belleza que nunca?"

# game/game/script.rpy:12053
translate es binarystarending_34400abe:

    # r "My ability is the Quasar that shines around me like a halo, pulling matter from everything else around it into a single volatile ring."
    r "Mi habilidad es el Quásar que brilla a mi alrededor como un halo, absorbiendo materia de todo lo que me rodea en un único anillo volátil."

translate es strings:

    old "'More exciting than a minimum wage cafe employee? I can't even imagine.'"
    new "'¿Más emocionante que un empleado de cafetería con salario mínimo? No puedo ni imaginarlo.'"

    old "'This is all the excitement I want to handle.'"
    new "'Este es todo el tipo de emoción que quiero manejar.'"

    old "Calm Haley down so the customers don't hear"
    new "Calmar a Haley para que los clientes no escuchen"

    old "Let Haley speak their truth"
    new "Dejar que Haley diga su verdad"

    old "(Soften the truth) 'Never had any interest in them.'"
    new "(Suavizar la verdad) 'Nunca tuve ningún interés en ellos.'"

    old "(Be honest) 'I find them somewhat...uncomfortable.'"
    new "(Hablar con honestidad) 'Me resultan algo... incómodos.'"

    old "'I can't do that Double...'"
    new "'No puedo hacer eso, Double...'"

    old "'Go fuck yourself Double.'"
    new "'Vete al diablo, Double.'"

    old "Invite him in"
    new "Invitarlo a pasar"

    old "Say goodbye"
    new "Despedirte"

    old "'Well Blaze, I'm {i}not {/i} interested.'"
    new "'Bueno, Blaze, {i}no{/i} me interesa.'"

    old "'Kindly fuck off.'"
    new "'Hazme el favor y lárgate.'"

    old "'What about him?'"
    new "'¿Y qué hay de él?'"

    old "'...Really?'"
    new "'¿...En serio?'"

    old "'Here's some coffee before you go.'"
    new "'Aquí tienes un poco de café antes de irte.'"

    old "'Have a good day at work.'"
    new "'Que tengas un buen día en el trabajo.'"

    old "'Definitely some skeletons.'"
    new "'Definitivamente hay esqueletos en el armario.'"

    old "'I just don't care.'"
    new "'Simplemente no me importa.'"

    old "'Why are you doing this...?'"
    new "'¿Por qué estás haciendo esto...?'"

    old "'Just leave me alone.'"
    new "'Solo déjame en paz.'"

    old "Nod"
    new "Asentir"

    old "Stare at defiantly"
    new "Mirarlo desafiante"

    old "'See you acting like a psycho murderer...?'"
    new "'¿Verte actuar como un asesino psicópata...?'"

    old "'...Thanks for saving me.'"
    new "'...Gracias por salvarme.'"

    old "'I can't sleep alone...' (Somewhat suggestive)"
    new "'No puedo dormir sin compañía...' (Algo insinuante)"

    old "Try to drift off to sleep"
    new "Intentar dormir"

    old "Yes"
    new "Sí"

    old "No"
    new "No"

    old "Phone"
    new "Teléfono"

    old "No, I shouldn't respond."
    new "No, no debería responder."

    old "Respond: '{i}Yes{/i}'"
    new "Responder: '{i}Sí{/i}'"

    old "Respond: '{i}No{/i}'"
    new "Responder: '{i}No{/i}'"

    old "Respond with something flirty"
    new "Responder con algo coqueto"

    old "Notebook"
    new "Cuaderno"

    old "'Why do you have a photo of me..?'"
    new "'¿Por qué tienes una foto mía...?'"

    old "'How did you get your abilities?'"
    new "'¿Cómo obtuviste tus habilidades?'"

    old "Call Haley"
    new "Llamar a Haley"

    old "Call Double"
    new "Llamar a Double"

    old "'Black'"
    new "'Negro'"

    old "'White'"
    new "'Blanco'"

    old "'What makes you think I'm wearing any?'"
    new "'¿Qué te hace pensar que llevo alguno puesto?'"

    old "Search some information about Binary Star"
    new "Buscar información sobre Binary Star"

    old "Go for the Front door."
    new "Ir hacia la puerta principal."

    old "Go for the Window."
    new "Ir hacia la ventana."

    old "Go for the Balcony door."
    new "Ir hacia la puerta del balcón."

    old "Binary Star Help Me!"
    new "¡Binary Star, ayúdame!"

    old "Sprint towards the balcony"
    new "Correr hacia el balcón"

    old "'But you're a Hero!'"
    new "'¡Pero eres un héroe!'"

    old "'That's cruel.'"
    new "'Eso es cruel.'"

    old "Move away from Ray."
    new "Alejarte de Ray."

    old "Take Ray's Hand."
    new "Tomar la mano de Ray."

    old "'Save me Ray.'"
    new "'Sálvame, Ray.'"

    old "Customer"
    new "Cliente"

    old "Interviewer"
    new "Entrevistador"

    old "Henchman 1"
    new "Secuaz 1"

    old "Henchman 2"
    new "Secuaz 2"

    old "Back"
    new "Atrás"

    old "History"
    new "Historial"

    old "Skip"
    new "Saltar"

    old "Auto"
    new "Auto"

    old "Save"
    new "Guardar"

    old "Q.Save"
    new "G. Rápido"

    old "Q.Load"
    new "C. Rápido"

    old "Prefs"
    new "Opciones"

    old "Start"
    new "Iniciar"

    old "Load"
    new "Cargar"

    old "Preferences"
    new "Preferencias"

    old "About"
    new "Acerca de"

    old "Play 'Favor'"
    new "Jugar 'Favor'"

    old "Album"
    new "Álbum"

    old "After Stories"
    new "Extra"

    old "Achievements"
    new "Logros"

    old "End Replay"
    new "Terminar Repetición"

    old "Main Menu"
    new "Menú Principal"

    old "Help"
    new "Ayuda"

    old "Quit"
    new "Salir"

    old "Return"
    new "Volver"

    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]."
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]."

    old "Page {}"
    new "Página {}"

    old "Automatic saves"
    new "Guardados automáticos"

    old "Quick saves"
    new "Guardados rápidos"

    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    old "empty slot"
    new "ranura vacía"

    old "<"
    new "<"

    old "{#auto_page}A"
    new "{#auto_page}A"

    old "{#quick_page}Q"
    new "{#quick_page}Q"

    old ">"
    new ">"

    old "Display"
    new "Pantalla"

    old "Window"
    new "Ventana"

    old "Fullscreen"
    new "Pantalla completa"

    old "Unseen Text"
    new "Texto no visto"

    old "After Choices"
    new "Después de las elecciones"

    old "Transitions"
    new "Transiciones"

    old "Text Speed"
    new "Velocidad del texto"

    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    old "Music Volume"
    new "Volumen de música"

    old "Sound Volume"
    new "Volumen de sonido"

    old "Test"
    new "Probar"

    old "Voice Volume"
    new "Volumen de voz"

    old "Mute All"
    new "Silenciar todo"

    old "The dialogue history is empty."
    new "El historial de diálogo está vacío."

    old "Keyboard"
    new "Teclado"

    old "Mouse"
    new "Ratón"

    old "Gamepad"
    new "Mando"

    old "Enter"
    new "Enter"

    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    old "Space"
    new "Espacio"

    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    old "Arrow Keys"
    new "Flechas de dirección"

    old "Navigate the interface."
    new "Navega por la interfaz."

    old "Escape"
    new "Escape"

    old "Accesses the game menu."
    new "Accede al menú del juego."

    old "Ctrl"
    new "Ctrl"

    old "Skips dialogue while held down."
    new "Omite el diálogo mientras se mantiene presionado."

    old "Tab"
    new "Tab"

    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogo."

    old "Page Up"
    new "Re Pág"

    old "Rolls back to earlier dialogue."
    new "Retrocede al diálogo anterior."

    old "Page Down"
    new "Av Pág"

    old "Rolls forward to later dialogue."
    new "Avanza al diálogo siguiente."

    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}narración automática{/a}."

    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    old "Left Click"
    new "Clic izquierdo"

    old "Middle Click"
    new "Clic central"

    old "Right Click"
    new "Clic derecho"

    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del ratón hacia arriba\nClic lateral de retroceso"

    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    old "Right Shoulder"
    new "Botón superior derecho"

    old "D-Pad, Sticks"
    new "Cruceta, palancas"

    old "Start, Guide"
    new "Start, Guía"

    old "Y/Top Button"
    new "Y/Botón superior"

    old "Calibrate"
    new "Calibrar"

    old "Skipping"
    new "Saltando"

    old "Menu"
    new "Menú"

    old "Next Page"
    new "Página Siguiente"