
# game/game/afterstories.rpy:43
translate es rayafterstory_b941e989:

    # n "The sunlight shines through the large window."
    n "La luz del sol brilla a través de la gran ventana."

# game/game/afterstories.rpy:45
translate es rayafterstory_847e9372:

    # n "I turn in the bed, my hand brushing against an unfamiliar emptiness beside me."
    n "Me giro en la cama, mi mano rozando un vacío desconocido a mi lado."

# game/game/afterstories.rpy:47
translate es rayafterstory_7f15e5a3:

    # n "{i}'It's still partially warm. He must have recently gotten up.'{/i}"
    n "{i}'Aún está parcialmente tibio. Debe haberse levantado hace poco.'{/i}"

# game/game/afterstories.rpy:49
translate es rayafterstory_1b96c2f8:

    # n "I stretch and rise out of bed, greeting the new day with a tired body."
    n "Me estiro y me levanto de la cama, saludando el nuevo día con un cuerpo cansado."

# game/game/afterstories.rpy:51
translate es rayafterstory_cc4ed863:

    # n "My feet travel over the heated ground as I move through the spacious condo."
    n "Mis pies recorren el suelo cálido mientras avanzo por el espacioso condominio."

# game/game/afterstories.rpy:53
translate es rayafterstory_e1864827:

    # n "The sound of coffee being brewed echos in the air."
    n "El sonido del café preparándose resuena en el aire."

# game/game/afterstories.rpy:55
translate es rayafterstory_fb8fac85:

    # n "I make my way to the kitchen."
    n "Me dirijo hacia la cocina."

# game/game/afterstories.rpy:57
translate es rayafterstory_43ed3c5a:

    # n "As I round the corner I see Ray leaning against the counter looking over a stack of papers."
    n "Al girar la esquina veo a Ray apoyado en el mostrador revisando un montón de papeles."

# game/game/afterstories.rpy:59
translate es rayafterstory_e9aa02ee:

    # n "{color=#510f80} 'Good morning...' {/color}, I yawn."
    n "{color=#510f80} 'Buenos días…' {/color}, bostezo."

# game/game/afterstories.rpy:61
translate es rayafterstory_423542c5:

    # n "He looks up slightly surprised, placing the stack onto the table as he makes his way over to me."
    n "Él levanta la mirada ligeramente sorprendido, dejando el montón sobre la mesa mientras se acerca a mí."

# game/game/afterstories.rpy:63
translate es rayafterstory_0e95d30c:

    # n "{color=#CD9300} 'Oh, good morning Star. How did you sleep?' {/color}"
    n "{color=#CD9300} 'Oh, buenos días, Estrella. ¿Cómo dormiste?' {/color}"

# game/game/afterstories.rpy:65
translate es rayafterstory_297e41d2:

    # n "He places a kiss onto the top of my head."
    n "Deposita un beso en la parte superior de mi cabeza."

# game/game/afterstories.rpy:70
translate es rayafterstory_21b40a13:

    # n "{color=#510f80} 'I.... I think I had a nightmare?' {/color}"
    n "{color=#510f80} 'Yo... creo que tuve una pesadilla.' {/color}"

# game/game/afterstories.rpy:72
translate es rayafterstory_cd5a16b4:

    # n "Ray's face looks concerned. His voice comes out gentle, slow."
    n "El rostro de Ray se muestra preocupado. Su voz suena suave, lenta."

# game/game/afterstories.rpy:74
translate es rayafterstory_e8ea9a76:

    # n "{color=#CD9300} 'Do you want to talk about it?'"
    n "{color=#CD9300} '¿Quieres hablar de eso?' {/color}"

# game/game/afterstories.rpy:76
translate es rayafterstory_04e716c9:

    # n "I shake my head lightly."
    n "Niego levemente con la cabeza."

# game/game/afterstories.rpy:78
translate es rayafterstory_9d2f4561:

    # n "{color=#510f80} 'I'm not sure that it'd make sense, even if I tried.' {/color}"
    n "{color=#510f80} 'No estoy segura de que tenga sentido, aunque lo intentara.' {/color}"

# game/game/afterstories.rpy:80
translate es rayafterstory_0704fd24:

    # n "Ray smiles sympathetically, he walks closer."
    n "Ray sonríe con simpatía, caminando más cerca."

# game/game/afterstories.rpy:82
translate es rayafterstory_d1f1e1ca:

    # n "{color=#CD9300} 'I used to have nightmares pretty often as a kid.' {/color}"
    n "{color=#CD9300} 'Solía tener pesadillas bastante seguido cuando era niño.' {/color}"

# game/game/afterstories.rpy:84
translate es rayafterstory_86bc8591:

    # n "{color=#510f80} 'What helped you get rid of them?' {/color}"
    n "{color=#510f80} '¿Qué te ayudó a deshacerte de ellas?' {/color}"

# game/game/afterstories.rpy:86
translate es rayafterstory_b3b66f90:

    # n "He smiles softly."
    n "Él sonríe suavemente."

# game/game/afterstories.rpy:88
translate es rayafterstory_b97ce306:

    # n "{color=#CD9300} 'Well, I don't think I ever really got rid of them.'{/color}"
    n "{color=#CD9300} 'Bueno, no creo que realmente me haya deshecho de ellas.' {/color}"

# game/game/afterstories.rpy:90
translate es rayafterstory_3da84a35:

    # n "{color=#CD9300} 'After a while you just get used to them.'{/color}"
    n "{color=#CD9300} 'Con el tiempo simplemente te acostumbras.' {/color}"

# game/game/afterstories.rpy:92
translate es rayafterstory_33cae181:

    # n "{color=#CD9300} 'They eventually just... stop being scary.'{/color}"
    n "{color=#CD9300} 'Eventualmente solo... dejan de dar miedo.' {/color}"

# game/game/afterstories.rpy:94
translate es rayafterstory_435b02a6:

    # n "He brushes down some of my bedhead."
    n "Acomoda un mechón rebelde de mi cabello."

# game/game/afterstories.rpy:96
translate es rayafterstory_d5d5551d:

    # n "{color=#CD9300} 'I know...probably not what you want to hear huh?'{/color}"
    n "{color=#CD9300} 'Lo sé... probablemente no era lo que querías oír, ¿eh?' {/color}"

# game/game/afterstories.rpy:98
translate es rayafterstory_506dd033:

    # n "{color=#510f80} 'No... but some part of me had a feeling that was the case.' {/color}"
    n "{color=#510f80} 'No... pero una parte de mí ya lo sospechaba.' {/color}"

# game/game/afterstories.rpy:100
translate es rayafterstory_41625cab:

    # n "{color=#510f80} 'I think I just gotta work through them.' {/color}"
    n "{color=#510f80} 'Creo que solo tengo que afrontarlas.' {/color}"

# game/game/afterstories.rpy:102
translate es rayafterstory_df0b260d:

    # n "Ray places a kiss on my cheek."
    n "Ray me da un beso en la mejilla."

# game/game/afterstories.rpy:104
translate es rayafterstory_fd90ea95:

    # n "{color=#CD9300} 'You can always talk to me about them if you want to. You know that right?'{/color}"
    n "{color=#CD9300} 'Siempre puedes hablar conmigo sobre ellas si quieres. Lo sabes, ¿verdad?' {/color}"

# game/game/afterstories.rpy:106
translate es rayafterstory_c38945e2:

    # n "I bite my lip and nod."
    n "Me muerdo el labio y asiento."

# game/game/afterstories.rpy:108
translate es rayafterstory_00dbe115:

    # n "Ray smiles. {color=#CD9300} 'Good.'{/color}"
    n "Ray sonríe. {color=#CD9300} 'Bien.' {/color}"

# game/game/afterstories.rpy:113
translate es rayafterstory_104215e0:

    # n "{color=#510f80} 'I think I slept pretty well...' {/color}"
    n "{color=#510f80} 'Creo que dormí bastante bien...' {/color}"

# game/game/afterstories.rpy:115
translate es rayafterstory_dbb2e2ac:

    # n "Ray smiles softly, straightening out my bunched up shirt."
    n "Ray sonríe suavemente, arreglando mi camiseta arrugada."

# game/game/afterstories.rpy:117
translate es rayafterstory_e96c1d74:

    # n "{color=#CD9300} 'You sure {i}look {/i} like you slept pretty well.'{/color}"
    n "{color=#CD9300} 'Sin duda {i}pareces{/i} haber dormido bastante bien.' {/color}"

# game/game/afterstories.rpy:119
translate es rayafterstory_f04f9bf1:

    # n "I pull a face and Ray laughs."
    n "Pongo una mueca y Ray se ríe."

# game/game/afterstories.rpy:121
translate es rayafterstory_e24aa1cb:

    # n "{color=#CD9300} 'Don't pout Star, you look cute.'{/color}"
    n "{color=#CD9300} 'No hagas pucheros, Estrella, te ves adorable.' {/color}"

# game/game/afterstories.rpy:123
translate es rayafterstory_3e3028c8:

    # n "{color=#CD9300} 'You were so peaceful while asleep, I tried my best not to wake you when I got up.'{/color}"
    n "{color=#CD9300} 'Estabas tan en paz mientras dormías, intenté no despertarte cuando me levanté.' {/color}"

# game/game/afterstories.rpy:125
translate es rayafterstory_74e748d9:

    # n "{color=#510f80} 'Eww, you were staring at me while I was sleeping? You creep~' {/color}"
    n "{color=#510f80} 'Eww, ¿me estabas mirando mientras dormía? Qué raro~' {/color}"

# game/game/afterstories.rpy:127
translate es rayafterstory_23326712:

    # n "I tease him back. A flash of annoyance drifts across Ray's expression."
    n "Lo molesto de vuelta. Un destello de molestia cruza el rostro de Ray."

# game/game/afterstories.rpy:129
translate es rayafterstory_78073076:

    # n "{color=#CD9300} 'Keep taunting me and I'll take you right back to bed...'{/color} He warns cooly."
    n "{color=#CD9300} 'Sigue provocándome y te llevaré directo de nuevo a la cama...' {/color} advierte con frialdad."

# game/game/afterstories.rpy:131
translate es rayafterstory_6ef73e0c:

    # n "I shut my mouth and sit down on one of the kitchen seats."
    n "Cierro la boca y me siento en uno de los asientos de la cocina."

# game/game/afterstories.rpy:133
translate es rayafterstory_9648661e:

    # n "{color=#CD9300} 'Do you want any coffee?'{/color} Ray asks while picking up a mug."
    n "{color=#CD9300} '¿Quieres café?' {/color} pregunta Ray mientras toma una taza."

# game/game/afterstories.rpy:137
translate es rayafterstory_c5486e11:

    # n "{color=#510f80} 'Yes, please!' {/color}"
    n "{color=#510f80} '¡Sí, por favor!' {/color}"

# game/game/afterstories.rpy:139
translate es rayafterstory_e643e02f:

    # n "Ray pulls out a second mug pouring a generous amount."
    n "Ray saca una segunda taza y sirve una cantidad generosa."

# game/game/afterstories.rpy:141
translate es rayafterstory_9f767c29:

    # n "{color=#CD9300} 'Milk? Sugar?'"
    n "{color=#CD9300} '¿Leche? ¿Azúcar?' {/color}"

# game/game/afterstories.rpy:143
translate es rayafterstory_2334d41b:

    # n "I hop up moving to my mug."
    n "Me levanto y me acerco a mi taza."

# game/game/afterstories.rpy:145
translate es rayafterstory_452fdefe:

    # n "{color=#510f80} 'I got it.' {/color} I say grabbing the mug and preparing my coffee to my taste."
    n "{color=#510f80} 'Yo me encargo.' {/color} digo tomando la taza y preparando mi café a mi gusto."

# game/game/afterstories.rpy:147
translate es rayafterstory_6d4cf1ec:

    # n "I bring the coffee back to my seat and relax into it."
    n "Llevo el café a mi asiento y me relajo."

# game/game/afterstories.rpy:149
translate es rayafterstory_d85e7a23:

    # n "I can't help but to sigh after taking my first sip, nothing beats coffee in the morning."
    n "No puedo evitar suspirar después del primer sorbo, nada supera el café por la mañana."

# game/game/afterstories.rpy:152
translate es rayafterstory_16c26e84:

    # n "{color=#510f80} 'No, thankyou.' {/color}"
    n "{color=#510f80} 'No, gracias.' {/color}"

# game/game/afterstories.rpy:154
translate es rayafterstory_8e1f6654:

    # n "Ray pours himself a cup and starts to sip."
    n "Ray se sirve una taza y empieza a beber."

# game/game/afterstories.rpy:156
translate es rayafterstory_7f9a69e4:

    # n "{color=#CD9300} 'Mmm, more for me I guess.' {/color}"
    n "{color=#CD9300} 'Mmm, más para mí, supongo.' {/color}"

# game/game/afterstories.rpy:158
translate es rayafterstory_f59d1533:

    # n "{color=#510f80} 'Knock yourself out old man.' {/color}"
    n "{color=#510f80} 'Disfrútalo, viejo.' {/color}"

# game/game/afterstories.rpy:160
translate es rayafterstory_11218241:

    # n "{color=#CD9300} '!?' {/color}"
    n "{color=#CD9300} '¿¡!?' {/color}"

# game/game/afterstories.rpy:162
translate es rayafterstory_b85d9874:

    # n "A look of shock hits Ray's face, he starts to cough."
    n "Una expresión de sorpresa cruza el rostro de Ray, empieza a toser."

# game/game/afterstories.rpy:164
translate es rayafterstory_34ccc84b:

    # n "{color=#CD9300} '{i}Old Man?! {/i} Excuse me?' {/color}"
    n "{color=#CD9300} '¿{i}Viejo?!{/i} ¿Perdón?' {/color}"

# game/game/afterstories.rpy:166
translate es rayafterstory_eec83129:

    # n "He places the coffee cup down."
    n "Deja la taza sobre la mesa."

# game/game/afterstories.rpy:168
translate es rayafterstory_d2b314eb:

    # n "{color=#CD9300} 'I am {i}not {/i} an old man.' {/color}"
    n "{color=#CD9300} 'No soy {i}un viejo.{/i}' {/color}"

# game/game/afterstories.rpy:170
translate es rayafterstory_d1e44e8d:

    # n "{color=#510f80} 'You drink coffee like one.' {/color}"
    n "{color=#510f80} 'Bebes café como uno.' {/color}"

# game/game/afterstories.rpy:172
translate es rayafterstory_970b6f2e:

    # n "{color=#CD9300} 'What...what does that mean?' {/color} Ray looks genuinely confused."
    n "{color=#CD9300} '¿Qué... qué se supone que significa eso?' {/color} Ray parece genuinamente confundido."

# game/game/afterstories.rpy:174
translate es rayafterstory_65064e87:

    # n "I can't help but to laugh. Ray approaches and my laughing is soon cut short as he looms above where I sit."
    n "No puedo evitar reírme. Ray se acerca y mi risa se corta en seco cuando se inclina sobre donde estoy sentada."

# game/game/afterstories.rpy:176
translate es rayafterstory_d1252bb9:

    # n "{color=#CD9300} 'My Star....are you really messing with me at 8:30 in the morning?' {/color}"
    n "{color=#CD9300} 'Mi Estrella... ¿realmente estás molestándome a las ocho y media de la mañana?' {/color}"

# game/game/afterstories.rpy:178
translate es rayafterstory_f99314c4:

    # n "I bat my eyes attempting to look innocent. Ray lets out a groan rubbing his eyes while walking back to the counter."
    n "Parpadeo intentando parecer inocente. Ray deja escapar un gemido, frotándose los ojos mientras regresa al mostrador."

# game/game/afterstories.rpy:180
translate es rayafterstory_8c805ccc:

    # n "{color=#CD9300} 'I should have started drinking coffee earlier if I knew you were gonna come out of the bed goddamn swinging.' {/color}"
    n "{color=#CD9300} 'Debería haber empezado a tomar café antes si sabía que ibas a salir de la cama lista para pelear.' {/color}"

# game/game/afterstories.rpy:182
translate es rayafterstory_722946f6:

    # n "{color=#CD9300} 'You're a fucking menace.' {/color}"
    n "{color=#CD9300} 'Eres un maldito peligro.' {/color}"

# game/game/afterstories.rpy:184
translate es rayafterstory_01a02e96:

    # n "I glance over at the papers that he was looking through."
    n "Miro los papeles que estaba revisando."

# game/game/afterstories.rpy:186
translate es rayafterstory_852af90b:

    # n "His eyes follow my own and he walks over picking them up. Ray gives a tired smile and places them on the sleek counter top in front of me."
    n "Sus ojos siguen los míos y camina para recogerlos. Ray sonríe con cansancio y los coloca sobre el mostrador elegante frente a mí."

# game/game/afterstories.rpy:188
translate es rayafterstory_b66102aa:

    # n "{color=#510f80} 'Some rental properties..?' {/color}"
    n "{color=#510f80} '¿Algunas propiedades en alquiler..?' {/color}"

# game/game/afterstories.rpy:190
translate es rayafterstory_f8910a27:

    # n "I shift through the stack of apartments, a good portion of them are pretty solid finds."
    n "Reviso el montón de apartamentos, una buena parte de ellos parecen opciones sólidas."

# game/game/afterstories.rpy:192
translate es rayafterstory_d21da7a7:

    # n "{color=#CD9300} 'You said the last ones were too expensive, so I tried to find something a bit more reasonable for you.' {/color}"
    n "{color=#CD9300} 'Dijiste que los anteriores eran demasiado caros, así que intenté encontrar algo un poco más razonable para ti.' {/color}"

# game/game/afterstories.rpy:194
translate es rayafterstory_d9a39a33:

    # n "I continue to flip through them."
    n "Sigo hojeándolos."

# game/game/afterstories.rpy:196
translate es rayafterstory_bd6a9034:

    # n "{color=#510f80} 'You didn't have to find all of these for me.' {/color} I say feeling a little guilty."
    n "{color=#510f80} 'No tenías que buscar todos estos por mí.' {/color} digo sintiéndome un poco culpable."

# game/game/afterstories.rpy:198
translate es rayafterstory_9a478fec:

    # n "I glance up at Ray, he smiles at me in an embarrassed way, probably realizing he may have overdone it a tad."
    n "Levanto la vista hacia Ray; él me sonríe de forma algo avergonzada, probablemente dándose cuenta de que quizá se pasó un poco."

# game/game/afterstories.rpy:200
translate es rayafterstory_904a4b1e:

    # n "{color=#CD9300} 'Well you said being here was temporary and you wanted your own place...' {/color}"
    n "{color=#CD9300} 'Bueno, dijiste que estar aquí era temporal y que querías tu propio hogar...' {/color}"

# game/game/afterstories.rpy:202
translate es rayafterstory_f5c43ff8:

    # n "{color=#CD9300} 'But of course, you are more than welcome to stay here.' {/color}"
    n "{color=#CD9300} 'Pero por supuesto, siempre puedes quedarte aquí.' {/color}"

# game/game/afterstories.rpy:204
translate es rayafterstory_21106da9:

    # n "{color=#CD9300} 'In fact, I would love you to...' {/color}"
    n "{color=#CD9300} 'De hecho, me encantaría que lo hicieras...' {/color}"

# game/game/afterstories.rpy:206
translate es rayafterstory_c57c526d:

    # n "I look at Ray. He seems genuine. I do care about him, and I like being around him ..."
    n "Miro a Ray. Parece sincero. Me importa, y me gusta estar cerca de él..."

# game/game/afterstories.rpy:208
translate es rayafterstory_17d0b671:

    # n "But our relationship...or whatever this is, didn't really start out on the best footing."
    n "Pero nuestra relación... o lo que sea esto, no empezó precisamente con buen pie."

# game/game/afterstories.rpy:210
translate es rayafterstory_60944ffa:

    # n "{i}'And I can't just live with him. I need to rebuild trust with him first.'{/i}"
    n "{i}'Y no puedo simplemente vivir con él. Necesito reconstruir la confianza primero.'{/i}"

# game/game/afterstories.rpy:212
translate es rayafterstory_d8b9c614:

    # n "{color=#CD9300} 'We can take it slow, take all the time needed to rebuild it.' {/color}"
    n "{color=#CD9300} 'Podemos ir despacio, tomarnos todo el tiempo necesario para reconstruirla.' {/color}"

# game/game/afterstories.rpy:214
translate es rayafterstory_92d2bb20:

    # n "{color=#510f80} 'Ray...' {/color}"
    n "{color=#510f80} 'Ray...' {/color}"

# game/game/afterstories.rpy:216
translate es rayafterstory_1b0a2794:

    # n "{color=#CD9300} 'Oh, sorry!' {/color}"
    n "{color=#CD9300} '¡Oh, lo siento!' {/color}"

# game/game/afterstories.rpy:218
translate es rayafterstory_07ded230:

    # n "He cringes. We previously set boundaries where Ray would not read my mind, but after a lifetime of old habit, a new habit can be hard to build."
    n "Hace una mueca. Ya habíamos establecido límites donde Ray no leería mi mente, pero después de toda una vida de hábitos, crear uno nuevo puede ser difícil."

# game/game/afterstories.rpy:220
translate es rayafterstory_c5847bac:

    # n "{color=#CD9300} 'I didn't- I'm...-' {/color}"
    n "{color=#CD9300} 'No lo hice—yo...—' {/color}"

# game/game/afterstories.rpy:222
translate es rayafterstory_ba773b80:

    # n "{color=#510f80} 'We are learning, it's okay.' {/color}"
    n "{color=#510f80} 'Estamos aprendiendo, está bien.' {/color}"

# game/game/afterstories.rpy:224
translate es rayafterstory_9edf2015:

    # n "Ray smiles, seeming genuinely relieved."
    n "Ray sonríe, visiblemente aliviado."

# game/game/afterstories.rpy:226
translate es rayafterstory_125bfa49:

    # n "{color=#CD9300} 'I dog-eared the ones that I thought looked good.' {/color}"
    n "{color=#CD9300} 'Marqué las que pensé que se veían bien.' {/color}"

# game/game/afterstories.rpy:228
translate es rayafterstory_1228b54e:

    # n "I started flipping through looking at all of the bookmarked ones."
    n "Empiezo a hojear mirando todas las que tienen marca."

# game/game/afterstories.rpy:230
translate es rayafterstory_cc83f847:

    # n "Something similar seemed to carry through out all of them..."
    n "Algo similar parece repetirse en todas..."

# game/game/afterstories.rpy:232
translate es rayafterstory_6eb6106a:

    # n "{color=#510f80} 'Are... all of these within a 3 block vicinity from here..?' {/color}"
    n "{color=#510f80} '¿Están... todas dentro de un radio de tres cuadras de aquí..?' {/color}"

# game/game/afterstories.rpy:234
translate es rayafterstory_7055db90:

    # n "Ray gives a little smirk sipping his coffee."
    n "Ray esboza una pequeña sonrisa mientras bebe su café."

# game/game/afterstories.rpy:236
translate es rayafterstory_d35ab8d2:

    # n "{color=#CD9300} 'I still want you close to me Star, {i}sue me.{/i}' {/color}"
    n "{color=#CD9300} 'Aún quiero tenerte cerca, Estrella, {i>demándame.{/i}' {/color}"

# game/game/afterstories.rpy:238
translate es rayafterstory_0e16b441:

    # n "Ray gives me an indecipherable look."
    n "Ray me lanza una mirada indescifrable."

# game/game/afterstories.rpy:240
translate es rayafterstory_81499c71:

    # n "{color=#CD9300} {size=-10}'You should be happy I'm even letting you go...' {/size} {/color}"
    n "{color=#CD9300} {size=-10}'Deberías agradecer de que siquiera te deje ir...'{/size} {/color}"

# game/game/afterstories.rpy:242
translate es rayafterstory_7f06ceef:

    # n "A second passes before he smiles."
    n "Pasa un segundo antes de que sonría."

# game/game/afterstories.rpy:244
translate es rayafterstory_98f48754:

    # n "{color=#CD9300} 'Kidding~' {/color}"
    n "{color=#CD9300} 'Es broma~' {/color}"

# game/game/afterstories.rpy:246
translate es rayafterstory_6ec65a48:

    # n "He was not kidding."
    n "No era broma."

# game/game/afterstories.rpy:248
translate es rayafterstory_7d086789:

    # n "{color=#CD9300} 'So, what are your plans for today?' {/color}"
    n "{color=#CD9300} 'Entonces, ¿cuáles son tus planes para hoy?' {/color}"

# game/game/afterstories.rpy:250
translate es rayafterstory_a4513d7c:

    # n "I think for a moment but decide on not responding to his former statement."
    n "Pienso por un momento, pero decido no responder a su comentario anterior."

# game/game/afterstories.rpy:252
translate es rayafterstory_d8fcfde9:

    # n "{color=#510f80} 'Probably job hunting, visit some of these rentals....this one looks pretty good.', {/color} I say pulling a paper from the stack."
    n "{color=#510f80} 'Probablemente buscando trabajo, visitar algunos de estos alquileres... este se ve bastante bien.', {/color} digo sacando un papel del montón."

# game/game/afterstories.rpy:254
translate es rayafterstory_a9a6e109:

    # n "Ray sips his coffee looking thoughtfully."
    n "Ray bebe un sorbo de café, pensativo."

# game/game/afterstories.rpy:256
translate es rayafterstory_ff013462:

    # n "{color=#CD9300} 'Sounds nice, maybe I'll join.' {/color}"
    n "{color=#CD9300} 'Suena bien, tal vez me una.' {/color}"

# game/game/afterstories.rpy:258
translate es rayafterstory_31d12a54:

    # n "{color=#510f80} 'I don't remember inviting you, and... don't you have work?' {/color}"
    n "{color=#510f80} 'No recuerdo haberte invitado, y... ¿no tienes trabajo?' {/color}"

# game/game/afterstories.rpy:260
translate es rayafterstory_cc8cf6fd:

    # n "Ray sets down his coffee. He brushes a hand through his hair."
    n "Ray deja su café a un lado. Pasa una mano por su cabello."

# game/game/afterstories.rpy:262
translate es rayafterstory_c0e5b9ab:

    # n "{color=#CD9300} 'Mmmmm, not really feeling it today...' {/color}"
    n "{color=#CD9300} 'Mmmmm, hoy no tengo muchas ganas...' {/color}"

# game/game/afterstories.rpy:264
translate es rayafterstory_93f6836b:

    # n "{color=#510f80} 'Ray, you protect the whole city. What do you mean you don't feel like it?' {/color}"
    n "{color=#510f80} 'Ray, tú proteges toda la ciudad. ¿Qué quieres decir con que no tienes ganas?' {/color}"

# game/game/afterstories.rpy:266
translate es rayafterstory_38d4ed4b:

    # n "{color=#CD9300} 'They can deal with me skipping a day.' {/color}"
    n "{color=#CD9300} 'Pueden arreglárselas sin mí por un día.' {/color}"

# game/game/afterstories.rpy:268
translate es rayafterstory_5f02730c:

    # n "{color=#CD9300} 'If the city can't protect itself for a single day, it doesn't deserve to have the peace that it does.' {/color}"
    n "{color=#CD9300} 'Si la ciudad no puede protegerse sola por un solo día, no merece la paz que tiene.' {/color}"

# game/game/afterstories.rpy:270
translate es rayafterstory_dc4f5a32:

    # n "{color=#510f80} 'Didn't that super villain 'Vandal' announce that he was going to attack the city today...?' {/color}"
    n "{color=#510f80} '¿No fue ese supervillano 'Vandal' quien anunció que atacaría la ciudad hoy...?' {/color}"

# game/game/afterstories.rpy:272
translate es rayafterstory_770c29f9:

    # n "Ray sips some coffee waving his hand dismissively."
    n "Ray toma un poco de café y agita la mano con desdén."

# game/game/afterstories.rpy:274
translate es rayafterstory_754223ef:

    # n "{color=#CD9300} 'Not my problem.' {/color} He states dismissively."
    n "{color=#CD9300} 'No es mi problema.' {/color} dice con indiferencia."

# game/game/afterstories.rpy:276
translate es rayafterstory_8abd2835:

    # n "{color=#CD9300} 'Plus, I'm depressed.....the object of my love and affections is moving out.' {/color}"
    n "{color=#CD9300} 'Además, estoy deprimido... el objeto de mi amor y afecto se está mudando.' {/color}"

# game/game/afterstories.rpy:278
translate es rayafterstory_d30a05a1:

    # n "Ray gives a sad expression that was obviously forced."
    n "Ray pone una expresión triste, claramente forzada."

# game/game/afterstories.rpy:280
translate es rayafterstory_72de444b:

    # n "{color=#CD9300} 'I think I might have to lay in bed and watch sitcoms all day.' {/color}"
    n "{color=#CD9300} 'Creo que tendré que quedarme en la cama viendo comedias todo el día.' {/color}"

# game/game/afterstories.rpy:282
translate es rayafterstory_be1f891b:

    # n "{i}He's really playing it up...{/i}"
    n "{i}Realmente está exagerando...{/i}"

# game/game/afterstories.rpy:284
translate es rayafterstory_81df357a:

    # n "{color=#510f80} '...you hate sitcoms.' {/color}"
    n "{color=#510f80} '...odias las comedias.' {/color}"

# game/game/afterstories.rpy:286
translate es rayafterstory_7167d244:

    # n "{color=#CD9300} 'Nature documentaries then.' {/color}"
    n "{color=#CD9300} 'Entonces documentales de naturaleza.' {/color}"

# game/game/afterstories.rpy:288
translate es rayafterstory_b4c498cd:

    # n "{color=#510f80} 'Depressed people don't watch nature documentaries.' {/color}"
    n "{color=#510f80} 'Las personas deprimidas no ven documentales de naturaleza.' {/color}"

# game/game/afterstories.rpy:290
translate es rayafterstory_4a36e643:

    # n "{color=#CD9300} 'Oh so first you break my heart, and now you put me in a box? You are {i}so {/i} ruthless Star.' {/color}"
    n "{color=#CD9300} 'Ah, ¿así que primero rompes mi corazón y ahora me encasillas? Eres {i}tan{/i} cruel, Estrella.' {/color}"

# game/game/afterstories.rpy:292
translate es rayafterstory_cfa221b5:

    # n "Ray cracks a smile, unable to keep a straight face."
    n "Ray sonríe, incapaz de mantener el rostro serio."

# game/game/afterstories.rpy:294
translate es rayafterstory_8f90c75d:

    # n "{color=#510f80} 'You are so insufferable.' {/color}"
    n "{color=#510f80} 'Eres tan insoportable.' {/color}"

# game/game/afterstories.rpy:296
translate es rayafterstory_c1d69373:

    # n "{color=#CD9300} 'I learned from the best brat around.' {/color} He gives me a cocky wink."
    n "{color=#CD9300} 'Lo aprendí de ti.' {/color} me guiña un ojo con descaro."

# game/game/afterstories.rpy:298
translate es rayafterstory_ef9b0fbe:

    # n "Ray starts to rinse his mug."
    n "Ray empieza a enjuagar su taza."

# game/game/afterstories.rpy:300
translate es rayafterstory_c352f941:

    # n "{color=#510f80} 'Ray are you really not going to protect the city...?' {/color}"
    n "{color=#510f80} 'Ray, ¿de verdad no vas a proteger la ciudad...?' {/color}"

# game/game/afterstories.rpy:302
translate es rayafterstory_a4d8efe9:

    # n "Ray doesn't answer and just places his mug in the dishwasher."
    n "Ray no responde y solo coloca su taza en el lavavajillas."

# game/game/afterstories.rpy:304
translate es rayafterstory_2103332c:

    # n "I get up and approach the tired looking blonde man."
    n "Me levanto y me acerco al hombre rubio de aspecto cansado."

# game/game/afterstories.rpy:306
translate es rayafterstory_81556a49:

    # n "{color=#510f80} 'Ray...please?' {/color}"
    n "{color=#510f80} 'Ray... por favor?' {/color}"

# game/game/afterstories.rpy:308
translate es rayafterstory_dba80985:

    # n "{color=#CD9300} 'No.' {/color}"
    n "{color=#CD9300} 'No.' {/color}"

# game/game/afterstories.rpy:310
translate es rayafterstory_92d2bb20_1:

    # n "{color=#510f80} 'Ray...' {/color}"
    n "{color=#510f80} 'Ray...' {/color}"

# game/game/afterstories.rpy:312
translate es rayafterstory_76c5c704:

    # n "Ray sighs, his shoulder slumping."
    n "Ray suspira, bajando los hombros."

# game/game/afterstories.rpy:314
translate es rayafterstory_69cd0742:

    # n "{color=#CD9300} 'Fine, but I need to steal some energy from you first.' {/color}"
    n "{color=#CD9300} 'Está bien, pero necesito robarte un poco de energía primero.' {/color}"

# game/game/afterstories.rpy:316
translate es rayafterstory_62c4dd43:

    # n "{color=#510f80} 'Wha-?' {/color}"
    n "{color=#510f80} '¿Qué—?' {/color}"

# game/game/afterstories.rpy:318
translate es rayafterstory_a644309b:

    # n "Ray turns around and wraps me into a tight hug."
    n "Ray se da la vuelta y me envuelve en un abrazo fuerte."

# game/game/afterstories.rpy:320
translate es rayafterstory_d3982600:

    # n "His arms and chest surround me like a cocoon, his soft sweater plush against my face."
    n "Sus brazos y su pecho me rodean como un capullo, su suéter suave contra mi rostro."

# game/game/afterstories.rpy:322
translate es rayafterstory_e55d3938:

    # n "His hot breath brushes against my ear making goosebumps rise on my skin."
    n "Su aliento caliente roza mi oído, erizando mi piel."

# game/game/afterstories.rpy:324
translate es rayafterstory_4b29c16e:

    # n "My face heats up and I start to squirm, he continues to hold me."
    n "Mi rostro se enciende y comienzo a moverme con incomodidad, pero él continúa abrazándome. "

# game/game/afterstories.rpy:326
translate es rayafterstory_4ac56331:

    # n "I can feel his calm steady heartbeat. Something in me knew he was holding onto me as if I was his last thread to this world."
    n "Puedo sentir su corazón, firme y tranquilo. Algo en mí sabía que me sostenía como si yo fuera su último hilo con este mundo."

# game/game/afterstories.rpy:328
translate es rayafterstory_57ab17c8:

    # n "{i}'Stay with us Ray, don't disappear.'{/i}"
    n "{i}'Quédate con nosotros, Ray, no desaparezcas.'{/i}"

# game/game/afterstories.rpy:330
translate es rayafterstory_b2d61671:

    # n "He breathes me in and exhales, Grounding himself to humanity."
    n "Inhala mi aroma y exhala, anclándose a la humanidad."

# game/game/afterstories.rpy:332
translate es rayafterstory_5d0da3da:

    # n "A minute or so passes. Finally Ray pulls back."
    n "Pasa un minuto o dos. Finalmente Ray se separa."

# game/game/afterstories.rpy:334
translate es rayafterstory_1b6b1c43:

    # n "{color=#CD9300} 'Okay, Sorry. I feel energized again.' {/color}"
    n "{color=#CD9300} 'Bien, lo siento. Me siento con energía otra vez.' {/color}"

# game/game/afterstories.rpy:336
translate es rayafterstory_15b5d974:

    # n "{color=#CD9300} 'I'll go to work now, sorry for worrying you Star.' {/color}"
    n "{color=#CD9300} 'Iré a trabajar ahora, perdón por preocuparte, Estrella.' {/color}"

# game/game/afterstories.rpy:338
translate es rayafterstory_bb2cf764:

    # n "..."
    n "..."

# game/game/afterstories.rpy:343
translate es rayafterstory_21f0cca3:

    # n "I look at the tired man leaned over the sink. His pale hair slips over his shoulder as he works. The dull shine sparkles in the sun that peaks through the window."
    n "Miro al hombre cansado inclinado sobre el fregadero. Su cabello pálido cae sobre su hombro mientras trabaja. El brillo opaco reluce con el sol que se cuela por la ventana."

# game/game/afterstories.rpy:345
translate es rayafterstory_1f3d815e:

    # n "Despite his past, despite his perceived failures, despite his agony, hatred, contempt, he was fighting still."
    n "A pesar de su pasado, de sus aparentes fracasos, de su agonía, odio y desprecio, seguía luchando."

# game/game/afterstories.rpy:347
translate es rayafterstory_5eaa8a5d:

    # n "Fighting against the hardest competitor, himself."
    n "Luchando contra su competidor más difícil: él mismo."

# game/game/afterstories.rpy:349
translate es rayafterstory_803244d8:

    # n "He turns to finish the rest of the dishes."
    n "Se vuelve para terminar el resto de los platos."

# game/game/afterstories.rpy:351
translate es rayafterstory_79b790c9:

    # n "{color=#510f80} 'Ray' {/color} I call to him."
    n "{color=#510f80} 'Ray' {/color} lo llamo."

# game/game/afterstories.rpy:353
translate es rayafterstory_69b3a693:

    # n "He turns slightly to look at me. I take the opportunity to cup his face bringing his lips to mine."
    n "Gira ligeramente para mirarme. Aprovecho la oportunidad para tomar su rostro y acercar sus labios a los míos."

# game/game/afterstories.rpy:355
translate es rayafterstory_58349db7:

    # n "I kiss him deeply, with so much care. At first his eyes are wide, shocked."
    n "Lo beso profundamente, con tanto cuidado. Al principio sus ojos se abren, sorprendido."

# game/game/afterstories.rpy:357
translate es rayafterstory_b7195620:

    # n "Then he deepens the kiss, dropping whatever he was holding to wrap his arms around me. To press himself into me more desperately than before."
    n "Luego profundiza el beso, dejando caer lo que tenía en las manos para rodearme con los brazos. Se presiona contra mí con más desesperación que antes."

# game/game/afterstories.rpy:359
translate es rayafterstory_a43a3b6e:

    # n "I correct my arms wrapping them around his neck. He walks me backward a bit as he pushes into me, threading the kiss ever deeper."
    n "Acomodo mis brazos alrededor de su cuello. Me hace retroceder un poco mientras el beso se vuelve más intenso."

# game/game/afterstories.rpy:361
translate es rayafterstory_0bb368bd:

    # n "I finally break away, looking up at him breathless."
    n "Finalmente me separo, mirándolo sin aliento."

# game/game/afterstories.rpy:363
translate es rayafterstory_3243cbcb:

    # n "{color=#510f80} 'How was that for some energy?' {/color} I smirk at him."
    n "{color=#510f80} '¿Qué tal eso como un poco de energía?' {/color} le sonrío."

# game/game/afterstories.rpy:365
translate es rayafterstory_6286ddf9:

    # n "His eyes stare at me with molten heat."
    n "Sus ojos me miran con un calor fundido."

# game/game/afterstories.rpy:367
translate es rayafterstory_984dad6f:

    # n "{color=#CD9300} 'I'm going to be late to work.' {/color} he states matter-of-fact before picking me up with ease."
    n "{color=#CD9300} 'Voy a llegar tarde al trabajo.' {/color} dice con naturalidad antes de levantarme con facilidad."

# game/game/afterstories.rpy:369
translate es rayafterstory_555869d3:

    # n "He carries me out of the kitchen..."
    n "Me carga fuera de la cocina..."

# game/game/afterstories.rpy:371
translate es rayafterstory_0087c78c:

    # n "And towards the bedroom."
    n "Y hacia el dormitorio."

# game/game/afterstories.rpy:375
translate es rayafterstory_4c724cc0:

    # n "{color=#510f80} 'Do your best today.' {/color}"
    n "{color=#510f80} 'Haz tu mejor esfuerzo hoy.' {/color}"

# game/game/afterstories.rpy:377
translate es rayafterstory_c4849f5e:

    # n "Ray looks at me curiously."
    n "Ray me mira con curiosidad."

# game/game/afterstories.rpy:379
translate es rayafterstory_247cb182:

    # n "{color=#510f80} 'You can do i-it!' {/color}, I give a small fist bump getting embarrassed as I try to cheer on Ray."
    n "{color=#510f80} '¡Tú puedes!' {/color}, levanto un pequeño puño, con pena mientras intento animarlo."

# game/game/afterstories.rpy:381
translate es rayafterstory_daa04eb9:

    # n "{color=#CD9300} 'Pfft...!' {/color}"
    n "{color=#CD9300} '¡Pfft...!' {/color}"

# game/game/afterstories.rpy:383
translate es rayafterstory_9b5b112e:

    # n "Ray covers his face turning away, I knew he was trying his hardest not to laugh at me."
    n "Ray se cubre el rostro, dándose la vuelta; sabía que se estaba conteniendo para no reírse de mí."

# game/game/afterstories.rpy:385
translate es rayafterstory_3b112667:

    # n "{color=#510f80} 'Oh my god Ray you are so rude!' {/color} I pout crossing my arms, looking at him through knitted eyebrows."
    n "{color=#510f80} '¡Dios mío, Ray, qué grosero eres!' {/color} hago un puchero, cruzando los brazos y mirándolo entre el ceño fruncido."

# game/game/afterstories.rpy:387
translate es rayafterstory_bbdfa15f:

    # n "{color=#CD9300} 'Hahahaha!' {/color}"
    n "{color=#CD9300} '¡Jajajaja!' {/color}"

# game/game/afterstories.rpy:389
translate es rayafterstory_365dc2d6:

    # n "Ray laughs genuinely, his eyes creasing and eyebrows pressing upwards."
    n "Ray ríe de verdad, sus ojos se arrugan y las cejas se elevan."

# game/game/afterstories.rpy:391
translate es rayafterstory_a4158bab:

    # n "My pout softens as I realize I have never actually seen him laugh genuinely before."
    n "Mi puchero se suaviza al darme cuenta de que nunca lo había visto reír sinceramente antes."

# game/game/afterstories.rpy:393
translate es rayafterstory_8a8f8c46:

    # n "He reaches over and ruffles my hair."
    n "Extiende la mano y me despeina el cabello."

# game/game/afterstories.rpy:395
translate es rayafterstory_b489a0f7:

    # n "{color=#CD9300} 'You are just {i}too {/i} goddamn cute, you know that?' {/color}"
    n "{color=#CD9300} 'Eres simplemente {i}demasiado{/i} condenadamente adorable, ¿lo sabías?' {/color}"

# game/game/afterstories.rpy:397
translate es rayafterstory_724eff38:

    # n "{color=#CD9300} 'What am I gonna do with you Star?' {/color}"
    n "{color=#CD9300} '¿Qué voy a hacer contigo, Estrella?' {/color}"

# game/game/afterstories.rpy:399
translate es rayafterstory_68e24815:

    # n "{color=#510f80} '...I was just trying to cheer you on.'{/color} I mumble looking away, face red."
    n "{color=#510f80} '...solo intentaba animarte.'{/color} murmuro, mirando hacia otro lado con el rostro rojo."

# game/game/afterstories.rpy:401
translate es rayafterstory_ed45e829:

    # n "Ray puts his hands up in defeat, smiling."
    n "Ray levanta las manos en rendición, sonriendo."

# game/game/afterstories.rpy:403
translate es rayafterstory_1e89150c:

    # n "{color=#CD9300} 'I know, I know, I'm sorry. I didn't mean to laugh, really!' {/color}"
    n "{color=#CD9300} 'Lo sé, lo sé, lo siento. No quería reírme, ¡de verdad!' {/color}"

# game/game/afterstories.rpy:405
translate es rayafterstory_e500cd48:

    # n "{color=#CD9300} 'I promise I won't laugh next time.' {/color}"
    n "{color=#CD9300} 'Prometo que no me reiré la próxima vez.' {/color}"

# game/game/afterstories.rpy:407
translate es rayafterstory_edd18b87:

    # n "I look at him skeptically."
    n "Lo miro con escepticismo."

# game/game/afterstories.rpy:409
translate es rayafterstory_d91c406e:

    # n "{color=#CD9300} 'I swear it!' {/color}"
    n "{color=#CD9300} '¡Lo juro!' {/color}"

# game/game/afterstories.rpy:411
translate es rayafterstory_a95421db:

    # n "{color=#510f80} 'Fine.' {/color}"
    n "{color=#510f80} 'Está bien.' {/color}"

# game/game/afterstories.rpy:413
translate es rayafterstory_11c7d2c9:

    # n "He approaches me cupping my face. Ray smiles at me warmly."
    n "Se acerca y toma mi rostro entre sus manos. Ray me sonríe con calidez."

# game/game/afterstories.rpy:415
translate es rayafterstory_350cd39e:

    # n "{color=#CD9300} 'Please cheer me on again Star.' {/color} He mumbles to me in a soft voice, leaning down and placing a tender kiss on my cheek."
    n "{color=#CD9300} 'Por favor, anímame otra vez, Estrella.' {/color} murmura con voz suave, inclinándose y dándome un tierno beso en la mejilla."

# game/game/afterstories.rpy:417
translate es rayafterstory_3db9bf4b:

    # n "My face heats up once again."
    n "Mi rostro vuelve a sonrojarse."

# game/game/afterstories.rpy:419
translate es rayafterstory_1bd48988:

    # n "{color=#510f80} '....Fine.' {/color}"
    n "{color=#510f80} '...Está bien.' {/color}"

# game/game/afterstories.rpy:422
translate es rayafterstory_b8a78a87:

    # n "Ray looks at me with so much love in his eyes."
    n "Ray me mira con tanto amor en sus ojos."

# game/game/afterstories.rpy:424
translate es rayafterstory_c48413bb:

    # n "I'm not sure either of us thought we would end up here."
    n "No se si alguno de los dos pensaría que llegaríamos aquí."

# game/game/afterstories.rpy:426
translate es rayafterstory_a8b7bb44:

    # n "Loved, and being loved. Being loved, and loved."
    n "Amando y siendo amados. Siendo amados y amando."

# game/game/afterstories.rpy:428
translate es rayafterstory_5333eb40:

    # n "The future may not be the smoothest of roads. Between us, there is a lot damaged, a lot broken."
    n "El futuro puede no ser el camino más fácil. Entre nosotros hay mucho dañado, mucho roto."

# game/game/afterstories.rpy:430
translate es rayafterstory_fc9f1950:

    # n "There is a chance that we can't repair it, that two broken people only serve to shatter each other more."
    n "Existe la posibilidad de que no podamos repararlo, que dos personas rotas solo terminen destrozándose más."

# game/game/afterstories.rpy:432
translate es rayafterstory_ac47ca78:

    # n "To pull each other apart."
    n "Desgarrándose mutuamente."

# game/game/afterstories.rpy:434
translate es rayafterstory_28b13b64:

    # n "But right now in this singular moment in time, I needed Ray and Ray needed me."
    n "Pero en este preciso momento, yo necesitaba a Ray y Ray me necesitaba a mí."

# game/game/afterstories.rpy:436
translate es rayafterstory_b948c160:

    # n "As if it was forseen in the stars, we met. We collided."
    n "Como si estuviera escrito en las estrellas, nos encontramos. Colisionamos."

# game/game/afterstories.rpy:438
translate es rayafterstory_70b042b7:

    # n "The gravitational pull keeping us in a preordained dance."
    n "La fuerza gravitacional nos mantiene en una danza predestinada."

# game/game/afterstories.rpy:440
translate es rayafterstory_0498a5cc:

    # n "We orbit each other."
    n "Orbitamos el uno al otro."

# game/game/afterstories.rpy:458
translate es bshafterstory_c909263b:

    # n "The aroma of oil and garlic fill Binary Star's kitchen."
    n "El aroma a aceite y ajo llena la cocina de Binary Star."

# game/game/afterstories.rpy:460
translate es bshafterstory_f428b17d:

    # n "I sit there, staring at him from the dining room table."
    n "Me quedo ahí, mirándolo desde la mesa del comedor."

# game/game/afterstories.rpy:462
translate es bshafterstory_2324d3f7:

    # n "He catches my gaze and gives me one of his iconic smiles."
    n "Atrapa mi mirada y me regala una de sus sonrisas características."

# game/game/afterstories.rpy:464
translate es bshafterstory_4f50cf21:

    # n "It is shallow, able to be swept away by a change in tide."
    n "Es superficial, capaz de desvanecerse con un simple cambio de marea."

# game/game/afterstories.rpy:466
translate es bshafterstory_c507d598:

    # n "{color=#CD9300} 'Be a dear and set the table?' {/color}"
    n "{color=#CD9300} '¿Podrías ser tan amable de poner la mesa?' {/color}"

# game/game/afterstories.rpy:468
translate es bshafterstory_d1b2ea79:

    # n "Ray asks, his eyes shifting back to the pan in his hands. His calm yet confident voice carries over the soft music that hums in the background."
    n "pregunta Ray, con la vista de nuevo en la sartén que sostiene. Su voz, calmada pero segura, se mezcla con la suave música que suena de fondo."

# game/game/afterstories.rpy:470
translate es bshafterstory_1e98e539:

    # n "I get up and grab two plates from his cupboard."
    n "Me levanto y tomo dos platos del armario."

# game/game/afterstories.rpy:472
translate es bshafterstory_ae1dd386:

    # n "He watches me pass by, but dares not to reach out towards me."
    n "Me observa pasar, pero no se atreve a extender la mano hacia mí."

# game/game/afterstories.rpy:474
translate es bshafterstory_7672d2f3:

    # n "Despite living together, we haven't had much intimacy yet."
    n "A pesar de vivir juntos, no hemos tenido mucha intimidad todavía."

# game/game/afterstories.rpy:476
translate es bshafterstory_a67ea64a:

    # n "Things were nice and rosy for a while... but the longer he is 'Binary Star', the less I have seen 'Ray'."
    n "Las cosas fueron agradables y color de rosa por un tiempo... pero cuanto más tiempo pasa siendo 'Binary Star', menos he visto a 'Ray'."

# game/game/afterstories.rpy:478
translate es bshafterstory_312cf5eb:

    # n "Between 'Binary Star' and 'Ray', to tell you the truth, I'm not sure if I understand either."
    n "Entre 'Binary Star' y 'Ray', sinceramente, no creo entender a ninguno."

# game/game/afterstories.rpy:480
translate es bshafterstory_590bce00:

    # n "Half the time, I'm not even sure who I'm talking to anymore."
    n "La mitad del tiempo, ni siquiera se con quién estoy hablando."

# game/game/afterstories.rpy:482
translate es bshafterstory_e64c32ac:

    # n "Things started to get tense when he couldn't find Double."
    n "Las cosas empezaron a tensarse cuando no pudo encontrar a Double."

# game/game/afterstories.rpy:484
translate es bshafterstory_879b62e8:

    # n "After a few weeks, Binary Star decided it would be better if he stopped trying. His search extended too far and it was dangerous to be away from me for so long."
    n "Después de unas semanas, Binary Star decidió que sería mejor dejar de buscar. Su búsqueda se extendió demasiado y era peligroso estar lejos de mí tanto tiempo."

# game/game/afterstories.rpy:486
translate es bshafterstory_6808d8bd:

    # n "So instead, he watches over me in his skyscraper apartment."
    n "Así que, en su lugar, me vigila desde su apartamento en el rascacielos."

# game/game/afterstories.rpy:488
translate es bshafterstory_88779f8f:

    # n "Every now and then Ray disappears for a couple of days, sometimes hurt other times not."
    n "De vez en cuando Ray desaparece por un par de días, a veces herido, otras no."

# game/game/afterstories.rpy:490
translate es bshafterstory_0270903d:

    # n "I recently noticed, the number of abilities he has must be increasing."
    n "Recientemente noté que el número de habilidades que tiene debe estar aumentando."

# game/game/afterstories.rpy:492
translate es bshafterstory_69dbd57a:

    # n "His mental state seems changing too."
    n "Su estado mental también parece estar cambiando."

# game/game/afterstories.rpy:494
translate es bshafterstory_9bfd8051:

    # n "When he doesn't notice me looking, his facial expression seems truly empty, Devoid of anything that resembles a human."
    n "Cuando no nota que lo miro, su expresión facial parece verdaderamente vacía, desprovista de cualquier cosa que parezca humana."

# game/game/afterstories.rpy:496
translate es bshafterstory_91a39e20:

    # n "It worries me, but I don't even know how to ask if he's okay... It made me realize I knew Binary Star even less than I thought I did."
    n "Me preocupa, pero ni siquiera sé cómo preguntarle si está bien... Me hizo darme cuenta de que conocía a Binary Star aún menos de lo que creía."

# game/game/afterstories.rpy:498
translate es bshafterstory_a2d00141:

    # n "I set the table nicely, putting wine glasses out along with water glasses."
    n "Pongo la mesa con cuidado, colocando copas de vino junto con vasos de agua."

# game/game/afterstories.rpy:500
translate es bshafterstory_7be9a001:

    # n "When Ray plates the food I place it on the table too."
    n "Cuando Ray sirve la comida, yo la coloco también en la mesa."

# game/game/afterstories.rpy:502
translate es bshafterstory_48ec7689:

    # n "I sit down in my seat in the way that has become all too normal."
    n "Me siento en mi lugar, de la forma que se ha vuelto demasiado habitual."

# game/game/afterstories.rpy:504
translate es bshafterstory_d4da578f:

    # n "With a light 'pop' Ray opens a wine bottle bringing it to the table."
    n "Con un suave 'pop', Ray abre una botella de vino y la lleva a la mesa."

# game/game/afterstories.rpy:506
translate es bshafterstory_4e38025e:

    # n "{color=#CD9300} 'Would you like some?' {/color}"
    n "{color=#CD9300} '¿Quieres un poco?' {/color}"

# game/game/afterstories.rpy:510
translate es bshafterstory_54e5549b:

    # n "I nod lightly and Ray gives a tasteful pour into my glass."
    n "Asiento levemente y Ray vierte una porción moderada en mi copa."

# game/game/afterstories.rpy:512
translate es bshafterstory_86ae7a0e:

    # n "I watch, mesmerized by the dark red liquid as it lightly ebbs against the crystal."
    n "Observo, atentamente, el líquido rojo oscuro mientras ondula suavemente contra el cristal."

# game/game/afterstories.rpy:514
translate es bshafterstory_c50ad50e:

    # n "Ray pours himself some and sets it on the table."
    n "Ray se sirve un poco y deja la copa sobre la mesa."

# game/game/afterstories.rpy:517
translate es bshafterstory_56d6b682:

    # n "{color=#510f80} 'I'm okay I think...'{/color}"
    n "{color=#510f80} 'Estoy bien, creo...' {/color}"

# game/game/afterstories.rpy:519
translate es bshafterstory_bc20e04b:

    # n "He smiles."
    n "Él sonríe."

# game/game/afterstories.rpy:521
translate es bshafterstory_cbea9fcb:

    # n "{color=#CD9300} 'Probably for the best.' {/color}"
    n "{color=#CD9300} 'Probablemente sea lo mejor.' {/color}"

# game/game/afterstories.rpy:523
translate es bshafterstory_f025ee47:

    # n "{color=#510f80} 'What's that supposed to mean?'{/color}"
    n "{color=#510f80} '¿Qué se supone que significa eso?' {/color}"

# game/game/afterstories.rpy:525
translate es bshafterstory_c17e65c8:

    # n "{color=#CD9300} 'I didn't mean it as an insult. Only that alcohol doesn't have the health properties people say that it does.'{/color}"
    n "{color=#CD9300} 'No lo dije como un insulto. Solo que el alcohol no tiene las propiedades saludables que la gente dice que tiene.' {/color}"

# game/game/afterstories.rpy:527
translate es bshafterstory_6b17f6eb:

    # n "I nod lightly."
    n "Asiento ligeramente."

# game/game/afterstories.rpy:529
translate es bshafterstory_91156129:

    # n "He smiles again."
    n "Él sonríe de nuevo."

# game/game/afterstories.rpy:531
translate es bshafterstory_9a48615a:

    # n "We start to eat."
    n "Comenzamos a comer."

# game/game/afterstories.rpy:533
translate es bshafterstory_947fc356:

    # n "Silence rests over the soft music. Music Ray somehow knew that I liked."
    n "El silencio se mezcla con la música suave. Música que Ray, de alguna forma, sabía que me gustaba."

# game/game/afterstories.rpy:535
translate es bshafterstory_8c5568fa:

    # n "{color=#CD9300} 'Is it alright...?' {/color}"
    n "{color=#CD9300} '¿Está bien...?' {/color}"

# game/game/afterstories.rpy:537
translate es bshafterstory_930cb62e:

    # n "I nod"
    n "Asiento."

# game/game/afterstories.rpy:539
translate es bshafterstory_0cc9e5d4:

    # n "{color=#510f80} 'It's very good.'{/color}"
    n "{color=#510f80} 'Está muy bueno.' {/color}"

# game/game/afterstories.rpy:541
translate es bshafterstory_b57efd9b:

    # n "{color=#CD9300} 'Great! I learned this recipe to cook for you specifically. I was hoping you would enjoy it.' {/color}"
    n "{color=#CD9300} '¡Genial! Aprendí esta receta específicamente para cocinarte. Esperaba que te gustara.' {/color}"

# game/game/afterstories.rpy:543
translate es bshafterstory_11ae0192:

    # n "I look up, a shallow bright smile adorning his expression."
    n "Levanto la vista; una sonrisa brillante pero superficial adorna su rostro."

# game/game/afterstories.rpy:545
translate es bshafterstory_ec3995ff:

    # n "We fall back into silence, only accompanied by the light clattering of utensils."
    n "Volvemos al silencio, solo acompañado por el leve sonido de los cubiertos."

# game/game/afterstories.rpy:547
translate es bshafterstory_435de1ec:

    # n "Soon enough the dinner is over and Ray takes my plate."
    n "Pronto la cena termina y Ray toma mi plato."

# game/game/afterstories.rpy:549
translate es bshafterstory_21c8a7d5:

    # n "I get up from my seat. Wine glass and water glass in hand."
    n "Me levanto de mi asiento, copa de vino y vaso de agua en mano."

# game/game/afterstories.rpy:551
translate es bshafterstory_65c93026:

    # n "{color=#510f80} 'Ray...'{/color}"
    n "{color=#510f80} 'Ray...' {/color}"

# game/game/afterstories.rpy:553
translate es bshafterstory_20abc48c:

    # n "He turns around at the sound of my voice."
    n "Se da vuelta al oír mi voz."

# game/game/afterstories.rpy:555
translate es bshafterstory_d54da24e:

    # n "{color=#510f80} 'I... really need to go outside.'{/color}"
    n "{color=#510f80} 'Yo... realmente necesito salir un rato.' {/color}"

# game/game/afterstories.rpy:557
translate es bshafterstory_36584cfa:

    # n "His face immediately falls, shedding the mask he so often wears."
    n "Su rostro se ensombrece de inmediato, dejando caer la máscara que suele llevar."

# game/game/afterstories.rpy:559
translate es bshafterstory_bd1b28ee:

    # n "{color=#510f80} 'I-i can't stay all couped up like this.'{/color}"
    n "{color=#510f80} 'No puedo quedarme aquí en estas cuatro paredes así.' {/color}"

# game/game/afterstories.rpy:561
translate es bshafterstory_a9832a3f:

    # n "Ray places the plates in the sink with a sigh. He washes his hands and drys them off. Every elongated second makes me more nervous."
    n "Ray coloca los platos en el fregadero con un suspiro. Se lava las manos y las seca. Cada segundo que pasa me pone más alerta."

# game/game/afterstories.rpy:563
translate es bshafterstory_92384f69:

    # n "Ray finally approaches me."
    n "Finalmente, Ray se acerca a mí."

# game/game/afterstories.rpy:565
translate es bshafterstory_50f944df:

    # n "As he walks over there is a loud explosion."
    n "Mientras camina, una fuerte explosión sacude el suelo."

# game/game/afterstories.rpy:567
translate es bshafterstory_c5aca502:

    # n "The Ground shakes and the lights flicker."
    n "El piso tiembla y las luces parpadean."

# game/game/afterstories.rpy:569
translate es bshafterstory_5c0ded0a:

    # n "I stumble, dropping the crystal wineglass which shatters onto the ground."
    n "Tropiezo, dejando caer la copa de cristal, que se hace añicos contra el suelo."

# game/game/afterstories.rpy:571
translate es bshafterstory_9c8de285:

    # n "The flickering light reflects off of the hundreds of glass shards, illuminating them like stars."
    n "La luz titilante se refleja en los cientos de fragmentos de vidrio, iluminándolos como estrellas."

# game/game/afterstories.rpy:573
translate es bshafterstory_633df34b:

    # n "{color=#CD9300} 'Don't move.' {/color}"
    n "{color=#CD9300} 'No te muevas.' {/color}"

# game/game/afterstories.rpy:575
translate es bshafterstory_dcb85943:

    # n "Ray is over me in a split second."
    n "Ray está sobre mí en un segundo."

# game/game/afterstories.rpy:577
translate es bshafterstory_3bd2e204:

    # n "He leans down gently scooping me into his arms and lifting me up without an ounce effort."
    n "Se inclina y me levanta suavemente en sus brazos sin el menor esfuerzo."

# game/game/afterstories.rpy:579
translate es bshafterstory_e24e5a79:

    # n "Ray, holds me in his arms as he saunters over to the window."
    n "Ray me sostiene mientras camina hacia la ventana."

# game/game/afterstories.rpy:581
translate es bshafterstory_579c03d2:

    # n "{color=#CD9300} 'My Star, look...' {/color}"
    n "{color=#CD9300} 'Mi Estrella, mira...' {/color}"

# game/game/afterstories.rpy:583
translate es bshafterstory_7b6c1f37:

    # n "I look up at him. He stares out of the tall window, one of many that lines his apartment."
    n "Levanto la vista hacia él. Observa por la alta ventana, una de muchas que rodean su apartamento."

# game/game/afterstories.rpy:585
translate es bshafterstory_3851a572:

    # n "I follow his gaze, My eyes landing on a dark cloud that begins to cover the other side of the city."
    n "Sigo su mirada; mis ojos se detienen en una nube oscura que empieza a cubrir el otro lado de la ciudad."

# game/game/afterstories.rpy:587
translate es bshafterstory_7f4a868c:

    # n "{color=#510f80} 'They're back...'{/color}"
    n "{color=#510f80} 'Han vuelto...' {/color}"

# game/game/afterstories.rpy:589
translate es bshafterstory_144d41d8:

    # n "The aliens begin to stalk across the city, destroying, decimating as they please."
    n "Los alienígenas comienzan a avanzar por la ciudad, destruyendo y arrasando a su antojo."

# game/game/afterstories.rpy:591
translate es bshafterstory_6aeb553e:

    # n "{color=#CD9300} 'Yes...' {/color}"
    n "{color=#CD9300} 'Sí...' {/color}"

# game/game/afterstories.rpy:593
translate es bshafterstory_1bf48a62:

    # n "{color=#CD9300} 'It's unsafe for you out there.' {/color}"
    n "{color=#CD9300} 'No es seguro para ti allá afuera.' {/color}"

# game/game/afterstories.rpy:595
translate es bshafterstory_94a61bcc:

    # n "{color=#CD9300} 'The Heroes aren't equipped to protect the city any longer from those things.' {/color}"
    n "{color=#CD9300} 'Los héroes ya no están equipados para proteger la ciudad de esas cosas.' {/color}"

# game/game/afterstories.rpy:597
translate es bshafterstory_6f7cee1b:

    # n "He smiles at me then turns back to the window."
    n "Él sonríe y luego vuelve su atención a la ventana."

# game/game/afterstories.rpy:599
translate es bshafterstory_0697866e:

    # n "{color=#CD9300} 'But the aliens, they are smart, they won't bother us.' {/color}"
    n "{color=#CD9300} 'Pero los alienígenas son inteligentes, no se meterán con nosotros.' {/color}"

# game/game/afterstories.rpy:601
translate es bshafterstory_7ea7c1ef:

    # n "{color=#CD9300} 'So, the whole city will be ours, we won't ever have to worry about Double coming after you again.' {/color}"
    n "{color=#CD9300} 'Así que toda la ciudad será nuestra, y nunca más tendrás que preocuparte de que Double te persiga.' {/color}"

# game/game/afterstories.rpy:603
translate es bshafterstory_d8ffabba:

    # n "I press my finger against the window, the alien moves underneath it, flames and smoke trailing behind."
    n "Apoyo un dedo contra la ventana; el alienígena pasa debajo, con llamas y humo a su paso."

# game/game/afterstories.rpy:608
translate es bshafterstory_508b177a:

    # n "{color=#510f80} 'What happened to the other heroes?...'{/color}"
    n "{color=#510f80} '¿Qué pasó con los otros héroes?...' {/color}"

# game/game/afterstories.rpy:610
translate es bshafterstory_d9fc270f:

    # n "Ray looks down at me. He gives a sad smile."
    n "Ray me mira hacia abajo. Me da una sonrisa triste."

# game/game/afterstories.rpy:612
translate es bshafterstory_f230db73:

    # n "{color=#CD9300} 'They couldn't keep up with the demand. The aliens got smarter, but the heroes didn't.'{/color}"
    n "{color=#CD9300} 'No pudieron seguir el ritmo. Los alienígenas se volvieron más inteligentes, pero los héroes no.' {/color}"

# game/game/afterstories.rpy:614
translate es bshafterstory_8cd2b5d1:

    # n "{color=#CD9300} 'Between the Aliens and Villains, Heroes just started to drop like flies.'{/color}"
    n "{color=#CD9300} 'Entre los alienígenas y los villanos, los héroes comenzaron a caer como moscas.' {/color}"

# game/game/afterstories.rpy:616
translate es bshafterstory_413fe268:

    # n "{color=#CD9300} 'It's a harsh world out there...'{/color}"
    n "{color=#CD9300} 'Es un mundo duro allá afuera...' {/color}"

# game/game/afterstories.rpy:620
translate es bshafterstory_bbdae0af:

    # n "{color=#510f80} 'Would the Aliens just stop after taking over this city?'{/color}"
    n "{color=#510f80} '¿Los alienígenas se detendrían después de tomar esta ciudad?' {/color}"

# game/game/afterstories.rpy:622
translate es bshafterstory_f678ee5b:

    # n "Ray gives me a measured look, then he smiles."
    n "Ray me mira con cuidado, luego sonríe."

# game/game/afterstories.rpy:624
translate es bshafterstory_4359b07f:

    # n "{color=#CD9300} 'It's hard to say...'{/color}"
    n "{color=#CD9300} 'Es difícil decirlo...' {/color}"

# game/game/afterstories.rpy:626
translate es bshafterstory_21246107:

    # n "{color=#CD9300} 'My guess would be no, but who knows.'{/color}"
    n "{color=#CD9300} 'Supongo que no, pero quién sabe.' {/color}"

# game/game/afterstories.rpy:628
translate es bshafterstory_3b2fc52a:

    # n "I watch as more Aliens move across the horizon. The glass chill on my fingertip."
    n "Observo cómo más alienígenas se mueven por el horizonte. El vidrio está frío bajo mi dedo."

# game/game/afterstories.rpy:630
translate es bshafterstory_76c0d1c7:

    # n "As I watch a tower in the distance topple and crumble it makes me feel..."
    n "Mientras miro una torre a lo lejos caer y desmoronarse, siento..."

# game/game/afterstories.rpy:634
translate es bshafterstory_c7eec7e4:

    # n "It makes me feel scared."
    n "Siento miedo."

# game/game/afterstories.rpy:636
translate es bshafterstory_b98f1e0a:

    # n "These terrifying beasts lurk and kill, we have no real idea how many of them there are."
    n "Esas criaturas aterradoras acechan y matan, sin que sepamos realmente cuántas hay."

# game/game/afterstories.rpy:638
translate es bshafterstory_da9403e5:

    # n "What they plan to do."
    n "Ni qué planean hacer."

# game/game/afterstories.rpy:640
translate es bshafterstory_c19389f3:

    # n "Ray holds me a bit tighter."
    n "Ray me sostiene un poco más fuerte."

# game/game/afterstories.rpy:642
translate es bshafterstory_d81f75c5:

    # n "{color=#CD9300} 'Don't worry, I'll protect you till my last breath.'{/color}"
    n "{color=#CD9300} 'No te preocupes, te protegeré hasta mi último aliento.' {/color}"

# game/game/afterstories.rpy:644
translate es bshafterstory_467f44a4:

    # n "{color=#CD9300} 'They won't be able to touch a hair on your head.'{/color}"
    n "{color=#CD9300} 'No podrán tocar ni un solo cabello de tu cabeza.' {/color}"

# game/game/afterstories.rpy:649
translate es bshafterstory_9ea88054:

    # n "It makes me feel sad."
    n "Eso me entristece."

# game/game/afterstories.rpy:651
translate es bshafterstory_2529a0d9:

    # n "This beautiful city destroyed for what? People suffering for what?"
    n "Esta hermosa ciudad destruida, ¿por qué? Personas sufriendo, ¿para qué?"

# game/game/afterstories.rpy:653
translate es bshafterstory_a27a9efc:

    # n "If nobody understands the intentions of these monsters, how can we even begin to process the loss? To mourn for each other?"
    n "Si nadie entiende las intenciones de esos monstruos, ¿Cómo podríamos empezar siquiera a procesar la pérdida? ¿A llorarnos entre nosotros?"

# game/game/afterstories.rpy:655
translate es bshafterstory_5558a6a5:

    # n "I bite my lip to keep the tears from spilling over."
    n "Muerdo mi labio para contener las lágrimas."

# game/game/afterstories.rpy:657
translate es bshafterstory_7dcb34b9:

    # n "Ray places a kiss on my head, his warmth lingering."
    n "Ray besa mi cabeza, su calidez permanece."

# game/game/afterstories.rpy:659
translate es bshafterstory_7ef7f968:

    # n "{color=#CD9300} 'Everything will be okay, I promise. Don't be sad. You should be happy, my shining Star.'{/color}"
    n "{color=#CD9300} 'Todo estará bien, lo prometo. No estés triste. Deberías estar feliz, mi brillante Estrella.' {/color}"

# game/game/afterstories.rpy:662
translate es bshafterstory_b299c96a:

    # n "{color=#CD9300} 'It's painful now, but it will be good for us in the end.'{/color}"
    n "{color=#CD9300} 'Duele ahora, pero al final será bueno para nosotros.' {/color}"

# game/game/afterstories.rpy:664
translate es bshafterstory_e347f7f2:

    # n "I watch someone running for their life, only to be picked up like a toy."
    n "Veo a alguien correr por su vida, solo para ser levantado como un juguete."

# game/game/afterstories.rpy:666
translate es bshafterstory_aa231050:

    # n "{color=#510f80} 'How will this ever be good for us? For anyone?'{/color}"
    n "{color=#510f80} '¿Cómo podría esto ser bueno para nosotros? ¿Para alguien?' {/color}"

# game/game/afterstories.rpy:668
translate es bshafterstory_c18c7335:

    # n "{color=#CD9300} 'You won't have to worry about Double anymore.'{/color}"
    n "{color=#CD9300} 'Ya no tendrás que preocuparte por Double.' {/color}"

# game/game/afterstories.rpy:670
translate es bshafterstory_87acc361:

    # n "I look at the carnage below."
    n "Miro la devastación debajo."

# game/game/afterstories.rpy:672
translate es bshafterstory_04881cb0:

    # n "{color=#510f80} 'It's not worth it.'{/color}"
    n "{color=#510f80} 'No vale la pena.' {/color}"

# game/game/afterstories.rpy:674
translate es bshafterstory_07c630a3:

    # n "Ray looks at me, his jaw sets ever so slightly."
    n "Ray me mira, su mandíbula se tensa ligeramente."

# game/game/afterstories.rpy:676
translate es bshafterstory_25543394:

    # n "{color=#510f80} 'How could my safety be worth ....{i}this{/i}.'{/color}"
    n "{color=#510f80} '¿Cómo podría mi seguridad valer... {i}esto{/i}?' {/color}"

# game/game/afterstories.rpy:678
translate es bshafterstory_88222c98:

    # n "{color=#510f80} 'Hundreds of lives... thousands.'{/color}"
    n "{color=#510f80} 'Cientos de vidas... miles.' {/color}"

# game/game/afterstories.rpy:680
translate es bshafterstory_f3baa138:

    # n "{color=#510f80} 'The other heroes may not be able to do anything...'{/color}"
    n "{color=#510f80} 'Puede que los otros héroes no puedan hacer nada...' {/color}"

# game/game/afterstories.rpy:682
translate es bshafterstory_a8b42625:

    # n "{color=#510f80} ' But you could stop it Ray, {i}you could save them.{/i}' {/color}"
    n "{color=#510f80} 'Pero tú podrías detenerlo, Ray, {i}podrías salvarlos.{/i}' {/color}"

# game/game/afterstories.rpy:684
translate es bshafterstory_3618f43d:

    # n "Ray sets me to my feet. He gives me a hard look studying my face."
    n "Ray me deja en el suelo. Me mira con seriedad, estudiando mi rostro."

# game/game/afterstories.rpy:686
translate es bshafterstory_14bb4493:

    # n "{color=#CD9300} 'No.'{/color}"
    n "{color=#CD9300} 'No.' {/color}"

# game/game/afterstories.rpy:688
translate es bshafterstory_3c02269b:

    # n "{color=#510f80} '...What...?'{/color}"
    n "{color=#510f80} '...¿Qué...?'{/color}"

# game/game/afterstories.rpy:690
translate es bshafterstory_25de13fe:

    # n "{color=#510f80} 'What do you mean?'{/color}"
    n "{color=#510f80} '¿Qué quieres decir?'{/color}"

# game/game/afterstories.rpy:692
translate es bshafterstory_0b6c9c43:

    # n "{color=#510f80} 'Like you can't...? Or do you... not want to?'{/color}"
    n "{color=#510f80} '¿Como que no puedes...? ¿O es que... no quieres?'{/color}"

# game/game/afterstories.rpy:694
translate es bshafterstory_eba35d97:

    # n "{color=#CD9300} 'I have everything I could ever want right here.'{/color}"
    n "{color=#CD9300} 'Tengo todo lo que podría desear justo aquí.'{/color}"

# game/game/afterstories.rpy:696
translate es bshafterstory_4d3b5d8e:

    # n "{color=#CD9300} 'If this opportunity makes life better for us, I'd be a fool to stop it.'{/color}"
    n "{color=#CD9300} 'Si esta oportunidad mejora nuestras vidas, sería un tonto si la detuviera.'{/color}"

# game/game/afterstories.rpy:698
translate es bshafterstory_73e703a8:

    # n "{color=#CD9300} 'Your safety is what is most important.'{/color}"
    n "{color=#CD9300} 'Tu seguridad es lo más importante.'{/color}"

# game/game/afterstories.rpy:700
translate es bshafterstory_c933e419:

    # n "{color=#510f80} 'Over the lives of thousands of people...?'{/color}"
    n "{color=#510f80} '¿Por encima de las vidas de miles de personas...?'{/color}"

# game/game/afterstories.rpy:702
translate es bshafterstory_c323c8a6:

    # n "{color=#510f80} 'That doesn't make sense.'{/color}"
    n "{color=#510f80} 'Eso no tiene sentido.'{/color}"

# game/game/afterstories.rpy:704
translate es bshafterstory_c5427620:

    # n "{color=#CD9300} 'It makes perfect sense.'{/color}"
    n "{color=#CD9300} 'Tiene todo el sentido del mundo.'{/color}"

# game/game/afterstories.rpy:706
translate es bshafterstory_7c3c3ac3:

    # n "{color=#510f80} 'Ray.'{/color}"
    n "{color=#510f80} 'Ray.'{/color}"

# game/game/afterstories.rpy:708
translate es bshafterstory_3b899972:

    # n "{color=#510f80} 'It can't be just us...'{/color}"
    n "{color=#510f80} 'No puede ser solo nosotros...'{/color}"

# game/game/afterstories.rpy:710
translate es bshafterstory_6e2b4a48:

    # n "Ray frowns. The expression felt real. It felt honest."
    n "Ray frunce el ceño. La expresión se sentía real. Se sentía sincera."

# game/game/afterstories.rpy:712
translate es bshafterstory_b03b18c7:

    # n "He leans in. I take a step back, but my back is pressed against the cold glass."
    n "Se inclina hacia mí. Doy un paso atrás, pero mi espalda se presiona contra el vidrio frío."

# game/game/afterstories.rpy:714
translate es bshafterstory_083ce26a:

    # n "{color=#CD9300} 'Star... it {i}is{/i} just us. It's {i}always{/i} been just us.'{/color}"
    n "{color=#CD9300} 'Estrella... {i}solo{/i} somos nosotros. {i}Siempre{/i} hemos sido solo nosotros.'{/color}"

# game/game/afterstories.rpy:716
translate es bshafterstory_bb489791:

    # n "{color=#510f80} 'Ray please!'{/color}"
    n "{color=#510f80} '¡Ray por favor!'{/color}"

# game/game/afterstories.rpy:718
translate es bshafterstory_d53a8398:

    # n "My pleas fall on deaf ears. He turns to walk away. Some part of me knows I have one more chance."
    n "Mis súplicas caen en oídos sordos. Él se da vuelta para marcharse. Una parte de mí sabe que tengo una última oportunidad."

# game/game/afterstories.rpy:723
translate es bshafterstory_c256d205:

    # n "{color=#510f80} 'Ray please! Please save them.'{/color}"
    n "{color=#510f80} '¡Ray por favor! Por favor, sálvalos.'{/color}"

# game/game/afterstories.rpy:725
translate es bshafterstory_25761346:

    # n "I collapse on my knees, sobs rack my body."
    n "Caigo de rodillas, los sollozos sacuden mi cuerpo."

# game/game/afterstories.rpy:727
translate es bshafterstory_daf09e4a:

    # n "Ray pauses, he turns around looking at my pitiful state."
    n "Ray se detiene, se da vuelta y observa mi lamentable estado."

# game/game/afterstories.rpy:729
translate es bshafterstory_fd5bbdd3:

    # n "As I sob ray slowly approaches me, he crouches down and wipes away my tears."
    n "Mientras lloro, Ray se me acerca lentamente, se agacha y seca mis lágrimas."

# game/game/afterstories.rpy:731
translate es bshafterstory_fbc5f47a:

    # n "{color=#510f80} 'Please! Please Ray, please!'{/color}"
    n "{color=#510f80} '¡Por favor! ¡Por favor Ray, por favor!'{/color}"

# game/game/afterstories.rpy:733
translate es bshafterstory_140cc05f:

    # n "I sob like a broken record. A carousel of conflicted expressions drift across his face."
    n "Lloro como un disco roto. Un carrusel de expresiones conflictivas cruza su rostro."

# game/game/afterstories.rpy:735
translate es bshafterstory_388be058:

    # n "Ray wipes away my tears, placing kisses on my cheeks, lips and nose."
    n "Ray seca mis lágrimas, depositando besos en mis mejillas, labios y nariz."

# game/game/afterstories.rpy:737
translate es bshafterstory_1ac4ee99:

    # n "{color=#CD9300} 'Just don't think about it Star, it will be easier that way.'{/color}"
    n "{color=#CD9300} 'Solo no pienses en eso Estrella, así será más fácil.'{/color}"

# game/game/afterstories.rpy:739
translate es bshafterstory_3a64d7c5:

    # n "{color=#510f80} 'I can't just NOT think about it!'{/color}"
    n "{color=#510f80} '¡No puedo simplemente NO pensar en eso!'{/color}"

# game/game/afterstories.rpy:741
translate es bshafterstory_c7ca4c95:

    # n "{color=#510f80} 'So many people will die because of me! I can't live like that...'{/color}"
    n "{color=#510f80} '¡Tantas personas morirán por mi culpa! No puedo vivir así...'{/color}"

# game/game/afterstories.rpy:743
translate es bshafterstory_cc9c6822:

    # n "{color=#510f80} 'I-i can't go on living knowing that....'{/color}"
    n "{color=#510f80} 'N-no puedo seguir viviendo sabiendo eso...'{/color}"

# game/game/afterstories.rpy:745
translate es bshafterstory_08ca2b5a:

    # n "{color=#CD9300} 'Well, I won't let you die either.'{/color}"
    n "{color=#CD9300} 'Bueno, tampoco dejaré que mueras.'{/color}"

# game/game/afterstories.rpy:747
translate es bshafterstory_cbc72eba:

    # n "{color=#510f80} 'Then what am I supposed to do Ray!? Tell me!'{/color}"
    n "{color=#510f80} '¿Entonces qué se supone que haga, Ray!? ¡Dímelo!'{/color}"

# game/game/afterstories.rpy:749
translate es bshafterstory_08f66cec:

    # n "{color=#510f80} 'If this happens, if people die like that... I can't forgive myself.'{/color}"
    n "{color=#510f80} 'Si esto sucede, si la gente muere así... no podré perdonarme.'{/color}"

# game/game/afterstories.rpy:751
translate es bshafterstory_511aef97:

    # n "{color=#510f80} 'I will curse myself, and spiral into despair.'{/color}"
    n "{color=#510f80} 'Me maldeciré y caeré en la desesperación.'{/color}"

# game/game/afterstories.rpy:753
translate es bshafterstory_93dbc311:

    # n "I look up at him, glaring fiercely."
    n "Lo miro, con una mirada feroz."

# game/game/afterstories.rpy:755
translate es bshafterstory_b6f53b1a:

    # n "{color=#510f80} 'And I will begin to hate you too...'{/color}"
    n "{color=#510f80} 'Y también empezaré a odiarte...'{/color}"

# game/game/afterstories.rpy:757
translate es bshafterstory_91418af1:

    # n "Ray smiles softly."
    n "Ray sonríe suavemente."

# game/game/afterstories.rpy:759
translate es bshafterstory_7142293f:

    # n "{color=#CD9300} 'Then hate me. Hate me like it's your last connection to sanity.'{/color}"
    n "{color=#CD9300} 'Entonces ódiame. Ódiame como si fuera tu último lazo con la cordura.'{/color}"

# game/game/afterstories.rpy:761
translate es bshafterstory_ceacf242:

    # n "{color=#CD9300} 'You can curse me, hit me, ignore me until you've had your fill.'{/color}"
    n "{color=#CD9300} 'Puedes maldecirme, golpearme, ignorarme hasta saciarte.'{/color}"

# game/game/afterstories.rpy:763
translate es bshafterstory_32ee86f5:

    # n "{color=#CD9300} 'I'll take all of it. Your hate, anger, sadness I'll take it all, every damn day if it means that you will be safe and alive at my side.'{/color}"
    n "{color=#CD9300} 'Lo soportaré todo. Tu odio, tu ira, tu tristeza... lo soportaré todo, cada maldito día, si eso significa que estarás a salvo y viva a mi lado.'{/color}"

# game/game/afterstories.rpy:765
translate es bshafterstory_ce901413:

    # n "I bury my face in my hands, the feeling of defeat washing over me."
    n "Entierro mi rostro entre las manos, el sentimiento de derrota me invade."

# game/game/afterstories.rpy:767
translate es bshafterstory_0aa6864f:

    # n "Ray reaches out and I grasp him."
    n "Ray extiende la mano y lo abrazo."

# game/game/afterstories.rpy:769
translate es bshafterstory_1f27af3a:

    # n "I curse him and curse him and curse him while hugging him tightly, sobbing, screaming, crying into his shirt."
    n "Lo maldigo, lo maldigo y lo maldigo mientras lo abrazo con fuerza, sollozando, gritando, llorando contra su camisa."

# game/game/afterstories.rpy:771
translate es bshafterstory_036fbd8f:

    # n "Even as the cause of my pain, he is the only one I could reach out to for comfort."
    n "Aun siendo la causa de mi dolor, es el único a quien puedo acudir en busca de consuelo."

# game/game/afterstories.rpy:773
translate es bshafterstory_75697c97:

    # n "Part of me wondered if he intended that all along, or if we just happened to end up here."
    n "Parte de mí se pregunta si lo planeó desde el principio, o si simplemente terminamos aquí por casualidad."

# game/game/afterstories.rpy:779
translate es bshafterstory_f83c0593:

    # n "{color=#510f80} 'But What if it's not just us?'{/color}"
    n "{color=#510f80} '¿Pero qué pasa si no somos solo nosotros?'{/color}"

# game/game/afterstories.rpy:781
translate es bshafterstory_e59edaad:

    # n "Ray pauses."
    n "Ray se detiene."

# game/game/afterstories.rpy:783
translate es bshafterstory_9c40110b:

    # n "He turns around slowly."
    n "Se da vuelta lentamente."

# game/game/afterstories.rpy:785
translate es bshafterstory_53f5b507:

    # n "{color=#CD9300} 'What...?'{/color}"
    n "{color=#CD9300} '¿Qué...?'{/color}"

# game/game/afterstories.rpy:787
translate es bshafterstory_c38bf0cc:

    # n "{color=#510f80} 'What if there can be someone else too?'{/color}"
    n "{color=#510f80} '¿Y si puede haber alguien más también?'{/color}"

# game/game/afterstories.rpy:789
translate es bshafterstory_74b19eed:

    # n "Ray walks over slowly."
    n "Ray camina lentamente hacia mí."

# game/game/afterstories.rpy:791
translate es bshafterstory_5c0e65c0:

    # n "{color=#CD9300} 'Are you... saying what I think you are saying?{/color}"
    n "{color=#CD9300} '¿Estás... diciendo lo que creo que estás diciendo?'{/color}"

# game/game/afterstories.rpy:793
translate es bshafterstory_a6d2c977:

    # n "{color=#510f80} 'I don't want to raise our family in a alien infested destroyed city.'{/color}"
    n "{color=#510f80} 'No quiero criar a nuestra familia en una ciudad destruida e infestada de alienígenas.'{/color}"

# game/game/afterstories.rpy:795
translate es bshafterstory_c0607238:

    # n "Ray's eyes widen. He searches my face, my mind, trying to determine if this is my attempt at humor."
    n "Los ojos de Ray se abren de par en par. Examina mi rostro, mi mente, tratando de determinar si es una broma."

# game/game/afterstories.rpy:797
translate es bshafterstory_0d22d16f:

    # n "{color=#CD9300} {i}'Our family...?'{/i}{/color}"
    n "{color=#CD9300} {i}'¿Nuestra familia...?'{/i}{/color}"

# game/game/afterstories.rpy:799
translate es bshafterstory_c08b440a:

    # n "Ray approaches closer. He places his hands on my face, cupping it lightly."
    n "Ray se acerca más. Coloca sus manos en mi rostro, sosteniéndolo suavemente."

# game/game/afterstories.rpy:801
translate es bshafterstory_28cba2c3:

    # n "{color=#510f80} 'Our family.'{/color}"
    n "{color=#510f80} 'Nuestra familia.'{/color}"

# game/game/afterstories.rpy:803
translate es bshafterstory_7baed012:

    # n "Binary Star places a deep kiss onto my lips, I can feel his hands shake slightly."
    n "Binary Star deposita un beso profundo en mis labios, puedo sentir sus manos temblar ligeramente."

# game/game/afterstories.rpy:805
translate es bshafterstory_781c4d41:

    # n "He pulls back, breathless."
    n "Se separa, sin aliento."

# game/game/afterstories.rpy:807
translate es bshafterstory_7761f05e:

    # n "{color=#CD9300} 'I don't think... I've been happier in my whole life than in this moment.'{/color}"
    n "{color=#CD9300} 'No creo... haber sido más feliz en toda mi vida que en este momento.'{/color}"

# game/game/afterstories.rpy:809
translate es bshafterstory_e14c69d3:

    # n "{color=#510f80} 'I want our kids to have friends, neighbors, companions in the same city they grew up in.'{/color}"
    n "{color=#510f80} 'Quiero que nuestros hijos tengan amigos, vecinos, compañeros en la misma ciudad donde crecieron.'{/color}"

# game/game/afterstories.rpy:811
translate es bshafterstory_4515d4b7:

    # n "{color=#CD9300} 'Kid{i}-S{/i}?!'{/color}"
    n "{color=#CD9300} '¿Hijo{i}-S{/i}?!'{/color}"

# game/game/afterstories.rpy:813
translate es bshafterstory_d5b1ecb4:

    # n "He kisses me again. Pulling back, there is so much love in his eyes it threatens to knock me off my feet."
    n "Me besa de nuevo. Al separarse, hay tanto amor en sus ojos que amenaza con derribarme."

# game/game/afterstories.rpy:815
translate es bshafterstory_80965543:

    # n "{color=#CD9300} 'I just can't say no to you Star.'{/color}"
    n "{color=#CD9300} 'Simplemente no puedo decirte que no, Estrella.'{/color}"

# game/game/afterstories.rpy:817
translate es bshafterstory_35f6823c:

    # n "Ray kisses me again, lifting me up, pressing my back against the glass."
    n "Ray me besa otra vez, levantándome, presionando mi espalda contra el vidrio."

# game/game/afterstories.rpy:819
translate es bshafterstory_a4ec0069:

    # n "{color=#510f80} 'R-Mmm-Ray!'{/color}"
    n "{color=#510f80} 'M-Mmm-¡Ray!'{/color}"

# game/game/afterstories.rpy:821
translate es bshafterstory_d648b428:

    # n "I push him back a bit and he obliges leaning back, looking down at me a heat swirling behind his eyes."
    n "Lo empujo un poco y él accede, inclinándose hacia atrás, mirándome con un calor que arde detrás de sus ojos."

# game/game/afterstories.rpy:823
translate es bshafterstory_d1172937:

    # n "{color=#510f80} 'Can you please go save them?'{/color}"
    n "{color=#510f80} '¿Puedes ir a salvarlos, por favor?'{/color}"

# game/game/afterstories.rpy:825
translate es bshafterstory_7e673343:

    # n "He looks at me intensely, unmoving, unconvinced."
    n "Me mira intensamente, inmóvil, sin convencerse."

# game/game/afterstories.rpy:827
translate es bshafterstory_8956c55d:

    # n "{color=#CD9300} 'Let me taste you a bit first, I'll take care of it right after.'{/color}"
    n "{color=#CD9300} 'Déjame saborearte un poco primero, me encargaré de eso justo después.'{/color}"

# game/game/afterstories.rpy:829
translate es bshafterstory_11f206fc:

    # n "His hand grips my thigh as he leans in closer to my neck."
    n "Su mano sujeta mi muslo mientras se inclina hacia mi cuello."

# game/game/afterstories.rpy:831
translate es bshafterstory_909bc921:

    # n "{color=#510f80} 'R-ray..!'{/color}"
    n "{color=#510f80} 'R-ray..!'{/color}"

# game/game/afterstories.rpy:833
translate es bshafterstory_6cdf63bc:

    # n "His lips trail my neck nibbling and licking as they move their way north towards my ear."
    n "Sus labios recorren mi cuello, mordisqueando y lamiendo mientras ascienden hacia mi oído."

# game/game/afterstories.rpy:835
translate es bshafterstory_b8b9c18f:

    # n "{color=#CD9300} 'Hmm?'{/color}"
    n "{color=#CD9300} '¿Hmm?'{/color}"

# game/game/afterstories.rpy:837
translate es bshafterstory_5665c9df:

    # n "{color=#510f80} 'Ray later, please!'{/color}"
    n "{color=#510f80} '¡Ray después, por favor!'{/color}"

# game/game/afterstories.rpy:839
translate es bshafterstory_136b0bbd:

    # n "He leans back again as I cover my neck against any future attacks."
    n "Se inclina hacia atrás otra vez mientras cubro mi cuello para evitar futuros ataques."

# game/game/afterstories.rpy:841
translate es bshafterstory_4e6e7543:

    # n "He stares blankly."
    n "Me mira en silencio."

# game/game/afterstories.rpy:843
translate es bshafterstory_ad19f928:

    # n "{color=#510f80} 'Right when you get back, I promise...'{/color}"
    n "{color=#510f80} 'Justo cuando regreses, lo prometo...'{/color}"

# game/game/afterstories.rpy:845
translate es bshafterstory_337459e9:

    # n "After a few seconds Ray lets out a deep sigh."
    n "Después de unos segundos, Ray deja escapar un profundo suspiro."

# game/game/afterstories.rpy:847
translate es bshafterstory_a6e4e218:

    # n "{color=#CD9300} 'Fine, I'll go.'{/color}"
    n "{color=#CD9300} 'Está bien, iré.'{/color}"

# game/game/afterstories.rpy:849
translate es bshafterstory_83eabcad:

    # n "He lowers my feet to the ground and backs up."
    n "Baja mis pies al suelo y retrocede."

# game/game/afterstories.rpy:851
translate es bshafterstory_73997cd5:

    # n "Ray begins to saunter off, I can tell by his walk that he is dreading getting back into the suit."
    n "Ray comienza a alejarse con paso lento, y puedo notar en su andar que detesta volver al traje."

# game/game/afterstories.rpy:853
translate es bshafterstory_198fddb5:

    # n "{color=#510f80} 'Wait Ray, you forgot something!'{/color}"
    n "{color=#510f80} '¡Espera Ray, olvidaste algo!'{/color}"

# game/game/afterstories.rpy:855
translate es bshafterstory_e8859a8e:

    # n "Ray turns around confused. I bound towards him placing a kiss onto his cheek."
    n "Ray se gira confundido. Corro hacia él y deposito un beso en su mejilla."

# game/game/afterstories.rpy:857
translate es bshafterstory_ebe775cc:

    # n "I whisper to him:"
    n "Le susurro:"

# game/game/afterstories.rpy:859
translate es bshafterstory_f3ccd037:

    # n "{color=#510f80} 'Thankyou Ray, you're my hero~'{/color}"
    n "{color=#510f80} 'Gracias Ray, eres mi héroe~'{/color}"

# game/game/afterstories.rpy:861
translate es bshafterstory_544f9b1a:

    # n "Ray's face heats up a light pink and he can't hide a small genuine smile."
    n "El rostro de Ray se sonroja levemente y no puede ocultar una pequeña sonrisa genuina."

# game/game/afterstories.rpy:863
translate es bshafterstory_f2688705:

    # n "{color=#CD9300} 'Go get some sleep Star, I'll see you when I get back.'{/color}"
    n "{color=#CD9300} 'Ve a dormir Estrella, te veré cuando vuelva.'{/color}"

# game/game/afterstories.rpy:865
translate es bshafterstory_0d9453ce:

    # n "Ray leaves the condo and I collapse on the couch. A whirlwind of emotions fly through me."
    n "Ray sale del condominio y me dejo caer en el sofá. Un torbellino de emociones me atraviesa."

# game/game/afterstories.rpy:867
translate es bshafterstory_86866c94:

    # n "Eventually enough time has passed that Ray is likely not in a near enough vicinity to hear my thoughts."
    n "Finalmente, ha pasado suficiente tiempo como para que Ray ya no esté lo bastante cerca para oír mis pensamientos."

# game/game/afterstories.rpy:869
translate es bshafterstory_4c66dd95:

    # n "Honestly, the stuff about 'family' was a last ditch effort, the only thing I could think of at the time."
    n "Honestamente, lo de la 'familia' fue un último recurso, lo único que se me ocurrió en ese momento."

# game/game/afterstories.rpy:871
translate es bshafterstory_a7e74302:

    # n "Part of me wasn't even sure I wanted kids...a larger part of me wasn't sure if I wanted kids with Ray himself."
    n "Una parte de mí ni siquiera estaba segura de querer hijos... una parte mayor no sabía si los quería con el propio Ray."

# game/game/afterstories.rpy:873
translate es bshafterstory_75f65193:

    # n "It was the best I could do at the time to convince him."
    n "Fue lo mejor que pude hacer en ese instante para convencerlo."

# game/game/afterstories.rpy:875
translate es bshafterstory_7beab4ca:

    # n "And I thank my lucky stars that it worked."
    n "Y agradezco a mis estrellas que haya funcionado."

# game/game/afterstories.rpy:877
translate es bshafterstory_34b4504a:

    # n "I guaranteed a future, not only for myself but for the rest of this city's citizens..."
    n "Aseguré un futuro, no solo para mí, sino para los ciudadanos de esta ciudad..."

# game/game/afterstories.rpy:879
translate es bshafterstory_1a700cc7:

    # n "I likely guaranteed a future for Ray himself as well."
    n "Probablemente también aseguré un futuro para el propio Ray."

# game/game/afterstories.rpy:881
translate es bshafterstory_bfaceb48:

    # n "Something deep inside of Ray is deeply ...wrong, misformed, and ever growing."
    n "Algo muy dentro de Ray está profundamente... mal, deformado y creciendo cada vez más."

# game/game/afterstories.rpy:883
translate es bshafterstory_a9aafcdb:

    # n "I can't ignore something like that any longer, I need to keep him moving, motivated."
    n "No puedo ignorar algo así por más tiempo, necesito mantenerlo en movimiento, motivado."

# game/game/afterstories.rpy:885
translate es bshafterstory_9fc5934d:

    # n "Because some part of me can't shake the feeling that the minute Binary Star stops moving..."
    n "Porque una parte de mí no puede quitarse la sensación de que en el momento en que Binary Star deje de moverse..."

# game/game/afterstories.rpy:887
translate es bshafterstory_28a635b6:

    # n "Is the minute everything else does too."
    n "Será el momento en que todo lo demás también lo haga."

# game/game/afterstories.rpy:907
translate es dblafterstory_19c69ae3:

    # n "I stare at the familiar wall, it's creases and marks unchanged."
    n "Miro la pared familiar, sus pliegues y marcas intactos."

# game/game/afterstories.rpy:909
translate es dblafterstory_81015096:

    # n "The couch I sit on feels no different from the one that I used to own."
    n "El sofá en el que me siento no se siente diferente del que solía tener."

# game/game/afterstories.rpy:911
translate es dblafterstory_4af626c9:

    # n "The living room even smells slightly of fresh flowers and wood. It's uncanny, as if I had been transported back in time."
    n "La sala incluso huele ligeramente a flores frescas y madera. Es inquietante, como si hubiera retrocedido en el tiempo."

# game/game/afterstories.rpy:913
translate es dblafterstory_c7ad010f:

    # n "As if nothing has changed."
    n "Como si nada hubiera cambiado."

# game/game/afterstories.rpy:915
translate es dblafterstory_2a1c2ae6:

    # n "But in reality, entirely too much had changed."
    n "Pero en realidad, demasiado había cambiado."

# game/game/afterstories.rpy:917
translate es dblafterstory_d12aec89:

    # n "The door clicks open."
    n "La puerta se abre con un clic."

# game/game/afterstories.rpy:919
translate es dblafterstory_6b65b430:

    # n "I don't even have to turn my head. I already know who it is."
    n "Ni siquiera tengo que girar la cabeza. Ya sé quién es."

# game/game/afterstories.rpy:921
translate es dblafterstory_00d1850c:

    # n "{color=#1F28AD} 'Not even a 'welcome home?'{/color}"
    n "{color=#1F28AD} ''¿Ni siquiera un 'bienvenida a casa?''{/color}"

# game/game/afterstories.rpy:923
translate es dblafterstory_b45e0115:

    # n "He calls from the threshold as he enters."
    n "Llama desde el umbral mientras entra."

# game/game/afterstories.rpy:925
translate es dblafterstory_03d71583:

    # n "{color=#510f80}'...Welcome home...'{/color}"
    n "{color=#510f80}'...Bienvenido a casa...'{/color}"

# game/game/afterstories.rpy:927
translate es dblafterstory_d71c0174:

    # n "I mumble in response, devoid of all enthusiasm."
    n "Murmuro en respuesta, sin ningún entusiasmo."

# game/game/afterstories.rpy:929
translate es dblafterstory_470efe88:

    # n "Double doesn't say anything. Instead, he continues to the kitchen placing some things down."
    n "Double no dice nada. En cambio, continúa hacia la cocina dejando algunas cosas."

# game/game/afterstories.rpy:931
translate es dblafterstory_24f4947a:

    # n "I stare at the wall."
    n "Miro la pared."

# game/game/afterstories.rpy:933
translate es dblafterstory_28021aa1:

    # n "He walks over slowly."
    n "Camina lentamente hacia mí."

# game/game/afterstories.rpy:935
translate es dblafterstory_944b73d1:

    # n "{color=#1F28AD} 'How was your day?' {/color}"
    n "{color=#1F28AD} '¿Cómo estuvo tu día?' {/color}"

# game/game/afterstories.rpy:939
translate es dblafterstory_71743a0a:

    # n "I glare at him, refusing to answer."
    n "Lo fulmino con la mirada, negándome a responder."

# game/game/afterstories.rpy:941
translate es dblafterstory_77ff63aa:

    # n "He smiles wide, enjoying my mirth."
    n "Sonríe ampliamente, disfrutando de mi desdén."

# game/game/afterstories.rpy:943
translate es dblafterstory_4e00849e:

    # n "{color=#1F28AD} 'Awww, don't be like that~ '{/color}"
    n "{color=#1F28AD} 'Awww, no seas así~'{/color}"

# game/game/afterstories.rpy:945
translate es dblafterstory_de271009:

    # n "Double walks over towards me."
    n "Double camina hacia mí."

# game/game/afterstories.rpy:947
translate es dblafterstory_5ac42b17:

    # n "{color=#1F28AD} 'You {i}really {/i} look like you want to hit me you know.'{/color}"
    n "{color=#1F28AD} 'Realmente {i}pareces{/i} que quieres golpearme, ¿sabes?'{/color}"

# game/game/afterstories.rpy:949
translate es dblafterstory_56fe1d84:

    # n "He reaches out his hand, brushing it against my cheek. I move my face away, but his hand follows."
    n "Extiende la mano, rozando mi mejilla. Aparto el rostro, pero su mano me sigue."

# game/game/afterstories.rpy:951
translate es dblafterstory_9dea391c:

    # n "{color=#1F28AD} 'It's okay being upset but you shouldn't carry that anger with you. It's unhealthy.' {/color}"
    n "{color=#1F28AD} 'Está bien tener molestia, pero no deberías cargar con esa ira. No es saludable.' {/color}"

# game/game/afterstories.rpy:953
translate es dblafterstory_5b1857df:

    # n "He moves his hand, brushing a finger over my lip. I snap, biting him {i}hard{/i}."
    n "Mueve su mano, pasando un dedo por mi labio. Reacciono mordiéndolo {i}con fuerza{/i}."

# game/game/afterstories.rpy:955
translate es dblafterstory_d8ea50c4:

    # n "The psycho doesn't even flinch. He just pulls his hand back and stares at the bite mark curiously."
    n "El psicópata ni siquiera se inmuta. Solo retira la mano y observa la marca de la mordida con curiosidad."

# game/game/afterstories.rpy:957
translate es dblafterstory_c6be73c0:

    # n "He looks back at me, his eyes dark, previous humor gone."
    n "Me mira de nuevo, sus ojos oscuros, el humor anterior desaparecido."

# game/game/afterstories.rpy:959
translate es dblafterstory_1205b6f8:

    # n "Double steps away and I return to staring at the same far wall."
    n "Double se aparta y vuelvo a mirar fijamente la pared lejana."

# game/game/afterstories.rpy:963
translate es dblafterstory_5acf5841:

    # n "I refuse to look at him."
    n "Me niego a mirarlo."

# game/game/afterstories.rpy:965
translate es dblafterstory_e370881e:

    # n "I continue to stare at the wall with resolve."
    n "Sigo mirando la pared con determinación."

# game/game/afterstories.rpy:967
translate es dblafterstory_677ff1e6:

    # n "As if he doesn't even exist."
    n "Como si él no existiera."

# game/game/afterstories.rpy:969
translate es dblafterstory_91f6b0b4:

    # n "{color=#1F28AD} 'You are being pretty fucking rude you know...'{/color}"
    n "{color=#1F28AD} 'Estás actuando con jodidamente ingratitud, ¿sabes...?'{/color} "

# game/game/afterstories.rpy:971
translate es dblafterstory_8c23f32d:

    # n "I clench my jaw and strengthen my resolve."
    n "Aprieto la mandíbula y refuerzo mi determinación."

# game/game/afterstories.rpy:973
translate es dblafterstory_a19b0e64:

    # n "A minute of silence passes."
    n "Pasa un minuto de silencio."

# game/game/afterstories.rpy:975
translate es dblafterstory_e94e2da0:

    # n "Double crosses my vision."
    n "Double cruza por mi campo de visión."

# game/game/afterstories.rpy:977
translate es dblafterstory_ccd5de25:

    # n "He walks up to the standing lamp."
    n "Se acerca a la lámpara de pie."

# game/game/afterstories.rpy:979
translate es dblafterstory_c0e18ce2:

    # n "In one swift motion Double pushes the lamp to the floor shattering the glass shade."
    n "En un solo movimiento, Double empuja la lámpara al suelo rompiendo la pantalla de vidrio."

# game/game/afterstories.rpy:981
translate es dblafterstory_9929c549:

    # n "He casually stomps on the bulb that remained in tact, breaking it too."
    n "Pisa casualmente el bombillo que quedó intacto, rompiéndolo también."

# game/game/afterstories.rpy:983
translate es dblafterstory_805ba2c2:

    # n "Slowly he picks up a large shard of glass."
    n "Lentamente recoge un gran fragmento de vidrio."

# game/game/afterstories.rpy:985
translate es dblafterstory_8265e702:

    # n "He turns toward me, walking over slowly."
    n "Se vuelve hacia mí, caminando lentamente."

# game/game/afterstories.rpy:987
translate es dblafterstory_8cf4d823:

    # n "As he approaches closer I try to scramble away...."
    n "A medida que se acerca intento alejarme..."

# game/game/afterstories.rpy:989
translate es dblafterstory_ea930f2e:

    # n "But the heavy chain attached to a thick metal clamp around my neck keeps me imprisoned to a 3 feet radius of the couch."
    n "Pero la pesada cadena unida al grueso grillete metálico en mi cuello me mantiene prisionera a un radio de un metro alrededor del sofá."

# game/game/afterstories.rpy:991
translate es dblafterstory_443c200e:

    # n "I scramble onto the hard floor by the far corner of the couch."
    n "Me arrastro por el suelo duro hasta la esquina más alejada del sofá."

# game/game/afterstories.rpy:993
translate es dblafterstory_635ae2ae:

    # n "I try to move further away but double brings his heavy boot down onto the chain."
    n "Intento alejarme más, pero Double baja su pesada bota sobre la cadena."

# game/game/afterstories.rpy:995
translate es dblafterstory_7859f574:

    # n "{color=#1F28AD}'Come here....'{/color}"
    n "{color=#1F28AD}'Ven aquí....'{/color}"

# game/game/afterstories.rpy:997
translate es dblafterstory_7fa4fc74:

    # n "He bends down picking up the chain in his other hand."
    n "Se agacha recogiendo la cadena con la otra mano."

# game/game/afterstories.rpy:999
translate es dblafterstory_dbaf2269:

    # n "{color=#1F28AD}'I said, {b}come here{/b}.'{/color}"
    n "{color=#1F28AD}'Dije, {b}ven aquí{/b}.'{/color}"

# game/game/afterstories.rpy:1001
translate es dblafterstory_e33813a3:

    # n "He yanks the chain. I fall forward, palms catching the floor right by his boot."
    n "Tira de la cadena. Caigo hacia adelante, las palmas golpeando el suelo junto a su bota."

# game/game/afterstories.rpy:1003
translate es dblafterstory_51ac4f16:

    # n "{color=#1F28AD}'That pose looks good on you sweetie, you should prostrate yourself more often~'{/color}"
    n "{color=#1F28AD}'Esa postura te queda bien, cariño, deberías postrarte más seguido~'{/color}"

# game/game/afterstories.rpy:1005
translate es dblafterstory_c8e571de:

    # n "He laughs to himself, short and harsh."
    n "Se ríe solo, corto y áspero."

# game/game/afterstories.rpy:1007
translate es dblafterstory_6b413533:

    # n "{color=#1F28AD}'Look at me.'{/color}"
    n "{color=#1F28AD}'Mírame.'{/color}"

# game/game/afterstories.rpy:1009
translate es dblafterstory_30000c9a:

    # n "I look upwards."
    n "Levanto la mirada."

# game/game/afterstories.rpy:1011
translate es dblafterstory_9ee1ea8b:

    # n "{color=#1F28AD}'Seems like you forgot how to be the lovely partner that you used to be.'{/color}"
    n "{color=#1F28AD}'Parece que olvidaste cómo ser la encantadora pareja que solías ser.'{/color}"

# game/game/afterstories.rpy:1013
translate es dblafterstory_5f21972c:

    # n "I look up at him, at the glass shard in his hand."
    n "Lo miro, al fragmento de vidrio en su mano."

# game/game/afterstories.rpy:1015
translate es dblafterstory_fd235a50:

    # n "My eyes shake and jump between the glass shard and his face. I will my eyes to not water."
    n "Mis ojos tiemblan, saltan entre el vidrio y su rostro. Me esfuerzo por no llorar."

# game/game/afterstories.rpy:1017
translate es dblafterstory_38d6834f:

    # n "{color=#1F28AD}'Ohhh, look at you! I just can't stay mad at you~'{/color}"
    n "{color=#1F28AD}'Ohhh, mírate. Simplemente no puedo seguir enojado contigo~'{/color}"

# game/game/afterstories.rpy:1019
translate es dblafterstory_74a42912:

    # n "{color=#1F28AD}'Do you remember how to be my lover, or do you need me to remind you of your dedication?'{/color}"
    n "{color=#1F28AD}'¿Recuerdas cómo ser mi amante, o necesitas que te recuerde tu dedicación?'{/color}"

# game/game/afterstories.rpy:1023
translate es dblafterstory_75777aee:

    # n "I look down."
    n "Bajo la mirada."

# game/game/afterstories.rpy:1025
translate es dblafterstory_7b7e47e2:

    # n "{color=#510f80} 'I'm...sorry.'{/color}"
    n "{color=#510f80}'Lo... siento.'{/color}"

# game/game/afterstories.rpy:1027
translate es dblafterstory_8d7c6bd4:

    # n "{color=#1F28AD}Aww, I couldn't quite hear you honey. Speak up. {/color}"
    n "{color=#1F28AD}'Aww, no te escuché bien, cariño. Habla más alto.'{/color}"

# game/game/afterstories.rpy:1029
translate es dblafterstory_d6af41a0:

    # n "{color=#510f80} 'I said I'm sorry!'{/color}"
    n "{color=#510f80}'¡Dije que lo siento!'{/color}"

# game/game/afterstories.rpy:1031
translate es dblafterstory_bcd6aafe:

    # n "I half shout, eyes welling up with tears."
    n "Grito a medias, con los ojos llenos de lágrimas."

# game/game/afterstories.rpy:1033
translate es dblafterstory_f63146cb:

    # n "Double crouches down in front of me. He places his hand on my chin, angling my face up towards him."
    n "Double se agacha frente a mí. Coloca su mano en mi barbilla, levantando mi rostro hacia él."

# game/game/afterstories.rpy:1035
translate es dblafterstory_dabc83ed:

    # n "{color=#510f80} Look at you poor thing~ Already crying and I haven't even punished you yet...{/color}"
    n "{color=#510f80}'Mírate, pobre~ Ya lloras y ni siquiera te he castigado aún...'{/color}"

# game/game/afterstories.rpy:1037
translate es dblafterstory_646e66cd:

    # n "{color=#1F28AD} 'Double please...! Please don't hurt me! I'll be a good partner I promise, I promise!' {/color}"
    n "{color=#1F28AD}'Double por favor... ¡Por favor no me hagas daño! Seré una buena pareja, lo prometo, ¡lo prometo!'{/color}"

# game/game/afterstories.rpy:1039
translate es dblafterstory_a80d0548:

    # n "Double smiles, but there is no kindness to it."
    n "Double sonríe, pero no hay bondad en ello."

# game/game/afterstories.rpy:1041
translate es dblafterstory_945091d1:

    # n "{color=#510f80} 'Honey, you know I can't trust you anymore...'{/color} "
    n "{color=#510f80}'Cariño, sabes que ya no puedo confiar en ti...'{/color}"

# game/game/afterstories.rpy:1043
translate es dblafterstory_2180613f:

    # n "{color=#510f80} 'I won't punish you, but we will have to leave you chained for another few weeks.'{/color} "
    n "{color=#510f80}'No te castigaré, pero tendrás que seguir con esa cadena unas semanas más.'{/color}"

# game/game/afterstories.rpy:1045
translate es dblafterstory_c1fd0d39:

    # n "{color=#1F28AD} 'No please, I want to go outside..! I don't want to be here!{/color}"
    n "{color=#1F28AD}'No, por favor, ¡quiero salir..! ¡No quiero estar aquí!'{/color}"

# game/game/afterstories.rpy:1047
translate es dblafterstory_6f7ea642:

    # n "Double's face falls and his hand around my jaw tightens dangerously."
    n "El rostro de Double se ensombrece y su mano en mi mandíbula se aprieta peligrosamente."

# game/game/afterstories.rpy:1049
translate es dblafterstory_b75d84be:

    # n "{color=#510f80} {i}'What do you mean you don't want to be here? This is your home. {b}Our home{/b}'{/i}{/color}"
    n "{color=#510f80}{i}'¿Qué quieres decir con que no quieres estar aquí? Este es tu hogar. {b}Nuestro hogar{/b}.'{/i}{/color}"

# game/game/afterstories.rpy:1051
translate es dblafterstory_b9d5e83d:

    # n "Double looks furious his grip tightening on my jaw by the second."
    n "Double parece furioso, su agarre apretando más cada segundo."

# game/game/afterstories.rpy:1053
translate es dblafterstory_50e99085:

    # n "{color=#1F28AD} 'T-that's not what I meant!'{/color}"
    n "{color=#1F28AD}'¡N-no es eso lo que quise decir!'{/color}"

# game/game/afterstories.rpy:1055
translate es dblafterstory_0a8e63e2:

    # n "His dark eyes narrow as he waits for my explanation."
    n "Sus ojos oscuros se entrecierran mientras espera mi explicación."

# game/game/afterstories.rpy:1057
translate es dblafterstory_db3d1f27:

    # n "{color=#1F28AD} 'I-i...I just want some new decorations! I'm bored of the same stuff! And it's-it's old..!'{/color}"
    n "{color=#1F28AD}'Y-yo... solo quiero unas nuevas decoraciones. ¡Me aburro de las mismas cosas! ¡Y están– están viejas!'{/color}"

# game/game/afterstories.rpy:1059
translate es dblafterstory_dc9f31da:

    # n "My desperate lie spills out. I hold my breath hoping my lie will ease his temperamental anger."
    n "Mi desesperada mentira se escapa. Contengo la respiración esperando que calme su temperamento volátil."

# game/game/afterstories.rpy:1061
translate es dblafterstory_b96481e7:

    # n "He smiles letting go of my chin."
    n "Sonríe soltando mi barbilla."

# game/game/afterstories.rpy:1063
translate es dblafterstory_40f0c6e8:

    # n "{color=#510f80} 'Why didn't you say so~'{/color}"
    n "{color=#510f80}'¿Por qué no lo dijiste antes~'{/color}"

# game/game/afterstories.rpy:1065
translate es dblafterstory_42b81951:

    # n "{color=#510f80} 'I always told you that you needed to throw out all this old garbage and update it some.'{/color}"
    n "{color=#510f80}'Siempre te dije que necesitabas deshacerte de toda esta basura vieja y renovarlo un poco.'{/color}"

# game/game/afterstories.rpy:1067
translate es dblafterstory_d08ee7fe:

    # n "{color=#510f80}'Looks like you're finally coming around huh?'{/color}"
    n "{color=#510f80}'Parece que por fin estás entrando en razón, ¿eh?'{/color}"

# game/game/afterstories.rpy:1069
translate es dblafterstory_20a86d5e:

    # n "Double looks genuinely happy and I silently thank whatever gods exist out there."
    n "Double parece genuinamente feliz y en silencio agradezco a los dioses que existan."

# game/game/afterstories.rpy:1073
translate es dblafterstory_e6d449a9:

    # n "I give Double a hard look."
    n "Le lanzo una mirada dura a Double."

# game/game/afterstories.rpy:1075
translate es dblafterstory_bef3bbe3:

    # n "{color=#510f80} 'Remind me, {i}Bitch.{/i}'{/color} I spit out with as much vitriol as I can manage."
    n "{color=#510f80}'Recuérdame, {i}Perra.{/i}'{/color} escupo con toda la rabia que puedo reunir."

# game/game/afterstories.rpy:1077
translate es dblafterstory_4d70e609:

    # n "He smiles wide, crazed, excited."
    n "Él sonríe ampliamente, enloquecido, emocionado."

# game/game/afterstories.rpy:1079
translate es dblafterstory_f278f8d4:

    # n "{color=#1F28AD}{i}'I was hoping you would say so.'{/i}{/color}"
    n "{color=#1F28AD}{i}'Esperaba que dijeras eso.'{/i}{/color}"

# game/game/afterstories.rpy:1081
translate es dblafterstory_18ce72e0:

    # n "He nudges me with his foot."
    n "Me empuja con el pie."

# game/game/afterstories.rpy:1083
translate es dblafterstory_ea4e1d7d:

    # n "{color=#1F28AD}'Sit up! Have some dignity.'{/color}"
    n "{color=#1F28AD}'¡Siéntate! Ten algo de dignidad.'{/color}"

# game/game/afterstories.rpy:1085
translate es dblafterstory_361ba961:

    # n "I do as I'm told."
    n "Obedezco."

# game/game/afterstories.rpy:1087
translate es dblafterstory_74423781:

    # n "He crouches down in front of me, holding the shard of glass up."
    n "Se agacha frente a mí, sosteniendo el fragmento de vidrio."

# game/game/afterstories.rpy:1089
translate es dblafterstory_287c1de1:

    # n "{color=#1F28AD} 'So, my love... where do you want your new tattoo?'{/color}"
    n "{color=#1F28AD}'Entonces, mi amor... ¿dónde quieres tu nuevo tatuaje?'{/color}"

# game/game/afterstories.rpy:1091
translate es dblafterstory_38006b35:

    # n "I will my eyes not to widen, my body not to shake...he's serious."
    n "Me esfuerzo por no abrir los ojos de par en par, por no temblar... está hablando en serio."

# game/game/afterstories.rpy:1094
translate es dblafterstory_3abfc679:

    # n "I hold out my wrist."
    n "Extiendo la muñeca."

# game/game/afterstories.rpy:1096
translate es dblafterstory_6a9021aa:

    # n "{color=#510f80} 'My wrist.' {/color}"
    n "{color=#510f80}'En mi muñeca.'{/color}"

# game/game/afterstories.rpy:1098
translate es dblafterstory_d0598f91:

    # n "Double laughs genuinely, his hair falling to the side as his head throws back."
    n "Double ríe de verdad, su cabello cayendo a un lado mientras echa la cabeza hacia atrás."

# game/game/afterstories.rpy:1100
translate es dblafterstory_0a5ed05e:

    # n "{color=#1F28AD} 'You could die like that you know~'{/color}"
    n "{color=#1F28AD}'Podrías morir así, ¿sabes~?'{/color}"

# game/game/afterstories.rpy:1102
translate es dblafterstory_739ce112:

    # n "I stare at him expressionless."
    n "Lo miro sin expresión."

# game/game/afterstories.rpy:1104
translate es dblafterstory_84f213d1:

    # n "{color=#510f80} 'Make it {i}deep{/i}.'{/color}"
    n "{color=#510f80}'Hazlo {i}profundo{/i}.'{/color}"

# game/game/afterstories.rpy:1106
translate es dblafterstory_3b7e76d1:

    # n "{color=#1F28AD}'So bold! How could I ever {i}not{/i} love you.'{/color}"
    n "{color=#1F28AD}'¡Qué audaz! ¿Cómo podría {i}no{/i} amarte?'{/color}"

# game/game/afterstories.rpy:1108
translate es dblafterstory_e8b93493:

    # n "He takes my wrist kissing it lightly."
    n "Toma mi muñeca y la besa suavemente."

# game/game/afterstories.rpy:1112
translate es dblafterstory_c79e2901:

    # n "I shift my body weight to show my side."
    n "Cambio el peso de mi cuerpo para mostrar mi costado."

# game/game/afterstories.rpy:1114
translate es dblafterstory_288435d3:

    # n "Double's eyebrows shoot upwards in a rare show of genuine expression."
    n "Las cejas de Double se alzan en una rara muestra de sorpresa genuina."

# game/game/afterstories.rpy:1116
translate es dblafterstory_65340919:

    # n "He looks back up at me and I smirk at him."
    n "Me mira y le dedico una sonrisa burlona."

# game/game/afterstories.rpy:1118
translate es dblafterstory_47a24851:

    # n "{color=#1F28AD}'This spot...'{/color}"
    n "{color=#1F28AD}'Este lugar...'{/color}"

# game/game/afterstories.rpy:1120
translate es dblafterstory_9e589cb8:

    # n "He taps the glass shard against my hip trailing it down roughly catches on the fabric."
    n "Golpea el fragmento de vidrio contra mi cadera, arrastrándolo con rudeza hasta engancharse en la tela."

# game/game/afterstories.rpy:1122
translate es dblafterstory_17da5962:

    # n "{color=#1F28AD}'-Is where animals get {i}branded{/i} darling.'{/color}"
    n "{color=#1F28AD}'–Es donde a los animales se les {i}marca{/i}, cariño.'{/color}"

# game/game/afterstories.rpy:1124
translate es dblafterstory_7f2b7c79:

    # n "{color=#1F28AD}'Did you know that? Are you trying to appease me? Tease me?{/color}"
    n "{color=#1F28AD}'¿Lo sabías? ¿Estás intentando complacerme? ¿Provocarme?{/color}"

# game/game/afterstories.rpy:1126
translate es dblafterstory_f5947921:

    # n "{color=#1F28AD} 'Or does it just come naturally to you?{/color}"
    n "{color=#1F28AD} ¿O simplemente te sale natural?'{/color}"

# game/game/afterstories.rpy:1128
translate es dblafterstory_b1e5c0e4:

    # n "{color=#1F28AD} 'Unfortunately, I don't quite agree with your choice of location...'{/color}"
    n "{color=#1F28AD}'Desafortunadamente, no estoy del todo de acuerdo con tu elección de lugar...'{/color}"

# game/game/afterstories.rpy:1130
translate es dblafterstory_4ecb5f3c:

    # n "His eyes brush across my body."
    n "Sus ojos recorren mi cuerpo."

# game/game/afterstories.rpy:1132
translate es dblafterstory_3c08ed51:

    # n "{color=#1F28AD}'I thiiiinkkkk...'{/color}"
    n "{color=#1F28AD}'Creeeooo queee...'{/color}"

# game/game/afterstories.rpy:1134
translate es dblafterstory_e43f04ea:

    # n "he brings a finger to the tip of my nose and trails it downwards."
    n "lleva un dedo a la punta de mi nariz y lo desliza hacia abajo."

# game/game/afterstories.rpy:1136
translate es dblafterstory_50962e3b:

    # n "He stops his finger when it reaches just under my collar bone."
    n "Detiene su dedo justo debajo de mi clavícula."

# game/game/afterstories.rpy:1138
translate es dblafterstory_2bc20753:

    # n "{color=#1F28AD} 'Here is perfect~'{/color}"
    n "{color=#1F28AD}'Aquí es perfecto~'{/color}"

# game/game/afterstories.rpy:1140
translate es dblafterstory_39d7d0b9:

    # n "He brings his hand up to cup my chin."
    n "Lleva su mano hacia mi mentón y lo sostiene."

# game/game/afterstories.rpy:1142
translate es dblafterstory_a95841c1:

    # n "{color=#1F28AD} Now Honey,...{/color}"
    n "{color=#1F28AD} Ahora, cariño...{/color}"

# game/game/afterstories.rpy:1144
translate es dblafterstory_07d4096b:

    # n "{color=#1F28AD} You can Bite me this time, in fact, you will probably need it.{/color}"
    n "{color=#1F28AD}Esta vez puedes morderme, de hecho, probablemente lo necesites.{/color}"

# game/game/afterstories.rpy:1146
translate es dblafterstory_6c398a84:

    # n "{color=#1F28AD} But be careful not to squirm too much, we don't want any mistakes right?{/color}"
    n "{color=#1F28AD}Pero ten cuidado de no moverte demasiado, no queremos errores, ¿verdad?{/color}"

# game/game/afterstories.rpy:1148
translate es dblafterstory_63affc95:

    # n "Double raises his hand up to my mouth and I latch onto it. I'd rather give some pain back to him, even if it is of his own decision."
    n "Double levanta su mano hacia mi boca y me aferro a ella. Prefiero devolverle algo de dolor, aunque sea por decisión suya."

# game/game/afterstories.rpy:1150
translate es dblafterstory_ff212bb9:

    # n "Wasting not a second longer, he presses the glass into my flesh. I scream, biting down into his hand at the breaking of my skin."
    n "Sin perder un segundo más, presiona el vidrio contra mi carne. Grito, mordiendo su mano al sentir mi piel romperse."

# game/game/afterstories.rpy:1152
translate es dblafterstory_aab7f863:

    # n "He smiles at me as he carves with a steady hand. I continue to scream, muffled by his hand that remains firmly held between my teeth."
    n "Él sonríe mientras talla con una mano firme. Sigo gritando, con la voz ahogada por su mano, aún entre mis dientes."

# game/game/afterstories.rpy:1154
translate es dblafterstory_3ec4e248:

    # n "He carves slowly with diligence, the seconds linger as if they are hours."
    n "Talla lentamente, con diligencia; los segundos se alargan como si fueran horas."

# game/game/afterstories.rpy:1156
translate es dblafterstory_92206bca:

    # n "I can feel his carving, my split flesh, the warm blood rolling down my chest."
    n "Puedo sentir su tallado, mi carne abierta, la sangre caliente bajando por mi pecho."

# game/game/afterstories.rpy:1158
translate es dblafterstory_2a73d54e:

    # n "My body breaks out into sweat and tears roll down my cheek. Some hit the open wound, making it sting harshly."
    n "Mi cuerpo suda, las lágrimas resbalan por mis mejillas. Algunas caen sobre la herida abierta, haciéndola arder intensamente."

# game/game/afterstories.rpy:1160
translate es dblafterstory_280ef211:

    # n "After what feels like an eternity, Double finally sighs and backs up. He drops the piece of glass to the ground and holds my shaking shoulders."
    n "Después de lo que parece una eternidad, Double finalmente suspira y retrocede. Deja caer el trozo de vidrio al suelo y sostiene mis hombros temblorosos."

# game/game/afterstories.rpy:1162
translate es dblafterstory_afcc8107:

    # n "{color=#1F28AD} 'Look at you, you are ephemeral, so lovely.' {/color}"
    n "{color=#1F28AD}'Mírate, eres como una presencia efímera, con tanta hermosura.'{/color}"

# game/game/afterstories.rpy:1164
translate es dblafterstory_cce379c7:

    # n "He places kisses on my face and I am too in shock to even move away."
    n "Coloca besos en mi rostro y yo estoy demasiado en shock para apartarme."

# game/game/afterstories.rpy:1166
translate es dblafterstory_c867e7de:

    # n "Double gets up. He moves away, soon returning with disinfectant supplies."
    n "Double se levanta. Se aleja y regresa con suministros desinfectantes."

# game/game/afterstories.rpy:1168
translate es dblafterstory_618fb2ed:

    # n "He cleans and bandages up my wounds. Taking time to wipe away my tears and whisper reassurances."
    n "Limpia y venda mis heridas. Se toma su tiempo para secar mis lágrimas y susurrar palabras de consuelo."

# game/game/afterstories.rpy:1170
translate es dblafterstory_43cf8973:

    # n "Double scoops me up from the floor, setting me on the couch in his lap."
    n "Double me levanta del suelo y me sienta en su regazo, en el sofá."

# game/game/afterstories.rpy:1172
translate es dblafterstory_155a1ae8:

    # n "He holds me tight breathing in my scent."
    n "Me abraza fuerte, inhalando mi aroma."

# game/game/afterstories.rpy:1174
translate es dblafterstory_310505eb:

    # n "{color=#1F28AD} 'I missed you all day Honey.'{/color}"
    n "{color=#1F28AD}'Te extrañé todo el día, cariño.'{/color}"

# game/game/afterstories.rpy:1176
translate es dblafterstory_c25ea4fa:

    # n "{color=#1F28AD} 'Couldn't wait to get back home and see you...'{/color}"
    n "{color=#1F28AD}'No podía esperar para volver a casa y verte...'{/color}"

# game/game/afterstories.rpy:1178
translate es dblafterstory_8b11e71f:

    # n "I couldn't get myself to speak."
    n "No podía obligarme a hablar."

# game/game/afterstories.rpy:1180
translate es dblafterstory_64855b80:

    # n "{color=#1F28AD} 'What movie do you want to see this weekend for our date? Let's stop by the bookstore after.'{/color}"
    n "{color=#1F28AD}'¿Qué película quieres ver este fin de semana en nuestra cita? Después pasemos por la librería.'{/color}"

# game/game/afterstories.rpy:1182
translate es dblafterstory_1f774c7e:

    # n "I stay silent."
    n "Permanezco en silencio."

# game/game/afterstories.rpy:1184
translate es dblafterstory_79d83679:

    # n "In the before times, Double and I used to go out for a date every weekend. He would treat me to a movie, a coffee, ice cream, books, various nicknacks..."
    n "En tiempos pasados, Double y yo solíamos salir cada fin de semana. Me invitaba al cine, a un café, helado, libros, pequeños recuerdos..."

# game/game/afterstories.rpy:1186
translate es dblafterstory_454f2e04:

    # n "Anything I looked at for a second too long became mine, even if I didn't particularly want it."
    n "Cualquier cosa que mirara por un segundo demasiado se volvía mía, incluso si no la quería realmente."

# game/game/afterstories.rpy:1188
translate es dblafterstory_19244f14:

    # n "Eventually his behavior became so problematic that it was more stressful to be outside with him than it was to be behind closed doors."
    n "Con el tiempo, su comportamiento se volvió tan problemático que era más estresante salir con él que quedarme en el encierro."

# game/game/afterstories.rpy:1190
translate es dblafterstory_b39b3943:

    # n "{color=#510f80} 'Um, it's okay I-'{/color}"
    n "{color=#510f80}'Um, está bien yo...'{/color}"

# game/game/afterstories.rpy:1192
translate es dblafterstory_bb2fe6a5:

    # n "Double moves his head back and looks at me with dead eyes."
    n "Double echa la cabeza hacia atrás y me mira con ojos vacíos."

# game/game/afterstories.rpy:1194
translate es dblafterstory_82a17ffc:

    # n "{color=#1F28AD} 'Excuse me..?' {/color}"
    n "{color=#1F28AD}'¿Perdón...?'{/color}"

# game/game/afterstories.rpy:1196
translate es dblafterstory_a9dc4853:

    # n "{color=#510f80} 'Yeah, I-...I can't wait.' {/color}"
    n "{color=#510f80}'Sí, yo... no puedo esperar.'{/color}"

# game/game/afterstories.rpy:1198
translate es dblafterstory_1e07980f:

    # n "He smiles hugging me again."
    n "Él sonríe y me abraza de nuevo."

# game/game/afterstories.rpy:1200
translate es dblafterstory_48d43fad:

    # n "His hugs felt suffocating. I needed to get away from him."
    n "Sus abrazos se sentían sofocantes. Necesitaba alejarme de él."

# game/game/afterstories.rpy:1202
translate es dblafterstory_35e76407:

    # n "{color=#510f80} 'Double...' {/color}"
    n "{color=#510f80}'Double...'{/color}"

# game/game/afterstories.rpy:1204
translate es dblafterstory_01b018ee:

    # n "I look up at him, he stares down at me looking slightly happy that I called him by his name."
    n "Levanto la vista hacia él; me observa, ligeramente feliz de que lo haya llamado por su nombre."

# game/game/afterstories.rpy:1206
translate es dblafterstory_b881c710:

    # n "{color=#510f80} 'Can I, make us dinner tonight?' {/color}"
    n "{color=#510f80}'¿Puedo prepararnos la cena esta noche?'{/color}"

# game/game/afterstories.rpy:1208
translate es dblafterstory_4aa843b2:

    # n "He looks at me, stares at me, scanning my intentions."
    n "Me mira, me escanea, buscando mis intenciones."

# game/game/afterstories.rpy:1210
translate es dblafterstory_1bcc40f4:

    # n "{color=#510f80} '...I want to make us something nice.' {/color}"
    n "{color=#510f80}'...Quiero hacernos algo bonito.'{/color}"

# game/game/afterstories.rpy:1212
translate es dblafterstory_38636965:

    # n "After staring at me for a bit longer he smiles."
    n "Después de observarme un poco más, sonríe."

# game/game/afterstories.rpy:1214
translate es dblafterstory_71dc94dc:

    # n "{color=#1F28AD} 'Sure.' {/color}"
    n "{color=#1F28AD}'Claro.'{/color}"

# game/game/afterstories.rpy:1216
translate es dblafterstory_318195b0:

    # n "He pulls me closer by the chain, so our noses are almost touching. I can feel his breath dust over my face."
    n "Me jala más cerca por la cadena, hasta que nuestras narices casi se tocan. Puedo sentir su aliento rozar mi rostro."

# game/game/afterstories.rpy:1218
translate es dblafterstory_7b4b186b:

    # n "He takes his time as he reaches into his pocket grabbing the key to the heavy lock that binds my neck."
    n "Se toma su tiempo mientras mete la mano en el bolsillo, sacando la llave del pesado candado que aprisiona mi cuello."

# game/game/afterstories.rpy:1220
translate es dblafterstory_f0e4a806:

    # n "I squirm, attempting to relieve my back of the tension caused by the awkward position."
    n "Me muevo, intentando aliviar la tensión de mi espalda causada por la posición incómoda."

# game/game/afterstories.rpy:1222
translate es dblafterstory_660f6d69:

    # n "Double smirks a little. He brings the key to my neck."
    n "Double sonríe levemente. Acerca la llave a mi cuello."

# game/game/afterstories.rpy:1224
translate es dblafterstory_5066ac12:

    # n "'Ka-Chink.'"
    n "'Ka-Chink.'"

# game/game/afterstories.rpy:1226
translate es dblafterstory_5aa39a4a:

    # n "The heavy lock falls to the wayside along with the metal clasp."
    n "El pesado candado cae a un lado junto con el broche metálico."

# game/game/afterstories.rpy:1228
translate es dblafterstory_76f5e0f4:

    # n "Double smiles as if he did me a favor."
    n "Double sonríe como si me hubiera hecho un favor."

# game/game/afterstories.rpy:1230
translate es dblafterstory_64afc13f:

    # n "{color=#1F28AD} 'Go get em' tiger.' {/color}"
    n "{color=#1F28AD}'Ve a por ello, fiera.'{/color}"

# game/game/afterstories.rpy:1232
translate es dblafterstory_76845bc1:

    # n "I stand up stretching my wobbly legs and make my way slowly over to the kitchen."
    n "Me pongo de pie, estiro mis piernas temblorosas y camino lentamente hacia la cocina."

# game/game/afterstories.rpy:1234
translate es dblafterstory_35b88604:

    # n "Some part of me feels enraged at how weak my legs have grown after weeks of not enough use."
    n "Una parte de mí se siente enfurecida por lo débiles que están mis piernas después de semanas sin suficiente uso."

# game/game/afterstories.rpy:1236
translate es dblafterstory_9a8cc677:

    # n "I lean on the counter top as I hear Double pick up his phone."
    n "Me apoyo en la encimera mientras escucho a Double tomar su teléfono."

# game/game/afterstories.rpy:1238
translate es dblafterstory_088984f1:

    # n "I spot his outer jacket draped over the bar chair. I wobble over to the jacket praying to god that it had a spare key in one of the pockets."
    n "Veo su chaqueta colgada sobre la silla del bar. Camino tambaleante hacia ella, rezando porque tuviera una llave de repuesto en algún bolsillo."

# game/game/afterstories.rpy:1240
translate es dblafterstory_c6d93c90:

    # n "I rifle through quickly...all of the pockets feel empty aside from one. My hand brushes against a hard object and a pointy object."
    n "Rebusco rápido... todos los bolsillos parecen vacíos, excepto uno. Mi mano roza algo duro y puntiagudo."

# game/game/afterstories.rpy:1242
translate es dblafterstory_e7696381:

    # n "I pull out the objects. One is a small key, that looks exactly like the key that double used on my collar."
    n "Saco los objetos. Uno es una pequeña llave, idéntica a la que Double usó en mi collar."

# game/game/afterstories.rpy:1244
translate es dblafterstory_e7ce39fa:

    # n "I don't have any pockets so I tuck it into the waist of my pants as snugly as I can manage."
    n "No tengo bolsillos, así que la escondo en la cintura de mis pantalones, tan ajustada como puedo."

# game/game/afterstories.rpy:1246
translate es dblafterstory_19ec445e:

    # n "I pull out the second object. It is a small deep black velvet box."
    n "Saco el segundo objeto. Es una pequeña caja de terciopelo negro."

# game/game/afterstories.rpy:1248
translate es dblafterstory_13c60268:

    # n "My heart pounds and my hands sweat as I open the box slowly."
    n "Mi corazón late con fuerza y mis manos sudan mientras abro la caja lentamente."

# game/game/afterstories.rpy:1250
translate es dblafterstory_f92b139d:

    # n "My fears surface as I eye the gorgeous ring."
    n "Mis temores se confirman al ver el hermoso anillo."

# game/game/afterstories.rpy:1252
translate es dblafterstory_35c9e264:

    # n "The ring shines in the kitchen light."
    n "El anillo brilla bajo la luz de la cocina."

# game/game/afterstories.rpy:1254
translate es dblafterstory_ed80fcd9:

    # n "I hear the couch creak as Double gets up. I quickly shove the ring back into the jacket pocket."
    n "Escucho el crujido del sofá cuando Double se levanta. Rápidamente vuelvo a meter el anillo en el bolsillo de la chaqueta."

# game/game/afterstories.rpy:1256
translate es dblafterstory_ad65f442:

    # n "My heart is pounding. Everything is quiet. I open the cupboard and close it."
    n "Mi corazón late con fuerza. Todo está en silencio. Abro un armario y lo cierro."

# game/game/afterstories.rpy:1258
translate es dblafterstory_118fb8ca:

    # n "Double takes another phone call."
    n "Double atiende otra llamada telefónica."

# game/game/afterstories.rpy:1260
translate es dblafterstory_c39f48ff:

    # n "I look at his jacket pocket again. 'Is he really...?'"
    n "Miro de nuevo el bolsillo de su chaqueta. '¿En serio...?'"

# game/game/afterstories.rpy:1262
translate es dblafterstory_17d2b878:

    # n "My palms sweat, my chest pounds, I start to feel nauseous."
    n "Mis palmas sudan, mi pecho late, empiezo a sentir mareo."

# game/game/afterstories.rpy:1264
translate es dblafterstory_e73c3fec:

    # n "I avert my gaze, looking around the kitchen instead. My eyes land on a large knife."
    n "Desvío la mirada, observando la cocina. Mis ojos se posan en un cuchillo grande."

# game/game/afterstories.rpy:1266
translate es dblafterstory_f0a3b8c6:

    # n "I look back at the tan jacket, mocking me, taunting me."
    n "Vuelvo a mirar la chaqueta color beige, burlándose de mí, provocándome."

# game/game/afterstories.rpy:1268
translate es dblafterstory_4b68ac5d:

    # n "I pick up the knife, looking at myself in the reflection. I then glance back at the tan irritating jacket, the disgusting lump lurking the pocket."
    n "Tomo el cuchillo, mirándome en su reflejo. Luego miro la chaqueta irritante, el bulto repugnante dentro del bolsillo."

# game/game/afterstories.rpy:1270
translate es dblafterstory_d386105e:

    # n "I feel..."
    n "Siento..."

# game/game/afterstories.rpy:1275
translate es dblafterstory_7a646455:

    # n "{i}I feel Indignant.{/i}"
    n "{i}Siento indignación.{/i}"

# game/game/afterstories.rpy:1277
translate es dblafterstory_f27ff6a7:

    # n "My hand tightens around the knife."
    n "Aprieto el cuchillo con fuerza."

# game/game/afterstories.rpy:1279
translate es dblafterstory_510a3a62:

    # n "I smile in the reflection, my resolve thickening."
    n "Sonrío en el reflejo, mi determinación se endurece."

# game/game/afterstories.rpy:1281
translate es dblafterstory_8491fd85:

    # n "{color=#1F28AD} 'How are things going?' {/color}"
    n "{color=#1F28AD}¿Cómo va todo?{/color}"

# game/game/afterstories.rpy:1283
translate es dblafterstory_e935efd6:

    # n "Double calls to me for the other room."
    n "Double me llama desde la otra habitación."

# game/game/afterstories.rpy:1285
translate es dblafterstory_3ae90417:

    # n "I smile, heart beating a thousand miles an hour."
    n "Sonrío, el corazón latiendo a mil por hora."

# game/game/afterstories.rpy:1287
translate es dblafterstory_6747c689:

    # n "{color=#510f80} 'Great. I'm making you the {i}perfect dish{/i}.' {/color}"
    n "{color=#510f80}'Genial. Estoy preparándote el {i}plato perfecto{/i}.'{/color}"

# game/game/afterstories.rpy:1289
translate es dblafterstory_26a0053b:

    # n "I walk towards the edge of the kitchen pressing myself against the wall."
    n "Camino hacia el borde de la cocina, pegándome a la pared."

# game/game/afterstories.rpy:1291
translate es dblafterstory_5006e263:

    # n "{color=#510f80} 'Come have a taste honey~' {/color}"
    n "{color=#510f80}'Ven a probar, cariño~'{/color}"

# game/game/afterstories.rpy:1293
translate es dblafterstory_bc7f492c:

    # n "I smile at my reflection in the knife."
    n "Sonrío a mi reflejo en el cuchillo."

# game/game/afterstories.rpy:1295
translate es dblafterstory_31a5dd44:

    # n "{i}If I can't have my freedom, I might as well take what I can from him.{/i}"
    n "{i}Si no puedo tener mi libertad, al menos tomaré lo que pueda de él.{/i}"

# game/game/afterstories.rpy:1297
translate es dblafterstory_4fcd7788:

    # n "I hear his footsteps approaching, I grip the knife steeling my resolve."
    n "Escucho sus pasos acercarse, agarro el cuchillo con firmeza, endureciendo mi resolución."

# game/game/afterstories.rpy:1299
translate es dblafterstory_457711f2:

    # n "{i}You want me Double? You are gonna get me.{/i}"
    n "{i}¿Me quieres, Double? Entonces me tendrás.{/i}"

# game/game/afterstories.rpy:1304
translate es dblafterstory_b57306d0:

    # n "{i}I feel regret.{/i}"
    n "{i}Siento arrepentimiento.{/i}"

# game/game/afterstories.rpy:1306
translate es dblafterstory_67e5e484:

    # n "Maybe...."
    n "Quizás..."

# game/game/afterstories.rpy:1308
translate es dblafterstory_b64c8669:

    # n "Maybe some of this is really my fault."
    n "Quizás algo de esto sí sea culpa mía."

# game/game/afterstories.rpy:1310
translate es dblafterstory_55a9cca2:

    # n "Maybe, I shouldn't have left Double..."
    n "Quizás no debí haber dejado a Double..."

# game/game/afterstories.rpy:1312
translate es dblafterstory_17f84682:

    # n "Maybe it really did hurt him."
    n "Quizás realmente le dolió."

# game/game/afterstories.rpy:1314
translate es dblafterstory_59ee5b4f:

    # n "Maybe."
    n "Quizás."

# game/game/afterstories.rpy:1316
translate es dblafterstory_94bb6063:

    # n "M-maybe...."
    n "Q-quizás..."

# game/game/afterstories.rpy:1318
translate es dblafterstory_5928b344:

    # n "....!"
    n "...¡!"

# game/game/afterstories.rpy:1320
translate es dblafterstory_b1e53453:

    # n "I can't bear to look at myself in the reflection any longer."
    n "No puedo soportar mirarme más en el reflejo."

# game/game/afterstories.rpy:1322
translate es dblafterstory_486185a4:

    # n "I toss the knife away and collapse onto the ground, my resolve crumbling."
    n "Lanzo el cuchillo y caigo al suelo, mi resolución desmoronándose."

# game/game/afterstories.rpy:1324
translate es dblafterstory_0cb2db25:

    # n "I sob and sob and sob."
    n "Lloro y lloro y lloro."

# game/game/afterstories.rpy:1326
translate es dblafterstory_52c013ae:

    # n "Double upon hearing the clatter teleports over. I can't even hear his words over my own agony."
    n "Al escuchar el estruendo, Double aparece de inmediato. No puedo oír sus palabras sobre mi propio dolor."

# game/game/afterstories.rpy:1328
translate es dblafterstory_c48de317:

    # n "I sob and scream and sob and scream until my voice disappears, until my throat feels like sandpaper, until I can taste blood."
    n "Lloro y grito y lloro y grito hasta que mi voz desaparece, hasta que mi garganta arde como papel de lija, hasta que puedo saborear la sangre."

# game/game/afterstories.rpy:1330
translate es dblafterstory_e867d221:

    # n "But no matter how much I cry, no matter how much I scream, no one will save me, no one can save me."
    n "Pero no importa cuánto llore, no importa cuánto grite, nadie vendrá a salvarme, nadie puede salvarme."

# game/game/afterstories.rpy:1332
translate es dblafterstory_b4c0f531:

    # n "It's only Double and I, exactly like he wanted all along."
    n "Solo estamos Double y yo, exactamente como él siempre quiso."

# game/game/afterstories.rpy:1351
translate es halafterstory_d858d815:

    # n "The three of us ride through the early night, the warm summer wind brushing around us in the cheap convertible."
    n "Los tres viajamos por la noche temprana, el cálido viento de verano rozándonos en el viejo convertible."

# game/game/afterstories.rpy:1353
translate es halafterstory_81aaa51c:

    # n "We finally make it to our destination."
    n "Finalmente llegamos a nuestro destino."

# game/game/afterstories.rpy:1355
translate es halafterstory_5b8a8796:

    # n "A road far in the middle of nowhere. Twisting, turning, beautiful manicured gardens leading up to a mansion."
    n "Un camino en medio de la nada. Curvas, giros, jardines bellamente cuidados que conducen a una mansión."

# game/game/afterstories.rpy:1357
translate es halafterstory_d484c1fa:

    # n "{i}Our next target.{/i}"
    n "{i}Nuestro siguiente objetivo.{/i}"

# game/game/afterstories.rpy:1359
translate es halafterstory_084a62e4:

    # n "We leave the van and Hal and I scout the outside of the ostentatious house."
    n "Salimos de la furgoneta y Hal y yo exploramos el exterior de la ostentosa casa."

# game/game/afterstories.rpy:1361
translate es halafterstory_f4a7c1d5:

    # n "After a round of scouting, we meet back up. Hal has found our way in."
    n "Tras una ronda de exploración, nos reunimos de nuevo. Hal ha encontrado nuestra forma de entrar."

# game/game/afterstories.rpy:1363
translate es halafterstory_99a5558b:

    # n "Next Hal works to disarm the security system. I scout the exit route while Miles keeps watch out front."
    n "Luego Hal trabaja para desactivar el sistema de seguridad. Yo reviso la ruta de escape mientras Miles vigila en la parte delantera."

# game/game/afterstories.rpy:1365
translate es halafterstory_eeba425e:

    # n "Everything is going pretty well to plan so far. A gig like this is basically like a rinse-and-repeat for our little group."
    n "Hasta ahora todo va bastante bien según el plan. Un trabajo como este es prácticamente rutina para nuestro pequeño grupo."

# game/game/afterstories.rpy:1367
translate es halafterstory_92d2989c:

    # n "Hal soon finds me, leading me to a back entrance."
    n "Hal pronto me encuentra, guiándome hacia una entrada trasera."

# game/game/afterstories.rpy:1369
translate es halafterstory_b21db753:

    # n "{color=#1A5F38} 'Look, this door has no camera, {i} no security system either. {/i} Can you believe it?'{/color}"
    n "{color=#1A5F38}'Mira, esta puerta no tiene cámara, {i}ni sistema de seguridad tampoco.{/i} ¿Puedes creerlo?'{/color}"

# game/game/afterstories.rpy:1371
translate es halafterstory_28dfbff7:

    # n "Haley shakes their head in disbelief pointing to a plastic device screwed into the wall beside the door."
    n "Haley niega con la cabeza incrédule, señalando un dispositivo de plástico atornillado a la pared junto a la puerta."

# game/game/afterstories.rpy:1373
translate es halafterstory_af35d7a7:

    # n "{color=#1A5F38} 'The camera up there is fake, it doesn't have wires or batteries.'{/color}"
    n "{color=#1A5F38}'La cámara de ahí arriba es falsa, no tiene cables ni baterías.'{/color}"

# game/game/afterstories.rpy:1375
translate es halafterstory_6813975f:

    # n "{color=#510f80} 'What? Really? Why would they do that...?{/color}"
    n "{color=#510f80}'¿Qué? ¿En serio? ¿Por qué harían eso...?'{/color}"

# game/game/afterstories.rpy:1377
translate es halafterstory_348e12bd:

    # n "Haley gives a dry laugh."
    n "Haley suelta una risa seca."

# game/game/afterstories.rpy:1379
translate es halafterstory_0f5d1d6e:

    # n "{color=#1A5F38} 'How do you think his mistress enters without alerting his wife?'{/color}"
    n "{color=#1A5F38}'¿Cómo crees que entra su amante sin alertar a su esposa?'{/color}"

# game/game/afterstories.rpy:1381
translate es halafterstory_7148e8b5:

    # n "{color=#1A5F38} 'And for that reason, the cameras inside are also easily turned off.'{/color}"
    n "{color=#1A5F38}'Y por esa misma razón, las cámaras interiores también se apagan fácilmente.'{/color}"

# game/game/afterstories.rpy:1383
translate es halafterstory_c69917ba:

    # n "{color=#510f80} 'Wow, jackpot I guess.'{/color}"
    n "{color=#510f80}'Vaya, supongo que tocó el premio gordo.'{/color}"

# game/game/afterstories.rpy:1385
translate es halafterstory_72a15cfc:

    # n "Haley mumbles in agreement while easily unlocking the nondescript back door."
    n "Haley murmura en acuerdo mientras abre sin dificultad la puerta trasera sin distintivos."

# game/game/afterstories.rpy:1387
translate es halafterstory_c3a94fbf:

    # n "{color=#1A5F38} 'Can you grab Miles?'{/color}"
    n "{color=#1A5F38}'¿Puedes traer a Miles?'{/color}"

# game/game/afterstories.rpy:1389
translate es halafterstory_061ca4f1:

    # n "By the time I return with Miles in-tow, Haley had already dismantled the indoor cameras."
    n "Cuando regreso con Miles, Haley ya había desmantelado las cámaras interiores."

# game/game/afterstories.rpy:1391
translate es halafterstory_e57f2d78:

    # n "We enter in the Mansion, the marble floors clicking under Hal's boots."
    n "Entramos a la mansión, los pisos de mármol resonando bajo las botas de Hal."

# game/game/afterstories.rpy:1393
translate es halafterstory_5e9d78a8:

    # n "Hal turns to us."
    n "Hal se vuelve hacia nosotros."

# game/game/afterstories.rpy:1395
translate es halafterstory_c47eb0ec:

    # n "{color=#1A5F38} 'So everyone remembers the plan right?' {/color}"
    n "{color=#1A5F38}'Entonces, ¿todos recuerdan el plan, verdad?'{/color}"

# game/game/afterstories.rpy:1397
translate es halafterstory_d5a6b36b:

    # n "There is some silence and then Miles leans over to me whispering."
    n "Hay un breve silencio y luego Miles se inclina hacia mí, susurrando."

# game/game/afterstories.rpy:1399
translate es halafterstory_a12f5451:

    # n "{color=#61170f} 'Uh... plan?'{/color}"
    n "{color=#61170f}'¿Eh... plan?'{/color}"

# game/game/afterstories.rpy:1401
translate es halafterstory_a696dfdd:

    # n "{color=#1A5F38} 'Miles! Do you seriously have to forget every time?!' {/color}"
    n "{color=#1A5F38}'¡Miles! !¿En serio tienes que olvidarlo cada vez?!'{/color}"

# game/game/afterstories.rpy:1403
translate es halafterstory_b5a054d3:

    # n "Miles pushes up his sweatshirt sleeves and holds up his arms."
    n "Miles se sube las mangas de la sudadera y levanta los brazos."

# game/game/afterstories.rpy:1405
translate es halafterstory_241549e0:

    # n "{color=#61170f} 'I wrote it on here, but then, it kinda washed off in the shower..'{/color}"
    n "{color=#61170f}'Lo escribí aquí, pero... se borró en la ducha...'{/color}"

# game/game/afterstories.rpy:1407
translate es halafterstory_339d656c:

    # n "Haley face-palms with a groan."
    n "Haley se lleva la mano a la cara con un quejido."

# game/game/afterstories.rpy:1409
translate es halafterstory_8068396d:

    # n "{color=#1A5F38} 'Well, thank god for that!' {/color}"
    n "{color=#1A5F38}'¡Gracias a dios por eso!'{/color}"

# game/game/afterstories.rpy:1411
translate es halafterstory_5a22a003:

    # n "{color=#1A5F38} 'You could just wear a shirt that says {i}'I'm going to rob this house'{/i} instead if you wanted.' {/color}"
    n "{color=#1A5F38}'Podrías usar una camiseta que diga {i}'Voy a robar esta casa'{/i} si quisieras.'{/color}"

# game/game/afterstories.rpy:1413
translate es halafterstory_0b4712c1:

    # n "{color=#61170f} 'Oh, was that part of the plan?' {/color}"
    n "{color=#61170f} '¿Oh, eso era parte del plan?' {/color}"

# game/game/afterstories.rpy:1415
translate es halafterstory_048fefe3:

    # n "{color=#1A5F38} '{i}NO.{/i}' {/color}"
    n "{color=#1A5F38} '{i}NO.{/i}' {/color}"

# game/game/afterstories.rpy:1417
translate es halafterstory_172fc040:

    # n "I could almost see the migraine surfacing on Haley's forehead."
    n "Casi puedo ver la jaqueca formándose en la frente de Haley."

# game/game/afterstories.rpy:1419
translate es halafterstory_a67672f2:

    # n "{color=#1A5F38} 'Miles. First, move the car to the back exit route. Then YOU watch the cameras on your phone.' {/color}"
    n "{color=#1A5F38}'Miles. Primero, mueve el auto a la salida trasera. Luego tú vigilas las cámaras en tu teléfono.'{/color}"

# game/game/afterstories.rpy:1421
translate es halafterstory_f52c8675:

    # n "{color=#1A5F38} 'If you give us a heads up {i}the second {/i} you see someone coming, it will give us a 5 minutes heads up. Which should be more than enough to get out of here in time.{/color}"
    n "{color=#1A5F38}'Si nos avisas {i}en el segundo{/i} que veas a alguien venir, nos darás cinco minutos de ventaja. Eso debería ser más que suficiente para salir de aquí a tiempo.'{/color}"

# game/game/afterstories.rpy:1423
translate es halafterstory_ba775d68:

    # n "Miles nods, giving a thumbs up. Haley turns to me about to ask if I know my assignment but I give them a small nod."
    n "Miles asiente, levantando el pulgar. Haley se gira hacia mí a punto de preguntar si sé mi tarea, pero le doy un pequeño asentimiento."

# game/game/afterstories.rpy:1425
translate es halafterstory_f01c2d05:

    # n "{color=#1A5F38} 'Alright, let's get going. This is a quick in-and-out.' {/color}"
    n "{color=#1A5F38}'Bien, pongámonos en marcha. Esto será rápido, entrar y salir.'{/color}"

# game/game/afterstories.rpy:1427
translate es halafterstory_7249c0ff:

    # n "We break and I immediately head to my location upstairs."
    n "Nos separamos y voy directamente a mi posición en el piso superior."

# game/game/afterstories.rpy:1429
translate es halafterstory_c7b68349:

    # n "Soon I find the master bedroom and start digging in any drawers I can find."
    n "Pronto encuentro el dormitorio principal y empiezo a registrar todos los cajones que puedo."

# game/game/afterstories.rpy:1431
translate es halafterstory_3f463d3b:

    # n "I place aside any item that looks like it may be worth something, making sure to throw some clothes around as I go so the scene appears as if the 'robbery' was done quickly."
    n "Aparto cualquier objeto que parezca tener valor, asegurándome de tirar algo de ropa alrededor para que parezca que el 'robo' fue apresurado."

# game/game/afterstories.rpy:1433
translate es halafterstory_af7be25d:

    # n "But I {i}know exactly {/i} what I'm looking for."
    n "Pero {i}sé exactamente{/i} lo que estoy buscando."

# game/game/afterstories.rpy:1435
translate es halafterstory_73bcf09c:

    # n "I easily sift through the nightstands and then make my way to the closet next."
    n "Reviso fácilmente las mesas de noche y luego me dirijo al armario."

# game/game/afterstories.rpy:1437
translate es halafterstory_6e558c59:

    # n "I open the closet and blanche at the incredible amount of....stuff."
    n "Abro el armario y me paralizo ante la increíble cantidad de... cosas."

# game/game/afterstories.rpy:1439
translate es halafterstory_4e954b7a:

    # n "Books, clothes, pictures, perfumes, jewelry, boxes..."
    n "Libros, ropa, fotos, perfumes, joyas, cajas..."

# game/game/afterstories.rpy:1441
translate es halafterstory_158d830f:

    # n "The value in this closet alone could have estimated a million easily."
    n "El valor de ese armario por sí solo podría estimarse fácilmente en un millón."

# game/game/afterstories.rpy:1443
translate es halafterstory_f449411d:

    # n "After stretching my neck a bit, I get to work. I start pulling out fabric, jewelry, digging through boxes..."
    n "Después de estirar un poco el cuello, me pongo a trabajar. Empiezo a sacar telas, joyas, revisando cajas..."

# game/game/afterstories.rpy:1445
translate es halafterstory_66ae7b86:

    # n "{color=#1A5F38} 'Wow that's a lot of shit.' {/color}"
    n "{color=#1A5F38}'Wow, eso es un montón de porquerías.'{/color}"

# game/game/afterstories.rpy:1447
translate es halafterstory_3cf4e853:

    # n "{color=#510f80}'!!!'{/color}"
    n "{color=#510f80}'¡¡¡!!!'{/color}"

# game/game/afterstories.rpy:1449
translate es halafterstory_9e659526:

    # n "I near jump out of my damn skin at the sound of Hal's voice."
    n "Casi salto del susto al oír la voz de Hal."

# game/game/afterstories.rpy:1451
translate es halafterstory_00abd29e:

    # n "{color=#510f80} 'Fuck, Hal! Are you a ghost or something!?'{/color}"
    n "{color=#510f80}'¡Joder, Hal! ¿Eres un fantasma o qué!?'{/color}"

# game/game/afterstories.rpy:1453
translate es halafterstory_dce16d07:

    # n "{color=#1A5F38} 'Oh sorry, I didn't mean to sneak up on you there.' {/color}"
    n "{color=#1A5F38}'Oh, perdón, no quería asustarte.'{/color}"

# game/game/afterstories.rpy:1455
translate es halafterstory_955d3dcc:

    # n "{color=#510f80} 'Did you already get the files?'{/color}"
    n "{color=#510f80}'¿Ya conseguiste los archivos?'{/color}"

# game/game/afterstories.rpy:1457
translate es halafterstory_4290594a:

    # n "{color=#1A5F38} 'Yep, I didn't even have to force my way in or take the drive. The password was literally his mistress's birthday...' {/color}"
    n "{color=#1A5F38}'Sí, ni siquiera tuve que forzar la entrada ni llevarme el disco. La contraseña era literalmente el cumpleaños de su amante...'{/color}"

# game/game/afterstories.rpy:1459
translate es halafterstory_4aadc6c4:

    # n "{color=#1A5F38} '34 years younger than him by the way...' {/color}"
    n "{color=#1A5F38}'34 años menor que él, por cierto...'{/color}"

# game/game/afterstories.rpy:1461
translate es halafterstory_7d5dc9a6:

    # n "{color=#510f80} 'Gross...'{/color}"
    n "{color=#510f80}'Qué asco...'{/color}"

# game/game/afterstories.rpy:1463
translate es halafterstory_cf885fa4:

    # n "Haley nods in agreement."
    n "Haley asiente en acuerdo."

# game/game/afterstories.rpy:1465
translate es halafterstory_2da991ad:

    # n "{color=#1A5F38} 'You need any help?' {/color}"
    n "{color=#1A5F38}'¿Necesitas ayuda?'{/color}"

# game/game/afterstories.rpy:1467
translate es halafterstory_58301563:

    # n "{color=#510f80} 'I could use some, yeah.' {/color}"
    n "{color=#510f80}'Podría venir bien, sí.'{/color}"

# game/game/afterstories.rpy:1469
translate es halafterstory_ad98291a:

    # n "Haley jumps in on my search, throwing valuables in my growing pile and taking extra care to search through the boxes."
    n "Haley se une a mi búsqueda, lanzando objetos de valor a mi creciente pila y revisando con cuidado las cajas."

# game/game/afterstories.rpy:1471
translate es halafterstory_52712cea:

    # n "A couple minutes go by as we search and sift in silence."
    n "Pasan un par de minutos mientras buscamos en silencio."

# game/game/afterstories.rpy:1473
translate es halafterstory_acdc8853:

    # n "{color=#1A5F38} 'Oh my god, {i}look {/i} at this shit.' {/color}"
    n "{color=#1A5F38}'Oh por dios, {i}mira{/i} esta cosa.'{/color}"

# game/game/afterstories.rpy:1475
translate es halafterstory_a3710fa2:

    # n "I glance up and Haley is sporting the most ridiculous hat I've ever seen. Puke green, fur trimmed, satin, diamond encrusted."
    n "Levanto la vista y Haley lleva puesto el sombrero más ridículo que he visto jamás. Verde vómito, con bordes de piel, satinado, incrustado con diamantes."

# game/game/afterstories.rpy:1477
translate es halafterstory_2f94743e:

    # n "I laugh at the absurd hat, so out of place on Haley's head."
    n "Me río del absurdo sombrero, tan fuera de lugar en la cabeza de Haley."

# game/game/afterstories.rpy:1479
translate es halafterstory_70f8262c:

    # n "{color=#510f80} 'Okay, now {i}that {/i} is a damn war crime.' {/color}"
    n "{color=#510f80}'De acuerdo, eso sí que es un crimen de guerra.'{/color}"

# game/game/afterstories.rpy:1481
translate es halafterstory_79d252c6:

    # n "I turn around grabbing a piece of clothing from the ground."
    n "Me doy la vuelta y tomo una prenda del suelo."

# game/game/afterstories.rpy:1483
translate es halafterstory_fa50ac5d:

    # n "{color=#510f80} 'But is it as bad as {i}This!?{/i}' {/color}"
    n "{color=#510f80}'¿¡Pero es tan malo como {i}esto!?'{/i}{/color}"

# game/game/afterstories.rpy:1485
translate es halafterstory_e54a9ab3:

    # n "I put on a ostentatious silver jacket made in a shiny material that would confound scientists across the globe."
    n "Me pongo una chaqueta plateada ostentosa hecha de un material tan brillante que desconcertaría a los científicos de todo el mundo."

# game/game/afterstories.rpy:1487
translate es halafterstory_5bf444cb:

    # n "The shoulder pads let out obnoxious squeaks as I pose like a model for Haley."
    n "Las hombreras chirrían de forma molesta mientras poso como modelo para Haley."

# game/game/afterstories.rpy:1489
translate es halafterstory_e5327b95:

    # n "Haley's laugh bubbles over."
    n "La risa de Haley estalla."

# game/game/afterstories.rpy:1491
translate es halafterstory_f923ef2f:

    # n "{color=#1A5F38} 'Personally, It's not high fashion enough for me yet darrrling...' {/color}"
    n "{color=#1A5F38} 'Personalmente, no es lo suficientemente alta costura para mí aún, cariño...'{/color}"

# game/game/afterstories.rpy:1493
translate es halafterstory_f1a5764a:

    # n "Haley purses their lips snootily in an exaggerated joking expression."
    n "Haley frunce los labios con una expresión exageradamente altiva."

# game/game/afterstories.rpy:1495
translate es halafterstory_8e403f42:

    # n "{color=#1A5F38} 'Now, if you add some of {i}these {/i} we can talk!' {/color}"
    n "{color=#1A5F38} 'Ahora, si le agregas algunos de {i}estos{/i}, ¡podemos hablar!' {/color}"

# game/game/afterstories.rpy:1497
translate es halafterstory_f3e1ce0a:

    # n "Haley holds out a pair of sunglasses for me to take. They resemble a single black bar that reached dangerous horizontal lengths."
    n "Haley me ofrece un par de gafas de sol. Parecen una sola barra negra de longitud peligrosamente horizontal."

# game/game/afterstories.rpy:1499
translate es halafterstory_cb0f54d0:

    # n "I take the sunglasses putting them on."
    n "Tomo las gafas y me las pongo."

# game/game/afterstories.rpy:1501
translate es halafterstory_54bbbce4:

    # n "{color=#510f80} 'I feel like I could walk the runway in these.' {/color}"
    n "{color=#510f80}'Siento que podría caminar por la pasarela con estas.'{/color}"

# game/game/afterstories.rpy:1503
translate es halafterstory_646f3696:

    # n "I strut around and attempt to do a fashion spin, but the glasses get caught on the corner of the wall. They snap in two, with half still on my face."
    n "Camino haciendo un giro de moda, pero las gafas se enganchan con la esquina de la pared. Se rompen en dos, con la mitad aún en mi cara."

# game/game/afterstories.rpy:1505
translate es halafterstory_1011160a:

    # n "We keel over in laughter."
    n "Nos doblamos de la risa."

# game/game/afterstories.rpy:1507
translate es halafterstory_80001c9c:

    # n "{color=#61170f} 'Aww, are you guys having fun without me?' {/color}"
    n "{color=#61170f} 'Aww, ¿se están divirtiendo sin mí?' {/color}"

# game/game/afterstories.rpy:1509
translate es halafterstory_30bd6f0d:

    # n "Miles appears in the doorway."
    n "Miles aparece en la puerta."

# game/game/afterstories.rpy:1511
translate es halafterstory_56acaeff:

    # n "{color=#61170f} 'Whoa, sick fits! I gotta get styled too!' {/color}"
    n "{color=#61170f} '¡Whoa, qué facha! ¡Yo también quiero estilo!' {/color}"

# game/game/afterstories.rpy:1513
translate es halafterstory_c78ad3b5:

    # n "Miles scours the pile of clothing and lands on a harsh pink and green bodycon dress."
    n "Miles rebusca en el montón de ropa y elige un ajustado vestido rosa y verde chillón."

# game/game/afterstories.rpy:1515
translate es halafterstory_81519aa6:

    # n "He smiles deviously, fitting it narrowly over his jeans and sweatshirt."
    n "Sonríe con picardía, encajándoselo sobre sus jeans y sudadera."

# game/game/afterstories.rpy:1517
translate es halafterstory_bdf2613e:

    # n "{color=#61170f} 'Do I look pretty?' {/color}"
    n "{color=#61170f} '¿Estoy lindo?' {/color}"

# game/game/afterstories.rpy:1522
translate es halafterstory_04e323c6:

    # n "{color=#510f80} 'You are the prettiest Miles in the whole world!' {/color}"
    n "{color=#510f80} '¡Eres el Miles más lindo del mundo entero!' {/color}"

# game/game/afterstories.rpy:1524
translate es halafterstory_597f04ce:

    # n "Miles takes on a cutesy pose and a southern accent."
    n "Miles adopta una pose coqueta y un acento sureño."

# game/game/afterstories.rpy:1526
translate es halafterstory_67e3fcc1:

    # n "{color=#61170f} 'Aww shucks, y'all make me feel like a million bucks!' {/color}"
    n "{color=#61170f} 'Aww, me hacen sentir como un millón de dólares, cielos.' {/color}"

# game/game/afterstories.rpy:1528
translate es halafterstory_e61d08f3:

    # n "I walk over and put some all-too-large sunglasses onto Mile's face."
    n "Camino hacia él y le pongo unas gafas de sol demasiado grandes."

# game/game/afterstories.rpy:1530
translate es halafterstory_599d6cd6:

    # n "{color=#510f80} 'Now you are pretty {i}and{/i} mysterious!' {/color}"
    n "{color=#510f80} '¡Ahora eres lindo {i}y{/i} misterioso!' {/color}"

# game/game/afterstories.rpy:1532
translate es halafterstory_31b5e799:

    # n "{color=#61170f} 'Do you think I can seduce a widowed old man in these?' {/color}"
    n "{color=#61170f} '¿Crees que podría seducir a un anciano viudo con esto?' {/color}"

# game/game/afterstories.rpy:1534
translate es halafterstory_648dfdbf:

    # n "{color=#510f80} 'Seduce? Not sure. Rob a bank though? Definitely.' {/color}"
    n "{color=#510f80} '¿Seducir? No lo sé. ¿Robar un banco? Definitivamente.' {/color}"

# game/game/afterstories.rpy:1536
translate es halafterstory_5aed3224:

    # n "Miles looks off into the distance, deep in thought."
    n "Miles mira al horizonte, pensativo."

# game/game/afterstories.rpy:1538
translate es halafterstory_8b33ba6b:

    # n "{color=#61170f} 'Kinda the same thing if you think about it...'{/color}"
    n "{color=#61170f} 'Si lo piensas bien, es casi lo mismo...'{/color}"

# game/game/afterstories.rpy:1542
translate es halafterstory_4629136f:

    # n "{color=#510f80} 'Yeah, but not as pretty as Hal.' {/color}"
    n "{color=#510f80} 'Sí, pero no tan linde como Hal.' {/color}"

# game/game/afterstories.rpy:1544
translate es halafterstory_175d3c96:

    # n "{color=#61170f} 'Aww! you always take Hal's side!' {/color}, He pouts."
    n "{color=#61170f} '¡Aww! ¡Siempre te pones del lado de Hal!' {/color}"

# game/game/afterstories.rpy:1546
translate es halafterstory_790879d9:

    # n "{color=#1A5F38} 'Skill issue.' {/color}"
    n "{color=#1A5F38} 'Problema de habilidad.' {/color}"

# game/game/afterstories.rpy:1548
translate es halafterstory_070c4abe:

    # n "Miles moseys over to a pile of discarded clothing. He rifles through it and starts to dress himself in random things."
    n "Miles se acerca al montón de ropa descartada. Rebusca y empieza a vestirse con cosas al azar."

# game/game/afterstories.rpy:1550
translate es halafterstory_6df9cc64:

    # n "{color=#61170f} 'Okay! What about {i}now{/i}?' {/color}"
    n "{color=#61170f} '¡Bien! ¿Qué tal {i}ahora{/i}?' {/color}"

# game/game/afterstories.rpy:1552
translate es halafterstory_3c74b278:

    # n "Haley and I look at miles..."
    n "Haley y yo miramos a Miles..."

# game/game/afterstories.rpy:1554
translate es halafterstory_bcd7e54e:

    # n "His arms are covered in Rolexes up to his elbows and he sports the most obnoxious pair of sunglasses."
    n "Sus brazos están cubiertos de Rolexes hasta los codos y lleva las gafas de sol más llamativas que existen."

# game/game/afterstories.rpy:1556
translate es halafterstory_5cba1ed6:

    # n "Haley and I break out in laughter."
    n "Haley y yo estallamos en carcajadas."

# game/game/afterstories.rpy:1558
translate es halafterstory_adf3a681:

    # n "The three of us continue trying on clothing, joking, soon dancing and singing wearing ridiculous, coats, scarves, dresses, boots."
    n "Los tres seguimos probándonos ropa, bromeando, pronto bailando y cantando mientras usamos abrigos, bufandas, vestidos y botas ridículos."

# game/game/afterstories.rpy:1560
translate es halafterstory_c08844c3:

    # n "Haley spins me while we dance together, I lose my footing, tripping over a dress, or maybe a necklace. A large painting topples over as I bump into it, knocking it off of the wall."
    n "Haley me hace girar mientras bailamos juntes, pierdo el equilibrio, tropezando con un vestido, o tal vez con un collar. Un gran cuadro se tambalea cuando lo golpeo, cayendo de la pared."

# game/game/afterstories.rpy:1562
translate es halafterstory_a5c697a3:

    # n "Underneath the painting is a safe."
    n "Debajo del cuadro hay una caja fuerte."

# game/game/afterstories.rpy:1564
translate es halafterstory_d3ba2b97:

    # n "We all stare, shocked."
    n "Todos nos quedamos mirando, impactados."

# game/game/afterstories.rpy:1566
translate es halafterstory_3dff53d0:

    # n "{color=#510f80} 'Hey guys, I think we found it.' {/color}"
    n "{color=#510f80} 'Chicos, creo que la encontramos.' {/color}"

# game/game/afterstories.rpy:1568
translate es halafterstory_b10d30b2:

    # n "They look at the safe."
    n "Miran la caja fuerte."

# game/game/afterstories.rpy:1570
translate es halafterstory_1d346e0b:

    # n "{color=#1A5F38} 'That's definitely it.' {/color}"
    n "{color=#1A5F38} 'Definitivamente es esa.' {/color}"

# game/game/afterstories.rpy:1572
translate es halafterstory_67ca0732:

    # n "{color=#1A5F38} 'How much you wanna bet it's the same password?' {/color}"
    n "{color=#1A5F38} '¿Cuánto apuestan a que tiene la misma contraseña?' {/color}"

# game/game/afterstories.rpy:1574
translate es halafterstory_18841b2a:

    # n "{color=#510f80} 'The mistresses birthday...?' {/color}"
    n "{color=#510f80} '¿El cumpleaños de la amante...?' {/color}"

# game/game/afterstories.rpy:1576
translate es halafterstory_9851265e:

    # n "{color=#510f80} 'He wouldn't, that would be so-' {/color}"
    n "{color=#510f80} 'No lo haría, eso sería tan—' {/color}"

# game/game/afterstories.rpy:1578
translate es halafterstory_4627c746:

    # n "'Ka-Chunk'"
    n "'Ka-Chunk'"

# game/game/afterstories.rpy:1580
translate es halafterstory_3c4ac560:

    # n "{color=#510f80} '-Dumb....' {/color}"
    n "{color=#510f80} '—Estúpido....' {/color}"

# game/game/afterstories.rpy:1582
translate es halafterstory_72ad1eac:

    # n "Haley opens the safe, smiling confidently at me."
    n "Haley abre la caja fuerte, sonriéndome con confianza."

# game/game/afterstories.rpy:1584
translate es halafterstory_cec67c66:

    # n "They take out the documents sifting through them."
    n "Sacan los documentos y los revisan."

# game/game/afterstories.rpy:1586
translate es halafterstory_afa60f50:

    # n "{color=#1A5F38} 'This is it, we got him!' {/color}"
    n "{color=#1A5F38} 'Esto es, lo tenemos!' {/color}"

# game/game/afterstories.rpy:1588
translate es halafterstory_8f161ab1:

    # n "{color=#1A5F38} 'Lets pack it up and-' {/color}"
    n "{color=#1A5F38} 'Empaquemos y—' {/color}"

# game/game/afterstories.rpy:1590
translate es halafterstory_7db1c164:

    # n "A light flashes into the house from the driveway."
    n "Una luz ilumina la casa desde el camino de entrada."

# game/game/afterstories.rpy:1592
translate es halafterstory_5b3cb707:

    # n "{color=#1A5F38} 'Miles....when was the last time you checked the cameras...?' {/color}"
    n "{color=#1A5F38} 'Miles... ¿Cuándo fue la última vez que revisaste las cámaras...?' {/color}"

# game/game/afterstories.rpy:1594
translate es halafterstory_79c3c94c:

    # n "Miles holds up his phone, the screen is black."
    n "Miles levanta su teléfono, la pantalla está negra."

# game/game/afterstories.rpy:1596
translate es halafterstory_f03d7279:

    # n "{color=#61170f} 'Oh yeah, my phone kinda died.' {/color}"
    n "{color=#61170f} 'Ah sí, mi teléfono como que se murió.' {/color}"

# game/game/afterstories.rpy:1598
translate es halafterstory_c54a980b:

    # n "{color=#1A5F38} 'Fuck! We gotta go {i}now{/i}!' {/color}"
    n "{color=#1A5F38} '¡Maldición! ¡Tenemos que irnos {i}ahora{/i}!' {/color}"

# game/game/afterstories.rpy:1600
translate es halafterstory_b79290a2:

    # n "I gather up what I can of the valuables and we break into a sprint down the hallway, then the stairs. The light approaches, bouncing in the windows illuminating us."
    n "Recojo lo que puedo de los objetos de valor y corremos por el pasillo, luego por las escaleras. La luz se acerca, rebotando en las ventanas y revelándonos."

# game/game/afterstories.rpy:1602
translate es halafterstory_972ae0cc:

    # n "A string of curses spill from my lips as my legs carry me as fast as they can through the long hallways."
    n "Una cadena de maldiciones se escapa de mis labios mientras mis piernas me llevan tan rápido como pueden por los largos pasillos."

# game/game/afterstories.rpy:1604
translate es halafterstory_d4e52f7f:

    # n "As we finally make it to the back door, I hear the lock click on the front door."
    n "Cuando por fin llegamos a la puerta trasera, escucho el clic de la cerradura de la puerta principal."

# game/game/afterstories.rpy:1606
translate es halafterstory_4284385a:

    # n "Haley already has the car started as I hop in the back of the convertible."
    n "Haley ya tiene el auto encendido mientras salto al asiento trasero del descapotable."

# game/game/afterstories.rpy:1608
translate es halafterstory_02a91fbf:

    # n "We peel out of the back exit as the lights turn on in the house. My heart beating a hundred miles an hour."
    n "Salimos por la salida trasera justo cuando se encienden las luces de la casa. Mi corazón late a cien por hora."

# game/game/afterstories.rpy:1610
translate es halafterstory_36c0261c:

    # n "We hit the road with speed heading north into the night."
    n "Tomamos la carretera a toda velocidad rumbo al norte, en la noche."

# game/game/afterstories.rpy:1612
translate es halafterstory_1651b5de:

    # n "{color=#510f80} 'We did it....! Oh thank god, we did it!' {/color}"
    n "{color=#510f80} '¡Lo hicimos...! Oh, gracias a Dios, ¡lo hicimos!' {/color}"

# game/game/afterstories.rpy:1614
translate es halafterstory_e00f949a:

    # n "{color=#510f80} 'We did it!!' {/color}"
    n "{color=#510f80} '¡¡Lo hicimos!!' {/color}"

# game/game/afterstories.rpy:1616
translate es halafterstory_5a532162:

    # n "{color=#1A5F38} 'Hell yeah! WOO!!!' {/color}"
    n "{color=#1A5F38} '¡Diablos, sí! ¡WOO!!!' {/color}"

# game/game/afterstories.rpy:1618
translate es halafterstory_063aa9fb:

    # n "We celebrate and shout driving into the night."
    n "Celebramos y gritamos conduciendo en la noche."

# game/game/afterstories.rpy:1620
translate es halafterstory_201d8d23:

    # n "After a few hours we begin to slow as we drive through a small town."
    n "Después de unas horas comenzamos a reducir la velocidad al atravesar un pequeño pueblo."

# game/game/afterstories.rpy:1622
translate es halafterstory_dc73d33a:

    # n "{color=#1A5F38} 'Let's get some food and bowling.' {/color}"
    n "{color=#1A5F38} 'Vamos por comida y a jugar bolos.' {/color}"

# game/game/afterstories.rpy:1624
translate es halafterstory_7e1166af:

    # n "{color=#510f80} 'Bowling?' {/color}"
    n "{color=#510f80} '¿Bolos?' {/color}"

# game/game/afterstories.rpy:1626
translate es halafterstory_9c3fc8a8:

    # n "Haley pulls up to a large building labeled in neon lights as '24-hr Bowling and Diner'."
    n "Haley se detiene frente a un gran edificio con luces de neón que dicen 'Bolera y cafetería 24 horas'."

# game/game/afterstories.rpy:1628
translate es halafterstory_4187a467:

    # n "{color=#1A5F38} 'My treat tonight.'{/color}"
    n "{color=#1A5F38} 'Yo invito esta noche.' {/color}"

# game/game/afterstories.rpy:1630
translate es halafterstory_e61e41b0:

    # n "Haley swivels their head, looking at both Miles and I."
    n "Haley gira la cabeza, mirándonos a Miles y a mí."

# game/game/afterstories.rpy:1632
translate es halafterstory_8447930f:

    # n "{color=#1A5F38} 'You guys aren't tired yet right?' {/color}"
    n "{color=#1A5F38} 'No están cansados aún, ¿verdad?' {/color}"

# game/game/afterstories.rpy:1634
translate es halafterstory_628da1f1:

    # n "{color=#61170f} 'Bowling!! I love bowling!' {/color}"
    n "{color=#61170f} '¡Bolos!! ¡Me encantan los bolos!' {/color}"

# game/game/afterstories.rpy:1636
translate es halafterstory_d258bea0:

    # n "Miles gives a small 'whoop!' and eagerly jogs towards the building."
    n "Miles suelta un pequeño '¡woo!' y corre entusiasmado hacia el edificio."

# game/game/afterstories.rpy:1638
translate es halafterstory_dcab2bc2:

    # n "{color=#510f80} 'Bowling it is then!' {/color}"
    n "{color=#510f80} 'Entonces bolos será!' {/color}"

# game/game/afterstories.rpy:1640
translate es halafterstory_584ba65f:

    # n "Haley strips their cat suit, changing into their usual fit. We walk into the bowling and diner combo. Surprisingly, it is quite busy."
    n "Haley se quita el traje de gato, cambiándose a su atuendo habitual. Entramos al local combinado de bolera y cafetería. Sorprendentemente, está bastante concurrido."

# game/game/afterstories.rpy:1642
translate es halafterstory_2494300a:

    # n "The usual patrons and workers seem to know Haley fondly, offering them free food and lanes."
    n "Los clientes habituales y empleados parecen conocer a Haley con cariño, ofreciéndoles comida y pistas gratis."

# game/game/afterstories.rpy:1644
translate es halafterstory_60609dda:

    # n "Haley turns them down, insisting on paying for our group."
    n "Haley los rechaza, insistiendo en pagar por el grupo."

# game/game/afterstories.rpy:1646
translate es halafterstory_f90f178d:

    # n "We walk up to the lane that has a small table in the back."
    n "Nos dirigimos a la pista que tiene una pequeña mesa al fondo."

# game/game/afterstories.rpy:1648
translate es halafterstory_9d176101:

    # n "{color=#1A5F38} 'I ordered us a bit of everything.' {/color}"
    n "{color=#1A5F38} 'Pedí un poco de todo.' {/color}"

# game/game/afterstories.rpy:1650
translate es halafterstory_4ba5dba3:

    # n "Haley gets up and stretches."
    n "Haley se levanta y se estira."

# game/game/afterstories.rpy:1652
translate es halafterstory_85580ee6:

    # n "{color=#1A5F38} 'So, who's ready to get beat?' {/color}"
    n "{color=#1A5F38} 'Entonces, ¿quién está listo para perder?' {/color}"

# game/game/afterstories.rpy:1654
translate es halafterstory_eadb4038:

    # n "Haley then types their name into the digital scoreboard."
    n "Haley escribe su nombre en el marcador digital."

# game/game/afterstories.rpy:1656
translate es halafterstory_d57f9f58:

    # n "Miles hops up also typing his name into the scoreboard."
    n "Miles se levanta también y escribe su nombre en el marcador."

# game/game/afterstories.rpy:1658
translate es halafterstory_d512185f:

    # n "I follow, typing my name in the scoreboard as well."
    n "Yo le sigo, escribiendo el mío."

# game/game/afterstories.rpy:1660
translate es halafterstory_f2dd0b3f:

    # n "We start to bowl. Halfway through the game our food arrives onto the table and we take a quick break to eat."
    n "Comenzamos a jugar. A mitad de la partida llega la comida y hacemos una pausa para comer."

# game/game/afterstories.rpy:1662
translate es halafterstory_c32f1595:

    # n "I didn't realize how hungry I have gotten."
    n "No me había dado cuenta del hambre que tenia."

# game/game/afterstories.rpy:1664
translate es halafterstory_f0c2a902:

    # n "Miles takes out his phone and snaps a picture of his arm covered in Rolexes in front of the pancakes."
    n "Miles saca su teléfono y toma una foto de su brazo lleno de Rolexes frente a los panqueques."

# game/game/afterstories.rpy:1666
translate es halafterstory_1727df9b:

    # n "{color=#1A5F38} 'Miles, you aren't posting that on the internet right...?' {/color}"
    n "{color=#1A5F38} 'Miles, no estarás subiendo eso a internet, ¿verdad...?' {/color}"

# game/game/afterstories.rpy:1668
translate es halafterstory_8d46e573:

    # n "{color=#61170f} 'Naw, dad was wondering how the lessons were going.' {/color}"
    n "{color=#61170f} 'Nah, papá quería saber cómo iban las lecciones.' {/color}"

# game/game/afterstories.rpy:1670
translate es halafterstory_b003c705:

    # n "{color=#1A5F38} 'Miles don't-' {/color}"
    n "{color=#1A5F38} 'Miles, no—' {/color}"

# game/game/afterstories.rpy:1672
translate es halafterstory_8140ad13:

    # n "{color=#61170f} 'Oh, dad said he is gonna give you a bonus!' {/color}"
    n "{color=#61170f} 'Oh, ¡papá dijo que te va a dar un bono!' {/color}"

# game/game/afterstories.rpy:1674
translate es halafterstory_9a3df752:

    # n "{color=#1A5F38} 'Never mind then! Carry on.'{/color}"
    n "{color=#1A5F38} 'Entonces olvídalo. Adelante.' {/color}"

# game/game/afterstories.rpy:1676
translate es halafterstory_87a606bf:

    # n "I chew on some food thoughtfully."
    n "Mastico la comida pensativamente."

# game/game/afterstories.rpy:1678
translate es halafterstory_c1a74419:

    # n "{color=#510f80} 'Miles, your dad really wants you to become a villain huh?' {/color}"
    n "{color=#510f80} 'Miles, ¿tu papá realmente quiere que te conviertas en villano, eh?' {/color}"

# game/game/afterstories.rpy:1680
translate es halafterstory_3e7887b8:

    # n "{color=#61170f} 'Yeah, he says it's in our blood. But I'm like 'That's your dream dad not mine!' ' {/color}"
    n "{color=#61170f} 'Sí, dice que está en nuestra sangre. Pero yo le digo '¡Ese es tu sueño, papá, no el mío!'' {/color}"

# game/game/afterstories.rpy:1682
translate es halafterstory_3e78d3b9:

    # n "{color=#61170f} 'The old man says I'm a disgrace to the family, but he just doesn't get it. Villains just aren't cool!' {/color}"
    n "{color=#61170f} 'El viejo dice que soy una desgracia para la familia, pero no lo entiende. ¡Los villanos ya no son geniales!' {/color}"

# game/game/afterstories.rpy:1684
translate es halafterstory_6367ee24:

    # n "{color=#61170f} 'I wanna help people...' {/color}"
    n "{color=#61170f} 'Yo quiero ayudar a la gente...' {/color}"

# game/game/afterstories.rpy:1686
translate es halafterstory_9b717601:

    # n "Mile's usual cheery demeanor shrinks and he hunches over staring thoughtfully at the pancake in front of him.."
    n "El habitual ánimo alegre de Miles se desvanece y se encorva, mirando pensativamente el panqueque frente a él."

# game/game/afterstories.rpy:1688
translate es halafterstory_32ed7178:

    # n "A sympathetic look moves across Hal's face."
    n "Una expresión de simpatía cruza el rostro de Hal."

# game/game/afterstories.rpy:1690
translate es halafterstory_b53a29b9:

    # n "{color=#1A5F38} 'Ah, don't worry about it too much Miles! Maybe if we work hard we can show him that it's not realistic for you to be a villain.'{/color}"
    n "{color=#1A5F38} 'Ah, no te preocupes tanto por eso, Miles. Tal vez si trabajamos duro podamos mostrarle que no es realista que seas un villano.' {/color}"

# game/game/afterstories.rpy:1692
translate es halafterstory_ccf5c6ce:

    # n "{color=#61170f} 'Really...?' {/color}"
    n "{color=#61170f} '¿En serio...?' {/color}"

# game/game/afterstories.rpy:1694
translate es halafterstory_6cc4066a:

    # n "Hal smiles."
    n "Hal sonríe."

# game/game/afterstories.rpy:1696
translate es halafterstory_d5e9db35:

    # n "{color=#1A5F38} 'Yeah, but let's not think about that for now. We got some bowling to do!'{/color}"
    n "{color=#1A5F38} 'Sí, pero no pensemos en eso ahora. ¡Tenemos unos bolos que jugar!' {/color}"

# game/game/afterstories.rpy:1698
translate es halafterstory_ae0ed5f7:

    # n "Miles instantly cheers up, shooting forward from his seat to the lane."
    n "Miles se anima al instante, lanzándose desde su asiento hacia la pista."

# game/game/afterstories.rpy:1700
translate es halafterstory_6a460c96:

    # n "Despite how much they tend to bicker, Haley does seem to know how to cheer Miles up."
    n "A pesar de lo mucho que suelen discutir, Haley parece saber cómo animar a Miles."

# game/game/afterstories.rpy:1702
translate es halafterstory_f1cafa54:

    # n "He walks over and grabs a bowling ball hurling it down the lane with a surprising amount of precision."
    n "Él camina y toma una bola de bolos lanzándola por la pista con una precisión sorprendente."

# game/game/afterstories.rpy:1704
translate es halafterstory_fc343db0:

    # n "Miles scores a strike and Haley and I cheer for him. He looks so proud of himself."
    n "Miles hace un strike y Haley y yo lo animamos. Se ve tan orgulloso de sí mismo."

# game/game/afterstories.rpy:1706
translate es halafterstory_b065a2dd:

    # n "I look at Haley, I can tell they are genuinely enjoying themselves."
    n "Miro a Haley, puedo notar que realmente está disfrutando el momento."

# game/game/afterstories.rpy:1708
translate es halafterstory_eac1b0ee:

    # n "Close to 4am in a diner that features both pancakes and bowling, something close to peace travels over me and I can't help but to smile too."
    n "Cerca de las 4 de la mañana, en una cafetería que tiene panqueques y bolos, algo parecido a la paz me invade y no puedo evitar sonreír también."

# game/game/afterstories.rpy:1710
translate es halafterstory_2b63ec6f:

    # n "In this moment life felt so beautiful, felt so perfect."
    n "En ese momento la vida se sentía tan hermosa, tan perfecta."

# game/game/afterstories.rpy:1712
translate es halafterstory_9d64b1c1:

    # n "And I won't tell Miles that it was actually my turn that he threw that strike on..."
    n "Y no le diré a Miles que en realidad era mi turno cuando lanzó ese strike..."

# game/game/afterstories.rpy:1714
translate es halafterstory_59118fed:

    # n "Eventually we finish our game and our food. Miles was... unexpectedly proficient at bowling."
    n "Finalmente terminamos nuestro juego y la comida. Miles resultó ser... sorprendentemente bueno en los bolos."

# game/game/afterstories.rpy:1716
translate es halafterstory_bf22b8a5:

    # n "We leave the diner behind us as we drive out into the day. The sunrise greets us as the road paves our way forward to our next town. To our next adventure."
    n "Dejamos atrás la cafetería mientras conducimos hacia el día. El amanecer nos saluda mientras la carretera nos guía hacia el siguiente pueblo. Hacia nuestra próxima aventura."

# game/game/afterstories.rpy:1718
translate es halafterstory_473fb906:

    # n "Part of me never wants this beautiful moment to change."
    n "Una parte de mí nunca quiere que este hermoso momento cambie."

translate es strings:

    old "'I think I had a nightmare...'"
    new "'Creo que tuve una pesadilla...'"

    old "'I slept well.'"
    new "'Dormí bien.'"

    old "'No'"
    new "'No'"

    old "Kiss him"
    new "Besarlo"

    old "'Do your best today.'"
    new "'Haz lo mejor que puedas hoy.'"

    old "'Yes'"
    new "'Sí'"

    old "'What happened to the other heroes?'"
    new "'¿Qué pasó con los otros héroes?'"

    old "'Will the Aliens stop at just this city?'"
    new "'¿Los alienígenas se detendrán solo en esta ciudad?'"

    old "Scared"
    new "Miedo"

    old "Sad"
    new "Tristeza"

    old "'Ray please save them!'"
    new "'¡Ray, por favor, sálvalos!'"

    old "'What if it's not just us..?'"
    new "'¿Y si no somos solo nosotros...?'"

    old "Glare at him"
    new "Mirarlo con furia"

    old "Ignore him"
    new "Ignorarlo"

    old "'I'm sorry...'"
    new "'Lo siento...'"

    old "'Remind me, bitch.'"
    new "'Recuérdamelo, perra.'"

    old "Wrist"
    new "Muñeca"

    old "Outside hip"
    new "Cadera exterior"

    old "Indignant"
    new "Con indignación"

    old "Regret"
    new "Con arrepentimiento"

    old "'You are the prettiest Miles in the whole world!'"
    new "'¡Eres el Miles más hermoso del mundo entero!'"

    old "'Yeah, but not as pretty as Hal...'"
    new "'Sí, pero no tan hermose como Hal...'"

    old "What did they call me in the criminal underworld?"
    new "¿Cómo me llamaban en el mundo del crimen?"

    old "My name?"
    new "¿Mi nombre?"
